"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import KitAssignmentPanel from "./KitAssignmentPanel";

const MAX_SCREENSHOT_SIZE_BYTES = 8 * 1024 * 1024;
function normalizeDetectedPlayerName(value) {
  return String(value || "")
    .toLowerCase()
    .replace(/\(wk\)/gi, "")
    .replace(/\(c\)/gi, "")
    .replace(/[^a-z0-9]+/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function findMatchingDatabasePlayer(
  detectedName,
  databasePlayers
) {
  const normalizedDetectedName =
    normalizeDetectedPlayerName(
      detectedName
    );

  if (!normalizedDetectedName) {
    return null;
  }

  return (
    databasePlayers.find(
      (databasePlayer) =>
        normalizeDetectedPlayerName(
          databasePlayer?.name
        ) === normalizedDetectedName
    ) || null
  );
}
function createTemporaryPlayer(name = "") {
  return {
    clientId:
      typeof crypto !== "undefined" &&
      typeof crypto.randomUUID === "function"
        ? crypto.randomUUID()
        : `${Date.now()}-${Math.random()}`,

    displayName: name,
    included: true,
    playerId: "",
    whatsappNumber: "",
    whatsappOptIn: false,
    matchStatus: "UNMATCHED",
  };
}

function createDetectedPlayer({
  name,
  databasePlayers,
  isLeaguePlayerMode,
}) {
  const temporaryPlayer =
    createTemporaryPlayer(name);

  /*
   * Surprise League uses the screenshot name as the
   * person identity, because the same roster is stored
   * beneath both Surprise teams.
   */
  if (isLeaguePlayerMode) {
    return temporaryPlayer;
  }

  const matchedDatabasePlayer =
    findMatchingDatabasePlayer(
      name,
      databasePlayers
    );

  if (!matchedDatabasePlayer) {
    return temporaryPlayer;
  }

  return {
    ...temporaryPlayer,

    displayName:
      matchedDatabasePlayer.name,

    playerId:
      String(
        matchedDatabasePlayer.id
      ),

    matchStatus: "MATCHED",
  };
}

function normalizeMatchStatus(value) {
  return String(value || "")
    .trim()
    .replace(/[\s-]+/g, "_")
    .toUpperCase();
}

function isAvailableMatch(match) {
  const status = normalizeMatchStatus(match?.status);

  return [
    "SCHEDULED",
    "ACTIVE",
    "LIVE",
    "IN_PROGRESS",
    "STARTED",
  ].includes(status);
}

function getMatchTeamName(match, side) {
  if (side === "A") {
    return (
      match?.teamA?.name ||
      match?.teamAName ||
      "Team A"
    );
  }

  return (
    match?.teamB?.name ||
    match?.teamBName ||
    "Team B"
  );
}

function getMatchTeamId(match, side) {
  if (side === "A") {
    return (
      match?.teamAId ||
      match?.teamA?.id ||
      ""
    );
  }

  return (
    match?.teamBId ||
    match?.teamB?.id ||
    ""
  );
}

function formatMatchDate(value) {
  if (!value) {
    return "Date not scheduled";
  }

  const parsedDate = new Date(value);

  if (Number.isNaN(parsedDate.getTime())) {
    return "Date not scheduled";
  }

  return parsedDate.toLocaleString([], {
    month: "short",
    day: "numeric",
    year: "numeric",
    hour: "numeric",
    minute: "2-digit",
  });
}

function PlayerReviewRow({
  player,
  index,
  teamPlayers,
  isLeaguePlayerMode,
  sourceMode = "SCREENSHOT",
  onChange,
  onRemove,
}) {
  const isTeamRosterMode =
    sourceMode === "TEAM_ROSTER";

  const matchedPlayer = teamPlayers.find(
    (candidate) =>
      String(candidate.id) ===
      String(player.playerId)
  );

  return (
    <div
      className={`kit-player-review-row ${
        isLeaguePlayerMode
          ? "kit-player-review-row-league-mode"
          : ""
      } ${
        isTeamRosterMode
          ? "kit-player-review-row-roster-mode"
          : ""
      }`}
    >
      <label className="kit-player-include">
        <input
          type="checkbox"
          checked={player.included}
          onChange={(event) =>
            onChange({
              included: event.target.checked,
            })
          }
        />

        <span>
          {player.included
            ? "Included"
            : "Excluded"}
        </span>
      </label>

      <div className="kit-player-number">
        {index + 1}
      </div>

      {isTeamRosterMode ? (
        <>
          <div className="kit-roster-player-cell">
            <label className="kit-mobile-field-label">
              Player
            </label>

            <div className="kit-roster-player-identity">
              <span className="kit-roster-avatar" aria-hidden="true">
                {String(player.displayName || "P")
                  .trim()
                  .charAt(0)
                  .toUpperCase() || "P"}
              </span>

              <span>
                <strong>
                  {player.displayName || "Unnamed player"}
                </strong>
                <small>Registered Cric4All player</small>
              </span>
            </div>
          </div>

          <div className="kit-player-match-status is-registered">
            <span
              className="kit-player-match-status-dot"
              aria-hidden="true"
            />
            <span>Registered</span>
          </div>
        </>
      ) : (
        <>
          <div className="kit-player-field kit-screenshot-name-cell">
            <label className="kit-mobile-field-label">
              Screenshot name
            </label>

            <input
              type="text"
              value={player.displayName}
              placeholder="Enter player name"
              onChange={(event) =>
                onChange({
                  displayName: event.target.value,
                  playerId: "",
                  matchStatus: "UNMATCHED",
                })
              }
            />
          </div>
{!isLeaguePlayerMode && (
  <div className="kit-player-field kit-player-match-cell">
              <label className="kit-mobile-field-label">
                Cric4All player
              </label>

              <select
                value={player.playerId}
                onChange={(event) => {
                  const nextPlayerId =
                    event.target.value;

                  const selectedPlayer =
                    teamPlayers.find(
                      (candidate) =>
                        String(candidate.id) ===
                        String(nextPlayerId)
                    );

                  onChange({
                    playerId: nextPlayerId,
                    displayName:
                      selectedPlayer?.name ||
                      player.displayName,
                    matchStatus: nextPlayerId
                      ? "MATCHED"
                      : "UNMATCHED",
                  });
                }}
              >
                <option value="">
                  Continue with screenshot name
                </option>

                {teamPlayers.map((candidate) => (
                  <option
                    key={candidate.id}
                    value={candidate.id}
                  >
                    {candidate.name}
                  </option>
                ))}
              </select>
            </div>
          )}

          {!isLeaguePlayerMode ? (
            <div
              className={`kit-player-match-status ${
                matchedPlayer
                  ? "is-matched"
                  : "is-unmatched"
              }`}
            >
              <span
                className="kit-player-match-status-dot"
                aria-hidden="true"
              />
              <span>
                {matchedPlayer
                  ? "Matched"
                  : "Not matched"}
              </span>
            </div>
          ) : (
            <div className="kit-player-match-status is-screenshot">
              <span
                className="kit-player-match-status-dot"
                aria-hidden="true"
              />
              <span>Screenshot identity</span>
            </div>
          )}
        </>
      )}

      <button
        type="button"
        className="kit-remove-player-btn"
        onClick={onRemove}
        aria-label={`Remove ${
          player.displayName || "player"
        }`}
        title="Remove player"
      >
        ✕
      </button>
    </div>
  );
}

function TeamPlayerReview({
  title,
  teamId,
  players,
  databasePlayers,
  isLeaguePlayerMode,
  newPlayerName,
  onNewPlayerNameChange,
  onAddPlayer,
  onUpdatePlayer,
  onRemovePlayer,
  onSetAllIncluded,
  sourceMode = "SCREENSHOT",
}) {
  const isTeamRosterMode =
    sourceMode === "TEAM_ROSTER";

  const includedCount = players.filter(
    (player) => player.included
  ).length;

  return (
    <details
      className={`kit-team-review-card kit-team-review-details ${
        isTeamRosterMode
          ? "kit-team-review-card-roster"
          : ""
      }`}
    >
      <summary className="kit-team-review-summary">
        <div className="kit-team-review-summary-main">
          <span className="kit-team-review-icon">
            👥
          </span>

          <div>
            <span className="kit-team-kicker">
              {isTeamRosterMode
                ? "Registered playing roster"
                : "Detected playing team"}
            </span>

            <h4>{title}</h4>

            <small>
              {includedCount} selected of {players.length}
            </small>
          </div>
        </div>

        <div className="kit-team-review-summary-actions">
          <button
            type="button"
            className="kit-team-bulk-btn"
            disabled={players.length === 0}
            onClick={(event) => {
              event.preventDefault();
              event.stopPropagation();
              onSetAllIncluded?.(false);
            }}
          >
            Clear All
          </button>

          <button
            type="button"
            className="kit-team-bulk-btn"
            disabled={players.length === 0}
            onClick={(event) => {
              event.preventDefault();
              event.stopPropagation();
              onSetAllIncluded?.(true);
            }}
          >
            Select All
          </button>

          <span className="kit-player-count-badge">
            {includedCount}
          </span>

          <span
            className="kit-team-review-chevron"
            aria-hidden="true"
          >
            ⌄
          </span>
        </div>
      </summary>

      <div className="kit-team-review-body">
      <div className="kit-add-player-row">
        <input
          type="text"
          value={newPlayerName}
          placeholder={`Add a player to ${title}`}
          onChange={(event) =>
            onNewPlayerNameChange(
              event.target.value
            )
          }
          onKeyDown={(event) => {
            if (event.key === "Enter") {
              event.preventDefault();
              onAddPlayer();
            }
          }}
        />

        <button
          type="button"
          className="btn btn-outline"
          onClick={onAddPlayer}
        >
          ＋ Add Player
        </button>
      </div>

      {players.length === 0 ? (
        <div className="kit-empty-player-list">
          <span className="kit-empty-player-icon" aria-hidden="true">
            {isTeamRosterMode ? "👥" : "📋"}
          </span>
          <strong>
            {isTeamRosterMode
              ? "Load the selected team roster to continue."
              : "No player names available yet."}
          </strong>
          <p>
            {isTeamRosterMode
              ? "Registered players will appear here as a clean checklist—no screenshot matching required."
              : "Upload and read a screenshot, or manually add players using the field above."}
          </p>
        </div>
      ) : (
        <div className="kit-player-review-list">
          <div
            className={`kit-player-review-columns ${
              isLeaguePlayerMode
                ? "kit-player-review-columns-league-mode"
                : ""
            } ${
              isTeamRosterMode
                ? "kit-player-review-columns-roster-mode"
                : ""
            }`}
          >
            <span>Included</span>
            <span>#</span>

            {isTeamRosterMode ? (
              <span>Player</span>
            ) : (
              <>
                <span>Screenshot name</span>
                {!isLeaguePlayerMode && (
                  <span>Cric4All player</span>
                )}
              </>
            )}

            <span>Status</span>
            <span aria-label="Remove" />
          </div>

          {players.map((player, index) => (
            <PlayerReviewRow
              key={player.clientId}
              player={player}
              index={index}
              teamPlayers={databasePlayers}
              isLeaguePlayerMode={isLeaguePlayerMode}
              sourceMode={sourceMode}
              onChange={(changes) =>
                onUpdatePlayer(
                  player.clientId,
                  changes
                )
              }
              onRemove={() =>
                onRemovePlayer(player.clientId)
              }
            />
          ))}
        </div>
      )}
      </div>
    </details>
  );
}

export default function KitResponsibilitySetup({
  matches = [],
  teams = [],
  selectedMatchId = "",
  onSelectedMatchIdChange,
  activeLeague,
  rotationMode = "TEAM",
}) {
  const fileInputRef = useRef(null);

  const [screenshotFile, setScreenshotFile] =
    useState(null);

  const [screenshotPreviewUrl, setScreenshotPreviewUrl] =
    useState("");

  const [screenshotError, setScreenshotError] =
    useState("");

  const [kitMessage, setKitMessage] =
    useState("");

  const [isReadingScreenshot, setIsReadingScreenshot] =
    useState(false);

  const [screenshotOrientation, setScreenshotOrientation] =
    useState("LEFT_TEAM_A");

  const [teamAPlayers, setTeamAPlayers] =
    useState([]);

  const [teamBPlayers, setTeamBPlayers] =
    useState([]);

  const [newTeamAPlayerName, setNewTeamAPlayerName] =
    useState("");

  const [newTeamBPlayerName, setNewTeamBPlayerName] =
    useState("");

  const [isSavingPlayerLists, setIsSavingPlayerLists] =
    useState(false);

  const [
    kitAssignmentRefreshKey,
    setKitAssignmentRefreshKey,
  ] = useState(0);

  const [kitInputMode, setKitInputMode] =
  useState("TEAM_ROSTER");

const [
  selectedRosterTeamId,
  setSelectedRosterTeamId,
] = useState("");

const [
  isLoadingTeamRoster,
  setIsLoadingTeamRoster,
] = useState(false);

const [
  pickupAssignment,
  setPickupAssignment,
] = useState(null);

const [
  pickupStatus,
  setPickupStatus,
] = useState("PENDING");

const [
  actualCarrierMatchPlayerId,
  setActualCarrierMatchPlayerId,
] = useState("");

const [
  actualCarrierRotationMemberId,
  setActualCarrierRotationMemberId,
] = useState("");

const [
  actualCarrierName,
  setActualCarrierName,
] = useState("");

const [
  isSavingPickup,
  setIsSavingPickup,
] = useState(false);

const [
  pickupError,
  setPickupError,
] = useState("");

const [
  pickupSuccess,
  setPickupSuccess,
] = useState("");

const [
  eligibleKitPlayers,
  setEligibleKitPlayers,
] = useState([]);

const isLeaguePlayerMode =
  String(rotationMode || "")
    .trim()
    .toUpperCase() ===
  "LEAGUE_PLAYER";


const normalizedActiveLeagueName =
  String(
    activeLeague?.name || ""
  )
    .trim()
    .replace(/\s+/g, " ")
    .toLowerCase();

const isSurpriseCricketLeague =
  normalizedActiveLeagueName ===
  "surprise cricket league";

/*
 * Surprise Cricket League is the explicit one-kit exception.
 * LEAGUE_PLAYER remains supported as the scalable configuration.
 */
const useOneSharedCarrier =
  isSurpriseCricketLeague ||
  isLeaguePlayerMode;

  const availableMatches = useMemo(
    () => matches.filter(isAvailableMatch),
    [matches]
  );

  /*
   * The shared kit always follows the earliest available
   * upcoming match. Users can still change the match, but
   * the normal workflow requires no match selection.
   */
  useEffect(() => {
    if (
      selectedMatchId ||
      availableMatches.length === 0 ||
      typeof onSelectedMatchIdChange !==
        "function"
    ) {
      return;
    }

    const sortedMatches = [
      ...availableMatches,
    ].sort((left, right) => {
      const leftTime =
        new Date(
          left.scheduledAt ||
            left.matchDate ||
            left.createdAt
        ).getTime();

      const rightTime =
        new Date(
          right.scheduledAt ||
            right.matchDate ||
            right.createdAt
        ).getTime();

      const safeLeft =
        Number.isFinite(leftTime)
          ? leftTime
          : Number.MAX_SAFE_INTEGER;

      const safeRight =
        Number.isFinite(rightTime)
          ? rightTime
          : Number.MAX_SAFE_INTEGER;

      return safeLeft - safeRight;
    });

    const nextMatch =
      sortedMatches[0];

    if (nextMatch?.id) {
      onSelectedMatchIdChange(
        String(nextMatch.id)
      );
    }
  }, [
    availableMatches,
    onSelectedMatchIdChange,
    selectedMatchId,
  ]);

  const selectedMatch = useMemo(
    () =>
      matches.find(
        (match) =>
          String(match.id) ===
          String(selectedMatchId)
      ) || null,
    [matches, selectedMatchId]
  );
  const teamAName = getMatchTeamName(
    selectedMatch,
    "A"
  );

  const teamBName = getMatchTeamName(
    selectedMatch,
    "B"
  );

  const teamAId = getMatchTeamId(
    selectedMatch,
    "A"
  );

  const teamBId = getMatchTeamId(
    selectedMatch,
    "B"
  );

  const selectedMatchTeams = useMemo(() => {
  if (!selectedMatch) {
    return [];
  }

  return [
    {
      id: Number(teamAId),
      name: teamAName,
      side: "A",
      players:
        selectedMatch?.teamA?.players ||
        [],
    },
    {
      id: Number(teamBId),
      name: teamBName,
      side: "B",
      players:
        selectedMatch?.teamB?.players ||
        [],
    },
  ].filter(
    (team) =>
      Number.isInteger(team.id) &&
      team.id > 0
  );
}, [
  selectedMatch,
  teamAId,
  teamBId,
  teamAName,
  teamBName,
]);

const selectedRosterTeam =
  selectedMatchTeams.find(
    (team) =>
      String(team.id) ===
      String(selectedRosterTeamId)
  ) || null;

  const teamADatabasePlayers =
    selectedMatch?.teamA?.players || [];

  const teamBDatabasePlayers =
    selectedMatch?.teamB?.players || [];

  useEffect(() => {
    return () => {
      if (screenshotPreviewUrl) {
        URL.revokeObjectURL(
          screenshotPreviewUrl
        );
      }
    };
  }, [screenshotPreviewUrl]);

  useEffect(() => {
    clearImportedScreenshotData({
      preserveSelectedMatch: true,
    });
  }, [selectedMatchId]);

useEffect(() => {
  setSelectedRosterTeamId("");
  setTeamAPlayers([]);
  setTeamBPlayers([]);
  setScreenshotError("");
  setKitMessage("");

  setPickupAssignment(null);
  setPickupStatus("PENDING");
  setActualCarrierMatchPlayerId("");
  setActualCarrierRotationMemberId("");
  setActualCarrierName("");
  setPickupError("");
  setPickupSuccess("");
  setEligibleKitPlayers([]);
}, [selectedMatchId]);

async function saveKitPickup() {
  if (!pickupAssignment?.id) {
    setPickupError(
      "No kit assignment was selected."
    );

    return;
  }

  if (
    pickupStatus !== "TOOK_KIT" &&
    pickupStatus !==
      "DID_NOT_TAKE_KIT"
  ) {
    setPickupError(
      "Select what happened to the kit after the match."
    );

    return;
  }

  if (
    pickupStatus === "TOOK_KIT" &&
    !actualCarrierName.trim()
  ) {
    setPickupError(
      "Select or enter the person who actually took the kit."
    );

    return;
  }

  setIsSavingPickup(true);
  setPickupAssignment(null);
  setPickupStatus("PENDING");
  setActualCarrierMatchPlayerId("");
  setActualCarrierName("");
  setPickupError("");
  setPickupSuccess("");

  try {
    const response = await fetch(
      `/api/kit-assignments/${pickupAssignment.id}/pickup`,
      {
        method: "PATCH",

        headers: {
          "Content-Type":
            "application/json",
        },

        body: JSON.stringify({
          pickupStatus,

          actualRotationMemberId:
            pickupStatus === "TOOK_KIT" &&
            actualCarrierRotationMemberId
              ? Number(
                  actualCarrierRotationMemberId
                )
              : null,

          actualMatchKitPlayerId:
            pickupStatus === "TOOK_KIT" &&
            actualCarrierMatchPlayerId
              ? Number(
                  actualCarrierMatchPlayerId
                )
              : null,

          actualDisplayName:
            pickupStatus === "TOOK_KIT"
              ? actualCarrierName.trim()
              : null,
        }),
      }
    );

    const data = await response.json();

    if (!response.ok) {
      throw new Error(
        data?.error ||
          "Unable to save kit pickup."
      );
    }

    setPickupSuccess(
      data?.message ||
        "Kit pickup saved successfully."
    );

    /*
     * Replace this with the name of your
     * existing assignment reload function.
     */
/*
 * Refresh KitAssignmentPanel after the pickup
 * result has been saved.
 */
setKitAssignmentRefreshKey(
  (previous) => previous + 1
);

window.setTimeout(() => {
  closeKitPickupForm();
}, 700);
  } catch (error) {
    setPickupError(
      error?.message ||
        "Unable to save kit pickup."
    );
  } finally {
    setIsSavingPickup(false);
  }
}

function openKitPickupForm(assignment) {
  setPickupAssignment(assignment);

  setPickupStatus(
    assignment?.pickupStatus ||
      "PENDING"
  );

  setActualCarrierRotationMemberId(
    assignment?.actualRotationMemberId
      ? String(
          assignment.actualRotationMemberId
        )
      : ""
  );

  setActualCarrierMatchPlayerId(
    assignment?.actualMatchKitPlayerId
      ? String(
          assignment.actualMatchKitPlayerId
        )
      : ""
  );

  setActualCarrierName(
    assignment?.actualDisplayName || ""
  );

  setPickupError("");
  setPickupSuccess("");
}

function closeKitPickupForm() {
  if (isSavingPickup) {
    return;
  }

  setPickupAssignment(null);
  setPickupStatus("PENDING");
  setActualCarrierRotationMemberId("");
  setActualCarrierMatchPlayerId("");
  setActualCarrierName("");
  setPickupError("");
  setPickupSuccess("");
}

function selectAssignedPersonAsCarrier() {
  if (!pickupAssignment) {
    return;
  }

  const assignedMember =
    pickupAssignment.rotationMember;

  setPickupStatus("TOOK_KIT");

  setActualCarrierRotationMemberId(
    assignedMember?.id
      ? String(assignedMember.id)
      : ""
  );

  const matchingMatchPlayer =
    eligibleKitPlayers.find(
      (player) =>
        Number(player.playerId) > 0 &&
        Number(player.playerId) ===
          Number(assignedMember?.playerId)
    );

  setActualCarrierMatchPlayerId(
    matchingMatchPlayer?.id
      ? String(matchingMatchPlayer.id)
      : ""
  );

  setActualCarrierName(
    assignedMember?.displayName || ""
  );

  setPickupError("");
}

function handleActualCarrierPlayerChange(
  event
) {
  const selectedId = event.target.value;

  setActualCarrierMatchPlayerId(
    selectedId
  );

  const selectedPlayer =
    eligibleKitPlayers.find(
      (player) =>
        String(player.id) ===
        String(selectedId)
    );

  if (!selectedPlayer) {
    setActualCarrierRotationMemberId("");
    return;
  }

  setActualCarrierName(
    selectedPlayer.displayName || ""
  );

  /*
   * Use this when your GET response also
   * returns rotationMemberId on each player.
   */
  setActualCarrierRotationMemberId(
    selectedPlayer.rotationMemberId
      ? String(
          selectedPlayer.rotationMemberId
        )
      : ""
  );

  setPickupStatus("TOOK_KIT");
  setPickupError("");
}

  function clearImportedScreenshotData({
    preserveSelectedMatch = true,
  } = {}) {
    if (screenshotPreviewUrl) {
      URL.revokeObjectURL(
        screenshotPreviewUrl
      );
    }

    setScreenshotFile(null);
    setScreenshotPreviewUrl("");
    setScreenshotError("");
    setKitMessage("");
    setIsReadingScreenshot(false);
    setScreenshotOrientation("LEFT_TEAM_A");
    setTeamAPlayers([]);
    setTeamBPlayers([]);
    setNewTeamAPlayerName("");
    setNewTeamBPlayerName("");

    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }

    if (
      !preserveSelectedMatch &&
      typeof onSelectedMatchIdChange ===
        "function"
    ) {
      onSelectedMatchIdChange("");
    }
  }

  function handleScreenshotSelection(event) {
    const file =
      event.target.files?.[0] || null;

    setScreenshotError("");
    setKitMessage("");

    if (!file) {
      return;
    }

    if (!selectedMatch) {
      setScreenshotError(
        "Please select a match before uploading the screenshot."
      );

      event.target.value = "";
      return;
    }

    if (!file.type.startsWith("image/")) {
      setScreenshotError(
        "Please upload a PNG, JPG, JPEG, WEBP, or another valid image."
      );

      event.target.value = "";
      return;
    }

    if (
      file.size >
      MAX_SCREENSHOT_SIZE_BYTES
    ) {
      setScreenshotError(
        "The screenshot must be 8 MB or smaller."
      );

      event.target.value = "";
      return;
    }

    if (screenshotPreviewUrl) {
      URL.revokeObjectURL(
        screenshotPreviewUrl
      );
    }

    const nextPreviewUrl =
      URL.createObjectURL(file);

    setScreenshotFile(file);
    setScreenshotPreviewUrl(nextPreviewUrl);
    setTeamAPlayers([]);
    setTeamBPlayers([]);

    setKitMessage(
      "Screenshot loaded. Confirm the left/right team mapping before reading names."
    );
  }

async function handleReadPlayerNames() {
  setScreenshotError("");
  setKitMessage("");

  if (!selectedMatch) {
    setScreenshotError(
      "Please select a match."
    );
    return;
  }

  if (!screenshotFile) {
    setScreenshotError(
      "Please upload the playing-teams screenshot."
    );
    return;
  }

  setIsReadingScreenshot(true);

  try {
    const formData = new FormData();

    formData.append(
      "image",
      screenshotFile,
      screenshotFile.name
    );

    const response = await fetch(
      "/api/kit/read-screenshot",
      {
        method: "POST",
        body: formData,
      }
    );

    const data = await response.json();

    if (!response.ok) {
      throw new Error(
        data?.error ||
          "Unable to read player names."
      );
    }

    const leftNames = Array.isArray(
      data?.leftTeam
    )
      ? data.leftTeam
      : [];

    const rightNames = Array.isArray(
      data?.rightTeam
    )
      ? data.rightTeam
      : [];

    if (
      leftNames.length === 0 &&
      rightNames.length === 0
    ) {
      throw new Error(
        "No player names were found in the screenshot."
      );
    }

    const leftPlayers = leftNames.map(
      (name) =>
        createDetectedPlayer({
          name,
          databasePlayers:
            screenshotOrientation ===
            "LEFT_TEAM_A"
              ? teamADatabasePlayers
              : teamBDatabasePlayers,
          isLeaguePlayerMode,
        })
    );

    const rightPlayers = rightNames.map(
      (name) =>
        createDetectedPlayer({
          name,
          databasePlayers:
            screenshotOrientation ===
            "LEFT_TEAM_A"
              ? teamBDatabasePlayers
              : teamADatabasePlayers,
          isLeaguePlayerMode,
        })
    );

    if (
      screenshotOrientation ===
      "LEFT_TEAM_A"
    ) {
      setTeamAPlayers(leftPlayers);
      setTeamBPlayers(rightPlayers);
    } else {
      setTeamAPlayers(rightPlayers);
      setTeamBPlayers(leftPlayers);
    }

    const teamACount =
      screenshotOrientation ===
      "LEFT_TEAM_A"
        ? leftPlayers.length
        : rightPlayers.length;

    const teamBCount =
      screenshotOrientation ===
      "LEFT_TEAM_A"
        ? rightPlayers.length
        : leftPlayers.length;

    const warningText =
      Array.isArray(data?.warnings) &&
      data.warnings.length > 0
        ? ` Review warning: ${data.warnings.join(
            " "
          )}`
        : "";

    setKitMessage(
      `Player names read successfully. ` +
        `${teamACount} detected for ${teamAName} and ` +
        `${teamBCount} detected for ${teamBName}. ` +
        `Confidence: ${data?.confidence || "MEDIUM"}. ` +
        `Please review every name before saving.` +
        warningText
    );
 } catch (error) {
  console.error(
    "Read kit screenshot failed:",
    error
  );

  setScreenshotError(
    error?.message ||
      "Unable to read player names from the screenshot. You can enter them manually."
  );
} finally {
  setIsReadingScreenshot(false);
}
}

  function setAllTeamPlayersIncluded(
    side,
    included
  ) {
    const setter =
      side === "A"
        ? setTeamAPlayers
        : setTeamBPlayers;

    setter((currentPlayers) =>
      currentPlayers.map(
        (player) => ({
          ...player,
          included,
        })
      )
    );

    setScreenshotError("");
    setKitMessage(
      included
        ? `Selected every player for ${
            side === "A"
              ? teamAName
              : teamBName
          }.`
        : `Cleared every player for ${
            side === "A"
              ? teamAName
              : teamBName
          }. Choose only the players participating in this match.`
    );
  }

  function updateTeamPlayer(
    side,
    clientId,
    changes
  ) {
    const setter =
      side === "A"
        ? setTeamAPlayers
        : setTeamBPlayers;

    setter((previousPlayers) =>
      previousPlayers.map((player) =>
        player.clientId === clientId
          ? {
              ...player,
              ...changes,
            }
          : player
      )
    );
  }

  function removeTeamPlayer(
    side,
    clientId
  ) {
    const setter =
      side === "A"
        ? setTeamAPlayers
        : setTeamBPlayers;

    setter((previousPlayers) =>
      previousPlayers.filter(
        (player) =>
          player.clientId !== clientId
      )
    );
  }

  function addManualPlayer(side) {
    const isTeamA = side === "A";

    const rawName = isTeamA
      ? newTeamAPlayerName
      : newTeamBPlayerName;

    const trimmedName =
      rawName.trim();

    if (!trimmedName) {
      setScreenshotError(
        `Enter a player name for ${
          isTeamA ? teamAName : teamBName
        }.`
      );

      return;
    }

    const setter = isTeamA
      ? setTeamAPlayers
      : setTeamBPlayers;

    setter((previousPlayers) => [
      ...previousPlayers,
      createTemporaryPlayer(trimmedName),
    ]);

    if (isTeamA) {
      setNewTeamAPlayerName("");
    } else {
      setNewTeamBPlayerName("");
    }

    setScreenshotError("");

    setKitMessage(
      `${trimmedName} added to ${
        isTeamA ? teamAName : teamBName
      }.`
    );
  }

  function swapTeamLists() {
    setTeamAPlayers(teamBPlayers);
    setTeamBPlayers(teamAPlayers);

    setScreenshotOrientation(
      (previous) =>
        previous === "LEFT_TEAM_A"
          ? "LEFT_TEAM_B"
          : "LEFT_TEAM_A"
    );

    setKitMessage(
      "The screenshot team sides have been swapped."
    );
  }

  async function loadBothTeamRosters() {
  setScreenshotError("");
  setKitMessage("");

  if (!selectedMatch) {
    setScreenshotError(
      "No upcoming match is available."
    );
    return;
  }

  const teamARoster =
    Array.isArray(
      selectedMatchTeams.find(
        (team) =>
          Number(team.id) ===
          Number(teamAId)
      )?.players
    )
      ? selectedMatchTeams.find(
          (team) =>
            Number(team.id) ===
            Number(teamAId)
        ).players
      : [];

  const teamBRoster =
    Array.isArray(
      selectedMatchTeams.find(
        (team) =>
          Number(team.id) ===
          Number(teamBId)
      )?.players
    )
      ? selectedMatchTeams.find(
          (team) =>
            Number(team.id) ===
            Number(teamBId)
        ).players
      : [];

  if (
    teamARoster.length === 0 &&
    teamBRoster.length === 0
  ) {
    setScreenshotError(
      "Neither playing team has registered players."
    );
    return;
  }

  setIsLoadingTeamRoster(true);

  try {
    const toReviewPlayers =
      (players) =>
        players.map(
          (player) => ({
            ...createTemporaryPlayer(
              player.name
            ),

            playerId:
              String(player.id),

            displayName:
              player.name,

            matchStatus:
              "MATCHED",
          })
        );

    const nextTeamAPlayers =
      toReviewPlayers(
        teamARoster
      );

    const nextTeamBPlayers =
      toReviewPlayers(
        teamBRoster
      );

    setTeamAPlayers(
      nextTeamAPlayers
    );

    setTeamBPlayers(
      nextTeamBPlayers
    );

    setSelectedRosterTeamId(
      ""
    );

    setKitMessage(
      `Loaded ${nextTeamAPlayers.length} players for ${teamAName} and ${nextTeamBPlayers.length} players for ${teamBName}. Uncheck anyone who is not playing, then save both teams once.`
    );
  } catch (error) {
    setScreenshotError(
      error?.message ||
        "Unable to load the two playing-team rosters."
    );
  } finally {
    setIsLoadingTeamRoster(false);
  }
}

const isTeamRosterWorkflow =
  kitInputMode === "TEAM_ROSTER";


  useEffect(() => {
    if (
      !selectedMatch ||
      !isTeamRosterWorkflow
    ) {
      return;
    }

    loadBothTeamRosters();
    // The selected match already supplies both team rosters.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [
    selectedMatch?.id,
    isTeamRosterWorkflow,
  ]);

  async function validateReviewData() {
  setScreenshotError("");
  setKitMessage("");

  if (!selectedMatch) {
    setScreenshotError("Please select a match.");
    return;
  }

  if (!teamAId || !teamBId) {
    setScreenshotError(
      "The selected match does not have valid team ids."
    );
    return;
  }

  const includedTeamAPlayers =
    teamAPlayers.filter(
      (player) =>
        player.included &&
        String(
          player.displayName || ""
        ).trim()
    );

  const includedTeamBPlayers =
    teamBPlayers.filter(
      (player) =>
        player.included &&
        String(
          player.displayName || ""
        ).trim()
    );

  const mapPlayerForSave = (player) => ({
    displayName: String(
      player.displayName || ""
    ).trim(),

    playerId: player.playerId
      ? Number(player.playerId)
      : null,

    included: true,
    isEligible: true,
  });

  let teamsToSave = [];

  if (isTeamRosterWorkflow) {
    if (
      includedTeamAPlayers.length === 0
    ) {
      setScreenshotError(
        `Select at least one eligible player for ${teamAName}.`
      );
      return;
    }

    if (
      includedTeamBPlayers.length === 0
    ) {
      setScreenshotError(
        `Select at least one eligible player for ${teamBName}.`
      );
      return;
    }

    teamsToSave = [
      {
        teamId:
          Number(teamAId),

        players:
          includedTeamAPlayers.map(
            mapPlayerForSave
          ),
      },
      {
        teamId:
          Number(teamBId),

        players:
          includedTeamBPlayers.map(
            mapPlayerForSave
          ),
      },
    ];
  } else {
    if (
      includedTeamAPlayers.length === 0
    ) {
      setScreenshotError(
        `Add at least one eligible player for ${teamAName}.`
      );
      return;
    }

    if (
      includedTeamBPlayers.length === 0
    ) {
      setScreenshotError(
        `Add at least one eligible player for ${teamBName}.`
      );
      return;
    }

    teamsToSave = [
      {
        teamId: Number(teamAId),

        players:
          includedTeamAPlayers.map(
            mapPlayerForSave
          ),
      },
      {
        teamId: Number(teamBId),

        players:
          includedTeamBPlayers.map(
            mapPlayerForSave
          ),
      },
    ];
  }

  const payload = {
    sourceMode: isTeamRosterWorkflow
      ? "TEAM_ROSTER"
      : "SCREENSHOT",

    teams: teamsToSave,
  };

  setIsSavingPlayerLists(true);

  try {
    const response = await fetch(
      `/api/matches/${selectedMatch.id}/kit-players`,
      {
        method: "POST",

        headers: {
          "Content-Type":
            "application/json",
        },

        body: JSON.stringify(payload),
      }
    );

    const data = await response.json();

    if (!response.ok) {
      throw new Error(
        data?.error ||
          "Unable to save the confirmed player list."
      );
    }

    const successMessage =
      `Saved ${
        includedTeamAPlayers.length
      } players for ${teamAName} and ${
        includedTeamBPlayers.length
      } players for ${teamBName}.`;

    setKitMessage(
      data?.message || successMessage
    );

    setKitAssignmentRefreshKey(
      (previous) => previous + 1
    );
  } catch (error) {
    setScreenshotError(
      error?.message ||
        "Unable to save the confirmed player list."
    );
  } finally {
    setIsSavingPlayerLists(false);
  }
}

  const hasReviewPlayers =
    teamAPlayers.length > 0 ||
    teamBPlayers.length > 0;
const handleKitAssignmentMessage =
  useCallback((nextMessage) => {
    setKitMessage(nextMessage);
    setScreenshotError("");
  }, []);

const handleKitAssignmentError =
  useCallback((nextError) => {
    setScreenshotError(nextError);
    setKitMessage("");
  }, []);
  return (
    <section className="kit-responsibility-card">
      <div className="kit-responsibility-heading">
        <div>
          <span className="kit-section-kicker">
            Guided shared-kit workflow
          </span>

          <h3>
            🧳 Kit Responsibility
          </h3>

          <p>
            Cric4All automatically selects the earliest upcoming match, loads both playing teams together, and guides you through one confirmation before suggesting the responsible carrier.
          </p>
        </div>

        <p className="kit-shared-context-text">
          One shared kit • one holder • one responsible carrier
        </p>
      </div>

      {activeLeague?.name && (
        <div className="kit-league-notice">
          <strong>
            League: {activeLeague.name}
          </strong>

          {useOneSharedCarrier && (
            <span>
              One shared-kit carrier is selected for the entire match. The same player may appear in both Surprise teams, but Cric4All treats that person as one league-wide rotation identity.
            </span>
          )}
        </div>
      )}

      <div className="kit-active-match-card">
        <div className="kit-active-match-primary">
          <span className="kit-section-kicker">
            Active kit match
          </span>

          {selectedMatch ? (
            <>
              <strong>
                {teamAName} vs {teamBName}
              </strong>

              <small>
                {formatMatchDate(
                  selectedMatch.scheduledAt ||
                    selectedMatch.matchDate ||
                    selectedMatch.createdAt
                )}
              </small>
            </>
          ) : (
            <>
              <strong>
                No upcoming match
              </strong>

              <small>
                Schedule a future match to start the kit workflow.
              </small>
            </>
          )}
        </div>

        {availableMatches.length > 1 && (
          <details className="kit-change-match">
            <summary>
              Change match
            </summary>

            <label className="kit-form-field">
              <span>
                Upcoming match
              </span>

              <select
                value={
                  selectedMatchId
                }
                onChange={(
                  event
                ) => {
                  if (
                    typeof onSelectedMatchIdChange ===
                    "function"
                  ) {
                    onSelectedMatchIdChange(
                      event.target.value
                    );
                  }
                }}
              >
                {availableMatches.map(
                  (match) => (
                    <option
                      key={
                        match.id
                      }
                      value={
                        match.id
                      }
                    >
                      {getMatchTeamName(
                        match,
                        "A"
                      )}{" "}
                      vs{" "}
                      {getMatchTeamName(
                        match,
                        "B"
                      )}{" "}
                      —{" "}
                      {formatMatchDate(
                        match.scheduledAt ||
                          match.matchDate ||
                          match.createdAt
                      )}
                    </option>
                  )
                )}
              </select>
            </label>
          </details>
        )}
      </div>

      <div className="kit-source-mode-card">
  <div className="kit-source-mode-heading">
    <div>
      <span className="kit-section-kicker">
        Player source
      </span>

      <h4>
        How do you want to choose eligible players?
      </h4>

      <p>
        Read today’s playing teams from a screenshot,
        or use an existing Cric4All team roster.
      </p>
    </div>
  </div>

  <div className="kit-source-mode-options">
    <button
      type="button"
      className={`kit-source-mode-option ${
        kitInputMode === "SCREENSHOT"
          ? "active"
          : ""
      }`}
      onClick={() => {
        setKitInputMode("SCREENSHOT");
        setSelectedRosterTeamId("");
        setScreenshotError("");
        setKitMessage("");
      }}
    >
      <span className="kit-source-mode-icon">
        📷
      </span>

      <span>
        <strong>Scan Playing-Team Screenshot</strong>
        <small>
          Read both playing teams from one screenshot.
        </small>
      </span>
    </button>

    <button
      type="button"
      className={`kit-source-mode-option ${
        kitInputMode === "TEAM_ROSTER"
          ? "active"
          : ""
      }`}
      onClick={() => {
        setKitInputMode("TEAM_ROSTER");
        setScreenshotError("");
        setKitMessage("");
      }}
    >
      <span className="kit-source-mode-icon">
        👥
      </span>

      <span>
        <strong>Use Both Team Rosters</strong>
        <small>
          Automatically load both playing teams’ saved rosters in one step.
        </small>
      </span>
    </button>
  </div>
</div>

      {!selectedMatch && (
        <div className="kit-info-message">
          Select the match before uploading its
          playing-team screenshot.
        </div>
      )}

      {kitInputMode === "SCREENSHOT" && (
        <>
          <div className="kit-upload-layout">
            <div className="kit-upload-controls">
              <label className="kit-upload-box">
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/png,image/jpeg,image/jpg,image/webp"
                  onChange={
                    handleScreenshotSelection
                  }
                />

                <span className="kit-upload-icon">
                  📷
                </span>

                <strong>
                  Upload Playing Teams Screenshot
                </strong>

                <small>
                  PNG, JPG, JPEG, or WEBP — maximum
                  8 MB
                </small>

                <span className="kit-upload-action">
                  Choose Screenshot
                </span>
              </label>

              {screenshotFile && (
                <div className="kit-file-summary">
                  <div>
                    <strong>
                      {screenshotFile.name}
                    </strong>

                    <span>
                      {(
                        screenshotFile.size /
                        1024 /
                        1024
                      ).toFixed(2)}{" "}
                      MB
                    </span>
                  </div>

                  <button
                    type="button"
                    className="btn btn-outline"
                    onClick={() =>
                      clearImportedScreenshotData({
                        preserveSelectedMatch: true,
                      })
                    }
                  >
                    Remove
                  </button>
                </div>
              )}

              <div className="kit-orientation-card">
                <div className="kit-orientation-heading">
                  <strong>
                    Confirm screenshot sides
                  </strong>

                  <p>
                    Choose the layout that matches the screenshot.
                  </p>
                </div>

                <label
                  className={`kit-orientation-option ${
                    screenshotOrientation ===
                    "LEFT_TEAM_A"
                      ? "is-selected"
                      : ""
                  }`}
                >
                  <input
                    type="radio"
                    name="kitScreenshotOrientation"
                    value="LEFT_TEAM_A"
                    checked={
                      screenshotOrientation ===
                      "LEFT_TEAM_A"
                    }
                    onChange={(event) =>
                      setScreenshotOrientation(
                        event.target.value
                      )
                    }
                  />

                  <span className="kit-orientation-radio" />

                  <span className="kit-orientation-option-copy">
                    <strong>
                      {teamAName} is on the left
                    </strong>

                    <small>
                      {teamBName} is on the right
                    </small>
                  </span>

                  <span className="kit-orientation-selected-label">
                    Selected
                  </span>
                </label>

                <label
                  className={`kit-orientation-option ${
                    screenshotOrientation ===
                    "LEFT_TEAM_B"
                      ? "is-selected"
                      : ""
                  }`}
                >
                  <input
                    type="radio"
                    name="kitScreenshotOrientation"
                    value="LEFT_TEAM_B"
                    checked={
                      screenshotOrientation ===
                      "LEFT_TEAM_B"
                    }
                    onChange={(event) =>
                      setScreenshotOrientation(
                        event.target.value
                      )
                    }
                  />

                  <span className="kit-orientation-radio" />

                  <span className="kit-orientation-option-copy">
                    <strong>
                      {teamBName} is on the left
                    </strong>

                    <small>
                      {teamAName} is on the right
                    </small>
                  </span>

                  <span className="kit-orientation-selected-label">
                    Selected
                  </span>
                </label>

                <button
                  type="button"
                  className="btn btn-outline kit-swap-lists-btn"
                  onClick={swapTeamLists}
                  disabled={!hasReviewPlayers}
                >
                  <span aria-hidden="true">⇄</span>
                  <span>Swap Current Player Lists</span>
                </button>
              </div>

              <button
                type="button"
                className="btn kit-read-screenshot-btn"
                onClick={handleReadPlayerNames}
                disabled={
                  !screenshotFile ||
                  isReadingScreenshot
                }
              >
                {isReadingScreenshot
                  ? "Reading Screenshot..."
                  : "🔎 Read Player Names"}
              </button>
            </div>

            <div className="kit-preview-panel">
              <div className="kit-preview-heading">
                <strong>Screenshot preview</strong>

                <span>
                  {screenshotOrientation ===
                  "LEFT_TEAM_A"
                    ? `${teamAName} ← left | right → ${teamBName}`
                    : `${teamBName} ← left | right → ${teamAName}`}
                </span>
              </div>

              {screenshotPreviewUrl ? (
                <img
                  src={screenshotPreviewUrl}
                  alt="Playing teams screenshot preview"
                  className="kit-screenshot-preview"
                />
              ) : (
                <div className="kit-empty-preview">
                  <span>🖼️</span>

                  <strong>
                    No screenshot selected
                  </strong>

                  <p>
                    The uploaded playing-team image
                    will appear here.
                  </p>
                </div>
              )}
            </div>
          </div>

          {screenshotError && (
            <div className="kit-error-message">
              {screenshotError}
            </div>
          )}

          {kitMessage && (
            <div className="kit-success-message">
              {kitMessage}
            </div>
          )}
          {hasReviewPlayers ? (
            <>
              <div className="kit-team-review-grid kit-team-review-grid-screenshot">
                <TeamPlayerReview
                  sourceMode={kitInputMode}
                  title={teamAName}
                  teamId={teamAId}
                  players={teamAPlayers}
                  databasePlayers={teamADatabasePlayers}
                  isLeaguePlayerMode={isLeaguePlayerMode}
                  newPlayerName={newTeamAPlayerName}
                  onNewPlayerNameChange={setNewTeamAPlayerName}
                  onAddPlayer={() => addManualPlayer("A")}
                  onUpdatePlayer={(clientId, changes) =>
                    updateTeamPlayer("A", clientId, changes)
                  }
                  onRemovePlayer={(clientId) =>
                    removeTeamPlayer("A", clientId)
                  }
                  onSetAllIncluded={(included) =>
                    setAllTeamPlayersIncluded(
                      "A",
                      included
                    )
                  }
                />

                <TeamPlayerReview
                  sourceMode={kitInputMode}
                  title={teamBName}
                  teamId={teamBId}
                  players={teamBPlayers}
                  databasePlayers={teamBDatabasePlayers}
                  isLeaguePlayerMode={isLeaguePlayerMode}
                  newPlayerName={newTeamBPlayerName}
                  onNewPlayerNameChange={setNewTeamBPlayerName}
                  onAddPlayer={() => addManualPlayer("B")}
                  onUpdatePlayer={(clientId, changes) =>
                    updateTeamPlayer("B", clientId, changes)
                  }
                  onRemovePlayer={(clientId) =>
                    removeTeamPlayer("B", clientId)
                  }
                  onSetAllIncluded={(included) =>
                    setAllTeamPlayersIncluded(
                      "B",
                      included
                    )
                  }
                />
              </div>

              <div className="kit-review-actions kit-review-actions-premium">
                <div>
                  <strong>Both teams are ready for review</strong>
                  <p>
                    {useOneSharedCarrier
                      ? `Today’s screenshot controls eligibility, while each player’s history follows them across ${teamAName} and ${teamBName}.`
                      : `Kit responsibility rotates independently for ${teamAName} and ${teamBName}.`}
                  </p>
                </div>

                <button
                  type="button"
                  className="btn kit-confirm-review-btn"
                  onClick={validateReviewData}
                  disabled={isSavingPlayerLists}
                >
                  {isSavingPlayerLists
                    ? "Saving Player Lists..."
                    : "✓ Confirm & Save Both Teams"}
                </button>
              </div>
            </>
          ) : (
            <div className="kit-workflow-placeholder">
              <div className="kit-workflow-placeholder-icon">✨</div>
              <div>
                <strong>Your player review will appear here</strong>
                <p>
                  Upload the screenshot, confirm the left/right teams, then click <b>Read Player Names</b>.
                </p>
              </div>
            </div>
          )}

<KitAssignmentPanel
  matchId={selectedMatch?.id}
  refreshKey={kitAssignmentRefreshKey}
  selectedTeamId=""
  sourceMode="SCREENSHOT"
  forceSharedKit={useOneSharedCarrier}
  onMessage={handleKitAssignmentMessage}
  onError={handleKitAssignmentError}
/>
        </>
      )}
      {kitInputMode === "TEAM_ROSTER" && (
        <section className="kit-roster-mode-card">
          <div className="kit-roster-mode-heading">
            <div>
              <span className="kit-section-kicker">
                One-step roster setup
              </span>

              <h4>
                Confirm both playing teams
              </h4>

              <p>
                Both registered rosters are loaded automatically from the active match. Uncheck players who are not playing, then save once.
              </p>
            </div>

            <button
              type="button"
              className="btn btn-outline"
              disabled={
                isLoadingTeamRoster ||
                !selectedMatch
              }
              onClick={
                loadBothTeamRosters
              }
            >
              {isLoadingTeamRoster
                ? "Loading Both Rosters..."
                : "↻ Reload Both Rosters"}
            </button>
          </div>

          {useOneSharedCarrier && (
            <div className="kit-shared-league-exception">
              <span>🏏</span>

              <div>
                <strong>
                  One shared-kit assignment for both teams
                </strong>

                <p>
                  This league uses a league-wide player rotation. Even when the same players appear under both teams, Cric4All combines them into one unique pool and shows one suggested kit carrier for the match.
                </p>
              </div>
            </div>
          )}

          <div className="kit-wizard-progress">
            <span className="is-complete">
              <b>1</b>
              Match selected
            </span>

            <span
              className={
                hasReviewPlayers
                  ? "is-complete"
                  : "is-active"
              }
            >
              <b>2</b>
              Confirm players
            </span>

            <span
              className={
                hasReviewPlayers
                  ? "is-active"
                  : ""
              }
            >
              <b>3</b>
              Save and assign
            </span>
          </div>

          <div className="kit-roster-team-overview">
            <article>
              <span>
                Team A
              </span>

              <strong>
                {teamAName}
              </strong>

              <small>
                {
                  teamAPlayers.filter(
                    (player) =>
                      player.included
                  ).length
                }{" "}
                selected of{" "}
                {teamAPlayers.length}
              </small>
            </article>

            <div className="kit-versus-badge">
              VS
            </div>

            <article>
              <span>
                Team B
              </span>

              <strong>
                {teamBName}
              </strong>

              <small>
                {
                  teamBPlayers.filter(
                    (player) =>
                      player.included
                  ).length
                }{" "}
                selected of{" "}
                {teamBPlayers.length}
              </small>
            </article>
          </div>

          {screenshotError && (
            <div className="kit-error-message">
              {screenshotError}
            </div>
          )}

          {kitMessage && (
            <div className="kit-success-message">
              {kitMessage}
            </div>
          )}

          {hasReviewPlayers ? (
            <>
              <div className="kit-team-review-grid">
                <TeamPlayerReview
                  sourceMode="TEAM_ROSTER"
                  title={teamAName}
                  teamId={teamAId}
                  players={teamAPlayers}
                  databasePlayers={
                    teamADatabasePlayers
                  }
                  isLeaguePlayerMode={
                    useOneSharedCarrier
                  }
                  newPlayerName={
                    newTeamAPlayerName
                  }
                  onNewPlayerNameChange={
                    setNewTeamAPlayerName
                  }
                  onAddPlayer={() =>
                    addManualPlayer("A")
                  }
                  onUpdatePlayer={(
                    clientId,
                    changes
                  ) =>
                    updateTeamPlayer(
                      "A",
                      clientId,
                      changes
                    )
                  }
                  onRemovePlayer={(
                    clientId
                  ) =>
                    removeTeamPlayer(
                      "A",
                      clientId
                    )
                  }
                  onSetAllIncluded={(
                    included
                  ) =>
                    setAllTeamPlayersIncluded(
                      "A",
                      included
                    )
                  }
                />

                <TeamPlayerReview
                  sourceMode="TEAM_ROSTER"
                  title={teamBName}
                  teamId={teamBId}
                  players={teamBPlayers}
                  databasePlayers={
                    teamBDatabasePlayers
                  }
                  isLeaguePlayerMode={
                    useOneSharedCarrier
                  }
                  newPlayerName={
                    newTeamBPlayerName
                  }
                  onNewPlayerNameChange={
                    setNewTeamBPlayerName
                  }
                  onAddPlayer={() =>
                    addManualPlayer("B")
                  }
                  onUpdatePlayer={(
                    clientId,
                    changes
                  ) =>
                    updateTeamPlayer(
                      "B",
                      clientId,
                      changes
                    )
                  }
                  onRemovePlayer={(
                    clientId
                  ) =>
                    removeTeamPlayer(
                      "B",
                      clientId
                    )
                  }
                  onSetAllIncluded={(
                    included
                  ) =>
                    setAllTeamPlayersIncluded(
                      "B",
                      included
                    )
                  }
                />
              </div>

              <div className="kit-review-actions kit-review-actions-premium">
                <div>
                  <strong>
                    Confirm today&apos;s playing rosters
                  </strong>

                  <p>
                    {useOneSharedCarrier
                      ? `Save both playing lists together. Because ${activeLeague?.name || "this league"} uses one shared kit and a league-wide player rotation, Cric4All will show only one suggested carrier box for the entire match. Duplicate players appearing under both teams are considered one person in the rotation.`
                      : "The current kit holders from the previous match are shown below. Confirm who is playing in this new match before Cric4All generates the next kit carrier assignments."}
                  </p>
                </div>

                <button
                  type="button"
                  className="btn kit-confirm-review-btn"
                  onClick={
                    validateReviewData
                  }
                  disabled={
                    isSavingPlayerLists
                  }
                >
                  {isSavingPlayerLists
                    ? "Confirming Rosters..."
                    : "Confirm Rosters and Continue →"}
                </button>
              </div>

              <KitAssignmentPanel
                matchId={
                  selectedMatch?.id
                }
                refreshKey={
                  kitAssignmentRefreshKey
                }
                selectedTeamId=""
                sourceMode="TEAM_ROSTER"
                forceSharedKit={
                  useOneSharedCarrier
                }
                onMessage={
                  handleKitAssignmentMessage
                }
                onError={
                  handleKitAssignmentError
                }
              />
            </>
          ) : (
            <div className="kit-workflow-placeholder">
              <div className="kit-workflow-placeholder-icon">
                👥
              </div>

              <div>
                <strong>
                  No registered players loaded
                </strong>

                <p>
                  Add players to the two teams or use the screenshot option for today’s playing lists.
                </p>
              </div>
            </div>
          )}
        </section>
      )}

      <style jsx global>{`
        .kit-responsibility-card {
          --kit-glow: rgba(34, 197, 94, 0.28);
          --kit-cyan: rgba(14, 165, 233, 0.22);
        }

        .kit-team-review-details {
          padding: 0 !important;
          overflow: hidden;
        }

        .kit-team-review-summary {
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 14px;
          min-height: 76px;
          padding: 14px 16px;
          cursor: pointer;
          list-style: none;
          user-select: none;
          background:
            linear-gradient(
              135deg,
              rgba(56, 189, 248, 0.08),
              rgba(99, 102, 241, 0.05)
            );
        }

        .kit-team-review-summary::-webkit-details-marker {
          display: none;
        }

        .kit-team-review-details[open]
          > .kit-team-review-summary {
          border-bottom: 1px solid
            rgba(148, 163, 184, 0.24);
        }

        .kit-team-review-summary-main {
          display: flex;
          align-items: center;
          gap: 12px;
          min-width: 0;
        }

        .kit-team-review-summary-main > div {
          display: grid;
          gap: 3px;
          min-width: 0;
        }

        .kit-team-review-summary-main h4 {
          margin: 0;
        }

        .kit-team-review-summary-main small {
          opacity: 0.72;
        }

        .kit-team-review-icon {
          display: flex;
          align-items: center;
          justify-content: center;
          width: 42px;
          height: 42px;
          flex: 0 0 auto;
          border-radius: 13px;
          background: rgba(56, 189, 248, 0.12);
          border: 1px solid rgba(56, 189, 248, 0.18);
        }

        .kit-team-review-summary-actions {
          display: flex;
          align-items: center;
          justify-content: flex-end;
          gap: 8px;
          flex: 0 0 auto;
        }

        .kit-team-bulk-btn {
          min-height: 34px;
          padding: 6px 10px;
          border: 1px solid rgba(148, 163, 184, 0.3);
          border-radius: 999px;
          background: rgba(15, 23, 42, 0.18);
          color: inherit;
          font: inherit;
          font-size: 0.76rem;
          font-weight: 700;
          cursor: pointer;
        }

        .kit-team-bulk-btn:hover:not(:disabled) {
          border-color: rgba(56, 189, 248, 0.52);
          background: rgba(56, 189, 248, 0.1);
        }

        .kit-team-bulk-btn:disabled {
          opacity: 0.42;
          cursor: not-allowed;
        }

        .kit-team-review-chevron {
          display: inline-block;
          transition: transform 0.2s ease;
        }

        .kit-team-review-details[open]
          .kit-team-review-chevron {
          transform: rotate(180deg);
        }

        .kit-team-review-body {
          padding: 16px;
          animation: kitTeamReveal 0.2s ease;
        }

        @keyframes kitTeamReveal {
          from {
            opacity: 0;
            transform: translateY(-4px);
          }

          to {
            opacity: 1;
            transform: translateY(0);
          }
        }

        .kit-shared-league-exception {
          display: flex;
          gap: 12px;
          margin: 16px 0;
          padding: 14px;
          border: 1px solid rgba(34, 197, 94, 0.34);
          border-radius: 14px;
          background:
            linear-gradient(
              135deg,
              rgba(34, 197, 94, 0.09),
              rgba(56, 189, 248, 0.06)
            );
        }

        .kit-shared-league-exception > span {
          font-size: 1.25rem;
        }

        .kit-shared-league-exception strong {
          display: block;
          margin-bottom: 4px;
        }

        .kit-shared-league-exception p {
          margin: 0;
          line-height: 1.5;
          opacity: 0.8;
        }

        .kit-active-match-card {
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 16px;
          margin: 18px 0;
          padding: 18px;
          border: 1px solid rgba(56, 189, 248, 0.3);
          border-radius: 18px;
          background:
            radial-gradient(
              circle at 10% 20%,
              rgba(56, 189, 248, 0.12),
              transparent 34%
            ),
            rgba(15, 23, 42, 0.32);
          box-shadow:
            inset 0 1px 0 rgba(255, 255, 255, 0.04),
            0 16px 34px rgba(2, 6, 23, 0.18);
        }

        .kit-active-match-primary {
          display: grid;
          gap: 5px;
        }

        .kit-active-match-primary strong {
          font-size: 1.15rem;
        }

        .kit-active-match-primary small {
          opacity: 0.74;
        }

        .kit-change-match {
          min-width: min(100%, 320px);
        }

        .kit-change-match summary {
          cursor: pointer;
          font-weight: 700;
          text-align: right;
        }

        .kit-change-match[open] summary {
          margin-bottom: 10px;
        }

        .kit-wizard-progress {
          display: grid;
          grid-template-columns: repeat(3, minmax(0, 1fr));
          gap: 10px;
          margin: 18px 0;
        }

        .kit-wizard-progress span {
          display: flex;
          align-items: center;
          gap: 9px;
          min-height: 46px;
          padding: 10px 12px;
          border: 1px solid rgba(148, 163, 184, 0.24);
          border-radius: 12px;
          opacity: 0.66;
        }

        .kit-wizard-progress b {
          display: inline-flex;
          align-items: center;
          justify-content: center;
          width: 26px;
          height: 26px;
          border-radius: 50%;
          background: rgba(148, 163, 184, 0.14);
        }

        .kit-wizard-progress .is-active {
          opacity: 1;
          border-color: rgba(56, 189, 248, 0.48);
          background: rgba(56, 189, 248, 0.08);
        }

        .kit-wizard-progress .is-complete {
          opacity: 1;
          border-color: rgba(34, 197, 94, 0.4);
          background: rgba(34, 197, 94, 0.08);
        }

        .kit-roster-team-overview {
          display: grid;
          grid-template-columns: minmax(0, 1fr) auto minmax(0, 1fr);
          align-items: center;
          gap: 12px;
          margin-bottom: 18px;
        }

        .kit-roster-team-overview article {
          display: grid;
          gap: 5px;
          padding: 15px;
          border: 1px solid rgba(148, 163, 184, 0.26);
          border-radius: 14px;
          background: rgba(15, 23, 42, 0.22);
        }

        .kit-roster-team-overview article span,
        .kit-roster-team-overview article small {
          opacity: 0.72;
        }

        .kit-versus-badge {
          display: flex;
          align-items: center;
          justify-content: center;
          width: 42px;
          height: 42px;
          border-radius: 50%;
          font-size: 0.78rem;
          font-weight: 800;
          background: linear-gradient(
            145deg,
            rgba(34, 197, 94, 0.2),
            rgba(56, 189, 248, 0.2)
          );
        }

        .kit-source-mode-card,
        .kit-roster-mode-card,
        .kit-team-review-card,
        .kit-workflow-placeholder {
          position: relative;
          overflow: hidden;
        }

        .kit-source-mode-card::before,
        .kit-roster-mode-card::before {
          content: "";
          position: absolute;
          inset: 0 auto auto 0;
          width: 100%;
          height: 2px;
          background: linear-gradient(90deg, transparent, #22c55e, #38bdf8, transparent);
          opacity: 0.8;
        }

        .kit-source-mode-options {
          display: grid;
          grid-template-columns: repeat(2, minmax(0, 1fr));
          gap: 14px;
        }

        .kit-source-mode-option {
          min-height: 104px;
          transition: transform 180ms ease, border-color 180ms ease, box-shadow 180ms ease;
        }

        .kit-source-mode-option:hover {
          transform: translateY(-2px);
        }

        .kit-source-mode-option.active {
          box-shadow: 0 16px 38px var(--kit-glow), inset 0 0 0 1px rgba(74, 222, 128, 0.22);
        }

        .kit-roster-steps {
          display: grid;
          grid-template-columns: repeat(4, minmax(0, 1fr));
          gap: 10px;
          margin: 18px 0;
        }

        .kit-roster-steps span {
          display: flex;
          align-items: center;
          gap: 8px;
          min-height: 44px;
          padding: 9px 11px;
          border: 1px solid rgba(148, 163, 184, 0.16);
          border-radius: 12px;
          background: rgba(15, 23, 42, 0.48);
          color: #94a3b8;
          font-size: 0.78rem;
          font-weight: 700;
        }

        .kit-roster-steps b {
          display: grid;
          place-items: center;
          width: 24px;
          height: 24px;
          flex: 0 0 24px;
          border-radius: 999px;
          background: rgba(51, 65, 85, 0.85);
          color: #e2e8f0;
        }

        .kit-roster-steps span.is-active {
          border-color: rgba(56, 189, 248, 0.45);
          color: #e0f2fe;
          box-shadow: 0 10px 24px var(--kit-cyan);
        }

        .kit-roster-steps span.is-active b {
          background: #0284c7;
          color: white;
        }

        .kit-roster-steps span.is-complete {
          border-color: rgba(34, 197, 94, 0.38);
          color: #bbf7d0;
        }

        .kit-roster-steps span.is-complete b {
          background: #16a34a;
          color: white;
        }

        .kit-player-review-columns-roster-mode,
        .kit-player-review-row-roster-mode {
          grid-template-columns: 90px 38px minmax(230px, 1fr) 126px 42px !important;
        }

        .kit-roster-player-identity {
          display: flex;
          align-items: center;
          gap: 11px;
          min-height: 42px;
          padding: 7px 10px;
          border: 1px solid rgba(148, 163, 184, 0.14);
          border-radius: 11px;
          background: linear-gradient(135deg, rgba(15, 23, 42, 0.88), rgba(30, 41, 59, 0.55));
        }

        .kit-roster-player-identity > span:last-child {
          display: flex;
          min-width: 0;
          flex-direction: column;
        }

        .kit-roster-player-identity strong {
          overflow: hidden;
          color: #f8fafc;
          text-overflow: ellipsis;
          white-space: nowrap;
        }

        .kit-roster-player-identity small {
          color: #7dd3fc;
          font-size: 0.7rem;
        }

        .kit-roster-avatar {
          display: grid;
          place-items: center;
          width: 32px;
          height: 32px;
          flex: 0 0 32px;
          border-radius: 10px;
          background: linear-gradient(135deg, #16a34a, #0284c7);
          color: white;
          font-weight: 900;
          box-shadow: 0 8px 20px rgba(2, 132, 199, 0.25);
        }

        .kit-player-match-status.is-registered {
          color: #86efac;
          font-weight: 800;
        }

        .kit-player-match-status.is-registered .kit-player-match-status-dot {
          background: #22c55e;
          box-shadow: 0 0 0 4px rgba(34, 197, 94, 0.13), 0 0 14px rgba(34, 197, 94, 0.55);
        }

        .kit-team-review-card-roster {
          border-color: rgba(34, 197, 94, 0.24);
          box-shadow: 0 18px 42px rgba(2, 6, 23, 0.22);
        }

        .kit-workflow-placeholder {
          display: flex;
          align-items: center;
          gap: 16px;
          min-height: 120px;
          margin-top: 18px;
          padding: 22px;
          border: 1px dashed rgba(56, 189, 248, 0.34);
          border-radius: 16px;
          background: linear-gradient(135deg, rgba(14, 165, 233, 0.08), rgba(34, 197, 94, 0.06));
        }

        .kit-workflow-placeholder-icon {
          display: grid;
          place-items: center;
          width: 52px;
          height: 52px;
          flex: 0 0 52px;
          border-radius: 16px;
          background: rgba(14, 165, 233, 0.13);
          font-size: 1.5rem;
          box-shadow: 0 12px 28px rgba(14, 165, 233, 0.16);
        }

        .kit-workflow-placeholder strong {
          color: #f8fafc;
          font-size: 1rem;
        }

        .kit-workflow-placeholder p {
          margin: 5px 0 0;
          color: #93c5fd;
          line-height: 1.5;
        }

        .kit-review-actions-premium {
          border-color: rgba(34, 197, 94, 0.34);
          background: linear-gradient(135deg, rgba(6, 78, 59, 0.28), rgba(8, 47, 73, 0.28));
          box-shadow: 0 16px 38px rgba(2, 6, 23, 0.2);
        }

        @media (max-width: 900px) {
          .kit-roster-steps {
            grid-template-columns: repeat(2, minmax(0, 1fr));
          }
        }

        @media (max-width: 720px) {
          .kit-source-mode-options {
            grid-template-columns: 1fr;
          }

          .kit-source-mode-option {
            min-height: 88px;
          }

          .kit-roster-steps {
            display: flex;
            overflow-x: auto;
            gap: 8px;
            padding-bottom: 4px;
            scrollbar-width: thin;
          }

          .kit-roster-steps span {
            min-width: 142px;
          }

          .kit-player-review-columns-roster-mode {
            display: none !important;
          }

          .kit-player-review-row-roster-mode {
            display: grid !important;
            grid-template-columns: 1fr auto !important;
            gap: 10px !important;
            padding: 14px !important;
            border: 1px solid rgba(148, 163, 184, 0.14);
            border-radius: 14px;
            background: rgba(15, 23, 42, 0.58);
          }

          .kit-player-review-row-roster-mode .kit-player-include {
            grid-column: 1;
            grid-row: 1;
          }

          .kit-player-review-row-roster-mode .kit-player-number {
            grid-column: 2;
            grid-row: 1;
          }

          .kit-player-review-row-roster-mode .kit-roster-player-cell {
            grid-column: 1 / -1;
            grid-row: 2;
          }

          .kit-player-review-row-roster-mode .kit-player-match-status {
            grid-column: 1;
            grid-row: 3;
            justify-self: start;
          }

          .kit-player-review-row-roster-mode .kit-remove-player-btn {
            grid-column: 2;
            grid-row: 3;
            justify-self: end;
          }

          .kit-roster-player-identity {
            min-height: 52px;
          }

          .kit-review-actions-premium,
          .kit-workflow-placeholder {
            align-items: flex-start;
            flex-direction: column;
          }

          .kit-review-actions-premium .kit-confirm-review-btn {
            width: 100%;
          }
        }

        @media (max-width: 760px) {
          .kit-team-review-summary {
            align-items: flex-start;
            padding: 12px;
          }

          .kit-team-review-summary-actions {
            display: grid;
            grid-template-columns: repeat(2, auto);
          }

          .kit-player-count-badge,
          .kit-team-review-chevron {
            display: none;
          }

          .kit-team-bulk-btn {
            min-height: 32px;
            padding: 5px 8px;
          }

          .kit-team-review-body {
            padding: 12px;
          }


          .kit-active-match-card {
            display: grid;
            padding: 14px;
          }

          .kit-change-match {
            min-width: 0;
          }

          .kit-change-match summary {
            text-align: left;
          }

          .kit-wizard-progress {
            grid-template-columns: 1fr;
          }

          .kit-roster-team-overview {
            grid-template-columns: 1fr;
          }

          .kit-versus-badge {
            margin: 0 auto;
          }

          .kit-source-mode-options,
          .kit-team-review-grid {
            grid-template-columns: 1fr;
          }
        }

        /* =========================================================
           MOBILE COMPACT MODE
           Keeps the guided workflow but removes repeated storytelling.
           ========================================================= */
        @media (max-width: 700px) {
          .kit-responsibility-card {
            display: grid;
            gap: 10px;
          }

          .kit-responsibility-heading {
            display: flex !important;
            align-items: center !important;
            justify-content: space-between !important;
            gap: 10px !important;
            padding: 12px 14px !important;
            border: 1px solid rgba(56, 189, 248, 0.28);
            border-radius: 16px;
            background:
              linear-gradient(
                135deg,
                rgba(14, 165, 233, 0.12),
                rgba(34, 197, 94, 0.08)
              );
          }

          .kit-responsibility-heading h3 {
            margin: 2px 0 0 !important;
            font-size: 1.05rem !important;
          }

          .kit-responsibility-heading p,
          .kit-league-notice span {
            display: none !important;
          }

          .kit-feature-badge {
            flex: 0 0 auto;
            max-width: 112px;
            padding: 6px 9px !important;
            font-size: 0.68rem !important;
            line-height: 1.2;
            text-align: center;
          }

          .kit-league-notice {
            display: flex !important;
            align-items: center;
            min-height: 38px;
            margin: 0 !important;
            padding: 9px 12px !important;
            border-radius: 12px !important;
          }

          .kit-league-notice strong {
            overflow: hidden;
            font-size: 0.8rem;
            text-overflow: ellipsis;
            white-space: nowrap;
          }

          .kit-active-match-card {
            grid-template-columns: minmax(0, 1fr) auto !important;
            align-items: center !important;
            gap: 10px !important;
            margin: 0 !important;
            padding: 11px 12px !important;
            border-radius: 14px !important;
          }

          .kit-active-match-primary {
            gap: 2px !important;
            min-width: 0;
          }

          .kit-active-match-primary strong {
            overflow: hidden;
            font-size: 0.92rem !important;
            text-overflow: ellipsis;
            white-space: nowrap;
          }

          .kit-active-match-primary small {
            font-size: 0.72rem;
          }

          .kit-change-match {
            min-width: auto !important;
          }

          .kit-change-match summary {
            padding: 7px 9px;
            border: 1px solid rgba(125, 211, 252, 0.28);
            border-radius: 999px;
            font-size: 0.7rem;
            text-align: center !important;
          }

          .kit-source-mode-card,
          .kit-roster-mode-card {
            padding: 12px !important;
            border-radius: 16px !important;
          }

          .kit-source-mode-heading h4,
          .kit-roster-mode-heading h4 {
            margin: 2px 0 0 !important;
            font-size: 0.95rem !important;
          }

          .kit-source-mode-heading p,
          .kit-roster-mode-heading p,
          .kit-shared-league-exception p,
          .kit-review-actions p,
          .kit-workflow-placeholder p {
            display: none !important;
          }

          .kit-source-mode-options {
            grid-template-columns: repeat(2, minmax(0, 1fr)) !important;
            gap: 8px !important;
          }

          .kit-source-mode-option {
            display: grid !important;
            grid-template-columns: auto minmax(0, 1fr);
            align-items: center;
            min-height: 68px !important;
            padding: 10px !important;
            border-radius: 13px !important;
          }

          .kit-source-mode-icon {
            font-size: 1.1rem !important;
          }

          .kit-source-mode-option strong {
            display: block;
            font-size: 0.73rem !important;
            line-height: 1.2;
          }

          .kit-source-mode-option small {
            display: none !important;
          }

          .kit-roster-mode-heading {
            display: flex !important;
            align-items: center !important;
            justify-content: space-between !important;
            gap: 10px !important;
          }

          .kit-roster-mode-heading .btn {
            width: auto !important;
            min-height: 34px !important;
            padding: 6px 9px !important;
            font-size: 0.68rem !important;
          }

          .kit-shared-league-exception {
            align-items: center !important;
            margin: 10px 0 !important;
            padding: 9px 11px !important;
          }

          .kit-shared-league-exception strong {
            font-size: 0.78rem !important;
            line-height: 1.25;
          }

          .kit-wizard-progress {
            display: flex !important;
            gap: 6px !important;
            margin: 10px 0 !important;
            overflow-x: auto;
            scrollbar-width: none;
          }

          .kit-wizard-progress::-webkit-scrollbar {
            display: none;
          }

          .kit-wizard-progress span {
            flex: 1 0 105px;
            min-height: 34px !important;
            padding: 6px 8px !important;
            font-size: 0.68rem;
            white-space: nowrap;
          }

          .kit-wizard-progress b {
            width: 21px !important;
            height: 21px !important;
            font-size: 0.67rem;
          }

          .kit-roster-team-overview {
            grid-template-columns: minmax(0, 1fr) auto minmax(0, 1fr) !important;
            gap: 7px !important;
            margin-bottom: 10px !important;
          }

          .kit-roster-team-overview article {
            gap: 2px !important;
            padding: 9px !important;
            border-radius: 12px !important;
          }

          .kit-roster-team-overview article span,
          .kit-roster-team-overview article small {
            font-size: 0.67rem;
          }

          .kit-roster-team-overview article strong {
            overflow: hidden;
            font-size: 0.82rem;
            text-overflow: ellipsis;
            white-space: nowrap;
          }

          .kit-versus-badge {
            width: 30px !important;
            height: 30px !important;
            font-size: 0.62rem !important;
          }

          .kit-team-review-grid {
            gap: 8px !important;
          }

          .kit-team-review-summary {
            min-height: 58px !important;
            padding: 9px 10px !important;
          }

          .kit-team-review-icon {
            width: 34px !important;
            height: 34px !important;
            border-radius: 10px !important;
          }

          .kit-team-review-summary-main {
            gap: 8px !important;
          }

          .kit-team-review-summary-main h4 {
            font-size: 0.82rem !important;
          }

          .kit-team-review-summary-main small,
          .kit-team-kicker {
            font-size: 0.63rem !important;
          }

          .kit-team-review-summary-actions {
            display: flex !important;
            gap: 5px !important;
          }

          .kit-team-bulk-btn {
            min-height: 28px !important;
            padding: 4px 7px !important;
            font-size: 0.62rem !important;
          }

          .kit-review-actions-premium {
            position: sticky;
            bottom: 8px;
            z-index: 25;
            display: grid !important;
            grid-template-columns: minmax(0, 1fr) auto;
            align-items: center !important;
            gap: 8px !important;
            margin: 10px 0 !important;
            padding: 10px !important;
            border-radius: 15px !important;
            backdrop-filter: blur(14px);
          }

          .kit-review-actions-premium strong {
            font-size: 0.76rem !important;
            line-height: 1.25;
          }

          .kit-review-actions-premium .kit-confirm-review-btn {
            width: auto !important;
            min-height: 38px !important;
            padding: 8px 10px !important;
            font-size: 0.68rem !important;
          }

          .kit-workflow-placeholder {
            min-height: 70px !important;
            margin-top: 8px !important;
            padding: 11px !important;
          }

          .kit-workflow-placeholder-icon {
            width: 38px !important;
            height: 38px !important;
            flex-basis: 38px !important;
            font-size: 1rem !important;
          }
        }

        /* =========================================================
           MOBILE POLISH PASS
           Restores readable typography and turns match navigation
           into a true compact segmented tab row.
           ========================================================= */
        @media (max-width: 700px) {
          /* Top Matches navigation: five real tabs in one row */
          .matches-subtabs.pro-match-tabs {
            display: grid !important;
            grid-template-columns: repeat(5, minmax(0, 1fr)) !important;
            gap: 4px !important;
            width: 100% !important;
            margin: 10px 0 14px !important;
            padding: 4px !important;
            overflow: visible !important;
            border: 1px solid rgba(96, 165, 250, 0.22) !important;
            border-radius: 14px !important;
            background: rgba(6, 15, 32, 0.82) !important;
            box-shadow:
              inset 0 1px 0 rgba(255, 255, 255, 0.04),
              0 10px 24px rgba(2, 6, 23, 0.2) !important;
          }

          .matches-subtabs.pro-match-tabs > button {
            display: inline-flex !important;
            flex-direction: row !important;
            align-items: center !important;
            justify-content: center !important;
            gap: 3px !important;
            width: 100% !important;
            min-width: 0 !important;
            min-height: 42px !important;
            margin: 0 !important;
            padding: 7px 3px !important;
            border: 0 !important;
            border-radius: 10px !important;
            background: transparent !important;
            box-shadow: none !important;
            color: #aebbd0 !important;
            font-size: 0.68rem !important;
            line-height: 1 !important;
            white-space: nowrap !important;
          }

          .matches-subtabs.pro-match-tabs > button.active {
            color: #ffffff !important;
            background:
              linear-gradient(
                135deg,
                rgba(37, 99, 235, 0.98),
                rgba(34, 211, 238, 0.9)
              ) !important;
            box-shadow:
              0 8px 18px rgba(37, 99, 235, 0.28),
              inset 0 1px 0 rgba(255, 255, 255, 0.18) !important;
          }

          .matches-subtabs.pro-match-tabs .tab-icon {
            display: inline !important;
            margin: 0 !important;
            font-size: 0.78rem !important;
            line-height: 1 !important;
          }

          .matches-subtabs.pro-match-tabs .tab-label {
            overflow: hidden;
            font-size: 0.65rem !important;
            font-weight: 800 !important;
            line-height: 1 !important;
            text-overflow: clip;
            white-space: nowrap;
          }

          /* Keep readable typography instead of shrinking text excessively */
          .kit-responsibility-card,
          .kit-responsibility-card button,
          .kit-responsibility-card input,
          .kit-responsibility-card select {
            font-size: 0.9rem;
          }

          .kit-section-kicker,
          .kit-source-mode-heading .kit-section-kicker,
          .kit-team-kicker {
            font-size: 0.72rem !important;
            letter-spacing: 0.08em !important;
          }

          .kit-responsibility-heading h3 {
            font-size: 1.1rem !important;
            line-height: 1.2 !important;
          }

          .kit-league-notice strong,
          .kit-active-match-primary strong,
          .kit-source-mode-option strong,
          .kit-team-review-summary-main h4 {
            font-size: 0.86rem !important;
            line-height: 1.28 !important;
          }

          .kit-active-match-primary small,
          .kit-roster-team-overview article span,
          .kit-roster-team-overview article small,
          .kit-team-review-summary-main small {
            font-size: 0.74rem !important;
            line-height: 1.3 !important;
          }

          /* Active match card: no overlap between match info and selector */
          .kit-active-match-card {
            display: grid !important;
            grid-template-columns: minmax(0, 1fr) auto !important;
            align-items: center !important;
            gap: 8px 10px !important;
            padding: 11px 12px !important;
          }

          .kit-active-match-primary {
            min-width: 0 !important;
          }

          .kit-active-match-primary strong {
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
          }

          .kit-change-match {
            position: static !important;
            min-width: 0 !important;
          }

          .kit-change-match summary {
            min-width: 104px !important;
            padding: 7px 10px !important;
            font-size: 0.74rem !important;
            white-space: nowrap !important;
          }

          .kit-change-match[open] {
            grid-column: 1 / -1 !important;
            width: 100% !important;
          }

          .kit-change-match[open] summary {
            width: fit-content !important;
            margin-left: auto !important;
            margin-bottom: 8px !important;
          }

          .kit-change-match .kit-form-field {
            display: grid !important;
            grid-template-columns: 1fr !important;
            gap: 6px !important;
            width: 100% !important;
            margin: 0 !important;
          }

          .kit-change-match .kit-form-field span {
            font-size: 0.74rem !important;
            font-weight: 800 !important;
          }

          .kit-change-match select {
            width: 100% !important;
            min-height: 44px !important;
            padding: 9px 36px 9px 11px !important;
            font-size: 0.82rem !important;
            line-height: 1.25 !important;
          }

          /* Player source cards: aligned icon and readable labels */
          .kit-source-mode-options {
            grid-template-columns: repeat(2, minmax(0, 1fr)) !important;
            gap: 8px !important;
          }

          .kit-source-mode-option {
            grid-template-columns: 38px minmax(0, 1fr) !important;
            min-height: 72px !important;
            gap: 8px !important;
            padding: 10px !important;
          }

          .kit-source-mode-icon {
            display: grid !important;
            place-items: center !important;
            width: 38px !important;
            height: 38px !important;
            margin: 0 !important;
            font-size: 1rem !important;
          }

          .kit-source-mode-option strong {
            overflow-wrap: normal !important;
            word-break: normal !important;
          }

          /* Screenshot orientation: compact radio rows, no text on far right */
          .kit-screenshot-orientation {
            display: grid !important;
            gap: 8px !important;
            padding: 12px !important;
          }

          .kit-screenshot-orientation > div:first-child {
            margin-bottom: 2px !important;
          }

          .kit-screenshot-orientation > div:first-child strong {
            font-size: 0.95rem !important;
          }

          .kit-screenshot-orientation > div:first-child p {
            margin: 3px 0 0 !important;
            font-size: 0.78rem !important;
            line-height: 1.35 !important;
          }

          .kit-screenshot-orientation > label {
            display: grid !important;
            grid-template-columns: 24px minmax(0, 1fr) !important;
            align-items: center !important;
            gap: 9px !important;
            width: 100% !important;
            min-height: 54px !important;
            margin: 0 !important;
            padding: 10px 12px !important;
            border: 1px solid rgba(148, 163, 184, 0.24) !important;
            border-radius: 12px !important;
            background: rgba(15, 23, 42, 0.54) !important;
          }

          .kit-screenshot-orientation > label input {
            width: 20px !important;
            height: 20px !important;
            margin: 0 !important;
          }

          .kit-screenshot-orientation > label span {
            display: block !important;
            min-width: 0 !important;
            font-size: 0.82rem !important;
            line-height: 1.35 !important;
            text-align: left !important;
            overflow-wrap: anywhere !important;
          }

          .kit-screenshot-orientation > .btn {
            width: 100% !important;
            min-height: 42px !important;
            margin-top: 2px !important;
            font-size: 0.82rem !important;
          }

          .kit-upload-dropzone {
            min-height: 205px !important;
            padding: 20px 14px !important;
          }

          .kit-upload-dropzone strong {
            font-size: 1rem !important;
          }

          .kit-upload-dropzone p {
            font-size: 0.8rem !important;
            line-height: 1.35 !important;
          }

          /* Keep action labels legible */
          .kit-review-actions-premium strong,
          .kit-review-actions-premium .kit-confirm-review-btn,
          .kit-team-bulk-btn,
          .kit-change-match summary {
            font-size: 0.74rem !important;
          }
        }

        @media (max-width: 390px) {
          .matches-subtabs.pro-match-tabs > button {
            gap: 2px !important;
            padding-inline: 2px !important;
          }

          .matches-subtabs.pro-match-tabs .tab-label {
            font-size: 0.6rem !important;
          }

          .matches-subtabs.pro-match-tabs .tab-icon {
            font-size: 0.72rem !important;
          }
        }

        /* =========================================================
           MOBILE V6 FINAL OVERRIDE
           This block intentionally appears last so older responsive
           rules cannot compress or misalign this workflow.
           ========================================================= */
        @media (max-width: 700px) {
          /* Player source is two full-width rows, never 50/50 columns. */
          .kit-source-mode-options {
            display: grid !important;
            grid-template-columns: minmax(0, 1fr) !important;
            gap: 10px !important;
          }

          .kit-source-mode-option {
            display: grid !important;
            grid-template-columns: 52px minmax(0, 1fr) auto !important;
            align-items: center !important;
            gap: 12px !important;
            width: 100% !important;
            min-height: 86px !important;
            padding: 13px !important;
            border: 1px solid rgba(113, 142, 206, 0.34) !important;
            border-radius: 15px !important;
            color: #f7f9ff !important;
            background: #101a30 !important;
            text-align: left !important;
          }

          .kit-source-mode-option::after {
            content: "Select";
            padding: 6px 9px;
            border-radius: 999px;
            color: #dce7ff;
            background: #1d2d50;
            font-size: 0.7rem;
            font-weight: 900;
            line-height: 1;
          }

          .kit-source-mode-option.active,
          .kit-source-mode-option[aria-pressed="true"] {
            border-color: rgba(94, 147, 255, 0.72) !important;
            background: #1a2d55 !important;
          }

          .kit-source-mode-option.active::after,
          .kit-source-mode-option[aria-pressed="true"]::after {
            content: "Selected";
            color: #ffffff;
            background: #4f85f3;
          }

          .kit-source-mode-icon {
            display: grid !important;
            place-items: center !important;
            width: 52px !important;
            height: 52px !important;
            margin: 0 !important;
            border-radius: 14px !important;
            background: #203255 !important;
            font-size: 1.2rem !important;
          }

          .kit-source-mode-option strong {
            display: block !important;
            color: #ffffff !important;
            font-size: 0.94rem !important;
            line-height: 1.3 !important;
            white-space: normal !important;
            overflow-wrap: normal !important;
            word-break: normal !important;
          }

          .kit-source-mode-option small {
            display: block !important;
            margin-top: 4px !important;
            color: #adbbd2 !important;
            font-size: 0.8rem !important;
            line-height: 1.4 !important;
            white-space: normal !important;
          }

          /* Progress is informational, not a row of buttons. */
          .kit-wizard-progress {
            position: relative !important;
            display: grid !important;
            grid-template-columns: repeat(3, minmax(0, 1fr)) !important;
            gap: 6px !important;
            margin: 12px 0 !important;
            padding: 0 !important;
            overflow: visible !important;
          }

          .kit-wizard-progress::before {
            content: "";
            position: absolute;
            top: 18px;
            left: 17%;
            right: 17%;
            height: 2px;
            background: rgba(117, 144, 202, 0.28);
          }

          .kit-wizard-progress span {
            position: relative !important;
            z-index: 1 !important;
            display: grid !important;
            justify-items: center !important;
            gap: 6px !important;
            min-width: 0 !important;
            min-height: 0 !important;
            padding: 0 2px !important;
            border: 0 !important;
            border-radius: 0 !important;
            color: #adbbd2 !important;
            background: transparent !important;
            box-shadow: none !important;
            font-size: 0.75rem !important;
            font-weight: 800 !important;
            line-height: 1.3 !important;
            text-align: center !important;
            white-space: normal !important;
          }

          .kit-wizard-progress b {
            display: grid !important;
            place-items: center !important;
            width: 36px !important;
            height: 36px !important;
            border: 2px solid rgba(117, 144, 202, 0.42) !important;
            border-radius: 50% !important;
            color: #dce7f8 !important;
            background: #101a30 !important;
            font-size: 0.8rem !important;
          }

          .kit-wizard-progress .is-active,
          .kit-wizard-progress .is-complete {
            color: #ffffff !important;
          }

          .kit-wizard-progress .is-active b {
            border-color: #43bce8 !important;
            background: #1d4770 !important;
          }

          .kit-wizard-progress .is-complete b {
            border-color: #4f85f3 !important;
            background: #4f85f3 !important;
          }

          /* Primary continuation action is unmistakably a button. */
          .kit-review-actions-premium {
            grid-template-columns: minmax(0, 1fr) !important;
            gap: 10px !important;
          }

          .kit-confirm-review-btn {
            width: 100% !important;
            min-height: 52px !important;
            padding: 12px 15px !important;
            border: 0 !important;
            border-radius: 13px !important;
            color: #ffffff !important;
            background: linear-gradient(135deg, #4f85f3, #43bce8) !important;
            box-shadow: 0 10px 24px rgba(66, 126, 238, 0.3) !important;
            font-size: 0.9rem !important;
            font-weight: 900 !important;
            line-height: 1.25 !important;
            white-space: normal !important;
          }

          /* Match tabs remain readable by scrolling horizontally. */
          .matches-subtabs.pro-match-tabs {
            display: flex !important;
            grid-template-columns: none !important;
            gap: 8px !important;
            padding: 6px !important;
            overflow-x: auto !important;
            scroll-snap-type: x proximity !important;
            scrollbar-width: none !important;
          }

          .matches-subtabs.pro-match-tabs::-webkit-scrollbar {
            display: none !important;
          }

          .matches-subtabs.pro-match-tabs > button {
            flex: 0 0 96px !important;
            min-width: 96px !important;
            min-height: 62px !important;
            padding: 8px 7px !important;
            scroll-snap-align: start !important;
          }

          .matches-subtabs.pro-match-tabs .tab-label {
            font-size: 0.76rem !important;
          }

          .matches-subtabs.pro-match-tabs .tab-icon {
            font-size: 1.08rem !important;
          }
        }

        @media (max-width: 390px) {
          .kit-source-mode-option {
            grid-template-columns: 48px minmax(0, 1fr) !important;
          }

          .kit-source-mode-option::after {
            display: none;
          }

          .matches-subtabs.pro-match-tabs > button {
            flex-basis: 90px !important;
            min-width: 90px !important;
          }
        }

        /* =========================================================
           FINAL MOBILE WOW DESIGN — SETUP FLOW
           ========================================================= */
        @media (max-width: 700px) {
          .kit-responsibility-card {
            gap: 10px !important;
            padding: 10px !important;
            border-radius: 18px !important;
            background:
              linear-gradient(
                160deg,
                #15213d,
                #0d1629
              ) !important;
          }

          .kit-responsibility-heading {
            display: grid !important;
            grid-template-columns: 1fr !important;
            gap: 5px !important;
            padding: 12px !important;
            border-radius: 15px !important;
            background: #14203a !important;
          }

          .kit-responsibility-heading h3 {
            font-size: 1.08rem !important;
            line-height: 1.22 !important;
          }

          .kit-shared-context-text {
            display: block !important;
            margin: 0 !important;
            padding: 0 !important;
            color: #aebbd2 !important;
            background: transparent !important;
            font-size: 0.8rem !important;
            font-weight: 650 !important;
            line-height: 1.35 !important;
          }

          .kit-league-notice {
            min-height: 40px !important;
            padding: 9px 11px !important;
          }

          .kit-active-match-card {
            grid-template-columns: 1fr !important;
            gap: 9px !important;
            padding: 11px !important;
          }

          .kit-change-match summary {
            width: 100% !important;
            min-height: 46px !important;
            border: 1px solid rgba(
              94,
              147,
              255,
              0.64
            ) !important;
            border-radius: 12px !important;
            color: #ffffff !important;
            background:
              linear-gradient(
                135deg,
                #263d6d,
                #1a2d55
              ) !important;
            font-size: 0.84rem !important;
            font-weight: 900 !important;
          }

          .kit-source-mode-card,
          .kit-roster-mode-card {
            padding: 12px !important;
            border-radius: 15px !important;
            background: #14203a !important;
          }

          .kit-source-mode-heading h4,
          .kit-roster-mode-heading h4 {
            font-size: 1rem !important;
          }

          .kit-source-mode-options {
            grid-template-columns: 1fr !important;
            gap: 9px !important;
          }

          .kit-source-mode-option {
            display: grid !important;
            grid-template-columns:
              48px minmax(0, 1fr) auto !important;
            align-items: center !important;
            gap: 11px !important;
            width: 100% !important;
            min-height: 80px !important;
            padding: 12px !important;
            border: 1px solid rgba(
              113,
              142,
              206,
              0.34
            ) !important;
            border-radius: 14px !important;
            background: #101a30 !important;
            text-align: left !important;
          }

          .kit-source-mode-option::after {
            content: "Choose";
            padding: 6px 8px;
            border-radius: 999px;
            color: #dce7ff;
            background: #1d2d50;
            font-size: 0.68rem;
            font-weight: 900;
          }

          .kit-source-mode-option.active,
          .kit-source-mode-option[aria-pressed="true"] {
            border-color: rgba(
              94,
              147,
              255,
              0.76
            ) !important;
            background: #1a2d55 !important;
          }

          .kit-source-mode-option.active::after,
          .kit-source-mode-option[aria-pressed="true"]::after {
            content: "Selected";
            color: #ffffff;
            background: #4f85f3;
          }

          .kit-source-mode-icon {
            width: 48px !important;
            height: 48px !important;
            border-radius: 13px !important;
            background: #203255 !important;
            font-size: 1.12rem !important;
          }

          .kit-source-mode-option strong {
            font-size: 0.9rem !important;
            line-height: 1.28 !important;
          }

          .kit-source-mode-option small {
            display: block !important;
            margin-top: 3px !important;
            color: #aebbd2 !important;
            font-size: 0.76rem !important;
            line-height: 1.35 !important;
          }

          .kit-wizard-progress {
            position: relative !important;
            display: grid !important;
            grid-template-columns:
              repeat(
                3,
                minmax(0, 1fr)
              ) !important;
            gap: 5px !important;
            margin: 11px 0 !important;
            overflow: visible !important;
          }

          .kit-wizard-progress::before {
            content: "";
            position: absolute;
            top: 18px;
            left: 17%;
            right: 17%;
            height: 2px;
            background: rgba(
              117,
              144,
              202,
              0.28
            );
          }

          .kit-wizard-progress span {
            position: relative !important;
            z-index: 1 !important;
            display: grid !important;
            justify-items: center !important;
            gap: 5px !important;
            min-height: 0 !important;
            padding: 0 2px !important;
            border: 0 !important;
            color: #aebbd2 !important;
            background: transparent !important;
            font-size: 0.72rem !important;
            font-weight: 800 !important;
            line-height: 1.25 !important;
            text-align: center !important;
            white-space: normal !important;
          }

          .kit-wizard-progress b {
            width: 36px !important;
            height: 36px !important;
            border: 2px solid rgba(
              117,
              144,
              202,
              0.42
            ) !important;
            border-radius: 50% !important;
            background: #101a30 !important;
          }

          .kit-wizard-progress .is-active b {
            border-color: #43bce8 !important;
            background: #1d4770 !important;
          }

          .kit-wizard-progress .is-complete b {
            border-color: #4f85f3 !important;
            background: #4f85f3 !important;
          }

          .kit-roster-team-overview {
            grid-template-columns: 1fr !important;
            gap: 7px !important;
          }

          .kit-versus-badge {
            justify-self: center !important;
            width: auto !important;
            height: auto !important;
            padding: 5px 13px !important;
          }

          .kit-review-actions-premium {
            grid-template-columns: 1fr !important;
            gap: 9px !important;
          }

          .kit-confirm-review-btn {
            width: 100% !important;
            min-height: 52px !important;
            padding: 12px 15px !important;
            border: 0 !important;
            border-radius: 13px !important;
            color: #ffffff !important;
            background:
              linear-gradient(
                135deg,
                #4f85f3,
                #43bce8
              ) !important;
            font-size: 0.9rem !important;
            font-weight: 900 !important;
            white-space: normal !important;
          }

          .matches-subtabs.pro-match-tabs {
            display: flex !important;
            grid-template-columns: none !important;
            gap: 8px !important;
            padding: 6px !important;
            overflow-x: auto !important;
            scroll-snap-type: x proximity !important;
            scrollbar-width: none !important;
          }

          .matches-subtabs.pro-match-tabs::-webkit-scrollbar {
            display: none !important;
          }

          .matches-subtabs.pro-match-tabs > button {
            flex: 0 0 96px !important;
            min-width: 96px !important;
            min-height: 62px !important;
            padding: 8px 7px !important;
            scroll-snap-align: start !important;
          }

          .matches-subtabs.pro-match-tabs .tab-label {
            font-size: 0.76rem !important;
          }
        }

        /* =========================================================
           MOBILE FINAL POLISH — SCREENSHOT SIDES + BUTTON HIERARCHY
           ========================================================= */
        @media (max-width: 700px) {
          .kit-orientation-card {
            display: grid !important;
            grid-template-columns: minmax(0, 1fr) !important;
            gap: 10px !important;
            width: 100% !important;
            padding: 13px !important;
            border: 1px solid rgba(113, 142, 206, 0.34) !important;
            border-radius: 16px !important;
            color: #f7f9ff !important;
            background: #14203a !important;
          }

          .kit-orientation-heading {
            display: grid !important;
            gap: 4px !important;
          }

          .kit-orientation-heading strong {
            color: #ffffff !important;
            font-size: 1rem !important;
            line-height: 1.25 !important;
          }

          .kit-orientation-heading p {
            display: block !important;
            margin: 0 !important;
            color: #aebbd2 !important;
            font-size: 0.8rem !important;
            line-height: 1.4 !important;
          }

          .kit-orientation-option {
            position: relative !important;
            display: grid !important;
            grid-template-columns: 24px minmax(0, 1fr) auto !important;
            align-items: center !important;
            gap: 11px !important;
            width: 100% !important;
            min-height: 70px !important;
            margin: 0 !important;
            padding: 12px !important;
            border: 1px solid rgba(113, 142, 206, 0.34) !important;
            border-radius: 13px !important;
            color: #f7f9ff !important;
            background: #101a30 !important;
            cursor: pointer !important;
          }

          .kit-orientation-option.is-selected {
            border-color: rgba(94, 147, 255, 0.78) !important;
            background: #1a2d55 !important;
            box-shadow:
              0 0 0 1px rgba(94, 147, 255, 0.13),
              0 8px 20px rgba(10, 28, 64, 0.24) !important;
          }

          .kit-orientation-option > input {
            position: absolute !important;
            width: 1px !important;
            height: 1px !important;
            opacity: 0 !important;
            pointer-events: none !important;
          }

          .kit-orientation-radio {
            position: relative !important;
            display: block !important;
            width: 22px !important;
            height: 22px !important;
            border: 2px solid rgba(152, 174, 219, 0.68) !important;
            border-radius: 50% !important;
            background: #0d1629 !important;
          }

          .kit-orientation-option.is-selected
            .kit-orientation-radio {
            border-color: #5e93ff !important;
            box-shadow: 0 0 0 3px rgba(94, 147, 255, 0.12) !important;
          }

          .kit-orientation-option.is-selected
            .kit-orientation-radio::after {
            content: "" !important;
            position: absolute !important;
            inset: 4px !important;
            border-radius: 50% !important;
            background: linear-gradient(135deg, #4f85f3, #43bce8) !important;
          }

          .kit-orientation-option-copy {
            display: grid !important;
            gap: 4px !important;
            min-width: 0 !important;
          }

          .kit-orientation-option-copy strong {
            color: #ffffff !important;
            font-size: 0.9rem !important;
            line-height: 1.3 !important;
            white-space: normal !important;
          }

          .kit-orientation-option-copy small {
            color: #aebbd2 !important;
            font-size: 0.78rem !important;
            line-height: 1.35 !important;
            white-space: normal !important;
          }

          .kit-orientation-selected-label {
            visibility: hidden !important;
            padding: 5px 7px !important;
            border-radius: 999px !important;
            color: #ffffff !important;
            background: #4f85f3 !important;
            font-size: 0.64rem !important;
            font-weight: 900 !important;
            line-height: 1 !important;
          }

          .kit-orientation-option.is-selected
            .kit-orientation-selected-label {
            visibility: visible !important;
          }

          .kit-swap-lists-btn {
            display: inline-flex !important;
            align-items: center !important;
            justify-content: center !important;
            gap: 8px !important;
            width: 100% !important;
            min-height: 48px !important;
            padding: 10px 13px !important;
            border: 1px solid rgba(105, 151, 244, 0.58) !important;
            border-radius: 12px !important;
            color: #ffffff !important;
            background: #1a2948 !important;
            box-shadow: 0 8px 18px rgba(7, 20, 48, 0.22) !important;
            font-size: 0.82rem !important;
            font-weight: 900 !important;
            line-height: 1.25 !important;
            white-space: normal !important;
          }

          /* Stronger, unmistakable button hierarchy across the setup flow. */
          .kit-responsibility-card .btn:not(:disabled),
          .kit-change-match summary,
          .kit-team-bulk-btn {
            border-color: rgba(105, 151, 244, 0.62) !important;
            box-shadow:
              0 8px 18px rgba(7, 20, 48, 0.24),
              inset 0 1px 0 rgba(255, 255, 255, 0.05) !important;
          }

          .kit-responsibility-card
            .btn:not(:disabled):active,
          .kit-change-match summary:active,
          .kit-team-bulk-btn:active,
          .kit-source-mode-option:active,
          .kit-orientation-option:active {
            transform: translateY(1px) !important;
          }

          .kit-confirm-review-btn,
          .kit-upload-dropzone .btn,
          .kit-generate-assignment-btn {
            min-height: 50px !important;
            border: 0 !important;
            color: #ffffff !important;
            background:
              linear-gradient(
                135deg,
                #4f85f3,
                #43bce8
              ) !important;
            box-shadow:
              0 10px 24px rgba(66, 126, 238, 0.32),
              inset 0 1px 0 rgba(255, 255, 255, 0.18) !important;
            font-size: 0.88rem !important;
            font-weight: 900 !important;
          }

          /* Readable mobile type scale. */
          .kit-responsibility-card {
            font-size: 0.88rem !important;
          }

          .kit-responsibility-card label,
          .kit-responsibility-card small,
          .kit-responsibility-card p {
            line-height: 1.4 !important;
          }
        }

        @media (max-width: 390px) {
          .kit-orientation-option {
            grid-template-columns: 22px minmax(0, 1fr) !important;
          }

          .kit-orientation-selected-label {
            display: none !important;
          }
        }

      `}</style>

    </section>
  );
}