import Link from "next/link";

export default function SiteFooter() {
  return (
    <footer className="site-footer">
      <div>© 2026 Cric4All is a cricket league management and live scoring platform operated by VSJ Serv LLC.</div>

      <div className="site-footer-links">
        <Link href="/about">About</Link>
        <Link href="/explore">Explore</Link>
        <Link href="/guides">Cricket Guides</Link>
        <Link href="/guides/cricket-scoring">Scoring Guide</Link>
        <Link href="/guides/league-management">League Guide</Link>
        <Link href="/help">Help</Link>
        <Link href="/privacy">Privacy Policy</Link>
        <Link href="/terms">
  Terms & Conditions
</Link>

<Link href="/sms-opt-in">
  SMS Opt-In
</Link>
        <Link href="/delete-account">Delete Account</Link>
        <Link href="/contact">Contact</Link>
      </div>
    </footer>
  );
}