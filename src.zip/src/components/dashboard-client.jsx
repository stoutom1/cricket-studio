"use client";
import { signOut, useSession } from "next-auth/react";
import React, { useEffect, useMemo, useRef, useState } from "react";
import { EXTRA_TYPES, getPlayerName, WICKET_TYPES, applyBallOutcome, isLegalDelivery } from "@/lib/scoring";
import "@/app/globals.css";
import "@/app/super-over-scorecard-mobile.css";
import { useRouter, useSearchParams } from "next/navigation";
import {formatMatchDateTime,getMatchTimelineText,} from "@/lib/date";
import { buildMatchInsights } from "@/lib/match-insights";
import { createPortal } from "react-dom";
import BirthdayPushSettings from "@/components/BirthdayPushSettings";
import PlayerInactivityAlertSettings from "@/components/PlayerInactivityAlertSettings";
import TeamKitManagement from "@/components/kit/TeamKitManagement";
import Link from "next/link";
import LeagueKitShortcut from "@/components/kit/LeagueKitShortcut";
import mobileKitStyles from "./DashboardKitMobile.module.css";
import KitPostMatchPrompt from "@/components/kit/KitPostMatchPrompt";
import LeagueResourcesShortcut from "@/components/resources/LeagueResourcesShortcut";
import matchDayNavStyles from "./MatchDayDashboardNav.module.css";
import playerCardStyles from "./DashboardPlayerCard.module.css";
import personalCricketStyles from "./PersonalCricketDashboard.module.css";
import personalDashboardStyles from "./PersonalDashboardSnapshot.module.css";
import PlayerAccountLinker from "@/components/PlayerAccountLinker";
import { shareCric4All } from "@/lib/native-share";
import { openCric4AllLink } from "@/lib/native-links";
import {
  filterScoreboardForPlayerAnalytics,
  shouldExcludePlayerFromLeagueAnalytics,
} from "@/lib/player-analytics-exclusions";
import FollowedLeaguesDrawerContent from "@/components/followed-leagues-drawer-content";
import {
  ROLE_LABELS,
  getAllowedInviteRoles,
  getRolePermissionDefaults,
} from "@/lib/league-role-permissions";
import {
  cacheOfflineMatchSnapshot,
  createClientEventId,
  getLastPendingOfflineBall,
  getOfflineDeviceId,
  getOfflineMatchSnapshot,
  getPendingOfflineBallCount,
  isOfflineRetryableError,
  listPendingOfflineBalls,
  queueOfflineBall,
  removeOfflineBall,
  updateOfflineBall,
  getPendingOfflineKeeperChangeCount,
  listPendingOfflineKeeperChanges,
  queueOfflineKeeperChange,
  removeOfflineKeeperChange,
  getPendingOfflineInningsTransition,
  getPendingOfflineInningsTransitionCount,
  queueOfflineInningsTransition,
  removeOfflineInningsTransition,
  getPendingOfflineStrikeSwapCount,
  listPendingOfflineStrikeSwaps,
  queueOfflineStrikeSwap,
  removeOfflineStrikeSwap,
  clearOfflineServerUndoSnapshot,
  getOfflineServerUndoSnapshot,
  getPendingOfflineServerUndo,
  getPendingOfflineServerUndoCount,
  queueOfflineServerUndo,
  removeOfflineServerUndo,
  saveOfflineServerUndoSnapshot,
} from "@/lib/offline-scoring-store";
import {
  clearOfflineScoringSession,
  getOfflineScoringSession,
  isCompletedMatchStatus,
  primeOfflineScoringShell,
  saveOfflineScoringSession,
} from "@/lib/offline-scoring-resume";


function DashboardLeaderShowcase({
  accent = "batting",
  hero,
  cards = [],
}) {
  const safeCards = (cards || []).filter(Boolean);

  return (
    <section
      className={`dashboard-leader-showcase dashboard-leader-showcase--${accent}`}
      aria-label={`${hero?.label || "League"} leaders`}
    >
      <article className="dashboard-leader-hero">
        <div className="dashboard-leader-hero-copy">
          <span className="dashboard-leader-eyebrow">
            {hero?.icon} {hero?.eyebrow}
          </span>
          <strong>{hero?.label}</strong>
          <span className="dashboard-leader-player">
            {hero?.row?.playerName || "No qualifier yet"}
          </span>
          <small>
            {hero?.row?.teamName || ""}
          </small>
        </div>

        <div className="dashboard-leader-hero-value">
          <strong>{hero?.value ?? "—"}</strong>
          <span>{hero?.unit || ""}</span>
          {hero?.detail ? <small>{hero.detail}</small> : null}
        </div>
      </article>

      <div className="dashboard-leader-grid">
        {safeCards.map((item, index) => (
          <article
            className="dashboard-leader-card"
            key={`${item.label}-${item.row?.playerId ?? item.row?.playerName ?? index}`}
          >
            <div className="dashboard-leader-card-top">
              <span className="dashboard-leader-card-icon">{item.icon}</span>
              <span>
                <strong>{item.label}</strong>
                <small>{item.hint}</small>
              </span>
            </div>

            {item.row ? (
              <>
                <div className="dashboard-leader-card-player">
                  <strong>{item.row.playerName}</strong>
                  <small>{item.row.teamName || ""}</small>
                </div>
                <div className="dashboard-leader-card-value">
                  <strong>{item.value}</strong>
                  <span>{item.unit}</span>
                </div>
              </>
            ) : (
              <div className="dashboard-leader-card-empty">
                No qualifier yet
              </div>
            )}
          </article>
        ))}
      </div>
    </section>
  );
}

function SuperOverScorecard({ superOver }) {
  if (!superOver?.exists) return null;

  return (
    <section
      className="super-over-scorecard-panel"
      aria-label="Super Over scorecard"
    >
      <div className="super-over-scorecard-heading">
        <strong>⚡ Super Over</strong>
        <span>
          {superOver.resultText ||
            (superOver.active
              ? `Super Over ${superOver.round} in progress`
              : "Tie-breaker")}
        </span>
      </div>

      {(superOver.history || []).map((round) => (
        <div
          key={`scoreboard-super-over-${round.round}`}
          className="super-over-scorecard-round"
        >
          <strong className="super-over-round-title">
            Round {round.round}
          </strong>

          {[round.first, round.second].map((innings, inningsIndex) => (
            <details
              key={`super-over-${round.round}-${inningsIndex + 1}`}
              open
              className="super-over-innings-details"
            >
              <summary className="super-over-innings-summary">
                <span className="super-over-team-name">
                  {innings.teamName}
                </span>
                <span className="super-over-team-score">
                  {innings.runs}/{innings.wickets} ({innings.overs} ov)
                </span>
              </summary>

              <div className="super-over-stat-section">
                <strong className="super-over-section-label">
                  🏏 Batting
                </strong>

                <div className="super-over-table-wrap">
                  <table className="score-table super-over-table super-over-batting-table">
                    <thead>
                      <tr>
                        <th>Batter</th>
                        <th>R</th>
                        <th>B</th>
                        <th>4s</th>
                        <th>6s</th>
                        <th>SR</th>
                        <th>Status</th>
                      </tr>
                    </thead>
                    <tbody>
                      {(innings.batting || []).map((batter) => (
                        <tr
                          key={`so-bat-${round.round}-${inningsIndex}-${batter.playerId}`}
                        >
                          <td data-label="Batter">{batter.playerName}</td>
                          <td data-label="Runs">{batter.runs}</td>
                          <td data-label="Balls">{batter.balls}</td>
                          <td data-label="4s">{batter.fours}</td>
                          <td data-label="6s">{batter.sixes}</td>
                          <td data-label="SR">{batter.strikeRate}</td>
                          <td data-label="Status">{batter.dismissal}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              {(innings.bowling || []).length > 0 && (
                <div className="super-over-stat-section">
                  <strong className="super-over-section-label">
                    🎯 Bowling
                  </strong>

                  <div className="super-over-table-wrap">
                    <table className="score-table super-over-table super-over-bowling-table">
                      <thead>
                        <tr>
                          <th>Bowler</th>
                          <th>O</th>
                          <th>R</th>
                          <th>W</th>
                          <th>Econ</th>
                        </tr>
                      </thead>
                      <tbody>
                        {(innings.bowling || []).map((bowler) => (
                          <tr
                            key={`so-bowl-${round.round}-${inningsIndex}-${bowler.playerId}`}
                          >
                            <td data-label="Bowler">{bowler.playerName}</td>
                            <td data-label="Overs">{bowler.overs}</td>
                            <td data-label="Runs">{bowler.runs}</td>
                            <td data-label="Wickets">{bowler.wickets}</td>
                            <td data-label="Econ">{bowler.economy}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}

              {(innings.commentary || []).length > 0 && (
                <div className="super-over-ball-section">
                  <strong className="super-over-section-label">
                    📝 Ball by ball
                  </strong>

                  <div className="super-over-ball-list">
                    {innings.commentary.map((ball) => (
                      <span
                        key={`so-ball-${round.round}-${inningsIndex}-${ball.id}`}
                        title={`${ball.over} ${ball.text} • ${ball.score}`}
                        className="super-over-ball-badge"
                      >
                        {ball.badge}
                      </span>
                    ))}
                  </div>
                </div>
              )}
            </details>
          ))}

          {round.resultText && (
            <small className="super-over-round-result">
              {round.resultText}
            </small>
          )}
        </div>
      ))}
    </section>
  );
}

function Card({
  title,
  children,
  right,
  defaultCollapsed = false
}) {
  const [collapsed, setCollapsed] = useState(defaultCollapsed);

  return (
    <section className="card">
      <div
        className="card-head"
        style={{
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          cursor: "pointer"
        }}
        onClick={() => setCollapsed((prev) => !prev)}
      >
        <div
          style={{
            display: "flex",
            alignItems: "center",
            gap: 10
          }}
        >
          <button
            type="button"
            className="btn btn-outline"
            style={{
              padding: "2px 10px",
              minWidth: 36
            }}
            onClick={(e) => {
              e.stopPropagation();
              setCollapsed((prev) => !prev);
            }}
          >
            {collapsed ? "＋" : "－"}
          </button>

          <h2 style={{ margin: 0 }}>{title}</h2>
        </div>

        <div
          onClick={(e) => e.stopPropagation()}
        >
          {right || null}
        </div>
      </div>

      {!collapsed && (
        <div style={{ marginTop: 16 }}>
          {children}
        </div>
      )}
    </section>
  );
}

function CollapsibleSection({
  title,
  children,
  defaultOpen = true
}) {
  const [open, setOpen] = useState(defaultOpen);

  return (
    <div className="collapsible-section">
      <button
        type="button"
        className="collapsible-toggle"
        onClick={() => setOpen(!open)}
      >
        <span>{title}</span>

        <span
          style={{
            fontSize: 18,
            fontWeight: 700
          }}
        >
          {open ? "−" : "+"}
        </span>
      </button>

      {open && (
        <div className="collapsible-content">
          {children}
        </div>
      )}
    </div>
  );
}
 

function formatDate(value) {
  try {
    return new Date(value).toLocaleString();
  } catch {
    return value;
  }
}
function MobileBattingCards({ rows = [], currentStrikerId }) {
  if (!rows.length) {
    return <p className="muted">Batting details not available yet.</p>;
  }

  return (
    <div className="mobile-scorecard-list">
      {rows.map((row, index) => (
        <div className="mobile-player-card" key={`mobile-bat-${row.playerId || index}`}>
          <div className="mobile-player-top">
            <strong>
              {row.playerName}
              {Number(currentStrikerId) === Number(row.playerId) ? " *" : ""}
            </strong>
            <span>{row.runs} ({row.balls})</span>
          </div>

          <div className="mobile-dismissal">
            {row.dismissal && row.dismissal !== "not out"
              ? row.dismissal
              : "not out"}
          </div>

<div className="mobile-stat-rail">
  <span><b>{row.fours}</b> 4s</span>
  <span><b>{row.sixes}</b> 6s</span>
  <span><b>{row.strikeRate}</b> SR</span>
</div>
        </div>
      ))}
    </div>
  );
}

function MobileBowlingCards({ rows = [] }) {
  if (!rows.length) {
    return <p className="muted">Bowling details not available yet.</p>;
  }

  return (
    <div className="mobile-scorecard-list">
      {rows.map((row, index) => (
        <div className="mobile-player-card" key={`mobile-bowl-${row.playerId || index}`}>
          <div className="mobile-player-top">
            <strong>{row.playerName}</strong>
            <span>
              {row.overs}-{row.maidens || 0}-{row.runs}-{row.wickets}
            </span>
          </div>

 <div className="mobile-stat-rail">
  <span><b>{row.wides || 0}</b> Wd</span>
  <span><b>{row.noBalls || 0}</b> Nb</span>
  <span><b>{row.economy}</b> Eco</span>
</div>
        </div>
      ))}
    </div>
  );
}

function getRecentBallInningsNo(ball) {
  const value =
    ball?.inningsNo ??
    ball?.inningsNumber ??
    ball?.inningNo ??
    ball?.inning;

  const parsed = Number(value);

  return Number.isInteger(parsed) && parsed > 0
    ? parsed
    : null;
}

function getRecentBallOverNumber(ball) {
  const directValue =
    ball?.overNumber ??
    ball?.overNo ??
    ball?.deliveryOver ??
    ball?.over;

  const directNumber = Number(directValue);

  if (Number.isFinite(directNumber)) {
    return directNumber;
  }

  /*
    Fallback for labels such as:
    "4.2 1"
    "4.3 Wd"
    "4.4 (6)"
  */
  const rawLabel = String(
    ball?.label ??
      ball?.shortText ??
      ball?.displayText ??
      ""
  );

  const match = rawLabel.match(
    /^\s*(\d+)\.(\d+)/
  );

  return match ? Number(match[1]) : null;
}

function getRecentBallExtraType(ball) {
  return String(
    ball?.extraType ??
      ball?.extrasType ??
      ball?.deliveryExtraType ??
      ""
  )
    .trim()
    .toUpperCase();
}

function getRecentBallDisplayText(ball) {
  const rawText =
    ball?.shortText ??
    ball?.displayText ??
    ball?.resultText ??
    ball?.label ??
    "-";

  return String(rawText)
    .replace(/^\s*\d+\.\d+\s*/, "")
    .replace(/[()]/g, "")
    .trim();
}

function isRecentBallLegal(ball) {
  /*
    Prefer an explicit API value when available.
  */
  if (typeof ball?.isLegal === "boolean") {
    return ball.isLegal;
  }

  if (typeof ball?.legalDelivery === "boolean") {
    return ball.legalDelivery;
  }

  const extraType = getRecentBallExtraType(ball);

  if (
    extraType === "WIDE" ||
    extraType === "WD" ||
    extraType === "NOBALL" ||
    extraType === "NO_BALL" ||
    extraType === "NB"
  ) {
    return false;
  }

  /*
    Fallback when extraType is missing.
  */
  const text = getRecentBallDisplayText(ball)
    .toUpperCase();

  return !(
    text.startsWith("WD") ||
    text.startsWith("WIDE") ||
    text.startsWith("NB") ||
    text.startsWith("NO BALL") ||
    text.startsWith("NOBALL")
  );
}



function formatPersonalMatchDateTime(value) {
  if (!value) return "";

  const date = new Date(value);

  if (Number.isNaN(date.getTime())) {
    return "";
  }

  /*
   * This runs in the browser, so the match is displayed in the user's
   * local timezone instead of the Vercel/server runtime timezone.
   */
  return new Intl.DateTimeFormat(undefined, {
    month: "short",
    day: "numeric",
    hour: "numeric",
    minute: "2-digit",
  }).format(date);
}

function getPersonalDashboardFormLabel(form) {
  const score = Number(form?.formScore || 0);
  const trend = String(form?.trend || "")
    .trim()
    .toUpperCase();

  if (score >= 75) {
    return { icon: "🔥", label: "Excellent", tone: "hot" };
  }
  if (trend === "IMPROVING") {
    return { icon: "📈", label: "Improving", tone: "good" };
  }
  if (trend === "STABLE") {
    return { icon: "✅", label: "Stable", tone: "steady" };
  }
  if (trend === "COOLING") {
    return { icon: "🧊", label: "Cooling", tone: "cool" };
  }
  return { icon: "🌱", label: "Building", tone: "building" };
}

function formatPersonalDashboardNextMatch(value) {
  if (!value) return "";
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return "";

  return new Intl.DateTimeFormat(undefined, {
    weekday: "short",
    month: "short",
    day: "numeric",
    hour: "numeric",
    minute: "2-digit",
  }).format(date);
}

function PersonalDashboardSnapshot({
  data,
  loading,
  leagueName,
  onOpenYourCricket,
}) {
  /*
   * Mobile-only behavior:
   * Your Cricket always starts collapsed whenever this landing snapshot mounts.
   * Desktop ignores this state entirely through CSS and remains fully expanded.
   */
  const [mobileExpanded, setMobileExpanded] = useState(false);
  if (loading) {
    return (
      <section
        className={`${personalDashboardStyles.shell} ${personalDashboardStyles.loading}`}
        aria-label="Your Cricket loading"
      >
        <span className={personalDashboardStyles.loadingIcon}>🏏</span>
        <div>
          <strong>Loading Your Cricket</strong>
          <small>Building your personal snapshot from completed-match data.</small>
        </div>
      </section>
    );
  }

  if (!data?.linked) {
    return (
      <section
        className={`${personalDashboardStyles.shell} ${personalDashboardStyles.unlinked}`}
        aria-label="Link your player profile"
      >
        <div className={personalDashboardStyles.unlinkedCopy}>
          <span>👤</span>
          <div>
            <small>🎯 PERSONAL DASHBOARD</small>
            <strong>Make Cric4All yours</strong>
            <p>
              Link your player profile in <b>{leagueName || "this league"}</b> to see
              your runs, rankings, form, milestones and next match here.
            </p>
          </div>
        </div>

        <button type="button" onClick={onOpenYourCricket}>
          🔗 Link Player Profile
        </button>
      </section>
    );
  }

  const career = data.career || {};
  const battingRank = data.rankings?.batting || null;
  const form = data.form || {};
  const nearest = data.progress?.nearest || null;
  const nextMatch = data.nextMatch || null;
  const formLabel = getPersonalDashboardFormLabel(form);
  const rankMovement = Number(battingRank?.movement || 0);
  const nextDate = formatPersonalDashboardNextMatch(nextMatch?.scheduledAt);

  return (
    <section
      className={`${personalDashboardStyles.shell} ${
        mobileExpanded
          ? personalDashboardStyles.mobileExpanded
          : personalDashboardStyles.mobileCollapsed
      }`}
      aria-label="Your Cricket personal dashboard"
    >
      <div className={personalDashboardStyles.topRow}>
        <div className={personalDashboardStyles.identity}>
          <span className={personalDashboardStyles.avatar}>
            {String(data.playerName || "?")
              .trim()
              .charAt(0)
              .toUpperCase()}
          </span>

          <div>
            <small>🎯 YOUR CRICKET</small>
            <strong>
              Welcome back, {data.playerName || "Player"}
            </strong>
            <p>
              {data.teamNames?.join(" / ") || "League player"}
              {leagueName ? ` · ${leagueName}` : ""}
            </p>
          </div>
        </div>

        <div className={personalDashboardStyles.headerActions}>
          <button
            type="button"
            className={personalDashboardStyles.openButton}
            onClick={onOpenYourCricket}
          >
            View full Your Cricket
            <span aria-hidden="true">→</span>
          </button>

          <button
            type="button"
            className={personalDashboardStyles.mobileToggle}
            aria-expanded={mobileExpanded}
            onClick={() =>
              setMobileExpanded((current) => !current)
            }
          >
            <span aria-hidden="true">
              {mobileExpanded ? "▴" : "▾"}
            </span>
            {mobileExpanded
              ? "Collapse Your Cricket"
              : "Expand Your Cricket"}
          </button>
        </div>
      </div>

      <div className={personalDashboardStyles.mobileSummary}>
        <span>
          <b>{career.runs ?? 0}</b> runs
        </span>

        <span>
          Batting{" "}
          <b>
            {battingRank?.rank
              ? `#${battingRank.rank}`
              : "—"}
          </b>
        </span>

        <span>
          {formLabel.icon} <b>{formLabel.label}</b>
        </span>
      </div>

      <div className={personalDashboardStyles.expandableBody}>
        <div className={personalDashboardStyles.statStrip}>
          {[
            ["🏏", "Runs", career.runs ?? 0],
            ["🎯", "Wickets", career.wickets ?? 0],
            ["🧤", "Fielding", career.fielding ?? 0],
            ["🎽", "Matches", career.matches ?? 0],
          ].map(([icon, label, value]) => (
            <article key={label}>
              <span>{icon}</span>
              <div>
                <strong>{value}</strong>
                <small>{label}</small>
              </div>
            </article>
          ))}
        </div>

        <div className={personalDashboardStyles.intelligenceGrid}>
          <article className={personalDashboardStyles.intelligenceCard}>
            <div className={personalDashboardStyles.intelligenceIcon}>
              🏆
            </div>

            <div>
              <small>League batting rank</small>
              <strong>
                {battingRank?.rank
                  ? `#${battingRank.rank}`
                  : "Not ranked yet"}
              </strong>

              {battingRank?.rank ? (
                <p
                  className={
                    rankMovement > 0
                      ? personalDashboardStyles.positive
                      : rankMovement < 0
                        ? personalDashboardStyles.negative
                        : ""
                  }
                >
                  {battingRank.isNew
                    ? "NEW"
                    : rankMovement > 0
                      ? `↑${rankMovement} since previous ranking`
                      : rankMovement < 0
                        ? `↓${Math.abs(rankMovement)} since previous ranking`
                        : "No ranking change"}
                </p>
              ) : (
                <p>
                  Qualify through completed-match performances.
                </p>
              )}
            </div>
          </article>

          <article className={personalDashboardStyles.intelligenceCard}>
            <div className={personalDashboardStyles.intelligenceIcon}>
              📅
            </div>

            <div>
              <small>Next match</small>
              <strong>
                {nextMatch
                  ? nextDate || "Scheduled"
                  : "No match scheduled"}
              </strong>
              <p>
                {nextMatch
                  ? nextMatch.opponentName
                    ? `vs ${nextMatch.opponentName}`
                    : `${nextMatch.teamAName} vs ${nextMatch.teamBName}`
                  : "Your linked team has no future scheduled fixture."}
              </p>
            </div>
          </article>

          <article className={personalDashboardStyles.intelligenceCard}>
            <div className={personalDashboardStyles.intelligenceIcon}>
              🎯
            </div>

            <div>
              <small>Next landmark</small>
              <strong>
                {nearest
                  ? `${nearest.remaining} ${String(
                      nearest.label ||
                        nearest.metric ||
                        ""
                    ).toLowerCase()} to ${nearest.target}`
                  : "Landmarks complete"}
              </strong>
              <p>
                {nearest
                  ? `${nearest.current} / ${nearest.target} ${String(
                      nearest.label ||
                        nearest.metric ||
                        ""
                    ).toLowerCase()}`
                  : "No configured landmark currently pending."}
              </p>
            </div>
          </article>

          <article
            className={`${personalDashboardStyles.intelligenceCard} ${
              personalDashboardStyles[
                `tone_${formLabel.tone}`
              ] || ""
            }`}
          >
            <div className={personalDashboardStyles.intelligenceIcon}>
              {formLabel.icon}
            </div>

            <div>
              <small>Current form</small>
              <strong>{formLabel.label}</strong>
              <p>
                Rating {Number(form.formScore || 0).toFixed(1)}
                {Number(form.lastFiveRuns || 0) ||
                Number(form.lastFiveWickets || 0)
                  ? ` · ${form.lastFiveRuns || 0} runs · ${form.lastFiveWickets || 0} wickets in last 5`
                  : " · Build form through completed appearances"}
              </p>
            </div>
          </article>
        </div>

        {(data.teamOfWeek?.selected ||
          data.achievements?.length) && (
          <div className={personalDashboardStyles.highlights}>
            {data.teamOfWeek?.selected ? (
              <span>
                ⭐ Team of the Week
                {data.teamOfWeek?.captain ? " · Captain" : ""}
                {data.teamOfWeek?.wicketkeeper ? " · WK" : ""}
              </span>
            ) : null}

            {data.achievements?.length ? (
              <span>
                🏅 {data.achievements.length} achievement
                {data.achievements.length === 1 ? "" : "s"} earned
              </span>
            ) : null}
          </div>
        )}

        <button
          type="button"
          className={personalDashboardStyles.mobileFullButton}
          onClick={onOpenYourCricket}
        >
          View full Your Cricket
          <span aria-hidden="true">→</span>
        </button>
      </div>
    </section>
  );
}

function PersonalCricketDashboard({
  data,
  loading,
  leagueName,
  leagueId,
  onLinkChanged,
}) {
  if (loading) {
    return (
      <div className={personalCricketStyles.loading}>
        <span>🏏</span>
        <div>
          <strong>Building Your Cricket...</strong>
          <small>Reading your latest completed-match performance.</small>
        </div>
      </div>
    );
  }

  if (!data?.linked) {
    return (
      <div className={personalCricketStyles.unlinkedShell}>
        <div className={personalCricketStyles.empty}>
          <span>👤</span>
          <div>
            <strong>Your player profile is not linked yet</strong>
            <p>
              Your Cric4All account is active, but no player record in{" "}
              <b>{leagueName || "this league"}</b> is linked to your account.
              Choose your player profile below. Cric4All will never let you
              claim a profile that is already linked to another account.
            </p>
          </div>
        </div>

        <PlayerAccountLinker
          leagueId={leagueId}
          linked={false}
          onChanged={onLinkChanged}
        />
      </div>
    );
  }

  const career = data.career || {};
  const form = data.form || {};
  const rankings = data.rankings || {};
  const progress = data.progress || {};
  const achievements = data.achievements || [];
  const streaks = data.streaks || [];
  const nextMatch = data.nextMatch || null;
  const lastMatch = form.lastFive?.[0] || null;
  const teamOfWeek = data.teamOfWeek || null;

  const rankItems = [
    ["Overall", rankings.overall],
    ["Batting", rankings.batting],
    ["Bowling", rankings.bowling],
    ["Fielding", rankings.fielding],
  ];

  const movementText = (rank) => {
    if (!rank) return "Not ranked";
    if (rank.isNew) return "NEW";
    if (Number(rank.movement || 0) > 0) {
      return `↑${rank.movement}`;
    }
    if (Number(rank.movement || 0) < 0) {
      return `↓${Math.abs(rank.movement)}`;
    }
    return "—";
  };

  return (
    <div className={personalCricketStyles.shell}>
      <section className={personalCricketStyles.hero}>
        <div className={personalCricketStyles.identity}>
          <span className={personalCricketStyles.avatar}>
            {String(data.playerName || "?")
              .trim()
              .charAt(0)
              .toUpperCase()}
          </span>

          <div>
            <small>🎯 YOUR CRICKET</small>
            <h3>{data.playerName}</h3>
            <p>
              {data.teamNames?.join(" / ") || "League player"} ·{" "}
              {leagueName}
            </p>
          </div>
        </div>

        <div className={personalCricketStyles.heroBadges}>
          {form.trend ? (
            <span>{form.trend} form</span>
          ) : null}
          {teamOfWeek?.selected ? (
            <span>⭐ Team of the Week</span>
          ) : null}
          {achievements.length ? (
            <span>
              🏅 {achievements.length} achievement
              {achievements.length === 1 ? "" : "s"}
            </span>
          ) : null}
        </div>
      </section>

      <section className={personalCricketStyles.careerGrid}>
        {[
          ["🏏", "Runs", career.runs ?? 0],
          ["🎯", "Wickets", career.wickets ?? 0],
          ["🧤", "Fielding", career.fielding ?? 0],
          ["🎽", "Matches", career.matches ?? 0],
        ].map(([icon, label, value]) => (
          <article key={label}>
            <span>{icon}</span>
            <div>
              <small>{label}</small>
              <strong>{value}</strong>
            </div>
          </article>
        ))}
      </section>

      <div className={personalCricketStyles.twoColumn}>
        <section className={personalCricketStyles.panel}>
          <div className={personalCricketStyles.panelHead}>
            <div>
              <small>🏆 LEAGUE POSITION</small>
              <strong>Your rankings</strong>
            </div>
            <span>Latest completed matches</span>
          </div>

          <div className={personalCricketStyles.rankGrid}>
            {rankItems.map(([label, rank]) => (
              <article key={label}>
                <small>{label}</small>
                <strong>
                  {rank?.rank ? `#${rank.rank}` : "—"}
                </strong>
                <span
                  className={
                    Number(rank?.movement || 0) > 0
                      ? personalCricketStyles.up
                      : Number(rank?.movement || 0) < 0
                        ? personalCricketStyles.down
                        : ""
                  }
                >
                  {movementText(rank)}
                </span>
                {rank?.careerBestRank ? (
                  <em>Best #{rank.careerBestRank}</em>
                ) : null}
              </article>
            ))}
          </div>
        </section>

        <section className={personalCricketStyles.panel}>
          <div className={personalCricketStyles.panelHead}>
            <div>
              <small>📈 CURRENT FORM</small>
              <strong>Last five appearances</strong>
            </div>
            <span>
              Rating {Number(form.formScore || 0).toFixed(1)}
            </span>
          </div>

          {form.lastFive?.length ? (
            <div className={personalCricketStyles.formStrip}>
              {form.lastFive.map((match, index) => (
                <article key={`${match.matchId || index}-${index}`}>
                  <strong>{match.runs || 0} runs</strong>
                  {Number(match.wickets || 0) > 0 ? (
                    <small>
                      🎯 {match.wickets} wicket
                      {match.wickets === 1 ? "" : "s"}
                    </small>
                  ) : null}
                  {Number(match.fieldingTotal || 0) > 0 ? (
                    <small>
                      🧤 {match.fieldingTotal} fielding
                    </small>
                  ) : null}
                </article>
              ))}
            </div>
          ) : (
            <p className={personalCricketStyles.muted}>
              No recent qualifying performance yet.
            </p>
          )}

          <div className={personalCricketStyles.formSummary}>
            <span>
              <small>Runs · last 5</small>
              <strong>{form.lastFiveRuns || 0}</strong>
            </span>
            <span>
              <small>Wickets · last 5</small>
              <strong>{form.lastFiveWickets || 0}</strong>
            </span>
            <span>
              <small>Trend</small>
              <strong>{form.trend || "Building"}</strong>
            </span>
          </div>
        </section>
      </div>

      <div className={personalCricketStyles.twoColumn}>
        <section className={personalCricketStyles.panel}>
          <div className={personalCricketStyles.panelHead}>
            <div>
              <small>🎯 NEXT LANDMARK</small>
              <strong>
                {progress.nearest
                  ? `${progress.nearest.target} ${progress.nearest.label}`
                  : "Landmark ladder complete"}
              </strong>
            </div>
            {progress.nearest ? (
              <span>
                {progress.nearest.remaining} to go
              </span>
            ) : null}
          </div>

          {progress.nearest ? (
            <>
              <div className={personalCricketStyles.progressTrack}>
                <span
                  style={{
                    width: `${Math.max(
                      3,
                      Number(progress.nearest.progress || 0)
                    )}%`,
                  }}
                />
              </div>
              <p className={personalCricketStyles.muted}>
                {progress.nearest.current} /{" "}
                {progress.nearest.target}{" "}
                {String(progress.nearest.label || "").toLowerCase()}
              </p>
            </>
          ) : (
            <p className={personalCricketStyles.muted}>
              You have reached every currently configured landmark.
            </p>
          )}

          {streaks.length ? (
            <div className={personalCricketStyles.streakList}>
              {streaks.slice(0, 3).map((streak) => (
                <article key={streak.id}>
                  <span>{streak.icon}</span>
                  <div>
                    <strong>{streak.type}</strong>
                    <small>{streak.description}</small>
                  </div>
                  <em>
                    {streak.current} current · best {streak.best}
                  </em>
                </article>
              ))}
            </div>
          ) : null}
        </section>

        <section className={personalCricketStyles.panel}>
          <div className={personalCricketStyles.panelHead}>
            <div>
              <small>📅 NEXT UP</small>
              <strong>
                {nextMatch
                  ? `${nextMatch.teamAName} vs ${nextMatch.teamBName}`
                  : "No scheduled match"}
              </strong>
            </div>
            {nextMatch?.scheduledAt ? (
              <span>
                {formatPersonalMatchDateTime(
                  nextMatch.scheduledAt
                )}
              </span>
            ) : nextMatch?.dateLabel ? (
              /*
               * Backward-compatible fallback while an older API response
               * may still be in the browser cache during deployment.
               */
              <span>{nextMatch.dateLabel}</span>
            ) : null}
          </div>

          {nextMatch ? (
            <div className={personalCricketStyles.nextMatch}>
              <span>🏟️</span>
              <div>
                <strong>
                  {nextMatch.opponentName
                    ? `vs ${nextMatch.opponentName}`
                    : "Upcoming fixture"}
                </strong>
                <small>
                  {nextMatch.venue || "Venue not entered"}
                </small>
              </div>
            </div>
          ) : (
            <p className={personalCricketStyles.muted}>
              Your linked team does not currently have a future scheduled match.
            </p>
          )}

          <div className={personalCricketStyles.lastChange}>
            <small>WHAT CHANGED IN YOUR LAST APPEARANCE?</small>
            {lastMatch ? (
              <p>
                <b>{lastMatch.runs || 0} runs</b>
                {Number(lastMatch.wickets || 0) > 0
                  ? ` · ${lastMatch.wickets} wicket${lastMatch.wickets === 1 ? "" : "s"}`
                  : ""}
                {Number(lastMatch.fieldingTotal || 0) > 0
                  ? ` · ${lastMatch.fieldingTotal} fielding contribution${lastMatch.fieldingTotal === 1 ? "" : "s"}`
                  : ""}
              </p>
            ) : (
              <p>No qualifying appearance recorded yet.</p>
            )}
          </div>
        </section>
      </div>

      {achievements.length ? (
        <section className={personalCricketStyles.panel}>
          <div className={personalCricketStyles.panelHead}>
            <div>
              <small>🏅 TROPHY CABINET</small>
              <strong>Your achievements</strong>
            </div>
            <span>{achievements.length} earned</span>
          </div>

          <div className={personalCricketStyles.achievementGrid}>
            {achievements.map((badge) => (
              <article
                key={badge.id}
                className={
                  badge.tier === "elite"
                    ? personalCricketStyles.elite
                    : ""
                }
              >
                <span>{badge.icon}</span>
                <div>
                  <strong>{badge.title}</strong>
                  <small>{badge.description}</small>
                </div>
              </article>
            ))}
          </div>
        </section>
      ) : null}

      <PlayerAccountLinker
        leagueId={leagueId}
        linked={true}
        onChanged={onLinkChanged}
      />
    </div>
  );
}

export default function DashboardClient() {
  const { data: session } = useSession();
  const router = useRouter();
  const searchParams = useSearchParams();

  const returnToRaw =
    searchParams.get("returnTo") || "";

  const returnTo =
    returnToRaw.startsWith("/") &&
    !returnToRaw.startsWith("//")
      ? returnToRaw
      : "";

  const returningToMatchDay =
    returnTo.includes("/match-day");

  const requestedDashboardTab =
    String(
      searchParams.get("tab") ||
      ""
    )
      .trim()
      .toLowerCase();

  const isOfflineResumeRequest =
    searchParams.get("offlineResume") === "1";

  const requestedMatchesSubTab =
    String(
      searchParams.get(
        "matchesSubTab"
      ) ||
      ""
    )
      .trim()
      .toUpperCase();

  const requestedLeagueId =
    Number(
      searchParams.get(
        "leagueId"
      )
    );

  const requestedTeamId =
    Number(
      searchParams.get(
        "teamId"
      )
    );

  const requestedDashboardSection =
    String(
      searchParams.get(
        "section"
      ) ||
      ""
    )
      .trim()
      .toLowerCase();

  const requestedMatchId =
    Number(
      searchParams.get(
        "matchId"
      )
    );

  const scoringDeepLinkLoadedRef =
    useRef("");

  const [teams, setTeams] = useState([]);
  const [matches, setMatches] = useState([]);
  const [selectedMatchId, setSelectedMatchId] = useState("");
  const [toast, setToast] = useState(null);
  const [activeQuickAction, setActiveQuickAction] = useState(null);
  const [expandedTeamId, setExpandedTeamId] = useState(null);
  const [selectedPlayerId, setSelectedPlayerId] = useState("");
  const [leagueName, setLeagueName] = useState("");
  const [showWicketModal, setShowWicketModal] = useState(false);
  const [
    wicketSubmissionInFlight,
    setWicketSubmissionInFlight,
  ] = useState(false);
  const [selectedWicketType, setSelectedWicketType] = useState("BOWLED");
  const [selectedNewBatter, setSelectedNewBatter] = useState("");
  const [showExtrasModal, setShowExtrasModal] = useState(false);
  const [selectedExtraType, setSelectedExtraType] = useState("WIDE");
  const [leagues, setLeagues] = useState([]);
  const [leagueForm, setLeagueForm] = useState({name: ""});
  const [selectedPlayerTeamId, setSelectedPlayerTeamId] = useState("");
  const [showLeagueModal, setShowLeagueModal] = useState(false);
  const [showEditLeagueModal, setShowEditLeagueModal] = useState(false);
  const [editLeagueSaving, setEditLeagueSaving] = useState(false);
  const [editLeagueForm, setEditLeagueForm] = useState({
    name: "",
    visibility: "PRIVATE",
  });
  const [pendingNonBallEvent, setPendingNonBallEvent] = useState(false);
  const [selectedTeamId, setSelectedTeamId] = useState("");
  const [expandedLeagueId, setExpandedLeagueId] = useState(null);
  const [activeLeagueId, setActiveLeagueId] = useState("");

  /*
   * Keep the globally rendered Resume Match control synchronized with the
   * league currently selected on the Dashboard. The resume banner lives in
   * AuthNav (RootLayout), so it cannot read this component's React state
   * directly. Persisting + publishing the value gives it a safe, minimal
   * cross-component signal without coupling the scoring UI to the header.
   */
  useEffect(() => {
    if (typeof window === "undefined") {
      return;
    }

    const numericLeagueId = Number(activeLeagueId);
    const validLeagueId =
      Number.isInteger(numericLeagueId) &&
      numericLeagueId > 0
        ? numericLeagueId
        : null;

    if (validLeagueId) {
      window.localStorage.setItem(
        "activeLeagueId",
        String(validLeagueId)
      );
    } else {
      window.localStorage.removeItem(
        "activeLeagueId"
      );
    }

    window.dispatchEvent(
      new CustomEvent(
        "cric4all:active-league-changed",
        {
          detail: {
            leagueId: validLeagueId,
          },
        }
      )
    );
  }, [activeLeagueId]);

  const [activeTab, setActiveTab] = useState("management");
  const [permissions, setPermissions] = useState(null);
  const [showControls, setShowControls] = useState(false);
  const [matchDetail, setMatchDetail] = useState(null);
  const [scoreboard, setScoreboard] = useState(null);
  const [showDlsModal, setShowDlsModal] = useState(false);
  const [dlsBusy, setDlsBusy] = useState(false);
  const [dlsError, setDlsError] = useState("");
  const [dlsState, setDlsState] = useState(null);
  const [showSuperOverModal, setShowSuperOverModal] = useState(false);
  const [superOverBusy, setSuperOverBusy] = useState(false);
  const [superOverError, setSuperOverError] = useState("");
  const [superOverState, setSuperOverState] = useState(null);
  const [superOverMatch, setSuperOverMatch] = useState(null);
  const [superOverSetup, setSuperOverSetup] = useState({
    batter1Id: "",
    batter2Id: "",
    batter3Id: "",
    bowlerId: "",
  });
  const [dlsForm, setDlsForm] = useState({
    mode: "STANDARD",

    /*
     * Official DLS has two genuinely different scorer workflows:
     *
     * RESUME:
     *   officials supply a revised innings allocation + target and play
     *   continues.
     *
     * END:
     *   play cannot resume; officials supply the official par at the exact
     *   suspension point and Cric4All ends the match from that figure.
     */
    officialAction: "",

    revisedOvers: "",
    target: "",
    par: "",
    note: "",
  });
  const [stats, setStats] = useState({ batting: [], bowling: [] });
  const [runOutRuns, setRunOutRuns] = useState(null);
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");
  const [showAdvancedSheet, setShowAdvancedSheet] = useState(false);
  const [showRetiredHurtModal, setShowRetiredHurtModal] = useState(false);
  const [retiredHurtBatterId, setRetiredHurtBatterId] = useState("");
  const [retiredPlayerType, setRetiredPlayerType] = useState("STRIKER");
  const [replacementPlayerId, setReplacementPlayerId] = useState("");
  const [selectedPlayers, setSelectedPlayers] = useState({});
  const [showBowlerModal, setShowBowlerModal] = useState(false);
  const [pendingBallData, setPendingBallData] = useState(null);
  const [mustChangeBowler, setMustChangeBowler] = useState(false);
  const [teamForm, setTeamForm] = useState({leagueId: "", name: ""});
const [playerForm, setPlayerForm] = useState({names: "",teamId: "",leagueId: ""});
const [preferencesLoaded, setPreferencesLoaded] = useState(false);
const [searchTerm, setSearchTerm] = useState("");
const [showFullScoreboard, setShowFullScoreboard] = useState(false);
const [roleFilter, setRoleFilter] = useState("ALL");
const [pointsTable, setPointsTable] = useState([]);
const [showPlayerModal, setShowPlayerModal] = useState(false);
const [showStartMatchModal, setShowStartMatchModal] = useState(false);
const [startMatchData, setStartMatchData] = useState({matchId: "",battingFirstTeamId: ""});
const [playerLeagueId, setPlayerLeagueId] = useState(null);
const [showPermissionModal,setShowPermissionModal] = useState(false);
const [selectedMember, setSelectedMember] = useState(null);
const [showAddTeam, setShowAddTeam] = useState(false);
const [playerNames, setPlayerNames] = useState("");
const [selectedMemberId, setSelectedMemberId] = useState("");
const [isMobile, setIsMobile] = useState(false);
const [showAddPlayers, setShowAddPlayers] = useState(false);

/*
 * Growth Phase 5 — Move Your League to Cric4All.
 * CSV is parsed locally for instant preview; only normalized rows are sent.
 */
const [showLeagueImportModal, setShowLeagueImportModal] = useState(false);
const [leagueImportText, setLeagueImportText] = useState("");
const [leagueImportRows, setLeagueImportRows] = useState([]);
const [leagueImportErrors, setLeagueImportErrors] = useState([]);
const [leagueImportSaving, setLeagueImportSaving] = useState(false);
const [leagueImportResult, setLeagueImportResult] = useState(null);
const [memberSearch, setMemberSearch] = useState("");
const [unregisteringMemberId, setUnregisteringMemberId] = useState(null);
const [matchesSubTab, setMatchesSubTab] = useState("ACTIVE");

/*
 * Completed history can grow very large. Rendering every completed match
 * card (desktop + mobile details) in one React pass makes the Completed tab
 * feel slow even though the data is already loaded.
 *
 * Render a small first page immediately, then progressively reveal more.
 */
const COMPLETED_MATCH_RENDER_PAGE_SIZE = 6;
const [
  completedMatchRenderLimit,
  setCompletedMatchRenderLimit,
] = useState(
  COMPLETED_MATCH_RENDER_PAGE_SIZE
);
const [me, setMe] = useState(null);
const [permissionsLoading, setPermissionsLoading] = useState(false);

/*
 * Keep the logged-in user's permissions separate from the permissions being
 * edited for another league member. Reusing one state object for both could
 * make the scorer's own buttons disappear while an admin inspected a member.
 */
const [memberPermissions, setMemberPermissions] = useState(null);

/*
 * A permission object is only valid for the league it was loaded for. This
 * prevents a canScoreMatch=true value from a previously selected league from
 * being reused while the next league's permission request is still loading.
 */
const permissionsLeagueIdRef = useRef(null);

/* Mobile full-screen scorer account menu. */
const [showScorerAccountMenu, setShowScorerAccountMenu] = useState(false);

/* Role-bound league invitation composer. */
const [showInviteRoleModal, setShowInviteRoleModal] = useState(false);
const [selectedInviteRole, setSelectedInviteRole] = useState("VIEWER");
const [inviteGenerating, setInviteGenerating] = useState(false);

/* Owner/Super Admin player inactivity settings panel. */
const [showPlayerInactivitySettings, setShowPlayerInactivitySettings] = useState(false);
const [showBirthdayLeagueToolSettings, setShowBirthdayLeagueToolSettings] = useState(false);

const canScoreCurrentLeague =
  Boolean(permissions?.canScoreMatch) &&
  Boolean(activeLeagueId) &&
  String(permissionsLeagueIdRef.current || "") === String(activeLeagueId);
const scheduledMatches = matches.filter((m) => normalizeStatus(m.status) === "SCHEDULED");
const [scoringSubTab, setScoringSubTab] = useState("ADVANCED");
const [statsSubTab, setStatsSubTab] = useState("BATTING");
const [dashboardLeadersTab, setDashboardLeadersTab] = useState("BATTING");
const [leagueStats, setLeagueStats] = useState(null);
const [myCricket, setMyCricket] = useState(null);
const [myCricketLoading, setMyCricketLoading] = useState(false);
const [awardsData, setAwardsData] = useState(null);
const [awardsLoading, setAwardsLoading] = useState(false);
const [awardsWeekOffset, setAwardsWeekOffset] = useState(0);
const [awardsMonthOffset, setAwardsMonthOffset] = useState(0);
const [awardsPeriodType, setAwardsPeriodType] = useState("WEEK");
const [awardsSeriesId, setAwardsSeriesId] = useState("ALL");
const [awardsView, setAwardsView] = useState("AWARDS");

const awardsSeriesMode =
  awardsSeriesId !==
  "ALL";
const [rankingType, setRankingType] = useState("topRunScorers");
const [aiAnalysis, setAiAnalysis] = useState("");
const [aiReview, setAiReview] = useState(null);
const [aiReviewMeta, setAiReviewMeta] = useState(null);
const [aiReviewTab, setAiReviewTab] = useState("OVERVIEW");
const [aiShareCopied, setAiShareCopied] = useState("");
const [aiAnalysisLoading, setAiAnalysisLoading] = useState(false);
const [showAiAnalysisModal, setShowAiAnalysisModal] = useState(false);
const [showMatchCreatedModal, setShowMatchCreatedModal] = useState(false);
const [createdMatchInfo, setCreatedMatchInfo] = useState(null);
const [contextFilters, setContextFilters] = useState({teamIds: [],matchIds: [],playerNames: [],statuses: [],roles: [],seriesIds: [],years: []});
const [openFilter, setOpenFilter] = useState(null);
const [filterSearch, setFilterSearch] = useState("");
const [filterCategory, setFilterCategory] = useState("teams");
const [seriesList, setSeriesList] = useState([]);
const [selectedSeriesId, setSelectedSeriesId] = useState("");
const [selectedYear, setSelectedYear] = useState(String(new Date().getFullYear()));
//const [seriesForm, setSeriesForm] = useState({name: "",year: new Date().getFullYear(),description: ""});
const [seriesForm, setSeriesForm] = useState({name: "",year: new Date().getFullYear(),status: "ACTIVE",});
const [editingSeries, setEditingSeries] = useState(null);
const [showSeriesModal, setShowSeriesModal] = useState(false);
const [showDeliverySetupModal, setShowDeliverySetupModal] = useState(false);
const [deliverySetupReason, setDeliverySetupReason] = useState("");
const [pendingDeliverySetupAfterStart, setPendingDeliverySetupAfterStart] = useState(false);
const [pendingSecondInningsSetup, setPendingSecondInningsSetup] = useState(false);
const [isSavingBall, setIsSavingBall] = useState(false);
const [offlineSyncState, setOfflineSyncState] = useState({
  online: typeof navigator === "undefined" ? true : navigator.onLine,
  pending: 0,
  syncing: false,
  conflict: null,
  lastError: "",
});

/*
 * `offlineResume=1` identifies the Resume Match navigation, but it does not
 * mean the device is still offline. A scorer can reconnect first and then tap
 * Resume Match. Only use the reduced IndexedDB-only dashboard bootstrap when
 * the browser is actually offline. When online, keep the resume deep link but
 * load the complete server-backed league and match lists.
 */
const isTrueOfflineResume =
  isOfflineResumeRequest &&
  offlineSyncState.online === false;
const [offlineLocalMatchComplete, setOfflineLocalMatchComplete] = useState(false);
const offlineSyncRunningRef = useRef(false);
const offlineServerSequencesRef = useRef({
  matchId: null,
  1: 0,
  2: 0,
});
const [pressedScoreKey, setPressedScoreKey] = useState("");
const [optimisticScoreboard, setOptimisticScoreboard] = useState(null);
const [selectedExtraOption, setSelectedExtraOption] = useState("");
const [showCorrectionModal, setShowCorrectionModal] =useState(false);
const [scorerMode, setScorerMode] = useState(false);
const [scorerDrawer, setScorerDrawer] = useState(null);
const [voiceRecording, setVoiceRecording] = useState(false);
const [voiceBusy, setVoiceBusy] = useState(false);
const [voiceMessage, setVoiceMessage] = useState("");
const [voiceRecorder, setVoiceRecorder] = useState(null);
const [voiceChunks, setVoiceChunks] = useState([]);
const [correctionForm, setCorrectionForm] = useState({
  inningsNo: "1",
  afterBallId: "",
  retiredPlayerId: "",
  replacementPlayerId: "",
  replacementOutBallId: "",
  newBatterAfterReplacementId: "",
});
const [lastCorrectionId, setLastCorrectionId] = useState(null);
const [showKeeperChangeModal, setShowKeeperChangeModal] = useState(false);
const [keeperChangeForm, setKeeperChangeForm] = useState({newKeeperId: "",note: "",});
const [keeperChangeSaving, setKeeperChangeSaving] = useState(false);
const [undoSaving, setUndoSaving] = useState(false);
const [showEditMatchModal, setShowEditMatchModal] = useState(false);
const [editingMatch, setEditingMatch] = useState(null);

const [showVenueModal, setShowVenueModal] = useState(false);
const [venueMatch, setVenueMatch] = useState(null);
const [venueSaving, setVenueSaving] = useState(false);
const [venueForm, setVenueForm] = useState({
  venueName: "",
  venueAddress: "",
});

const [editMatchForm, setEditMatchForm] = useState({
  scheduledAt: "",
  venueName: "",
  venueAddress: "",
  oversPerInnings: 20,
  powerplayOversInnings: 6,
  maxWicketsPerInnings: "",
  maxOversPerBowler: "",
  seriesId: "",
  teamAId: "",
  teamBId: "",
  teamACaptainId: "",
  teamBCaptainId: "",
  teamAViceCaptainId: "",
  teamBViceCaptainId: "",
  teamAWicketKeeperId: "",
  teamBWicketKeeperId: "",
});
const [correctionStatus, setCorrectionStatus] = useState("");
const [correctionSaving, setCorrectionSaving] = useState(false);
const [rollbackSaving, setRollbackSaving] = useState(false);
const [leagueStatsLoading, setLeagueStatsLoading] = useState(false);
const [pendingMatchesSubTab, setPendingMatchesSubTab] = useState("");
const [instantDeliveryStatus, setInstantDeliveryStatus] = useState("");
const [showPublicLeagueDrawer, setShowPublicLeagueDrawer] = useState(false);
const [showFollowedLeaguesDrawer, setShowFollowedLeaguesDrawer] =  useState(false);
const [showMatchPicker, setShowMatchPicker] = useState(false);
const [overCompleteNotice, setOverCompleteNotice] = useState("");
const [voiceScoringOn, setVoiceScoringOn] = useState(false);
const [voiceStatus, setVoiceStatus] = useState("");
const [voiceSupported, setVoiceSupported] = useState(false);
const [dashboardReady, setDashboardReady] = useState(false);
const [showEditTeamModal, setShowEditTeamModal] = useState(false);
const [editingTeam, setEditingTeam] = useState(null);
const [showEditPlayerModal, setShowEditPlayerModal] = useState(false);
const [editingPlayer, setEditingPlayer] = useState(null);
const [editPlayerName, setEditPlayerName] = useState("");
const [editPlayerWhatsappNumber, setEditPlayerWhatsappNumber] = useState("");
const [editPlayerWhatsappOptIn, setEditPlayerWhatsappOptIn] = useState(false);
const [teamEditName, setTeamEditName] = useState("");
const [teamRoleForm, setTeamRoleForm] = useState({
  defaultCaptainId: "",
  defaultViceCaptainId: "",
  defaultWicketKeeperId: "",
});
const [showTransferPlayerModal, setShowTransferPlayerModal] = useState(false);
const [transferPlayer, setTransferPlayer] = useState(null);
const [transferTeamId, setTransferTeamId] = useState("");
const [pageVisible, setPageVisible] = useState(true);
const [ballSaveInFlight, setBallSaveInFlight] = useState(false);
const [tabsScrolled, setTabsScrolled] = useState(false);
const [endInningsAfterWicket, setEndInningsAfterWicket] = useState(false);
const [userActivity, setUserActivity] = useState(null);
const [userActivityLoading, setUserActivityLoading] = useState(false);
const [auditLogs, setAuditLogs] = useState([]);
const [auditLogsLoading, setAuditLogsLoading] = useState(false);
const [growthData, setGrowthData] = useState(null);
const [growthLoading, setGrowthLoading] = useState(false);
const [growthDays, setGrowthDays] = useState(30);
const [showCorrectionCenter, setShowCorrectionCenter] = useState(false);
const [correctionType, setCorrectionType] = useState("TRANSFER_BATTER_RUNS");
const [correctionReason, setCorrectionReason] = useState("");
const [correctionHistory, setCorrectionHistory] = useState([]);
const [correctionLoading, setCorrectionLoading] = useState(false);
const [correctionInnings, setCorrectionInnings] = useState(1);
const [activeScoreboardInnings, setActiveScoreboardInnings] = useState(1);
const [openPlayerActionId, setOpenPlayerActionId] = useState(null);
const [selectedAuditLeagueKey, setSelectedAuditLeagueKey] = useState("ALL");
const [showScoringFormSheet, setShowScoringFormSheet] = useState(false);
const [bowlerSearchText, setBowlerSearchText] = useState("");
const [scoringFormSubmitting, setScoringFormSubmitting] = useState(false);
const [
  postMatchKitPrompt,
  setPostMatchKitPrompt,
] = useState(null);
const postMatchKitAutoPromptedRef =
  useRef(new Set());
const selectedMatchExplicitLoadRef =
  useRef("");

useEffect(() => {
  if (
    !postMatchKitPrompt ||
    typeof document === "undefined"
  ) {
    return;
  }

  /*
   * The kit-custody prompt is a match-end blocking modal. Keep Scorer Mode
   * visible underneath it, but prevent the scorer page from scrolling while
   * the custody decision is being made.
   */
  const previousOverflow =
    document.body.style.overflow;

  document.body.style.overflow =
    "hidden";

  return () => {
    document.body.style.overflow =
      previousOverflow;
  };
}, [postMatchKitPrompt]);
const [
  milestoneCelebration,
  setMilestoneCelebration,
] = useState(null);

const normalizedSessionEmail = String(
  session?.user?.email || ""
)
  .trim()
  .toLowerCase();

const isSuperAdmin =
  normalizedSessionEmail ===
  "surprisecricket11@gmail.com";

  
useEffect(() => {
  fetch("/api/me")
    .then((r) => r.json())
    .then(setMe);
}, []);

useEffect(() => {
  if (!message && !error) return;

  const timer = setTimeout(() => {
    setMessage("");
    setError("");
  }, 20000); // 30 seconds

  return () => clearTimeout(timer);
}, [message, error]);

useEffect(() => {
  if (!session?.user?.email) return;

  const sendHeartbeat = () => {
    if (document.visibilityState !== "visible") return;

    fetch("/api/user/heartbeat", {
      method: "POST",
    }).catch(() => {});
  };

  sendHeartbeat();

  const interval = setInterval(sendHeartbeat, 2 * 60 * 1000);

  return () => clearInterval(interval);
}, [session?.user?.email]);

const selectedLeague =
  leagues.find(
    (l) => String(l.id) === String(activeLeagueId)
  );
const activeLeague =
  leagues.find(
    (league) =>
      league.id ===
      Number(activeLeagueId)
  ) || null;

useEffect(() => {
  if (
    !selectedMatchId ||
    activeTab !== "scoring" ||
    !scoreboard
  ) {
    return;
  }

  const status =
    scoreboard?.match?.status ||
    matchDetail?.status ||
    "";

  if (isCompletedMatchStatus(status)) {
    clearOfflineScoringSession(selectedMatchId);
    return;
  }

  const inningsList =
    Array.isArray(scoreboard?.innings)
      ? scoreboard.innings
      : [];

  const latestInnings =
    inningsList.length
      ? inningsList[inningsList.length - 1]
      : null;

  const scoreText =
    latestInnings
      ? `${latestInnings?.teamName || ""} ${
          latestInnings?.runs ?? 0
        }/${latestInnings?.wickets ?? 0} (${
          latestInnings?.oversDisplay || "0.0"
        } ov)`
      : "";

  saveOfflineScoringSession({
    matchId: Number(selectedMatchId),
    leagueId: Number(activeLeagueId) || null,
    leagueName:
      activeLeague?.name ||
      scoreboard?.match?.leagueName ||
      "",
    teamAName:
      scoreboard?.match?.teamAName ||
      matchDetail?.teamA?.name ||
      "",
    teamBName:
      scoreboard?.match?.teamBName ||
      matchDetail?.teamB?.name ||
      "",
    scoreText,
    inningsNo: Number(
      scoreboard?.currentInnings ||
      scoreboard?.currentState?.inningsNo ||
      1
    ),
    matchStatus: status,
  });

  // Prime the authenticated Next.js Dashboard document plus its JS/CSS while
  // internet is available. The scoring DATA remains in existing IndexedDB.
  if (
    typeof navigator !== "undefined" &&
    navigator.onLine !== false
  ) {
    primeOfflineScoringShell().catch(() => {});
  }
}, [
  selectedMatchId,
  activeTab,
  activeLeagueId,
  activeLeague?.name,
  scoreboard,
  matchDetail,
]);

useEffect(() => {
  if (
    !selectedMatchId ||
    activeTab !== "scoring"
  ) {
    return;
  }

  const isOffline = () =>
    typeof navigator !== "undefined" &&
    navigator.onLine === false;

  function handleOfflineLinkClick(event) {
    if (!isOffline()) return;

    const anchor =
      event.target?.closest?.("a[href]");

    if (!anchor) return;

    const rawHref =
      anchor.getAttribute("href");

    if (
      !rawHref ||
      rawHref.startsWith("#") ||
      rawHref.startsWith("javascript:")
    ) {
      return;
    }

    try {
      const target =
        new URL(anchor.href, window.location.href);

      const sameScorer =
        target.pathname === "/dashboard" &&
        target.searchParams.get("tab") === "scoring" &&
        Number(target.searchParams.get("matchId")) ===
          Number(selectedMatchId);

      if (sameScorer) return;
    } catch {
      return;
    }

    const leave =
      window.confirm(
        "You are offline. Your current match is saved on this device and can be resumed.\n\nLeave scoring?"
      );

    if (!leave) {
      event.preventDefault();
      event.stopPropagation();
    }
  }

  function handleBeforeUnload(event) {
    if (!isOffline()) return;
    event.preventDefault();
    event.returnValue = "";
  }

  document.addEventListener(
    "click",
    handleOfflineLinkClick,
    true
  );
  window.addEventListener(
    "beforeunload",
    handleBeforeUnload
  );

  return () => {
    document.removeEventListener(
      "click",
      handleOfflineLinkClick,
      true
    );
    window.removeEventListener(
      "beforeunload",
      handleBeforeUnload
    );
  };
}, [selectedMatchId, activeTab]);

useEffect(() => {
  if (activeTab === "scoring") {
    setScoringSubTab("ADVANCED");
  }
}, [activeTab]);
useEffect(() => {
  if (!activeLeagueId) return;

  if (isSuperAdmin) {
    permissionsLeagueIdRef.current = String(activeLeagueId);

    setPermissions({
        canViewDashboard:  true,
  canViewManagement:  true,
  canViewMatches:  true,
  canViewScoring:  true,
  canViewStats:  true,

  canCreateLeague:  true,
  canEditLeague:  true,
  canDeleteLeague:  true,

  canManageMembers:  true,
  canManagePermissions:  true,

  canCreateTeam:  true,
  canEditTeam:  true,
  canDeleteTeam:  true,

  canCreatePlayer:  true,
  canEditPlayer:  true,
  canDeletePlayer:  true,

  canCreateMatch:  true,
  canEditMatch:  true,
  canDeleteMatch:  true,

  canScoreMatch:  true,
  canEditScore:  true,
  canUndoBall:  true,
  canSwapStrike:  true,
  canRetirePlayer:  true,

  canEndMatch:  true,
  canAbandonMatch:  true,
  canLockMatch:  true,

  canExportStats:  true,
  canViewAuditLogs:  true
    });

    return;
  }
  //loadPermissions(selectedMember);
  loadMyLeaguePermissions(activeLeagueId);
}, [activeLeagueId, isSuperAdmin]);
useEffect(() => {
  function onVisibilityChange() {
    setPageVisible(document.visibilityState === "visible");
  }

  document.addEventListener("visibilitychange", onVisibilityChange);
  onVisibilityChange();

  return () => {
    document.removeEventListener("visibilitychange", onVisibilityChange);
  };
}, []);

useEffect(() => {
  function handleVisibilityChange() {
    setPageVisible(document.visibilityState === "visible");
  }

  handleVisibilityChange();
  document.addEventListener("visibilitychange", handleVisibilityChange);

  return () => {
    document.removeEventListener("visibilitychange", handleVisibilityChange);
  };
}, []);

useEffect(() => {
  if (activeTab !== "Points" || !activeLeagueId) return;
  loadPointsTable(activeLeagueId);
}, [activeTab, activeLeagueId]);

useEffect(() => {
  setContextFilters({
    teamIds: [],
    matchIds: [],
    playerNames: [],
    statuses: [],
    roles: [],
    seriesIds: [],
    years: []
  });

  setOpenFilter(null);
}, [activeLeagueId]);
useEffect(() => {
  loadSeries();
}, [activeLeagueId]);
useEffect(() => {
  if (activeTab !== "matches") return;
  if (!pendingMatchesSubTab) return;

  setMatchesSubTab(pendingMatchesSubTab);
  setPendingMatchesSubTab("");
}, [activeTab, pendingMatchesSubTab]);
const selectedSeries = seriesList.find(
  (s) => Number(s.id) === Number(selectedSeriesId)
);

useEffect(() => {
  if (activeTab !== "admin") return;
  loadUserActivity();
}, [activeTab]);
useEffect(() => {
  if (activeTab !== "admin") return;

  loadUserActivity();
  loadAuditLogs();
  loadGrowthData(growthDays);
}, [activeTab, activeLeagueId]);

const battingTeamForCorrection =
  correctionInnings === 1
    ? matchDetail?.battingFirstTeamId === matchDetail?.teamA?.id
      ? matchDetail?.teamA
      : matchDetail?.teamB
    : matchDetail?.battingFirstTeamId === matchDetail?.teamA?.id
      ? matchDetail?.teamB
      : matchDetail?.teamA;

const bowlingTeamForCorrection =
  correctionInnings === 1
    ? matchDetail?.battingFirstTeamId === matchDetail?.teamA?.id
      ? matchDetail?.teamB
      : matchDetail?.teamA
    : matchDetail?.battingFirstTeamId === matchDetail?.teamA?.id
      ? matchDetail?.teamA
      : matchDetail?.teamB;



async function loadUserActivity() {
  try {
    setUserActivityLoading(true);
    const data = await api("/api/admin/user-activity");
    setUserActivity(data);
  } catch (err) {
    setError(err.message || "Failed to load user activity.");
  } finally {
    setUserActivityLoading(false);
  }
}
async function loadGrowthData(days = growthDays) {
  try {
    setGrowthLoading(true);
    const data = await api(`/api/admin/growth?days=${Number(days) || 30}`);
    setGrowthData(data);
  } catch (err) {
    setError(err.message || "Failed to load growth analytics.");
  } finally {
    setGrowthLoading(false);
  }
}

async function loadAuditLogs() {
  try {
    setAuditLogsLoading(true);

    //const query = await api("/api/audit-logs");

    const data = await api("/api/audit-logs");
    setAuditLogs(Array.isArray(data) ? data : []);
  } catch (err) {
    setError(err.message || "Failed to load audit logs.");
  } finally {
    setAuditLogsLoading(false);
  }
}

async function loadAiAnalysis(matchId) {
  try {
    /*
     * Open the modal immediately. A first-time AI review may legitimately
     * take several seconds to generate, but the button must never look
     * frozen while the network/OpenAI work is happening.
     */
    setAiAnalysisLoading(true);
    setAiShareCopied("");
    setAiAnalysis("");
    setAiReview(null);
    setAiReviewMeta(null);
    setAiReviewTab("OVERVIEW");
    setShowAiAnalysisModal(true);

    const data = await api(
      `/api/matches/${matchId}/ai-analysis`
    );

    setAiAnalysis(
      data.analysis || ""
    );

    setAiReview(
      data.review || null
    );

    setAiReviewMeta({
      cached:
        data.cached ===
        true,

      generatedAt:
        data.generatedAt ||
        data.review
          ?.cacheMetadata
          ?.generatedAt ||
        null,

      generationSource:
        data.review
          ?.cacheMetadata
          ?.generationSource ||
        null,
    });

    setAiReviewTab("OVERVIEW");
  } catch (err) {
    setError(
      err.message ||
        "Unable to load AI Match Intelligence."
    );
  } finally {
    setAiAnalysisLoading(false);
  }
}

async function copyAiReviewText(
  text,
  label
) {
  const value =
    String(text || "").trim();

  if (!value) {
    setError(
      "There is no share text available yet."
    );
    return;
  }

  try {
    await navigator.clipboard.writeText(
      value
    );

    setAiShareCopied(label);

    window.setTimeout(
      () => setAiShareCopied(""),
      1800
    );
  } catch {
    setError(
      "Copy failed. Please select and copy the text manually."
    );
  }
}
async function loadSeries() {
  if (!activeLeagueId) return;

  const data = await api(`/api/series?leagueId=${activeLeagueId}`);

  setSeriesList(data || []);
}
async function loadPermissions(member) {
  try {
    if (!activeLeague?.id || !member?.id) {
      setError("Member id is required");
      return;
    }

    setPermissionsLoading(true);

    const data = await api(
      `/api/leagues/${activeLeague.id}/permissions?memberId=${member.id}`
    );

    const latestMember = data.member;

    setSelectedMember(latestMember);

    const loadedPermissions = {
      role: latestMember.role || "VIEWER",
    };

    for (const field of PERMISSION_FIELDS) {
      loadedPermissions[field] =
        latestMember[field] ?? false;
    }

    setMemberPermissions(loadedPermissions);
    setShowPermissionModal(true);
  } catch (err) {
    console.error(err);
    setError(err.message);
  } finally {
    setPermissionsLoading(false);
  }
}
const teamsForSelectedLeague = useMemo(() => {
  if (!activeLeagueId) {
    return [];
  }

  const leagueId = String(activeLeagueId);

  // Prefer the complete /api/teams response. It contains the full Team
  // record (including players and permanent role fields).
  const loadedTeamsForLeague = (teams || []).filter(
    (team) => String(team.leagueId) === leagueId
  );

  if (loadedTeamsForLeague.length > 0) {
    return loadedTeamsForLeague;
  }

  // Fallback while /api/teams is loading or if a league payload is the only
  // team source available.
  return selectedLeague?.teams || [];
}, [teams, activeLeagueId, selectedLeague]);

const selectedTeam = useMemo(() => {
  if (!selectedTeamId) {
    return null;
  }

  const wantedTeamId = String(selectedTeamId);

  return (
    teamsForSelectedLeague.find(
      (team) => String(team.id) === wantedTeamId
    ) || null
  );
}, [selectedTeamId, teamsForSelectedLeague]);

const canEditSelectedTeam = Boolean(
  selectedTeamId &&
  selectedTeam &&
  (isSuperAdmin || permissions?.canEditTeam === true)
);

const canDeleteSelectedTeam = Boolean(
  selectedTeamId &&
  selectedTeam &&
  (isSuperAdmin || permissions?.canDeleteTeam === true)
);

const filteredMembers =
  activeLeague?.members?.filter(
    (member) => {
      const matchesSearch =
        (member.user?.name || "")
          .toLowerCase()
          .includes(
            searchTerm.toLowerCase()
          ) ||
        (member.user?.email || "")
          .toLowerCase()
          .includes(
            searchTerm.toLowerCase()
          );

      const matchesRole =
        roleFilter === "ALL" ||
        member.role === roleFilter;

      return (
        matchesSearch &&
        matchesRole
      );
    }
  ) || [];

  const helpCardStyle = {
  padding: 20,
  borderRadius: 12,

  border: "1px solid #e2e8f0",
  boxShadow:
    "0 2px 8px rgba(15,23,42,0.06)",
};

  const playerTeams =
  leagues
    .find((l) => l.id === playerLeagueId)
    ?.teams || [];
const selectedPlayerLeague = leagues.find(
  (l) => l.id === Number(playerLeagueId)
);
useEffect(() => {
  if (
    activeLeague?.members?.length > 0
  ) {
    setSelectedMember(
      activeLeague.members[0]
    );
  }
}, [activeLeague]);
useEffect(() => {
  async function initializeDashboard() {
    const browserOffline =
      typeof navigator !== "undefined" &&
      navigator.onLine === false;

    /*
     * OFFLINE RESUME BOOTSTRAP
     * ------------------------
     * Do not wait for /api/leagues, /api/teams, /api/me, permissions or the
     * server-backed match list. Those requests cannot succeed while offline
     * and were the reason the cached Dashboard remained on "Loading...".
     *
     * The scorer itself already has the authoritative local match snapshot in
     * IndexedDB. Here we only create the minimum local Dashboard context needed
     * to render the scoring tab and let loadSelectedMatch() restore that
     * snapshot.
     */
    if (
      isTrueOfflineResume &&
      requestedDashboardTab === "scoring" &&
      Number.isInteger(requestedMatchId) &&
      requestedMatchId > 0
    ) {
      const resumeSession =
        getOfflineScoringSession();

      const offlineLeagueId =
        Number.isInteger(requestedLeagueId) &&
        requestedLeagueId > 0
          ? requestedLeagueId
          : Number(resumeSession?.leagueId) > 0
            ? Number(resumeSession.leagueId)
            : null;

      setDashboardReady(false);
      setPermissionsLoading(false);
      setActiveTab("scoring");
      setScoringSubTab("ADVANCED");
      setSelectedMatchId(String(requestedMatchId));

      if (offlineLeagueId) {
        setActiveLeagueId(offlineLeagueId);

        /*
         * Minimal local league context only. We deliberately do not fabricate
         * teams, members or admin data. This exists solely so the scorer header
         * has a meaningful league name while disconnected.
         */
        setLeagues((current) => {
          if (
            current.some(
              (league) =>
                Number(league.id) ===
                Number(offlineLeagueId)
            )
          ) {
            return current;
          }

          return [
            ...current,
            {
              id: offlineLeagueId,
              name:
                resumeSession?.leagueName ||
                "Offline League",
              teams: [],
              members: [],
              series: [],
            },
          ];
        });
      }

      /*
       * Offline mode gets SCORING-ONLY permissions. We do not expose management
       * or mutation tabs based on cached assumptions.
       */
      if (offlineLeagueId) {
        permissionsLeagueIdRef.current = String(offlineLeagueId);
      }

      setPermissions({
        canViewDashboard: true,
        canViewManagement: false,
        canViewMatches: false,
        canViewScoring: true,
        canViewStats: false,

        canCreateLeague: false,
        canEditLeague: false,
        canDeleteLeague: false,
        canManageMembers: false,
        canManagePermissions: false,

        canCreateTeam: false,
        canEditTeam: false,
        canDeleteTeam: false,

        canCreatePlayer: false,
        canEditPlayer: false,
        canDeletePlayer: false,

        canCreateMatch: false,
        canEditMatch: false,
        canDeleteMatch: false,

        /*
         * IMPORTANT:
         * The existing Scorer Mode keypad is rendered behind:
         *
         *   permissions?.canScoreMatch
         *
         * The earlier offline bootstrap accidentally set `canScore`, which is
         * not the permission key used by the scorer UI. That restored the
         * scoreboard but hid every scoring button.
         *
         * These capabilities are limited to the already-cached active match;
         * no admin/league-management permissions are granted offline.
         */
        canScoreMatch: true,
        canEditScore: true,
        canUndoBall: true,
        canSwapStrike: true,
        canRetirePlayer: true,

        canEndMatch: false,
        canAbandonMatch: false,
        canLockMatch: false,

        canExportStats: false,
        canViewAuditLogs: false,
      });

      setPreferencesLoaded(true);
      setDashboardReady(true);
      setError("");

      return;
    }

    try {
      setDashboardReady(false);

      const loadedLeagues = await loadLeagues(null);
      await loadTeams();

      const res = await fetch("/api/me");
      const meData = await res.json();

      /*
       * Never trust a saved/requested league id by itself. A user may have
       * been unregistered from that league since their preference was saved,
       * or a different account may be using the same browser.
       *
       * /api/leagues is the authoritative list of leagues this CURRENT user
       * can access. Only choose an id that still exists in that response.
       */
      const accessibleLeagues =
        Array.isArray(
          loadedLeagues
        )
          ? loadedLeagues
          : [];

      const requestedCandidate =
        Number.isInteger(
          requestedLeagueId
        ) &&
        requestedLeagueId > 0
          ? Number(
              requestedLeagueId
            )
          : null;

      const savedCandidate =
        Number(
          meData?.activeLeagueId
        );

      const hasAccessibleLeague =
        (leagueId) =>
          Number.isInteger(
            Number(
              leagueId
            )
          ) &&
          Number(
            leagueId
          ) > 0 &&
          accessibleLeagues.some(
            (league) =>
              Number(
                league.id
              ) ===
              Number(
                leagueId
              )
          );

      const preferredLeagueId =
        hasAccessibleLeague(
          requestedCandidate
        )
          ? requestedCandidate
          : hasAccessibleLeague(
                savedCandidate
              )
            ? savedCandidate
            : accessibleLeagues?.[0]
                ?.id
              ? Number(
                  accessibleLeagues[0].id
                )
              : null;

      if (preferredLeagueId) {
        setActiveLeagueId(
          preferredLeagueId
        );

        await loadMyLeaguePermissions(
          preferredLeagueId
        );

        await loadMatches(
          preferredLeagueId
        );
      } else {
        /*
         * No current league membership/access. Clear every league-scoped
         * selection so stale preferences cannot trigger /stats,
         * /permissions/me or /matches calls for a league the user no longer
         * belongs to.
         */
        setActiveLeagueId(
          null
        );
        setSelectedTeamId(
          ""
        );
        setSelectedPlayerTeamId(
          ""
        );
        setSelectedMatchId(
          ""
        );
        setMatches(
          []
        );
        setMatchDetail(
          null
        );
        setScoreboard(
          null
        );
        setLeagueStats(
          null
        );
        setPermissions(
          null
        );
        permissionsLeagueIdRef.current =
          null;
      }

      if (
        !(
          requestedDashboardTab ===
            "scoring" &&
          Number.isInteger(
            requestedMatchId
          ) &&
          requestedMatchId > 0
        )
      ) {
        setSelectedMatchId("");
      }

      setPreferencesLoaded(true);
    } catch (err) {
      setError(err.message);
    } finally {
      setDashboardReady(true);
    }
  }

  initializeDashboard();
}, []);
useEffect(() => {
  if (!activeLeagueId) return;
  if (!["matches", "scoring"].includes(activeTab)) return;

  const browserOffline =
    typeof navigator !== "undefined" &&
    navigator.onLine === false;

  if (
    isTrueOfflineResume &&
    activeTab === "scoring"
  ) {
    return;
  }

  loadMatches(activeLeagueId);
}, [
  activeTab,
  activeLeagueId,
  isTrueOfflineResume,
]);

useEffect(() => {
  if (!activeLeagueId) return;
  if (activeTab !== "management") return;

  loadSeries();
}, [activeTab, activeLeagueId]);
/*useEffect(() => {
    async function loadUserPreferences() {
      const res = await fetch("/api/me");

      if (!res.ok) {
        setPreferencesLoaded(true);
        return;
      }

      const data = await res.json();

      setActiveLeagueId(data.activeLeagueId ?? null);

setSelectedMatchId("");

      setPreferencesLoaded(true);
    }

    loadUserPreferences();
  }, []);
*/
  useEffect(() => {
    if (
      !Number.isInteger(
        requestedTeamId
      ) ||
      requestedTeamId <= 0 ||
      !teams.length
    ) {
      return;
    }

    const requestedTeam =
      teams.find(
        (team) =>
          Number(
            team.id
          ) ===
            requestedTeamId &&
          (
            !requestedLeagueId ||
            Number(
              team.leagueId
            ) ===
              requestedLeagueId
          )
      );

    if (!requestedTeam) {
      return;
    }

    setSelectedTeamId(
      String(
        requestedTeam.id
      )
    );
  }, [
    requestedLeagueId,
    requestedTeamId,
    teams,
  ]);

  useEffect(() => {
    if (
      requestedDashboardSection !==
        "players" ||
      activeTab !==
        "management" ||
      !selectedTeamId
    ) {
      return;
    }

    const timer =
      window.setTimeout(
        () => {
          document
            .getElementById(
              "players-section"
            )
            ?.scrollIntoView({
              behavior:
                "smooth",
              block:
                "start",
            });
        },
        120
      );

    return () =>
      window.clearTimeout(
        timer
      );
  }, [
    activeTab,
    requestedDashboardSection,
    selectedTeamId,
  ]);

  useEffect(() => {
    const validTabs =
      new Set([
        "management",
        "matches",
        "scoring",
        "points",
        "stats",
        "permissions",
        "help",
        "about",
        "admin",
      ]);

    if (
      validTabs.has(
        requestedDashboardTab
      )
    ) {
      setActiveTab(
        requestedDashboardTab ===
          "points"
          ? "Points"
          : requestedDashboardTab
      );
    }

    if (
      Number.isInteger(
        requestedLeagueId
      ) &&
      requestedLeagueId > 0
    ) {
      setActiveLeagueId(
        requestedLeagueId
      );
    }

    if (
      requestedMatchesSubTab
    ) {
      const validMatchTabs =
        new Set([
          "CREATE MATCH",
          "ACTIVE",
          "SCHEDULED",
          "KIT",
          "COMPLETED",
        ]);

      if (
        validMatchTabs.has(
          requestedMatchesSubTab
        )
      ) {
        setActiveTab(
          "matches"
        );

        setMatchesSubTab(
          requestedMatchesSubTab
        );
      }
    }
  }, [
    requestedDashboardTab,
    requestedLeagueId,
    requestedMatchesSubTab,
  ]);

  useEffect(() => {
    if (
      !isTrueOfflineResume ||
      requestedDashboardTab !== "scoring" ||
      activeTab !== "scoring" ||
      !Number.isInteger(requestedMatchId) ||
      requestedMatchId <= 0
    ) {
      return;
    }

    /*
     * This path is only for a true offline resume. If the scorer has already
     * reconnected, normal dashboard initialization loads all leagues/matches
     * and the scoring deep link below still opens the requested match.
     */
    let cancelled = false;

    async function resumeCachedScoring() {
      try {
        if (
          Number.isInteger(requestedLeagueId) &&
          requestedLeagueId > 0
        ) {
          setActiveLeagueId(requestedLeagueId);
        }

        setSelectedMatchId(String(requestedMatchId));
        setScoringSubTab("ADVANCED");

        selectedMatchExplicitLoadRef.current =
          String(requestedMatchId);

        // loadSelectedMatch already contains Cric4All's IndexedDB fallback:
        // API failure -> getOfflineMatchSnapshot(matchId).
        const cachedBoard =
          await loadSelectedMatch(
            requestedMatchId,
            {
              loadDetail: true,
              loadStatsData: false,
              syncBallForm: true,
            }
          );

        if (cancelled) return;

        if (!cachedBoard) {
          throw new Error(
            "No offline scoring snapshot is available for this match on this device."
          );
        }

        setError("");
        setMessage(
          "📴 Offline scoring restored from this device. New deliveries will stay queued until Cric4All reconnects."
        );
      } catch (resumeError) {
        if (cancelled) return;

        setError(
          resumeError?.message ||
          "Unable to restore this offline scoring match."
        );
      }
    }

    resumeCachedScoring();

    return () => {
      cancelled = true;
    };
  }, [
    isTrueOfflineResume,
    requestedDashboardTab,
    activeTab,
    requestedLeagueId,
    requestedMatchId,
  ]);

  useEffect(() => {
    if (
      requestedDashboardTab !==
        "scoring" ||
      activeTab !==
        "scoring" ||
      !Number.isInteger(
        requestedMatchId
      ) ||
      requestedMatchId <= 0 ||
      !matches.length
    ) {
      return;
    }

    if (
      Number.isInteger(
        requestedLeagueId
      ) &&
      requestedLeagueId > 0 &&
      Number(
        activeLeagueId
      ) !==
        requestedLeagueId
    ) {
      return;
    }

    const match =
      matches.find(
        (candidate) =>
          Number(
            candidate.id
          ) ===
          requestedMatchId
      );

    if (!match) {
      return;
    }

    const alreadyLoaded =
      Number(
        selectedMatchId
      ) ===
        requestedMatchId &&
      Number(
        matchDetail?.id
      ) ===
        requestedMatchId;

    if (alreadyLoaded) {
      return;
    }

    const deepLinkKey =
      `${requestedLeagueId || activeLeagueId}:${requestedMatchId}`;

    if (
      scoringDeepLinkLoadedRef
        .current ===
      deepLinkKey
    ) {
      return;
    }

    scoringDeepLinkLoadedRef.current =
      deepLinkKey;

    handleScoringMatchSelect(
      requestedMatchId
    )
      .catch(
        (failure) => {
          setError(
            failure instanceof Error
              ? failure.message
              : "Unable to open the selected match for scoring."
          );
        }
      )
      .finally(
        () => {
          /*
           * Release the guard after every load. If another dashboard
           * initialization effect clears the selected match, this effect
           * can safely restore it on the next render.
           */
          scoringDeepLinkLoadedRef.current =
            "";
        }
      );
  }, [
    activeLeagueId,
    activeTab,
    matchDetail?.id,
    matches,
    requestedDashboardTab,
    requestedLeagueId,
    requestedMatchId,
    selectedMatchId,
  ]);

  useEffect(() => {
  if (!preferencesLoaded) return;

  if (
    isTrueOfflineResume
  ) {
    return;
  }

  fetch("/api/user/preferences", {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      activeLeagueId,
      activeMatchId: selectedMatchId || null
    })
  });
}, [
  activeLeagueId,
  selectedMatchId,
  preferencesLoaded,
  isTrueOfflineResume,
]);
useEffect(() => {
  const preserveOfflineResumeMatch =
    isTrueOfflineResume &&
    requestedDashboardTab === "scoring" &&
    Number.isInteger(requestedMatchId) &&
    requestedMatchId > 0;

  if (!activeLeagueId) {
    setShowDeliverySetupModal(false);
    setPendingDeliverySetupAfterStart(false);
    setPendingSecondInningsSetup(false);
    setDeliverySetupReason("");
    setMatches([]);

    if (!preserveOfflineResumeMatch) {
      setSelectedMatchId("");
      setMatchDetail(null);
      setScoreboard(null);
      setStats(null);
    }

    return;
  }

  /*
   * ONLINE:
   * Preserve the original behavior when the scorer changes leagues.
   *
   * OFFLINE RESUME:
   * activeLeagueId is being restored from the saved local scoring session.
   * Do NOT erase selectedMatchId / scoreboard immediately after restoring it.
   */
  if (!preserveOfflineResumeMatch) {
    setSelectedMatchId("");
    setMatchDetail(null);
    setScoreboard(null);
    setStats(null);

    loadMatches();
  }
}, [
  activeLeagueId,
  isTrueOfflineResume,
  requestedDashboardTab,
  requestedMatchId,
]);

useEffect(() => {
  if (
    activeTab === "matches" &&
    !matchesSubTab
  ) {
    setMatchesSubTab("SCHEDULED");
  }
}, [activeTab]);

useEffect(() => {
  if (
    showPlayerModal &&
    activeLeague
  ) {
    setPlayerForm((prev) => ({
      ...prev,
      leagueId: activeLeague.id,
    }));
  }
}, [showPlayerModal, activeLeague]);

useEffect(() => {
  if (!activeLeague) return;

  const member =
    activeLeague.members?.find(
      (m) =>
        String(m.id) === String(selectedMemberId)
    );

  if (member) {
    setSelectedMember(member);
  }

  setShowPermissionModal(false);
}, [selectedMemberId, activeLeague]);
useEffect(() => {
  const checkMobile = () => {
    setIsMobile(window.innerWidth < 768);
  };

  checkMobile();

  window.addEventListener(
    "resize",
    checkMobile
  );

  return () =>
    window.removeEventListener(
      "resize",
      checkMobile
    );
}, []);
useEffect(() => {
  if (activeLeagueId) {
    loadLeagueStats(activeLeagueId);
    loadMyCricket(activeLeagueId);
  } else {
    setMyCricket(null);
  }
}, [activeLeagueId]);

useEffect(() => {
  if (
    statsSubTab !==
      "AWARDS" ||
    !activeLeagueId
  ) {
    return;
  }

  loadAwards(
    activeLeagueId,
    {
      period:
        awardsPeriodType,

      weekOffset:
        awardsWeekOffset,

      monthOffset:
        awardsMonthOffset,

      seriesId:
        awardsSeriesId,
    }
  );
}, [
  statsSubTab,
  activeLeagueId,
  awardsPeriodType,
  awardsWeekOffset,
  awardsMonthOffset,
  awardsSeriesId,
]);

useEffect(() => {
  if (!isMobile || !scorerMode) {
    document.body.classList.remove("cric4all-scorer-open");
    return;
  }

  document.body.classList.add("cric4all-scorer-open");

  return () => {
    document.body.classList.remove("cric4all-scorer-open");
  };
}, [isMobile, scorerMode]);

async function handleCreateLeague() {
  const league = await api("/api/leagues", {
    method: "POST",
    body: JSON.stringify({
      name: leagueName,
      visibility: leagueForm.visibility || "PRIVATE"
    })
  });

  await loadLeagues();

  setActiveLeagueId(String(league.id));
  setSelectedTeamId("");

  setShowLeagueModal(false);
  setLeagueName("");
}
async function loadMyCricket(leagueId) {
  const numericLeagueId = Number(leagueId);

  if (!Number.isInteger(numericLeagueId) || numericLeagueId <= 0) {
    setMyCricket(null);
    return;
  }

  setMyCricketLoading(true);

  try {
    const response = await fetch(
      `/api/leagues/${numericLeagueId}/my-cricket`,
      {
        cache: "no-store",
      }
    );

    const payload = await response.json().catch(() => ({}));

    if (!response.ok) {
      throw new Error(
        payload?.error || "Unable to load Your Cricket"
      );
    }

    setMyCricket(payload);
  } catch (err) {
    console.error("Load Your Cricket failed:", err);
    setMyCricket({
      linked: false,
      error:
        err?.message ||
        "Unable to load your personal cricket profile",
    });
  } finally {
    setMyCricketLoading(false);
  }
}

async function loadLeagueStats(
  leagueId = activeLeagueId,
  options = {}
) {
  if (!leagueId) return;

  const requestedSeriesIds =
    (
      options.seriesIds ??
      contextFilters?.seriesIds ??
      []
    )
      .map(Number)
      .filter(
        (value) =>
          Number.isInteger(value) &&
          value > 0
      );

  const query =
    new URLSearchParams();

  if (requestedSeriesIds.length) {
    query.set(
      "seriesIds",
      requestedSeriesIds.join(",")
    );
  }

  const statsUrl =
    `/api/leagues/${leagueId}/stats${
      query.toString()
        ? `?${query.toString()}`
        : ""
    }`;

  try {
    setLeagueStatsLoading(true);
    const data = await api(statsUrl);
    setLeagueStats(data);
  } catch (err) {
    console.error("Load league stats failed:", err);
    setError("Failed to load league stats");
  } finally {
    setLeagueStatsLoading(false);
  }
}

async function loadAwards(
  leagueId = activeLeagueId,
  options = {}
) {
  const requestedSeriesId =
    options.seriesId ??
    awardsSeriesId;

  const period =
    requestedSeriesId &&
    requestedSeriesId !==
      "ALL"
      ? "SERIES"
      : options.period ||
        awardsPeriodType;

  const weekOffset =
    options.weekOffset ??
    awardsWeekOffset;

  const monthOffset =
    options.monthOffset ??
    awardsMonthOffset;

  const seriesId =
    requestedSeriesId;
  if (!leagueId) {
    setAwardsData(null);
    return;
  }

  try {
    setAwardsLoading(true);

    const query =
      new URLSearchParams({
        period,
        weekOffset:
          String(
            weekOffset
          ),
        monthOffset:
          String(
            monthOffset
          ),
      });

    if (
      seriesId &&
      seriesId !==
      "ALL"
    ) {
      query.set(
        "seriesId",
        String(
          seriesId
        )
      );
    }

    const data = await api(
      `/api/leagues/${leagueId}/awards?${query.toString()}`
    );

    setAwardsData(data);
  } catch (err) {
    console.error(
      "Load awards failed:",
      err
    );

    setError(
      err?.message ||
      "Failed to load league awards."
    );
  } finally {
    setAwardsLoading(false);
  }
}

function formatAwardsPeriod(
  start,
  end
) {
  if (!start || !end) {
    return "Selected week";
  }

  const startDate =
    new Date(start);

  const endDate =
    new Date(end);

  endDate.setDate(
    endDate.getDate() - 1
  );

  return `${startDate.toLocaleDateString(
    undefined,
    {
      month: "short",
      day: "numeric",
    }
  )} – ${endDate.toLocaleDateString(
    undefined,
    {
      month: "short",
      day: "numeric",
      year: "numeric",
    }
  )}`;
}

const captaincyRows =
  leagueStats?.captaincy?.length
    ? leagueStats.captaincy
    : stats?.captaincy || [];

const wicketkeepingRows =
  leagueStats?.wicketkeeping?.length
    ? leagueStats.wicketkeeping
    : stats?.wicketkeeping || [];
    
const filteredTeams = teams.filter(
  (team) =>
    String(team.leagueId) ===
    String(activeLeagueId)
);
const filteredMatches = matches.filter(
  (match) =>
    String(match.leagueId) ===
    String(activeLeagueId)
);
const teamsForMatch =
  activeLeagueId
    ? filteredTeams
    : teams;

 const [matchForm, setMatchForm] = useState({
  teamAId: "",
  teamBId: "",

  // Match date and real physical venue.
  scheduledAt: "",
  venueName: "",
  venueAddress: "",

  // keep this, but now it is optional
  battingFirstTeamId: "",

  oversPerInnings: 20,
  powerplayOversInnings: 6,
  maxWicketsPerInnings: "",
  maxOversPerBowler: "",

  // NEW
  status: "SCHEDULED",
  teamACaptainId: "",
  teamBCaptainId: "",
  teamAViceCaptainId: "",
  teamBViceCaptainId: "",
  teamAWicketKeeperId: "",
  teamBWicketKeeperId: ""
});

const [ballForm, setBallForm] = useState({
  inningsNo: "1",
  strikerId: "",
  nonStrikerId: "",
  bowlerId: "",
  extraType: "NONE",
  runsOffBat: "0",
  extras: "0",
  isWicket: false,
  wicketType: "NONE",
  dismissedPlayerId: "",
  newBatterId: "",
  note: "",
  fielderId: "",
  assistantFielderId: "",
  wicketNote: ""
});
const rankingConfig = {
  topRunScorers: {
    label: "Runs",
    icon: "🏏",
    title: "Top Run Scorers",
    value: (r) => `${r.runs} runs`
  },
  topWicketTakers: {
    label: "Wickets",
    icon: "🎯",
    title: "Top Wicket Takers",
    value: (r) => `${r.wickets} wkts`
  },
  bestStrikeRate: {
    label: "Strike Rate",
    icon: "🚀",
    title: "Best Strike Rate",
    value: (r) => r.strikeRate
  },
  bestEconomy: {
    label: "Economy",
    icon: "🧊",
    title: "Best Economy",
    value: (r) => r.economy
  },
  mostSixes: {
    label: "Sixes",
    icon: "💥",
    title: "Most Sixes",
    value: (r) => `${r.sixes} sixes`
  },
  bestAllRounders: {
    label: "Top Performers",
    icon: "⭐",
    title: "Top Performers",
    value: (r) => `${r.allRounderPoints} pts`
  }
};

const selectedRanking =
  leagueStats?.rankings?.[rankingType] || [];

const currentRankingConfig =
  rankingConfig[rankingType];

async function loadMatches(leagueId = activeLeagueId) {
  try {
    if (!leagueId) {
      setMatches([]);

      if (!isTrueOfflineResume) {
        setSelectedMatchId("");
      }

      return;
    }

    /*
     * The explicit resume route is local-first. Do not require the normal
     * server-backed match list merely to reopen the scorer.
     */
    if (
      isTrueOfflineResume &&
      requestedDashboardTab === "scoring"
    ) {
      return matches;
    }

    const data = await api(
      `/api/matches?leagueId=${leagueId}`
    );
    setMatches(Array.isArray(data) ? data : data.matches || []);

    const leagueMatches = data.filter(
      (m) =>
        String(m.leagueId) === String(leagueId)
    );

    setMatches(leagueMatches);

    if (
      selectedMatchId &&
      !leagueMatches.some(
        (m) => String(m.id) === String(selectedMatchId)
      )
    ) {
      setSelectedMatchId("");
      setMatchDetail(null);
      setScoreboard(null);
      setStats(null);
      return;
    }

  } catch (error) {
    console.error("Load Matches Error:", error);
  }
}
async function loadTeams() {
  try {
    const data = await api("/api/teams");
    const loadedTeams = Array.isArray(data) ? data : [];

    setTeams(loadedTeams);

    // Keep the selected team valid for the CURRENT league only.
    // The old logic used the first team from the global /api/teams response,
    // which could leave a team from another league selected after switching
    // leagues. That made selectedTeam null and hid Edit Team.
    if (activeLeagueId) {
      const leagueId = String(activeLeagueId);
      const leagueTeams = loadedTeams.filter(
        (team) => String(team.leagueId) === leagueId
      );

      setSelectedTeamId((currentTeamId) => {
        if (
          currentTeamId &&
          leagueTeams.some(
            (team) => String(team.id) === String(currentTeamId)
          )
        ) {
          return currentTeamId;
        }

        return leagueTeams[0] ? String(leagueTeams[0].id) : "";
      });
    } else {
      setSelectedTeamId("");
    }

  } catch (error) {
    console.error(
      "Load Teams Error:",
      error
    );

    setError(
      error.message ||
      "Failed to load teams"
    );

    setTeams([]);
  }
}
function parseLeagueImportCsv(
  text
) {
  const source =
    String(
      text ||
      ""
    ).replace(
      /^\uFEFF/,
      ""
    );

  const rows =
    [];

  let current =
    [];

  let cell =
    "";

  let quoted =
    false;

  for (
    let i = 0;
    i <
    source.length;
    i += 1
  ) {
    const char =
      source[i];

    if (char === '"') {
      if (
        quoted &&
        source[i + 1] ===
          '"'
      ) {
        cell +=
          '"';
        i += 1;
      } else {
        quoted =
          !quoted;
      }

      continue;
    }

    if (
      char === "," &&
      !quoted
    ) {
      current.push(
        cell
      );
      cell =
        "";
      continue;
    }

    if (
      (
        char === "\n" ||
        char === "\r"
      ) &&
      !quoted
    ) {
      if (
        char === "\r" &&
        source[i + 1] ===
          "\n"
      ) {
        i += 1;
      }

      current.push(
        cell
      );

      if (
        current.some(
          (value) =>
            String(
              value ||
              ""
            ).trim()
        )
      ) {
        rows.push(
          current
        );
      }

      current =
        [];
      cell =
        "";
      continue;
    }

    cell +=
      char;
  }

  if (
    cell ||
    current.length >
      0
  ) {
    current.push(
      cell
    );

    if (
      current.some(
        (value) =>
          String(
            value ||
            ""
          ).trim()
      )
    ) {
      rows.push(
        current
      );
    }
  }

  return rows;
}

function buildLeagueImportPreview(
  text
) {
  const csvRows =
    parseLeagueImportCsv(
      text
    );

  if (
    csvRows.length ===
    0
  ) {
    return {
      rows: [],
      errors: [],
    };
  }

  const first =
    csvRows[0].map(
      (value) =>
        String(
          value ||
          ""
        )
          .trim()
          .toLowerCase()
    );

  const hasHeader =
    first.some(
      (value) =>
        [
          "team",
          "team name",
          "teamname",
        ].includes(
          value
        )
    );

  const dataRows =
    hasHeader
      ? csvRows.slice(1)
      : csvRows;

  const teamIndex =
    hasHeader
      ? first.findIndex(
          (value) =>
            [
              "team",
              "team name",
              "teamname",
            ].includes(
              value
            )
        )
      : 0;

  const playerIndex =
    hasHeader
      ? first.findIndex(
          (value) =>
            [
              "player",
              "player name",
              "playername",
              "name",
            ].includes(
              value
            )
        )
      : 1;

  const phoneIndex =
    hasHeader
      ? first.findIndex(
          (value) =>
            [
              "whatsapp",
              "whatsapp number",
              "phone",
              "mobile",
              "mobile number",
            ].includes(
              value
            )
        )
      : 2;

  const result =
    [];

  const errors =
    [];

  dataRows.forEach(
    (
      row,
      index
    ) => {
      const displayRow =
        index +
        (
          hasHeader
            ? 2
            : 1
        );

      const teamName =
        String(
          row[
            teamIndex >=
            0
              ? teamIndex
              : 0
          ] ||
          ""
        ).trim();

      const playerName =
        String(
          row[
            playerIndex >=
            0
              ? playerIndex
              : 1
          ] ||
          ""
        ).trim();

      const whatsappNumber =
        String(
          row[
            phoneIndex >=
            0
              ? phoneIndex
              : 2
          ] ||
          ""
        ).trim();

      if (
        !teamName
      ) {
        errors.push(
          `Row ${displayRow}: Team is required.`
        );

        return;
      }

      result.push({
        teamName,
        playerName,
        whatsappNumber,
      });
    }
  );

  return {
    rows:
      result.slice(
        0,
        1000
      ),
    errors:
      errors.slice(
        0,
        25
      ),
  };
}

function updateLeagueImportPreview(
  value
) {
  setLeagueImportText(
    value
  );

  const preview =
    buildLeagueImportPreview(
      value
    );

  setLeagueImportRows(
    preview.rows
  );

  setLeagueImportErrors(
    preview.errors
  );

  setLeagueImportResult(
    null
  );
}

async function handleLeagueImportFile(
  event
) {
  const file =
    event?.target?.files?.[0];

  if (!file) {
    return;
  }

  const lowerName =
    String(
      file.name ||
      ""
    ).toLowerCase();

  if (
    !lowerName.endsWith(
      ".csv"
    )
  ) {
    setLeagueImportErrors([
      "Please choose a .csv file. Excel files can be saved/exported as CSV before importing.",
    ]);
    event.target.value =
      "";
    return;
  }

  if (
    file.size >
    2 * 1024 * 1024
  ) {
    setLeagueImportErrors([
      "CSV file is too large. Keep a single import under 2 MB / 1,000 rows.",
    ]);
    event.target.value =
      "";
    return;
  }

  try {
    const text =
      await file.text();

    updateLeagueImportPreview(
      text
    );
  } catch (
    error
  ) {
    setLeagueImportErrors([
      error?.message ||
      "Unable to read the CSV file.",
    ]);
  }
}

function downloadLeagueImportTemplate() {
  /*
   * IMPORTANT:
   * Use REAL CRLF line breaks in the CSV.
   *
   * The previous implementation joined with the literal characters
   * "\\r\\n", which caused Excel to put almost the entire template on one
   * worksheet row.
   *
   * One player belongs on one CSV row and the Team name repeats for every
   * player on that team.
   */
  const csvRows = [
    [
      "Team",
      "Player",
      "WhatsApp",
    ],
    [
      "Eagles",
      "John Smith",
      "+16105550101",
    ],
    [
      "Eagles",
      "David Patel",
      "",
    ],
    [
      "Eagles",
      "Mike Jones",
      "+16105550103",
    ],
    [
      "Tigers",
      "Raj Kumar",
      "+12155550104",
    ],
    [
      "Tigers",
      "Steve Thomas",
      "",
    ],
    [
      "New Team",
      "",
      "",
    ],
  ];

  function csvEscape(value) {
    const text =
      String(
        value ??
        ""
      );

    if (
      /[",\r\n]/.test(
        text
      )
    ) {
      return `"${text.replace(
        /"/g,
        '""'
      )}"`;
    }

    return text;
  }

  const csv =
    csvRows
      .map(
        (row) =>
          row
            .map(
              csvEscape
            )
            .join(",")
      )
      .join("\r\n");

  /*
   * UTF-8 BOM helps Excel open the CSV cleanly, including non-ASCII names.
   */
  const blob =
    new Blob(
      [
        "\uFEFF",
        csv,
      ],
      {
        type:
          "text/csv;charset=utf-8",
      }
    );

  const url =
    URL.createObjectURL(
      blob
    );

  const link =
    document.createElement(
      "a"
    );

  link.href =
    url;
  link.download =
    "cric4all-league-import-template.csv";

  document.body.appendChild(
    link
  );

  link.click();
  link.remove();

  URL.revokeObjectURL(
    url
  );
}

async function submitLeagueImport(
  event
) {
  event?.preventDefault?.();

  if (
    !activeLeagueId
  ) {
    setLeagueImportErrors([
      "Select a league before importing.",
    ]);
    return;
  }

  if (
    leagueImportRows.length ===
    0
  ) {
    setLeagueImportErrors([
      "Add at least one valid import row.",
    ]);
    return;
  }

  if (
    leagueImportErrors.length >
    0
  ) {
    return;
  }

  setLeagueImportSaving(
    true
  );

  setLeagueImportResult(
    null
  );

  try {
    const result =
      await api(
        `/api/leagues/${activeLeagueId}/import`,
        {
          method:
            "POST",
          body:
            JSON.stringify({
              rows:
                leagueImportRows,
            }),
        }
      );

    setLeagueImportResult(
      result
    );

    await loadLeagues();

    await loadMatches(
      activeLeagueId
    );

    setMessage(
      `🚚 Import complete: ${result.createdTeams || 0} team(s) and ${result.createdPlayers || 0} player(s) created.`
    );

    showToast?.(
      "success",
      `🚚 Imported ${result.createdTeams || 0} team(s) and ${result.createdPlayers || 0} player(s)`
    );
  } catch (
    error
  ) {
    setLeagueImportErrors([
      error?.message ||
      "League import failed.",
    ]);
  } finally {
    setLeagueImportSaving(
      false
    );
  }
}

const handleAddPlayers = async (e) => {
 //alert(JSON.stringify(playerForm));

  e.preventDefault();

  /*
   * UI permission checks are repeated here so the action cannot be
   * triggered through a stale/open modal or a synthetic submit event.
   * The API route must continue enforcing the same rule server-side.
   */
  if (!canAddPlayers) {
    setShowPlayerModal(false);
    setError(
      "Only the league owner, an admin, a captain, or a permission manager can add players."
    );
    return;
  }

  try {


    if (!playerForm.teamId) {
      setError("Please select a team");
      return;
    }

    const rawNames = playerForm.names || "";



    const playerNames = rawNames
      .split(/\r?\n/)
      .map((name) => name.trim())
      .filter((name) => name.length > 0);



    if (playerNames.length === 0) {
      setError("Enter at least one player");
      return;
    }

    const payload = {
      teamId: Number(selectedPlayerTeamId),
      names: playerNames,
    };



    const response = await fetch(
      "/api/players/bulk",
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(payload),
      }
    );

    await refreshPlayerLists();

setShowPlayerModal(false);
setPlayerForm((prev) => ({
  ...prev,
  names: "",
}));
showToast("success", "✅ Players added.");
    const data = await response.json();

  

    if (!response.ok) {
      throw new Error(
        data.error || "Failed to create players"
      );
    }

    await loadTeams();
    await loadLeagues();

    setMessage(
      `${data.created || playerNames.length} players added`
    );

    setPlayerForm({
      names: "",
      teamId: "",
      leagueId: activeLeagueId || "",
    });

    setShowPlayerModal(false);

  } catch (error) {
    console.error("Add Players Error:", error);
    setError(error.message);
  }
};
async function savePlayerName() {

  await api(`/api/players/${editingPlayer.id}`,{

    method:"PATCH",

body: JSON.stringify({
    name: editPlayerName.trim(),

    whatsappNumber:
      editPlayerWhatsappNumber.trim(),

    whatsappOptIn:
      editPlayerWhatsappOptIn,
})

  });
await refreshPlayerLists();

setShowEditPlayerModal(false);
setEditingPlayer(null);
setEditPlayerName("");
setEditPlayerWhatsappNumber("");
setEditPlayerWhatsappOptIn(false);
showToast("success", "✅ Player updated.");
  await loadTeams();

  showToast("success","✅ Player updated.");

  setShowEditPlayerModal(false);

  setEditingPlayer(null);

}  
function openEditPlayer(player) {
  setEditingPlayer(player);

  setEditPlayerName(player.name || "");

  setEditPlayerWhatsappNumber(
    player.whatsappNumber || ""
  );

  setEditPlayerWhatsappOptIn(
    Boolean(player.whatsappOptIn)
  );

  setShowEditPlayerModal(true);
}
function buildLiveMatchCenter(
  scoreboard,
  preferLocalTarget = false,
  dlsState = null
) {
  if (!scoreboard) return null;

  const currentInningsNo = Number(scoreboard.currentInnings || 1);

  const innings =
    scoreboard.innings?.find(
      (inn) => Number(inn.number) === currentInningsNo
    ) || scoreboard.innings?.[currentInningsNo - 1];

  if (!innings) return null;

  const runs = Number(innings.runs || 0);
  const wickets = Number(innings.wickets || 0);
  const legalBalls = Number(innings.legalBalls || 0);
  const originalOversPerInnings =
    Number(
      scoreboard
        ?.match
        ?.oversPerInnings ||
      0
    );

  const scoreboardDls =
    scoreboard
      ?.summary
      ?.dls ||
    {};

  const dlsActive =
    Boolean(
      scoreboardDls
        ?.active ||
      dlsState
        ?.active
    );

  const dlsAllocation =
    Number(
      currentInningsNo === 2
        ? (
            dlsState
              ?.innings2Allocation ||
            scoreboardDls
              ?.revisedOvers ||
            scoreboardDls
              ?.innings2Allocation ||
            0
          )
        : (
            dlsState
              ?.innings1Allocation ||
            scoreboardDls
              ?.revisedOvers ||
            scoreboardDls
              ?.innings1Allocation ||
            0
          )
    );

  const oversPerInnings =
    dlsActive &&
    dlsAllocation > 0
      ? dlsAllocation
      : originalOversPerInnings;

  const maxBalls =
    oversPerInnings *
    6;

  const dlsMethodLabel =
    String(
      dlsState
        ?.latest
        ?.mode ||
      scoreboardDls
        ?.mode ||
      ""
    )
      .trim()
      .toUpperCase() ===
    "OFFICIAL_OVERRIDE"
      ? "DLS"
      : (
          dlsActive
            ? "D/L Standard"
            : ""
        );

  const oversDisplay = innings.oversDisplay || "0.0";
  const crr =
    legalBalls > 0 ? ((runs / legalBalls) * 6).toFixed(2) : "0.00";

  const isSecondInnings =
    currentInningsNo === 2;

  const firstInningsRuns =
    Number(
      scoreboard
        ?.innings
        ?.[0]
        ?.runs ||
      0
    );

  /*
   * During offline/local-first scoring, scoreboard.summary.target may still
   * be the last server target. If innings 1 contained local unsynced runs,
   * derive the chase target from the LOCAL first-innings total instead.
   *
   * Keep the server target online so DLS/adjusted targets are preserved.
   */
  const target =
    preferLocalTarget &&
    isSecondInnings &&
    !dlsActive
      ? firstInningsRuns + 1
      : Number(
          scoreboard
            .summary
            ?.target ||
          dlsState
            ?.latest
            ?.target ||
          0
        );

  const ballsRemaining =
    maxBalls > 0 ? Math.max(maxBalls - legalBalls, 0) : 0;

  const runsRequired =
    isSecondInnings && target > 0
      ? Math.max(target - runs, 0)
      : 0;

  const rrr =
    isSecondInnings && ballsRemaining > 0 && runsRequired > 0
      ? ((runsRequired / ballsRemaining) * 6).toFixed(2)
      : "-";

  /*
   * CRIC4ALL CHASE PAR
   * ==================
   * This is a tactical chase indicator, NOT Official DLS.
   *
   * Base progress:
   *   how much of the innings has been consumed by legal deliveries.
   *
   * Wicket pressure:
   *   wickets consume batting resources, so the par line moves upward as
   *   wickets are lost. The 0.35 factor is intentionally moderate so one
   *   early wicket does not make the indicator jump unrealistically.
   *
   * At the final legal ball, par naturally converges to target - 1, which is
   * the tie score in a normal chase.
   *
   * Display starts only after the first legal delivery of innings 2.
   */
  const configuredMaxWickets =
    Number(
      scoreboard
        ?.match
        ?.maxWicketsPerInnings ??
      0
    );

  const effectiveMaxWickets =
    configuredMaxWickets > 0
      ? configuredMaxWickets
      : 10;

  const ballsUsed =
    maxBalls > 0
      ? Math.min(
          legalBalls,
          maxBalls
        )
      : 0;

  const timeProgress =
    maxBalls > 0
      ? Math.min(
          Math.max(
            ballsUsed /
              maxBalls,
            0
          ),
          1
        )
      : 0;

  const wicketProgress =
    effectiveMaxWickets > 0
      ? Math.min(
          Math.max(
            wickets /
              effectiveMaxWickets,
            0
          ),
          1
        )
      : 0;

  const wicketPressureWeight =
    0.35;

  const resourceProgress =
    Math.min(
      1,
      timeProgress +
        (
          1 -
          timeProgress
        ) *
          wicketProgress *
          wicketPressureWeight
    );

  const parBase =
    Math.max(
      target - 1,
      0
    );

  const chasePar =
    isSecondInnings &&
    target > 0 &&
    legalBalls > 0
      ? Math.min(
          parBase,
          Math.max(
            0,
            Math.floor(
              parBase *
                resourceProgress
            )
          )
        )
      : null;

  const vsPar =
    chasePar != null
      ? runs -
        chasePar
      : null;

  const parState =
    vsPar == null
      ? ""
      : vsPar > 0
        ? "AHEAD"
        : vsPar < 0
          ? "BEHIND"
          : "LEVEL";

  const parDeltaLabel =
    vsPar == null
      ? ""
      : vsPar > 0
        ? `+${vsPar}`
        : String(vsPar);

  const projected =
    legalBalls > 0 && maxBalls > 0
      ? Math.round((runs / legalBalls) * maxBalls)
      : runs;

  const currentPartnership =
    [...(innings.partnerships || [])]
      .reverse()
      .find((p) => p.ongoing) ||
    [...(innings.partnerships || [])].at(-1);

  const recentBalls =
    scoreboard.recentBalls?.slice(0, 6)?.map((ball) => {
      const label = ball.label || "";
      return (
        label.split(" ").slice(1).join(" ") || label
      ).replace(/[()]/g, "");
    }) || [];

  return {
    inningsNo: currentInningsNo,
    runs,
    wickets,
    oversDisplay,
    crr,
    rrr,
    projected,
    target,
    ballsRemaining,
    runsRequired,
    chasePar,
    vsPar,
    parState,
    parDeltaLabel,
    dlsActive,
    dlsMethodLabel,
    activeOversPerInnings:
      oversPerInnings,
    recentBalls,
    partnershipRuns: currentPartnership?.runs ?? 0,
    partnershipBalls: currentPartnership?.balls ?? 0,
    isSecondInnings,
  };
}


function buildOfflineLocalResultText(
  board,
  liveCenter
) {
  if (
    !board ||
    !liveCenter
  ) {
    return "";
  }

  const inningsNo =
    Number(
      liveCenter.inningsNo ||
      board.currentInnings ||
      1
    );

  if (inningsNo !== 2) {
    return "";
  }

  const firstInnings =
    board
      ?.innings
      ?.[0] ||
    {};

  const secondInnings =
    board
      ?.innings
      ?.[1] ||
    {};

  const firstRuns =
    Number(
      firstInnings.runs ||
      0
    );

  const secondRuns =
    Number(
      secondInnings.runs ||
      0
    );

  const secondWickets =
    Number(
      secondInnings.wickets ||
      0
    );

  const target =
    Number(
      liveCenter
        ?.target ||
      firstRuns +
        1
    );

  const dlsActive =
    Boolean(
      liveCenter
        ?.dlsActive ||
      board
        ?.summary
        ?.dls
        ?.active
    );

  const dlsSuffix =
    dlsActive
      ? ` (${
          liveCenter
            ?.dlsMethodLabel ||
          "DLS"
        })`
      : "";

  const ballsRemaining =
    Number(
      liveCenter
        .ballsRemaining ||
      0
    );

  const battingTeamName =
    secondInnings.teamName ||
    secondInnings
      .battingTeamName ||
    board
      ?.match
      ?.teamBName ||
    "Chasing team";

  const defendingTeamName =
    firstInnings.teamName ||
    firstInnings
      .battingTeamName ||
    board
      ?.match
      ?.teamAName ||
    "Defending team";

  const maxWickets =
    Number(
      board
        ?.match
        ?.maxWicketsPerInnings ||
      matchDetail
        ?.maxWicketsPerInnings ||
      10
    );

  if (
    secondRuns >=
    target
  ) {
    const wicketsRemaining =
      Math.max(
        maxWickets -
          secondWickets,
        0
      );

    return wicketsRemaining > 0
      ? `${battingTeamName} won by ${wicketsRemaining} wicket${
          wicketsRemaining === 1
            ? ""
            : "s"
        }${dlsSuffix}`
      : `${battingTeamName} won the match${dlsSuffix}`;
  }

  const runsNeeded =
    Math.max(
      target -
        secondRuns,
      0
    );

  const localCompletion =
    getOfflineLocalCompletionState(
      board,
      2
    );

  if (
    ballsRemaining === 0 ||
    localCompletion
      .wicketsFinished ||
    (
      !dlsActive &&
      localCompletion
        .oversFinished
    )
  ) {
    /*
     * In a revised DLS chase, the final tie position is the active target - 1.
     * Do not compare against the original first-innings total.
     */
    const tieScore =
      dlsActive
        ? Math.max(
            target - 1,
            0
          )
        : firstRuns;

    if (
      secondRuns ===
      tieScore
    ) {
      return `Match tied${dlsSuffix}`;
    }

    if (
      secondRuns >
      tieScore
    ) {
      const winningMargin =
        secondRuns -
        tieScore;

      return `${battingTeamName} won by ${winningMargin} run${
        winningMargin === 1
          ? ""
          : "s"
      }${dlsSuffix}`;
    }

    const winningMargin =
      Math.max(
        tieScore -
          secondRuns,
        0
      );

    return `${defendingTeamName} won by ${winningMargin} run${
      winningMargin === 1
        ? ""
        : "s"
    }${dlsSuffix}`;
  }

  return `${battingTeamName} need ${runsNeeded} run${
    runsNeeded === 1
      ? ""
      : "s"
  } from ${ballsRemaining} ball${
    ballsRemaining === 1
      ? ""
      : "s"
  }${dlsActive ? ` · ${liveCenter?.dlsMethodLabel || "DLS"}` : ""}`;
}


function getInstantDeliveryStatus(data) {
  const runs = Number(data.runsOffBat || 0);
  const extras = Number(data.extras || 0);
  const extraType = String(data.extraType || "NONE");
  const wicketType = String(data.wicketType || "NONE");

  if (data.isWicket) {
    if (wicketType === "RETIRED_HURT") {
      return "🏥 Retired hurt recorded.";
    }

    return "☝️ Wicket recorded.";
  }

  if (extraType === "WIDE") {
    return `⚪ Wide recorded${extras ? ` • ${extras} extra${extras > 1 ? "s" : ""}` : ""}.`;
  }

  if (extraType === "NOBALL") {
    return `🟡 No-ball recorded${extras ? ` • ${extras} extra${extras > 1 ? "s" : ""}` : ""}.`;
  }

  if (extraType === "BYE") {
    return `🏃 Bye recorded • ${extras} run${extras === 1 ? "" : "s"} added.`;
  }

  if (extraType === "LEGBYE") {
    return `🦵 Leg bye recorded • ${extras} run${extras === 1 ? "" : "s"} added.`;
  }

  if (runs === 0) {
    return "🟢 Dot ball recorded.";
  }

  if (runs === 4) {
    return "🔥 FOUR! Ball recorded and 4 runs added.";
  }

  if (runs === 6) {
    return "🚀 SIX! Ball recorded and 6 runs added.";
  }

  return `🏏 Ball recorded • ${runs} run${runs > 1 ? "s" : ""} added to the total.`;
}

function openVenueModalForMatch(
  match
) {
  if (!match?.id) {
    return;
  }

  setVenueMatch(
    match
  );

  setVenueForm({
    venueName:
      match.venueName ||
      "",
    venueAddress:
      match.venueAddress ||
      "",
  });

  setShowVenueModal(
    true
  );
}

async function handleSaveMatchVenue(
  event
) {
  event?.preventDefault?.();

  if (!venueMatch?.id) {
    return;
  }

  setVenueSaving(
    true
  );

  setError("");
  setMessage("");

  try {
    const updated =
      await api(
        `/api/matches/${venueMatch.id}/venue`,
        {
          method:
            "PATCH",
          body:
            JSON.stringify({
              venueName:
                venueForm.venueName,
              venueAddress:
                venueForm.venueAddress,
            }),
        }
      );

    setVenueMatch(
      (
        previous
      ) => ({
        ...previous,
        ...updated,
      })
    );

    setShowVenueModal(
      false
    );

    setVenueMatch(
      null
    );

    await loadMatches(
      activeLeagueId
    );

    if (
      selectedMatchId &&
      Number(
        selectedMatchId
      ) ===
        Number(
          updated.id
        )
    ) {
      await loadSelectedMatch(
        selectedMatchId
      );
    }

    setMessage(
      "📍 Match venue updated."
    );

    showToast?.(
      "success",
      "📍 Match venue updated"
    );
  } catch (
    err
  ) {
    setError(
      err?.message ||
      "Unable to update match venue."
    );
  } finally {
    setVenueSaving(
      false
    );
  }
}

async function openEditMatchModal(match) {
  try {
    const fullMatch = await api(`/api/matches/${match.id}`);

    setEditingMatch(fullMatch);

    setEditMatchForm({
      scheduledAt: fullMatch.scheduledAt
        ? new Date(fullMatch.scheduledAt).toISOString().slice(0, 16)
        : "",

      venueName:
        fullMatch.venueName ||
        "",

      venueAddress:
        fullMatch.venueAddress ||
        "",

      oversPerInnings: fullMatch.oversPerInnings || 20,
      powerplayOversInnings: fullMatch.powerplayOversInnings || 0,
      maxWicketsPerInnings: fullMatch.maxWicketsPerInnings || "",
      maxOversPerBowler: fullMatch.maxOversPerBowler || "",
      seriesId: fullMatch.seriesId || "",
      teamAId: String(match.teamAId || ""),
      teamBId: String(match.teamBId || ""),

      teamACaptainId: fullMatch.teamACaptainId
        ? String(fullMatch.teamACaptainId)
        : "",
      teamBCaptainId: fullMatch.teamBCaptainId
        ? String(fullMatch.teamBCaptainId)
        : "",
      teamAViceCaptainId: fullMatch.teamAViceCaptainId
        ? String(fullMatch.teamAViceCaptainId)
        : "",
      teamBViceCaptainId: fullMatch.teamBViceCaptainId
        ? String(fullMatch.teamBViceCaptainId)
        : "",
      teamAWicketKeeperId: fullMatch.teamAWicketKeeperId
        ? String(fullMatch.teamAWicketKeeperId)
        : "",
      teamBWicketKeeperId: fullMatch.teamBWicketKeeperId
        ? String(fullMatch.teamBWicketKeeperId)
        : "",
    });

    setShowEditMatchModal(true);
  } catch (err) {
    setError(err.message || "Unable to load match details.");
  }
}
async function handleUpdateScheduledMatch(e) {
  e.preventDefault();

  if (!editingMatch?.id) return;

  const teamAId = Number(editMatchForm.teamAId);
const teamBId = Number(editMatchForm.teamBId);

if (
  !Number.isInteger(teamAId) ||
  teamAId <= 0 ||
  !Number.isInteger(teamBId) ||
  teamBId <= 0
) {
  alert("Please select both teams.");
  return;
}

if (teamAId === teamBId) {
  alert("Team A and Team B must be different.");
  return;
}

  try {
    await api(`/api/matches/${editingMatch.id}`, {
      method: "PATCH",
      body: JSON.stringify({
        scheduledAt: editMatchForm.scheduledAt
          ? new Date(editMatchForm.scheduledAt).toISOString()
          : null,

        venueName:
          editMatchForm.venueName ||
          "",

        venueAddress:
          editMatchForm.venueAddress ||
          "",

        oversPerInnings: Number(editMatchForm.oversPerInnings),
        powerplayOversInnings: Number(editMatchForm.powerplayOversInnings || 0),
        maxWicketsPerInnings: editMatchForm.maxWicketsPerInnings
          ? Number(editMatchForm.maxWicketsPerInnings)
          : null,
        maxOversPerBowler: editMatchForm.maxOversPerBowler
          ? Number(editMatchForm.maxOversPerBowler)
          : null,
        seriesId: editMatchForm.seriesId || null,
        
        teamAId,
        teamBId,

        teamACaptainId: editMatchForm.teamACaptainId
          ? Number(editMatchForm.teamACaptainId)
          : null,
        teamBCaptainId: editMatchForm.teamBCaptainId
          ? Number(editMatchForm.teamBCaptainId)
          : null,
        teamAViceCaptainId: editMatchForm.teamAViceCaptainId
          ? Number(editMatchForm.teamAViceCaptainId)
          : null,
        teamBViceCaptainId: editMatchForm.teamBViceCaptainId
          ? Number(editMatchForm.teamBViceCaptainId)
          : null,
        teamAWicketKeeperId: editMatchForm.teamAWicketKeeperId
          ? Number(editMatchForm.teamAWicketKeeperId)
          : null,
        teamBWicketKeeperId: editMatchForm.teamBWicketKeeperId
          ? Number(editMatchForm.teamBWicketKeeperId)
          : null,
      }),
    });

    await loadMatches();
    await loadLeagueStats(activeLeagueId);

    if (selectedMatchId && Number(selectedMatchId) === Number(editingMatch.id)) {
      await loadSelectedMatch(selectedMatchId);
    }

    setShowEditMatchModal(false);
    setEditingMatch(null);
    setMessage("✅ Scheduled match updated");
  } catch (err) {
    setError(err.message);
  }
}
async function openPermissionEditor(member) {
  try {
    setSelectedMember(member);
    setShowPermissionModal(true);

    const response = await fetch(
      //`/api/leagues/${activeLeague.id}/permissions?memberId=${member.id}`
    `/api/leagues/${activeLeague.id}/permissions?memberId=${member.id}`
    );

    const data = await response.json();

    if (!response.ok) {
      throw new Error(
        data.error || "Failed to load permissions"
      );
    }

    const latestMember = data.member;

    const loadedPermissions = {
      role: latestMember.role || "VIEWER",
    };

    for (const field of PERMISSION_FIELDS) {
      loadedPermissions[field] =
        latestMember[field] ?? false;
    }

    setSelectedMember(latestMember);
    setMemberPermissions(loadedPermissions);
  } catch (error) {
    setError(error.message);
  }
}
function updatePermission(permission, value) {
  setMemberPermissions((prev) => ({
    ...(prev || {}),
    [permission]: value,
  }));
}

async function savePermissions(member) {

  if (!selectedMember || !activeLeague?.id || !memberPermissions) return;

  try {
    const response = await fetch(
      `/api/leagues/${activeLeague.id}/permissions?memberId=${member.id}`,
      {
        method: "PATCH",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          memberId: selectedMember.id,
          email: selectedMember.user?.email,
          role: memberPermissions?.role || selectedMember.role || "VIEWER",
          ...Object.fromEntries(
            PERMISSION_FIELDS.map((field) => [
              field,
              memberPermissions?.[field] ?? false,
            ])
          ),
        }),
      }
    );

    const data = await response.json();

    if (!response.ok) {
      throw new Error(
        data.error || "Failed to save permissions"
      );
    }

    const updatedMember = data.member || {
      ...selectedMember,
      ...(memberPermissions || {}),
    };

    setLeagues((prev) =>
      prev.map((league) =>
        league.id === activeLeague.id
          ? {
              ...league,
              members: league.members?.map((member) =>
                member.id === selectedMember.id
                  ? {
                      ...member,
                      ...updatedMember,
                    }
                  : member
              ),
            }
          : league
      )
    );

    setSelectedMember(updatedMember);
    setMemberPermissions(null);
    setShowPermissionModal(false);
    setMessage("✅ Role and permissions updated successfully");
  } catch (error) {
    setError(error.message);
  }
}
async function handleUnregisterLeagueMember(
  member
) {
  if (
    !activeLeague?.id ||
    !member?.userId ||
    unregisteringMemberId
  ) {
    return;
  }

  if (
    !canUnregisterLeagueMembers
  ) {
    setError(
      "Only the Cric4All Super Admin or a league Owner can unregister league members."
    );
    return;
  }

  const memberName =
    member.user?.name ||
    member.user?.email ||
    "this user";

  const confirmation =
    window.confirm(
      `Unregister ${memberName} from ${activeLeague.name}?\n\nThis removes only this league membership. The user's Cric4All account, completed-match history, scores, statistics, and memberships in other leagues will be preserved.`
    );

  if (!confirmation) {
    return;
  }

  setError("");
  setMessage("");
  setUnregisteringMemberId(
    member.id
  );

  try {
    const result =
      await api(
        `/api/leagues/${activeLeague.id}/members?userId=${encodeURIComponent(member.userId)}`,
        {
          method:
            "DELETE",
        }
      );

    setLeagues((previous) =>
      previous.map((league) =>
        Number(league.id) ===
        Number(activeLeague.id)
          ? {
              ...league,
              members:
                (league.members || []).filter(
                  (existingMember) =>
                    Number(existingMember.id) !==
                    Number(member.id)
                ),
            }
          : league
      )
    );

    setSelectedMember(
      null
    );
    setMemberPermissions(
      null
    );
    setShowPermissionModal(
      false
    );

    setMessage(
      `✅ ${result?.message || `${memberName} was unregistered from ${activeLeague.name}.`}`
    );

    showToast(
      "success",
      `✅ ${memberName} unregistered from league`
    );
  } catch (
    error
  ) {
    setError(
      error?.message ||
      "Unable to unregister league member."
    );
  } finally {
    setUnregisteringMemberId(
      null
    );
  }
}

const PERMISSION_FIELDS = [
  "canViewDashboard",
  "canViewManagement",
  "canViewMatches",
  "canViewScoring",
  "canViewStats",

  "canCreateLeague",
  "canEditLeague",
  "canDeleteLeague",

  "canManageMembers",
  "canManagePermissions",

  "canCreateTeam",
  "canEditTeam",
  "canDeleteTeam",

  "canCreatePlayer",
  "canEditPlayer",
  "canDeletePlayer",

  "canCreateMatch",
  "canEditMatch",
  "canDeleteMatch",

  "canScoreMatch",
  "canEditScore",
  "canUndoBall",
  "canSwapStrike",
  "canRetirePlayer",

  "canEndMatch",
  "canAbandonMatch",
  "canLockMatch",

  "canExportStats",
  "canViewAuditLogs",
];
async function api(url, options = {}) { 
    const res = await fetch(url, {
      ...options,
      headers: {
        "Content-Type": "application/json",
        ...(options.headers || {})
      }
    });
    const data = await res.json().catch(() => ({}));

    if (!res.ok) {
      const requestError = new Error(
        data.message || data.error || "Request failed"
      );
      requestError.status = res.status;
      requestError.code = data.code || data.errorCode || data.error || null;
      requestError.data = data;
      throw requestError;
    }

    return data;
  }

function isOfflineSyncConflictError(error) {
  return (
    Number(error?.status || 0) === 409 &&
    (
      String(error?.code || "").trim().toUpperCase() ===
        "OFFLINE_SYNC_CONFLICT" ||
      String(
        error?.data?.code ||
        error?.data?.error ||
        ""
      ).trim().toUpperCase() ===
        "OFFLINE_SYNC_CONFLICT"
    )
  );
}

function showToast(type, text) {
  setToast({ type, text });

  setTimeout(() => {
    setToast(null);
  }, 3000);
}
function buildCaptainStats(matches) {
  const captainMap = new Map();

  for (const match of matches || []) {
    const status = String(match.status || "").toUpperCase();

    if (!["COMPLETED", "COMPLETED_LOCKED", "COMPLETED_CORRECTED"].includes(status)) continue;

    const statusText = String(match.statusText || "").toLowerCase();

    const captains = [
      {
        playerId: match.teamACaptainId,
        teamName: match.teamA?.name,
      },
      {
        playerId: match.teamBCaptainId,
        teamName: match.teamB?.name,
      },
    ].filter((c) => c.playerId);

    for (const captain of captains) {
      if (!captainMap.has(Number(captain.playerId))) {
        captainMap.set(Number(captain.playerId), {
          playerId: Number(captain.playerId),
          played: 0,
          won: 0,
          lost: 0,
        });
      }

      const row = captainMap.get(Number(captain.playerId));
      row.played += 1;

      if (statusText.includes(String(captain.teamName || "").toLowerCase())) {
        row.won += 1;
      } else if (!statusText.includes("tied")) {
        row.lost += 1;
      }
    }
  }

  return [...captainMap.values()];
}
function buildWicketKeeperStats(matches) {
  const keeperMap = new Map();

  for (const match of matches || []) {
    const keepers = [
      match.teamAWicketKeeperId,
      match.teamBWicketKeeperId,
    ].filter(Boolean);

    for (const keeperId of keepers) {
      if (!keeperMap.has(Number(keeperId))) {
        keeperMap.set(Number(keeperId), {
          playerId: Number(keeperId),
          catches: 0,
          stumpings: 0,
          runOuts: 0,
          dismissals: 0,
        });
      }
    }

    for (const ball of match.balls || []) {
      const wicketType = String(ball.wicketType || "").toUpperCase();

      const fielderId = Number(ball.fielderId || 0);
      const assistantFielderId = Number(ball.assistantFielderId || 0);

      if (keeperMap.has(fielderId)) {
        const row = keeperMap.get(fielderId);

        if (wicketType === "CAUGHT") row.catches += 1;
        if (wicketType === "STUMPED") row.stumpings += 1;
        if (wicketType === "RUN_OUT") row.runOuts += 1;
      }

      if (keeperMap.has(assistantFielderId)) {
        const row = keeperMap.get(assistantFielderId);

        if (wicketType === "RUN_OUT") row.runOuts += 1;
      }
    }
  }

  return [...keeperMap.values()].map((row) => ({
    ...row,
    dismissals: row.catches + row.stumpings + row.runOuts,
  }));
}
function flashScoreButton(key, callback) {
  setPressedScoreKey(key);
callback();
  window.setTimeout(() => {
    setPressedScoreKey("");
  }, 180);
}
function previewScoreboardAfterBall(board, data) {
  if (!board?.innings?.length) return board;

  const inningsNo =
    Number(data.inningsNo || board.currentInnings || 1);

  const inningsIndex = inningsNo - 1;

  const totalRuns =
    Number(data.runsOffBat || 0) +
    Number(data.extras || 0);

  const isLegal =
    data.extraType !== "WIDE" &&
    data.extraType !== "NOBALL" &&
    data.wicketType !== "RETIRED_HURT";

  const isRealWicket =
    Number(data.isWicket) &&
    data.wicketType !== "RETIRED_HURT";

  const copy =
    typeof structuredClone === "function"
      ? structuredClone(board)
      : JSON.parse(JSON.stringify(board));

  const innings = copy.innings?.[inningsIndex];

  if (!innings) return board;

  const nextBallLabel = (() => {
  const legalBallsBefore =
    Number(
      innings.legalBalls ||
      0
    );

  let over;
  let ball;

  /*
   * Use the number of legal balls BEFORE the delivery.
   * This keeps the sixth legal ball in the over that is actually ending.
   *
   * 17 legal balls before -> 2.6
   * 18 legal balls before -> 3.1
   */
  over =
    Math.floor(
      legalBallsBefore /
      6
    );

  ball =
    (
      legalBallsBefore %
      6
    ) +
    1;

  let result = String(totalRuns);

  if (data.wicketType === "RETIRED_HURT") {
    result = "RH";
  } else if (isRealWicket) {
    result = "W";
  } else if (data.extraType === "WIDE") {
    result = totalRuns > 1 ? `WD+${totalRuns - 1}` : "WD";
  } else if (data.extraType === "NOBALL") {
    result = Number(data.runsOffBat || 0) > 0
      ? `NB+${data.runsOffBat}`
      : "NB";
  } else if (data.extraType === "BYE") {
    result = `B${data.extras || ""}`;
  } else if (data.extraType === "LEGBYE") {
    result = `LB${data.extras || ""}`;
  }

  return `${over}.${ball} ${result}`;
})();

  innings.runs = Number(innings.runs || 0) + totalRuns;

  if (isRealWicket) {
    innings.wickets = Number(innings.wickets || 0) + 1;
  }

  if (isLegal) {
    innings.legalBalls = Number(innings.legalBalls || 0) + 1;

    const overs = Math.floor(innings.legalBalls / 6);
    const balls = innings.legalBalls % 6;

    innings.oversDisplay = `${overs}.${balls}`;
  }
const currentState = copy.currentState;

if (currentState) {
  const batRuns = Number(data.runsOffBat || 0);
  const extras = Number(data.extras || 0);

  if (currentState.strikerStats) {
    currentState.strikerStats.runs =
      Number(currentState.strikerStats.runs || 0) + batRuns;

    if (isLegal) {
      currentState.strikerStats.balls =
        Number(currentState.strikerStats.balls || 0) + 1;
    }

    currentState.strikerStats.strikeRate =
      currentState.strikerStats.balls
        ? (
            (Number(currentState.strikerStats.runs || 0) /
              Number(currentState.strikerStats.balls || 1)) *
            100
          ).toFixed(2)
        : "0.00";
  }

  if (currentState.bowlerStats) {
    const bowlerRuns =
      data.extraType === "BYE" || data.extraType === "LEGBYE"
        ? 0
        : batRuns + extras;

    currentState.bowlerStats.runs =
      Number(currentState.bowlerStats.runs || 0) + bowlerRuns;

    if (isLegal) {
function oversToBalls(oversValue) {
  const [oversPart, ballsPart] = String(oversValue || "0.0")
    .split(".")
    .map(Number);

  return (oversPart || 0) * 6 + (ballsPart || 0);
}

const previousBowlerBalls =
  currentState.bowlerStats.balls != null
    ? Number(currentState.bowlerStats.balls)
    : oversToBalls(currentState.bowlerStats.overs);

const currentBalls = previousBowlerBalls + 1;

      currentState.bowlerStats.balls = currentBalls;
      currentState.bowlerStats.overs =
        `${Math.floor(currentBalls / 6)}.${currentBalls % 6}`;
    }

    if (isRealWicket) {
      currentState.bowlerStats.wickets =
        Number(currentState.bowlerStats.wickets || 0) + 1;
    }
  }
}
/*
 * Keep local striker/non-striker state accurate while offline. The server uses
 * the same applyBallOutcome() helper when it later replays this queued event.
 */
if (copy.currentState) {
  const legalBallsBefore = Number(innings.legalBalls || 0) - (isLegal ? 1 : 0);
  const localBallInOver = (Math.max(0, legalBallsBefore) % 6) + 1;

  const localOutcome = applyBallOutcome({
    ...data,
    strikerId: Number(data.strikerId),
    nonStrikerId: Number(data.nonStrikerId),
    legalDelivery: isLegal,
    ballInOver: localBallInOver,
    isWicket: isRealWicket ? 1 : 0,
  });

  const oldStrikerId = Number(copy.currentState.strikerId || data.strikerId);
  const oldNonStrikerId = Number(copy.currentState.nonStrikerId || data.nonStrikerId);
  const oldStrikerName = copy.currentState.strikerName;
  const oldNonStrikerName = copy.currentState.nonStrikerName;
  const oldStrikerStats = copy.currentState.strikerStats;
  const oldNonStrikerStats = copy.currentState.nonStrikerStats;

  copy.currentState.strikerId = localOutcome.strikerId;
  copy.currentState.nonStrikerId = localOutcome.nonStrikerId;

  if (Number(localOutcome.strikerId) === oldNonStrikerId) {
    copy.currentState.strikerName = oldNonStrikerName;
    copy.currentState.strikerStats = oldNonStrikerStats;
  } else if (Number(localOutcome.strikerId) === oldStrikerId) {
    copy.currentState.strikerName = oldStrikerName;
    copy.currentState.strikerStats = oldStrikerStats;
  }

  if (Number(localOutcome.nonStrikerId) === oldStrikerId) {
    copy.currentState.nonStrikerName = oldStrikerName;
    copy.currentState.nonStrikerStats = oldStrikerStats;
  } else if (Number(localOutcome.nonStrikerId) === oldNonStrikerId) {
    copy.currentState.nonStrikerName = oldNonStrikerName;
    copy.currentState.nonStrikerStats = oldNonStrikerStats;
  }

  /*
   * WICKET / RETIRED-HURT OFFLINE REPLACEMENT
   * ------------------------------------------
   * applyBallOutcome() correctly returns newBatterId, but the old preview
   * code only knew how to copy names/stats when the final batter was one of
   * the PREVIOUS striker/non-striker.
   *
   * When a new batter enters, the ID changed but the displayed name/stats
   * stayed on the dismissed/retired player. Resolve both final IDs against
   * the batting roster so local UI and ballForm move together.
   */
  const resolveLocalBatter =
    (playerId) =>
      battingTeam
        ?.players
        ?.find(
          (player) =>
            Number(player.id) ===
            Number(playerId)
        );

  const finalStriker =
    resolveLocalBatter(
      copy.currentState.strikerId
    );

  const finalNonStriker =
    resolveLocalBatter(
      copy.currentState.nonStrikerId
    );

  if (finalStriker) {
    copy.currentState.strikerName =
      finalStriker.name;

    if (
      Number(finalStriker.id) !==
        oldStrikerId &&
      Number(finalStriker.id) !==
        oldNonStrikerId
    ) {
      copy.currentState.strikerStats = {
        playerId:
          finalStriker.id,
        playerName:
          finalStriker.name,
        runs: 0,
        balls: 0,
        fours: 0,
        sixes: 0,
        strikeRate:
          "0.00",
      };
    }
  }

  if (finalNonStriker) {
    copy.currentState.nonStrikerName =
      finalNonStriker.name;

    if (
      Number(finalNonStriker.id) !==
        oldStrikerId &&
      Number(finalNonStriker.id) !==
        oldNonStrikerId
    ) {
      copy.currentState.nonStrikerStats = {
        playerId:
          finalNonStriker.id,
        playerName:
          finalNonStriker.name,
        runs: 0,
        balls: 0,
        fours: 0,
        sixes: 0,
        strikeRate:
          "0.00",
      };
    }
  }
}

copy.recentBalls = [
  {
    id: `optimistic-${Date.now()}`,
    label: nextBallLabel,
    optimistic: true,
  },
  ...(copy.recentBalls || []),
].slice(0, 20);

  return copy;
}
async function loadPointsTable(leagueId) {
  if (!leagueId) return;

  const data = await api(`/api/leagues/${leagueId}/points-table`);
  setPointsTable(data);
}

async function applyRetiredHurtCorrection({
  inningsNo,
  afterSequence,
  retiredPlayerId,
  replacementPlayerId,
}) {
  try {
    setCorrectionSaving(true);

setCorrectionStatus(
  "🏏 Replaying innings..."
);
    const result = await api(
      `/api/matches/${selectedMatchId}/corrections/retired-hurt`,
      {
        method: "POST",
body: JSON.stringify({
  inningsNo: correctionForm.inningsNo,
  afterBallId: correctionForm.afterBallId,
  retiredPlayerId: correctionForm.retiredPlayerId,
  replacementPlayerId: correctionForm.replacementPlayerId,
  replacementOutBallId: correctionForm.replacementOutBallId,
  newBatterAfterReplacementId: correctionForm.newBatterAfterReplacementId,
}),
      }
    );
    setCorrectionStatus(
  "✅ Scorecard recalculated."
);
setTimeout(() => {
  setShowCorrectionModal(false);
}, 1500);
setLastCorrectionId(result.correctionId);

await api(
  "/api/milestones/reconcile",
  {
    method:
      "POST",

    body:
      JSON.stringify({
        matchId:
          Number(
            selectedMatchId
          ),
      }),
  }
);
    await loadSelectedMatch(selectedMatchId);
    await loadMatches();
    await loadLeagueStats(activeLeagueId);
    setShowCorrectionModal(false);

setMessage(
  `✅ Correction applied

• ${result.updatedBalls} deliveries replayed
• Trinadh retired hurt inserted
• Batting order recalculated

Rollback available.`
);
    showToast?.(
  "success",
  "Correction completed successfully."
);

  } catch (err) {
    setError(err.message);
  } finally{
    setCorrectionSaving(false);
  }
}

async function rollbackCorrection(correctionId) {
  try {
    setRollbackSaving(true);

setCorrectionStatus(
  "↩️ Restoring original scorecard..."
);
    await api(
      `/api/matches/${selectedMatchId}/corrections/${correctionId}/rollback`,
      { method: "POST" }
    );
    setCorrectionStatus(
  "✅ Rollback completed."
);

setRollbackSaving(false);

setLastCorrectionId(null);
    await loadSelectedMatch(selectedMatchId);
    await loadMatches();

    setMessage("↩️ Correction rolled back successfully.");
    showToast?.(
  "success",
  "Rollback completed successfully."
);
  } catch (err) {
    setError(err.message);
  }
}
const spectatorShareSiteUrl =
  String(
    process.env.NEXT_PUBLIC_SITE_URL ||
    "https://cric4all.app"
  )
    .trim()
    .replace(/\/+$/, "");

async function handleShareMatch() {
  if (!scoreboard) return;

  const shareCode =
    scoreboard?.match?.shareCode;

  if (!shareCode) {
    setError(
      "Share code is not available for this match."
    );
    return;
  }

  const shareUrl =
    `${spectatorShareSiteUrl}/live/${encodeURIComponent(
      shareCode
    )}/share-v1`;

  const innings =
    scoreboard.innings?.[scoreboard.innings.length - 1];

  const leagueName =
    scoreboard.match?.leagueName ||
    activeLeague?.name ||
    "Cric4All";

  const teamA = scoreboard.match?.teamAName || "Team A";
  const teamB = scoreboard.match?.teamBName || "Team B";

  const scoreLine = innings
    ? `${innings.teamName || ""} ${innings.runs ?? 0}/${innings.wickets ?? 0} (${innings.oversDisplay || "0.0"} ov)`
    : "Score loading...";

  const statusText =
    scoreboard.summary?.statusText ||
    scoreboard.summary?.targetText ||
    "Follow the live scorecard for updates.";

  const shareText = `
🏏 LIVE CRICKET MATCH

${leagueName}
${teamA} 🆚 ${teamB}

━━━━━━━━━━━━━━━━━━
📊 LIVE SCORE

${scoreLine}
${statusText}

━━━━━━━━━━━━━━━━━━
📲 Watch LIVE Scorecard

${shareUrl}

━━━━━━━━━━━━━━━━━━
🏏 Cric4All — Live Cricket Scoring, Scorecards & Player Stats
`.trim();

  try {
    const result =
      await shareCric4All({
        title: `${teamA} vs ${teamB}`,
        text: shareText,
        url: shareUrl,
        dialogTitle: "Share live Cric4All score",
      });

    if (result?.cancelled) {
      return;
    }

    if (result?.unsupported) {
      await navigator.clipboard.writeText(
        shareText
      );

      showToast?.(
        "success",
        "📋 Live score message copied."
      );
    }
  } catch (err) {
    console.error(
      "Share live score failed:",
      err
    );

    try {
      await navigator.clipboard.writeText(
        shareText
      );

      showToast?.(
        "success",
        "📋 Live score message copied."
      );
    } catch {
      showToast?.(
        "error",
        "Unable to share this live score."
      );
    }
  }
}
const loadLeagues = async (leagueIdToValidate = null) => {
  const response = await fetch("/api/leagues");
  const data = await response.json();

  setLeagues(data || []);

  const idToCheck = leagueIdToValidate ?? activeLeagueId;

  if (idToCheck) {
    const refreshedLeague = data.find(
      (l) => String(l.id) === String(idToCheck)
    );

    if (!refreshedLeague) {
      setActiveLeagueId(null);
      setSelectedTeamId("");
    }
  }

  return data || [];
};

async function updateRole(
  leagueId,
  memberId,
  role
) {
  try {
    const response = await fetch(
      `/api/leagues/${activeLeague.id}/permissions?memberId=${memberId}`,
      {
        method: "PATCH",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          memberId,
          role
        })
      }
    );

    const data = await response.json();

    if (!response.ok) {
      throw new Error(
        data.error || "Failed to update role"
      );
    }

    setLeagues((prev) =>
      prev.map((league) =>
        league.id === leagueId
          ? {
              ...league,
              members: league.members?.map(
                (member) =>
                  member.id === memberId
                    ? {
                        ...member,
                        role
                      }
                    : member
              )
            }
          : league
      )
    );

    setMessage("Role updated successfully");
  } catch (error) {
    console.error(error);
    setError(error.message);
  }
}

async function loadSelectedMatch(matchId, options = {}) {
  const {
    loadDetail = false,
    loadStatsData = false,
    syncBallForm = true,
  } = options;

  if (!matchId) {
    setMatchDetail(null);
    setScoreboard(null);
    setStats({
      batting: [],
      bowling: [],
    });
    return null;
  }

  let board = null;
  let detail = null;

  try {
    /*
     * PERFORMANCE:
     * Start scoreboard, detail and optional stats requests together.
     * The scoreboard remains the primary/fast render path.
     *
     * Preference persistence is intentionally not done here anymore.
     * The existing preferences useEffect owns that responsibility.
     */
    const boardPromise =
      api(`/api/scoreboard/${matchId}`);

    const detailPromise =
      loadDetail
        ? api(`/api/matches/${matchId}`)
        : Promise.resolve(null);

    const statsPromise =
      loadStatsData
        ? api(`/api/stats/${matchId}`)
        : Promise.resolve(null);

    board = await boardPromise;
    setScoreboard(board);

    offlineServerSequencesRef.current = {
      matchId:
        Number(matchId),

      1:
        Number(
          board
            ?.sync
            ?.serverSequences
            ?.[1] ??
          board
            ?.sync
            ?.serverSequences
            ?.["1"] ??
          0
        ),

      2:
        Number(
          board
            ?.sync
            ?.serverSequences
            ?.[2] ??
          board
            ?.sync
            ?.serverSequences
            ?.["2"] ??
          0
        ),
    };

    if (
      syncBallForm &&
      board?.currentState &&
      !showDeliverySetupModal
    ) {
      setBallForm((prev) => ({
        ...prev,

        strikerId:
          board.currentState.strikerId ??
          prev.strikerId,

        nonStrikerId:
          board.currentState.nonStrikerId ??
          prev.nonStrikerId,

        bowlerId:
          board.currentState.bowlerId ??
          prev.bowlerId,
      }));
    }

    const [
      resolvedDetail,
      resolvedStats,
    ] = await Promise.all([
      detailPromise,
      statsPromise,
    ]);

    if (resolvedDetail) {
      detail = resolvedDetail;
      setMatchDetail(
        resolvedDetail
      );
    }

    if (resolvedStats) {
      setStats(
        resolvedStats
      );
    }

    await cacheOfflineMatchSnapshot(
      matchId,
      {
        scoreboard:
          board,

        matchDetail:
          detail ||
          matchDetail ||
          null,
      }
    ).catch(() => {});

    return board;
  } catch (loadError) {
    if (
      !isOfflineRetryableError(
        loadError
      )
    ) {
      throw loadError;
    }

    const cached =
      await getOfflineMatchSnapshot(
        matchId
      ).catch(() => null);

    if (
      !cached?.scoreboard
    ) {
      throw loadError;
    }

    board =
      cached.scoreboard;

    setScoreboard(
      board
    );

    if (
      cached.matchDetail
    ) {
      setMatchDetail(
        cached.matchDetail
      );
    }

    if (
      syncBallForm &&
      board?.currentState &&
      !showDeliverySetupModal &&
      offlineSyncState?.online !== false &&
      Number(
        offlineSyncState?.pending ||
        0
      ) === 0
    ) {
      setBallForm((prev) => ({
        ...prev,

        strikerId:
          board.currentState.strikerId ??
          prev.strikerId,

        nonStrikerId:
          board.currentState.nonStrikerId ??
          prev.nonStrikerId,

        bowlerId:
          board.currentState.bowlerId ??
          prev.bowlerId,
      }));
    }

    setOfflineSyncState(
      (previous) => ({
        ...previous,

        online:
          false,

        lastError:
          "Using the last saved match snapshot while offline.",
      })
    );

    return board;
  }
}

async function handleAddLeague(e) {
  e.preventDefault();

  setMessage("");
  setError("");

  try {
const league = await api("/api/leagues", {
  method: "POST",
  body: JSON.stringify({
    name: leagueForm.name.trim(),
    leagueId: activeLeagueId
  })
});

    setLeagueForm({
      name: ""
    });
    await loadLeagues();
    setActiveLeagueId(Number(league.id));
    showToast(
      "success",
      "🏆 League created"
    );

    await loadLeagues();
    await loadMatches();
    await loadTeams();
    await refreshAll();
  } catch (err) {
    setError(err.message);
  }
}

function openEditLeagueModal(league = activeLeague) {
  if (!league) {
    setError("Please select a league first.");
    return;
  }

  if (!(isSuperAdmin || permissions?.canEditLeague)) {
    setError("You do not have permission to edit this league.");
    return;
  }

  setEditLeagueForm({
    name: String(league.name || ""),
    visibility: String(league.visibility || "PRIVATE").toUpperCase(),
  });
  setError("");
  setShowEditLeagueModal(true);
}

async function handleUpdateLeague() {
  if (!activeLeague?.id || editLeagueSaving) {
    return;
  }

  const name = String(editLeagueForm.name || "").trim();
  const visibility = String(editLeagueForm.visibility || "PRIVATE")
    .trim()
    .toUpperCase();

  if (!name) {
    setError("League name is required.");
    return;
  }

  if (!["PRIVATE", "UNLISTED", "PUBLIC"].includes(visibility)) {
    setError("Please select a valid league visibility.");
    return;
  }

  try {
    setEditLeagueSaving(true);
    setError("");

    const response = await fetch(`/api/leagues/${activeLeague.id}`, {
      method: "PATCH",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        action: "UPDATE_LEAGUE",
        name,
        visibility,
      }),
    });

    const data = await response.json();

    if (!response.ok) {
      throw new Error(data?.error || "Failed to update league");
    }

    const activeId = String(activeLeague.id);
    const updatedLeagues = await loadLeagues(activeId);
    const refreshedLeague = (updatedLeagues || []).find(
      (league) => String(league.id) === activeId
    );

    if (refreshedLeague) {
      setActiveLeagueId(activeId);
      setLeagueName(refreshedLeague.name || "");
    }

    setShowEditLeagueModal(false);
    setMessage(
      visibility === "PUBLIC"
        ? `✅ ${name} is now a public league.`
        : visibility === "UNLISTED"
          ? `✅ ${name} is now unlisted and viewable by link.`
          : `✅ ${name} is now private.`
    );
    showToast(
      "success",
      visibility === "PUBLIC"
        ? "🌍 League is now public"
        : "✅ League settings updated"
    );
  } catch (error) {
    setError(error?.message || "Failed to update league");
  } finally {
    setEditLeagueSaving(false);
  }
}

async function handleDeleteLeague(
  leagueId,
  leagueName
) {
  if (
    !confirm(
      `Delete league "${leagueName}"?`
    )
  ) {
    return;
  }

  try {
    await api(
      `/api/leagues/${leagueId}`,
      {
        method: "DELETE"
      }
    );

    showToast(
      "success",
      "🗑️ League deleted"
    );

    await refreshAll();
  } catch (err) {
    setError(err.message);
  }
}
  async function refreshAll(matchId = selectedMatchId) {
    await Promise.all([loadLeagues(), loadTeams(), loadMatches()]);
    if (matchId) {
      await loadSelectedMatch(matchId);
    }
  }

  useEffect(() => {
    if (selectedMatchId) {
      if (!pageVisible) {
        return;
      }

      /*
       * handleMatchSelect() already performs the intentional load with the
       * correct options. Do not immediately issue another scoreboard request
       * just because selectedMatchId changed.
       */
      if (
        selectedMatchExplicitLoadRef
          .current ===
        String(
          selectedMatchId
        )
      ) {
        selectedMatchExplicitLoadRef
          .current =
          "";

        return;
      }

      loadSelectedMatch(
        selectedMatchId
      ).catch(
        (err) =>
          setError(
            err.message
          )
      );
    } else {
      selectedMatchExplicitLoadRef
        .current =
        "";

      setMatchDetail(
        null
      );

      setScoreboard(
        null
      );

      setStats({
        batting: [],
        bowling: [],
      });
    }
  }, [selectedMatchId]);

  useEffect(() => {
    /*
     * DLS STATE HYDRATION
     * ===================
     * Standard match selection remains as fast as before.
     * Only a scoreboard that explicitly reports an active DLS adjustment
     * loads the small DLS state endpoint so revised allocation/target survives
     * a browser refresh and remains correct in Scorer Mode.
     */
    if (
      !selectedMatchId ||
      !scoreboard
        ?.summary
        ?.dls
        ?.active
    ) {
      return;
    }

    let cancelled =
      false;

    api(
      `/api/matches/${selectedMatchId}/dls`
    )
      .then((state) => {
        if (
          !cancelled
        ) {
          setDlsState(
            state
          );
        }
      })
      .catch(() => {
        /*
         * The scoreboard's DLS target remains usable even if this optional
         * hydration request fails.
         */
      });

    return () => {
      cancelled =
        true;
    };
  }, [
    selectedMatchId,
    scoreboard
      ?.summary
      ?.dls
      ?.active,
  ]);

  useEffect(() => {
    /*
     * While offline (or while unsynced local changes exist), ballForm is the
     * authoritative live scoring state. Do not let a cached/server scoreboard
     * overwrite the locally selected innings/players.
     */
    if (
      offlineSyncState?.online === false ||
      Number(offlineSyncState?.pending || 0) > 0
    ) {
      return;
    }

    if (scoreboard?.currentInnings) {
      setBallForm((prev) => ({
        ...prev,
        inningsNo: String(scoreboard.currentInnings)
      }));
    }
  }, [
    scoreboard?.currentInnings,
    offlineSyncState?.online,
    offlineSyncState?.pending,
  ]);

  const battingTeam = useMemo(() => {
    if (!matchDetail) return null;
    const inningsNo = Number(ballForm.inningsNo);

    const battingFirst =
      matchDetail.battingFirstTeamId === matchDetail.teamA.id
        ? matchDetail.teamA
        : matchDetail.teamB;

    const secondBat =
      matchDetail.battingFirstTeamId === matchDetail.teamA.id
        ? matchDetail.teamB
        : matchDetail.teamA;

    return inningsNo === 1 ? battingFirst : secondBat;
  }, [matchDetail, ballForm.inningsNo]);

  const bowlingTeam = useMemo(() => {
    if (!matchDetail || !battingTeam) return null;
    return battingTeam.id === matchDetail.teamA.id ? matchDetail.teamB : matchDetail.teamA;
  }, [matchDetail, battingTeam]);


  const currentWicketKeeperId =
    Number(
      bowlingTeam?.id
    ) ===
    Number(
      matchDetail?.teamAId
    )
      ? Number(
          matchDetail
            ?.teamAWicketKeeperId
        )
      : Number(
          matchDetail
            ?.teamBWicketKeeperId
        );

  const currentWicketKeeperName =
    (
      bowlingTeam
        ?.players ||
      []
    ).find(
      (player) =>
        Number(
          player.id
        ) ===
        Number(
          currentWicketKeeperId
        )
    )?.name ||
    (
      Number(
        bowlingTeam?.id
      ) ===
      Number(
        matchDetail?.teamAId
      )
        ? matchDetail
            ?.teamAWicketKeeperName
        : matchDetail
            ?.teamBWicketKeeperName
    ) ||
    "Not selected";

  const wicketKeeperReplacementOptions =
    (
      bowlingTeam
        ?.players ||
      []
    ).filter(
      (player) =>
        Number(
          player.id
        ) !==
        Number(
          currentWicketKeeperId
        )
    );

useEffect(() => {
  if (showDeliverySetupModal) return;
  if (!battingTeam || !bowlingTeam) return;

    const firstStriker = battingTeam.players[0]?.id ? String(battingTeam.players[0].id) : "";
    const secondPlayer = battingTeam.players.find(
      (p) => String(p.id) !== firstStriker
    );
    const firstNonStriker = secondPlayer?.id ? String(secondPlayer.id) : "";
    const firstBowler = bowlingTeam.players[0]?.id ? String(bowlingTeam.players[0].id) : "";

    setBallForm((prev) => ({
      ...prev,
      strikerId: prev.strikerId || firstStriker,
      nonStrikerId: prev.nonStrikerId || firstNonStriker,
      bowlerId: prev.bowlerId || firstBowler,
      dismissedPlayerId: prev.dismissedPlayerId || firstStriker
    }));
  }, [battingTeam?.id, bowlingTeam?.id]);

  useEffect(() => {
    if (!scoreboard?.currentState) {
      return;
    }

    /*
     * OFFLINE LOCAL STATE GUARD
     * -------------------------
     * When there are local unsynced actions, the current striker,
     * non-striker and bowler in ballForm must NOT be replaced by a cached
     * server snapshot. That was causing Setup Next Delivery to reopen
     * intermittently during the 2nd innings.
     */
    if (
      offlineSyncState?.online === false ||
      Number(offlineSyncState?.pending || 0) > 0
    ) {
      return;
    }

    setBallForm((prev) => ({
      ...prev,

      inningsNo:
        scoreboard?.currentInnings != null
          ? String(scoreboard.currentInnings)
          : prev.inningsNo,

      strikerId:
        scoreboard?.currentState?.strikerId != null
          ? String(scoreboard.currentState.strikerId)
          : prev.strikerId,

      nonStrikerId:
        scoreboard?.currentState?.nonStrikerId != null
          ? String(scoreboard.currentState.nonStrikerId)
          : prev.nonStrikerId,

      dismissedPlayerId:
        scoreboard?.currentState?.strikerId != null
          ? String(scoreboard.currentState.strikerId)
          : prev.dismissedPlayerId,

      bowlerId:
        scoreboard.currentState.bowlerId
          ? String(scoreboard.currentState.bowlerId)
          : prev.bowlerId,

      bowlerName:
        scoreboard.currentState.bowlerId
          ? String(scoreboard.currentState.bowlerName || "")
          : prev.bowlerName,

      newBatterId: ""
    }));
  }, [
    scoreboard?.currentState?.strikerId,
    scoreboard?.currentState?.nonStrikerId,
    scoreboard?.currentState?.bowlerId,
    scoreboard?.currentState?.bowlerName,
    scoreboard?.currentInnings,
    offlineSyncState?.online,
    offlineSyncState?.pending,
  ]);
useEffect(() => {
  if (
    scoreboard?.currentState
      ?.needNewBowler
  ) {
    //alert("Opening bowler popup555");
    setBowlerSearchText("");
    setShowBowlerModal(true);
  }
}, [scoreboard]);

const handleAddTeam = async (e) => {
  e.preventDefault();

  try {


    const response = await fetch("/api/teams", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        name: teamForm.name,
        leagueId: teamForm.leagueId,
      }),
    });

    const data = await response.json();



    if (!response.ok) {
      throw new Error(data.error || "Failed to create team");
    }

 setMessage(`Team "${data.name}" created`);

await loadLeagues();
await loadTeams();

setTeamForm((prev) => ({
  ...prev,
  name: ""
}));

setShowAddTeam(false);

  } catch (error) {
    console.error("Create Team Error:", error);

    setError(error.message);
  }
};

  async function handleDeleteTeam(teamId, teamName) {
    if (!confirm(`Delete team "${teamName}"?`)) {
       return;
    }   

    setMessage("");
    setError("");

    try {
      await api(`/api/teams/${teamId}`, {
        method: "DELETE"
      });
      setMessage("🗑️ Team deleted");
      showToast("success", "🗑️ Team deleted");
      await refreshAll();
    } catch (err) {
      setError(err.message);
    }
  }

const handleAddPlayer = async (e) => {
  e.preventDefault();

  try {
    const response = await fetch(
      "/api/players",
      {
        method: "POST",
        headers: {
          "Content-Type":
            "application/json",
        },
        body: JSON.stringify({
          name: playerForm.name,
          teamId: selectedTeam.id,
        }),
      }
    );

    const data =
      await response.json();

    if (!response.ok) {
      throw new Error(
        data.error ||
          "Failed to add player"
      );
    }

    setMessage(
      `Player "${data.name}" added`
    );

    setPlayerForm({
      name: "",
    });

    setShowPlayerModal(false);

   const updatedLeagues = await loadLeagues();

const refreshedLeague = updatedLeagues.find(
  (l) => l.id === activeLeague.id
);

if (refreshedLeague) {
  selectLeague(refreshedLeague);
}

  } catch (error) {
    setError(error.message);
  }
};

  async function handleDeletePlayer(
    playerId,
    playerName
  ) {
    const privilegedRemoval =
      Boolean(
        isSuperAdmin ||
        activeLeagueRole ===
          "OWNER"
      );

    const confirmationText =
      privilegedRemoval
        ? `Remove player "${playerName}" from the active roster?\n\nIf this player has historical match data, Cric4All will preserve that history and remove the player only from active roster workflows.`
        : `Delete player "${playerName}"?`;

    if (
      !confirm(
        confirmationText
      )
    ) {
      return;
    }

    setMessage("");
    setError("");

    try {
      const result =
        await api(
          `/api/players/${playerId}`,
          {
            method:
              "DELETE",
          }
        );

      await refreshPlayerLists();

      const successMessage =
        result?.archived
          ? "🗑️ Player removed from active roster; historical match data preserved."
          : "🗑️ Player deleted";

      setMessage(
        successMessage
      );

      showToast(
        "success",
        result?.archived
          ? "✅ Player removed from active roster"
          : "✅ Player deleted"
      );

      await refreshAll();
    } catch (err) {
      setError(
        err.message
      );
    }
  }

  async function handleCreateMatch(e) {
    e.preventDefault();
    setMessage("");
    setError("");

    try {
      const match = await api("/api/matches", {
        method: "POST",
 body: JSON.stringify({
  teamAId: Number(matchForm.teamAId),
  teamBId: Number(matchForm.teamBId),
battingFirstTeamId: matchForm.battingFirstTeamId
  ? Number(matchForm.battingFirstTeamId)
  : null,

scheduledAt: matchForm.scheduledAt
  ? new Date(matchForm.scheduledAt).toISOString()
  : null,

venueName:
  matchForm.venueName ||
  "",

venueAddress:
  matchForm.venueAddress ||
  "",

status: "SCHEDULED",

  oversPerInnings: Number(matchForm.oversPerInnings),

  powerplayOversInnings: Number(
    matchForm.powerplayOversInnings
  ),

  maxWicketsPerInnings:
    matchForm.maxWicketsPerInnings
      ? Number(matchForm.maxWicketsPerInnings)
      : null,

  maxOversPerBowler:
    matchForm.maxOversPerBowler
      ? Number(matchForm.maxOversPerBowler)
      : null,
  seriesId: matchForm.seriesId || selectedSeriesId || null,
  teamACaptainId: matchForm.teamACaptainId
  ? Number(matchForm.teamACaptainId)
  : null,

teamBCaptainId: matchForm.teamBCaptainId
  ? Number(matchForm.teamBCaptainId)
  : null,

teamAViceCaptainId: matchForm.teamAViceCaptainId
  ? Number(matchForm.teamAViceCaptainId)
  : null,

teamBViceCaptainId: matchForm.teamBViceCaptainId
  ? Number(matchForm.teamBViceCaptainId)
  : null,

teamAWicketKeeperId: matchForm.teamAWicketKeeperId
  ? Number(matchForm.teamAWicketKeeperId)
  : null,

teamBWicketKeeperId: matchForm.teamBWicketKeeperId
  ? Number(matchForm.teamBWicketKeeperId)
  : null,
})
      });

setMatchForm({
  teamAId: "",
  teamBId: "",
  scheduledAt: "",
  venueName: "",
  venueAddress: "",
  battingFirstTeamId: "",
  oversPerInnings: 20,
  powerplayOversInnings: 6,
  maxWicketsPerInnings: "",
  maxOversPerBowler: "",
  status: "SCHEDULED",
  seriesId: "",
  teamACaptainId: "",
  teamBCaptainId: "",
  teamAViceCaptainId: "",
  teamBViceCaptainId: "",
  teamAWicketKeeperId: "",
  teamBWicketKeeperId: "",
});

const teamA = teams.find(
  (t) => Number(t.id) === Number(match.teamAId)
);

const teamB = teams.find(
  (t) => Number(t.id) === Number(match.teamBId)
);

const created = {
  ...match,
  teamAName: teamA?.name,
  teamBName: teamB?.name,
};

setCreatedMatchInfo(created);

await loadMatches(activeLeagueId);

setShowMatchCreatedModal(true);
setMessage("");
setError("");

showToast?.("success", "✅ Match created successfully.");
    } catch (err) {
      setError(err.message);
    }
  }

function dispatchLeagueMatchAlert(
  matchId,
  alertType
) {
  const numericMatchId =
    Number(
      matchId
    );

  if (
    !Number.isInteger(
      numericMatchId
    ) ||
    numericMatchId <= 0
  ) {
    return;
  }

  /*
   * Retention alerts must never block scoring.
   * Delivery is deduplicated again on the server by:
   * userId + matchId + alertType.
   */
  fetch(
    "/api/league-alerts/dispatch",
    {
      method:
        "POST",
      credentials:
        "include",
      headers: {
        "Content-Type":
          "application/json",
      },
      keepalive:
        true,
      body:
        JSON.stringify({
          matchId:
            numericMatchId,
          alertType,
        }),
    }
  ).catch(
    (
      error
    ) => {
      console.warn(
        "[LEAGUE_MATCH_ALERT_DISPATCH_SKIPPED]",
        error
      );
    }
  );
}

async function handleStartMatch(match) {
  if (!match?.id) {
    setError("Match was not found.");
    return;
  }

  try {
    setMessage("");
    setError("");

    const matchId = Number(match.id);

    setSelectedMatchId(String(matchId));
    setEditingMatch(match);
    setStartMatchData({
      matchId: String(matchId),
      battingFirstTeamId:
        match.battingFirstTeamId || match.battingFirstTeam?.id || "",
    });

    const battingFirstTeamId =
      match.battingFirstTeamId || match.battingFirstTeam?.id || "";

    if (!battingFirstTeamId) {
      setShowStartMatchModal(true);
      return;
    }

    await api(`/api/matches/${matchId}/start`, {
      method: "POST",
      body: JSON.stringify({
        battingFirstTeamId: Number(battingFirstTeamId),
      }),
    });

    dispatchLeagueMatchAlert(
      matchId,
      "MATCH_START"
    );

    await loadMatches(activeLeagueId);

    await openScoringAfterBattingFirst(matchId);
  } catch (err) {
    setError(err.message || "Unable to start match.");
  }
}
  
useEffect(() => {
  if (
    !offlineLocalMatchComplete
  ) {
    return;
  }

  const state =
    getOfflineLocalCompletionState(
      scoreboard,
      ballForm?.inningsNo
    );

  if (!state.complete) {
    setOfflineLocalMatchComplete(
      false
    );

    if (
      Number(
        ballForm
          ?.inningsNo
      ) === 2 &&
      state.runsNeeded != null &&
      state.runsNeeded > 0
    ) {
      setError("");
      setMessage(
        `📴 Chase still live · ${state.runsNeeded} run${
          state.runsNeeded === 1
            ? ""
            : "s"
        } needed.`
      );
    }
  }
}, [
  offlineLocalMatchComplete,
  scoreboard,
  ballForm?.inningsNo,
]);

const isMatchCompleted =
  scoreboard?.match?.status ===
  "COMPLETED";

const hasOfflineLocalState =
  offlineSyncState
    ?.online ===
    false ||
  Number(
    offlineSyncState
      ?.pending ||
    0
  ) > 0;

const offlineLocalCompletionState =
  hasOfflineLocalState
    ? getOfflineLocalCompletionState(
        /*
         * At this point in DashboardClient, displayScoreboard has not been
         * declared yet. Offline scoring already writes every optimistic
         * delivery into scoreboard, so scoreboard is the correct source
         * for this early local-completion check.
         */
        scoreboard,
        ballForm
          ?.inningsNo
      )
    : {
        complete:
          false,
      };

const isOfflineMatchCompleted =
  Boolean(
    offlineLocalMatchComplete &&
    offlineLocalCompletionState
      .complete
  );

const isEffectiveMatchCompleted =
  isMatchCompleted ||
  isOfflineMatchCompleted;
const isMatchLocked = scoreboard?.match?.status ===  "COMPLETED_LOCKED";
const isMatchCorrected = scoreboard?.match?.status ===  "COMPLETED_CORRECTED";
const isMatchAbandoned = scoreboard?.match?.status ===  "ABANDONED";

  async function handleDeleteMatch(matchId) {
    if (!confirm("Delete this match and all its scoring data?")) return;

    setMessage("");
    setError("");

    try {
      await api(`/api/matches/${matchId}`, {
        method: "DELETE"
      });
      setMessage("🗑️ Match deleted");
      showToast("success", "🗑️ Match deleted");
      await refreshAll();
    } catch (err) {
      setError(err.message);
    }
  }

  async function handleUndoBall() {
    if (undoSaving) {
      return;
    }

    setMessage("");
    setError("");

    if (!selectedMatchId) {
      setError("Please select a match");
      return;
    }

    setUndoSaving(true);

    try {
      /*
       * If the newest delivery exists only in the offline queue, undo it
       * locally. Do not call the server because the server has never seen it.
       */
      const pendingOfflineBall = await getLastPendingOfflineBall(selectedMatchId).catch(() => null);

      if (pendingOfflineBall) {
        await removeOfflineBall(pendingOfflineBall.clientEventId);

        if (pendingOfflineBall.boardBefore) {
          setScoreboard(pendingOfflineBall.boardBefore);
          await cacheOfflineMatchSnapshot(selectedMatchId, {
            scoreboard: pendingOfflineBall.boardBefore,
            matchDetail: matchDetail || null,
          }).catch(() => {});
        }

        if (pendingOfflineBall.ballFormBefore) {
          setBallForm(pendingOfflineBall.ballFormBefore);
        }

        setOptimisticScoreboard(null);
        setOfflineLocalMatchComplete(false);
        const pending = await refreshOfflinePendingCount(selectedMatchId);
        setMessage(
          `↩️ Offline delivery removed · ${pending} change${pending === 1 ? "" : "s"} still waiting to sync.`
        );
        return;
      }

      if (
        (
          typeof navigator !== "undefined" &&
          navigator.onLine === false
        ) ||
        Boolean(offlineSyncState?.conflict)
      ) {
        /*
         * There is no pending local ball, so the last visible delivery is
         * already on the server.
         *
         * Offline Undo is still safe when we have the exact pre-delivery
         * snapshot captured when that server ball was scored.
         */
        const undoSnapshot =
          await getOfflineServerUndoSnapshot(
            selectedMatchId
          ).catch(
            () => null
          );

        if (
          !undoSnapshot
            ?.boardBefore ||
          !undoSnapshot
            ?.ballFormBefore
        ) {
          setError(
            "This server delivery was loaded before offline Undo history was available. Reconnect once, then future deliveries can be undone offline."
          );

          return;
        }

        const inningsNo =
          Number(
            undoSnapshot
              .inningsNo ||
            ballForm
              ?.inningsNo ||
            1
          );

        const expectedServerSequence =
          Number(
            undoSnapshot
              .serverSequenceAfter ||
            0
          );

        const currentKnownSequence =
          Number(
            offlineServerSequencesRef
              .current
              ?.[inningsNo] ??
            scoreboard
              ?.sync
              ?.serverSequences
              ?.[inningsNo] ??
            scoreboard
              ?.sync
              ?.serverSequences
              ?.[String(
                inningsNo
              )] ??
            expectedServerSequence
          );

        if (
          expectedServerSequence >
            0 &&
          currentKnownSequence >
            0 &&
          currentKnownSequence !==
            expectedServerSequence
        ) {
          setError(
            "Offline Undo snapshot does not match the latest known server delivery. Reconnect before undoing to avoid removing the wrong ball."
          );

          return;
        }

        await queueOfflineServerUndo({
          matchId:
            Number(
              selectedMatchId
            ),

          inningsNo,

          serverSequenceBefore:
            Number(
              undoSnapshot
                .serverSequenceBefore ||
              Math.max(
                expectedServerSequence -
                  1,
                0
              )
            ),

          serverSequenceAfter:
            expectedServerSequence,

          clientEventId:
            undoSnapshot
              .clientEventId ||
            null,
        });

        setScoreboard(
          undoSnapshot
            .boardBefore
        );

        setBallForm(
          undoSnapshot
            .ballFormBefore
        );

        await cacheOfflineMatchSnapshot(
          selectedMatchId,
          {
            scoreboard:
              undoSnapshot
                .boardBefore,

            matchDetail:
              matchDetail ||
              null,

            ballForm:
              undoSnapshot
                .ballFormBefore,

            savedAt:
              new Date()
                .toISOString(),
          }
        ).catch(
          () => {}
        );

        /*
         * New offline balls scored AFTER this undo must branch from the
         * server position that will exist once the queued undo is replayed.
         */
        offlineServerSequencesRef.current = {
          ...offlineServerSequencesRef
            .current,

          matchId:
            Number(
              selectedMatchId
            ),

          [inningsNo]:
            Number(
              undoSnapshot
                .serverSequenceBefore ||
              0
            ),
        };

        setOptimisticScoreboard(
          null
        );

        setOfflineLocalMatchComplete(
          false
        );

        setShowWicketModal(
          false
        );

        setShowRetiredHurtModal(
          false
        );

        setShowBowlerModal(
          false
        );

        setMustChangeBowler(
          false
        );

        setPendingBallData(
          null
        );

        setWicketSubmissionInFlight(
          false
        );

        const pending =
          await refreshOfflinePendingCount(
            selectedMatchId
          );

        setError(
          ""
        );

        setMessage(
          `↩️ Server delivery undone locally · ${pending} change${
            pending === 1
              ? ""
              : "s"
          } waiting to sync.`
        );

        return;
      }

      const undoResult =
        await api(
          `/api/matches/${selectedMatchId}/undo`,
          {
            method:
              "POST",
          }
        );

      const updatedBoard =
        await api(
          `/api/scoreboard/${selectedMatchId}`
        );

      setScoreboard(
        updatedBoard
      );

      /*
       * CRITICAL ONLINE-UNDO / OFFLINE-SYNC FIX
       * ----------------------------------------
       * A successful server Undo rewinds the authoritative ball sequence.
       * Keep the offline sequence reference synchronized with the freshly
       * reloaded server scoreboard; otherwise the next delivery can be sent
       * with a stale expectedPreviousSequence and create a false sync conflict
       * even though this device is still online.
       */
      offlineServerSequencesRef.current = {
        matchId:
          Number(
            selectedMatchId
          ),

        1:
          Number(
            updatedBoard
              ?.sync
              ?.serverSequences
              ?.[1] ??
            updatedBoard
              ?.sync
              ?.serverSequences
              ?.["1"] ??
            0
          ),

        2:
          Number(
            updatedBoard
              ?.sync
              ?.serverSequences
              ?.[2] ??
            updatedBoard
              ?.sync
              ?.serverSequences
              ?.["2"] ??
            0
          ),
      };

      /*
       * Reaching this point proves that both the server Undo and the
       * authoritative scoreboard reload succeeded. Clear only stale sync
       * warning state so an ordinary online Undo cannot leave Scorer Mode
       * presenting itself as offline / needing Retry Sync.
       */
      setOfflineSyncState(
        (
          previous
        ) => ({
          ...previous,

          online:
            typeof navigator === "undefined"
              ? true
              : navigator.onLine,

          conflict:
            null,

          lastError:
            "",
        })
      );

      const restoredState =
        undoResult?.restoredState ||
        updatedBoard?.currentState ||
        {};

      setBallForm(
        (
          previous
        ) => ({
          ...previous,

          inningsNo:
            restoredState.inningsNo ??
            updatedBoard
              ?.currentState
              ?.inningsNo ??
            previous.inningsNo,

          strikerId:
            restoredState.strikerId ??
            updatedBoard
              ?.currentState
              ?.strikerId ??
            previous.strikerId,

          nonStrikerId:
            restoredState.nonStrikerId ??
            updatedBoard
              ?.currentState
              ?.nonStrikerId ??
            previous.nonStrikerId,

          /*
           * When the undone delivery was 4.1, this is the bowler that
           * had already been selected for over 4.
           */
          bowlerId:
            restoredState.bowlerId ??
            updatedBoard
              ?.currentState
              ?.bowlerId ??
            previous.bowlerId,

          runsOffBat:
            "0",

          extras:
            "0",

          extraType:
            "NONE",

          isWicket:
            false,

          wicketType:
            "NONE",

          dismissedPlayerId:
            "",

          newBatterId:
            "",

          fielderId:
            "",

          assistantFielderId:
            "",

          wicketNote:
            "",
        })
      );

      /*
       * Undo is a rewind operation. Any delivery-specific modal state
       * from the removed ball must be discarded.
       */
      setShowWicketModal(
        false
      );

      setShowRetiredHurtModal(
        false
      );

      setRunOutRuns(
        null
      );

      setEndInningsAfterWicket(
        false
      );

      setPendingBallData(
        null
      );

      setWicketSubmissionInFlight(
        false
      );

      if (
        undoResult
          ?.preserveBowlerSelection
      ) {
        /*
         * The first ball of a new over was removed. Keep the selected
         * new-over bowler and do not request Change Bowler again.
         */
        setMustChangeBowler(
          false
        );

        setShowBowlerModal(
          false
        );

        setMessage(
          "↩️ First ball of the over removed. The selected bowler has been preserved."
        );
      } else {
        /*
         * If the removed ball was the last ball of an over, the match is
         * now back before over completion. Do not show Change Bowler until
         * that final ball is scored again.
         */
        setMustChangeBowler(
          false
        );

        setShowBowlerModal(
          false
        );

        setMessage(
          "↩️ Last ball removed"
        );
      }

      setOptimisticScoreboard(
        null
      );

      await clearOfflineServerUndoSnapshot(
        selectedMatchId
      ).catch(
        () => {}
      );

      void api(
        "/api/milestones/reconcile",
        {
          method:
            "POST",

          body:
            JSON.stringify({
              matchId:
                Number(
                  selectedMatchId
                ),
            }),
        }
      ).catch(
        (
          milestoneError
        ) => {
          console.error(
            "[UNDO_MILESTONE_RECONCILE_FAILED]",
            milestoneError
          );
        }
      );
    } catch (err) {
      setError(
        err.message
      );
    } finally {
      setUndoSaving(
        false
      );
    }
  }

  const battingByTeam = stats?.batting.reduce((acc, row) => {
    if (!acc[row.teamName]) acc[row.teamName] = [];
    acc[row.teamName].push(row);
    return acc;
  }, {});

  const bowlingByTeam = stats?.bowling.reduce((acc, row) => {
    if (!acc[row.teamName]) acc[row.teamName] = [];
    acc[row.teamName].push(row);
    return acc;
  }, {});
async function handleEndFirstInnings() {
  if (!selectedMatchId) {
    return;
  }

  const confirmed =
    window.confirm(
      "End 1st innings and start 2nd innings setup?\n\nUse this when the batting side is finished before all scheduled overs are bowled."
    );

  if (!confirmed) {
    return;
  }

  const numericMatchId =
    Number(
      selectedMatchId
    );

  /*
   * Move the LOCAL scoring state into innings 2 without changing any
   * server score. This is used by the true-offline path and by the
   * connection-loss race fallback.
   */
  const moveToSecondInningsLocally =
    async () => {
      const localBoard =
        scoreboard
          ? (
              typeof structuredClone ===
              "function"
                ? structuredClone(
                    scoreboard
                  )
                : JSON.parse(
                    JSON.stringify(
                      scoreboard
                    )
                  )
            )
          : null;

      if (localBoard) {
        localBoard.currentInnings =
          2;

        localBoard.currentState = {
          ...(localBoard
            .currentState ||
            {}),

          inningsNo:
            2,

          /*
           * NEW INNINGS PLAYER STATE
           * ------------------------
           * Never carry Team 1's active-player presentation into innings 2.
           *
           * Previously we cleared only the IDs. The old names and stat
           * objects remained on currentState, so after selecting the new
           * innings-2 striker/non-striker/bowler their NAMES changed but:
           *
           *   strikerStats
           *   nonStrikerStats
           *   bowlerStats
           *
           * still belonged to innings 1.
           */
          strikerId:
            null,

          strikerName:
            "",

          strikerStats:
            null,

          nonStrikerId:
            null,

          nonStrikerName:
            "",

          nonStrikerStats:
            null,

          bowlerId:
            null,

          bowlerName:
            "",

          bowlerStats:
            null,

          legalBalls:
            Number(
              localBoard
                ?.innings
                ?.[1]
                ?.legalBalls ||
              0
            ),
        };

        setScoreboard(
          localBoard
        );

        await cacheOfflineMatchSnapshot(
          numericMatchId,
          {
            scoreboard:
              localBoard,

            matchDetail:
              matchDetail ||
              null,

            ballForm: {
              ...ballForm,

              inningsNo:
                2,

              strikerId:
                "",

              nonStrikerId:
                "",

              bowlerId:
                "",
            },

            savedAt:
              new Date()
                .toISOString(),
          }
        ).catch(
          (
            cacheError
          ) => {
            console.warn(
              "[OFFLINE_END_INNINGS_CACHE_FAILED]",
              cacheError
            );
          }
        );
      }

      setPendingSecondInningsSetup(
        true
      );

      setBallForm(
        (
          previous
        ) => ({
          ...previous,

          inningsNo:
            "2",

          strikerId:
            "",

          nonStrikerId:
            "",

          bowlerId:
            "",
        })
      );

      setDeliverySetupReason(
        "🏏 1st innings ended locally. Select the opening striker, non-striker, and bowler for the 2nd innings. Cric4All will synchronize the innings transition automatically when the connection returns."
      );

      setShowDeliverySetupModal(
        true
      );
    };

  const queueTransitionLocally =
    async () => {
      const existingTransition =
        await getPendingOfflineInningsTransition(
          numericMatchId
        ).catch(
          () => null
        );

      if (!existingTransition) {
        await queueOfflineInningsTransition({
          matchId:
            numericMatchId,

          fromInnings:
            1,

          toInnings:
            2,

          /*
           * The transition must be replayed after every queued innings-1
           * ball and before the first queued innings-2 ball.
           */
          afterSequence:
            Number(
              offlineServerSequencesRef
                .current
                ?.[1] ||
              scoreboard
                ?.innings
                ?.[0]
                ?.lastSequence ||
              scoreboard
                ?.currentState
                ?.lastSequence ||
              0
            ),

          localOrder:
            Date.now() * 1000 +
            Math.floor(
              Math.random() * 999
            ),
        });
      }

      await moveToSecondInningsLocally();

      setOfflineSyncState(
        (
          previous
        ) => ({
          ...previous,

          online:
            false,

          syncing:
            false,

          conflict:
            null,
        })
      );

      const pending =
        await refreshOfflinePendingCount(
          numericMatchId
        );

      setError(
        ""
      );

      setMessage(
        `📴 First innings ended locally · ${pending} change${
          pending === 1
            ? ""
            : "s"
        } waiting to sync. Set up the 2nd innings and continue scoring.`
      );
    };

  try {
    const browserIsOffline =
      typeof navigator !==
        "undefined" &&
      navigator.onLine ===
        false;

    const appIsOffline =
      offlineSyncState?.online === false ||
      Boolean(offlineSyncState?.conflict);

    if (
      browserIsOffline ||
      appIsOffline
    ) {
      await queueTransitionLocally();
      return;
    }

    /*
     * ONLINE PATH:
     * Preserve the existing server behavior exactly.
     */
    await api(
      `/api/matches/${numericMatchId}/end-innings`,
      {
        method:
          "POST",
      }
    );

    await loadSelectedMatch(
      numericMatchId
    );

    setPendingSecondInningsSetup(
      true
    );

    setBallForm(
      (
        previous
      ) => ({
        ...previous,

        inningsNo:
          "2",

        strikerId:
          "",

        nonStrikerId:
          "",

        bowlerId:
          "",
      })
    );

    setDeliverySetupReason(
      "🏏 2nd innings is ready. Select the opening striker, non-striker, and bowler before scoring."
    );

    setShowDeliverySetupModal(
      true
    );

    setMessage(
      "✅ First innings ended. Set up the 2nd innings."
    );
  } catch (err) {
    /*
     * Race-condition safety:
     * If connectivity disappears after the online check but before the
     * request completes, convert the action into a queued offline innings
     * transition instead of leaving the scorer stuck in innings 1.
     */
    if (
      isOfflineRetryableError(
        err
      )
    ) {
      try {
        await queueTransitionLocally();
        return;
      } catch (
        queueError
      ) {
        console.error(
          "[OFFLINE_END_INNINGS_QUEUE_FAILED]",
          queueError
        );
      }
    }

    setError(
      err.message
    );
  }
}

  async function quickNormalBall(runs) {
  
  try{  
    await submitBall({
    matchId: Number(selectedMatchId),
    inningsNo: Number(ballForm.inningsNo),
    strikerId: Number(ballForm.strikerId),
    nonStrikerId: Number(ballForm.nonStrikerId),
    bowlerId: Number(ballForm.bowlerId),
    extraType: "NONE",
    runsOffBat: runs,
    extras: 0,
    isWicket: 0,
    wicketType: "NONE",
    dismissedPlayerId: null,
    newBatterId: null
  });

    if (runs === 0) {
      setMessage("🟢 Dot ball recorded.");
    } else if (runs === 4) {
      setMessage("🔥 FOUR! Ball recorded and 4 runs added.");
    } else if (runs === 6) {
      setMessage("🚀 SIX! Ball recorded and 6 runs added.");
    } else {
      setMessage(
        `🏏 Ball recorded • ${runs} run${runs > 1 ? "s" : ""} added to the total.`
      );
    }
  } catch (err) {
    setError(err.message);
  }  
}

async function handleAddBall(e) {
  e?.preventDefault();
  try {
  await submitBall({
    matchId: Number(selectedMatchId),
    inningsNo: Number(ballForm.inningsNo),
    strikerId: Number(ballForm.strikerId),
    nonStrikerId: Number(ballForm.nonStrikerId),
    bowlerId: Number(ballForm.bowlerId),
    extraType: ballForm.extraType,
    runsOffBat: Number(ballForm.runsOffBat),
    extras: Number(ballForm.extras),
    isWicket: ballForm.isWicket && ballForm.wicketType !== "RETIRED_HURT"? 1 : 0,
    wicketType: ballForm.isWicket? ballForm.wicketType: "NONE",
    dismissedPlayerId: ballForm.isWicket
            ? Number(ballForm.dismissedPlayerId || ballForm.strikerId)
            : null,
    newBatterId:
            ballForm.isWicket && ballForm.newBatterId
              ? Number(ballForm.newBatterId)
              : null,
    note: ballForm.note,
    matchStatus: scoreboard.match.status,
    fielderId: ballForm.fielderId
  ? Number(ballForm.fielderId)
  : null,

assistantFielderId: ballForm.assistantFielderId
  ? Number(ballForm.assistantFielderId)
  : null,

wicketNote: ballForm.wicketNote || null
  });
    return true;
  } catch (error) {
    console.error("Add ball failed:", error);
    setError("Failed to add delivery.");
    return false;
  }
}


async function handleScorerSignOut() {
  setShowScorerAccountMenu(false);
  setScorerDrawer(null);
  setScorerMode(false);

  await signOut({
    callbackUrl: "/",
  });
}

function getOfflineStatusLabel() {
  if (offlineSyncState.conflict) {
    return `🔴 Sync paused · ${offlineSyncState.pending} waiting · scoring locally`;
  }

  if (offlineSyncState.syncing) {
    return `🔵 Syncing · ${offlineSyncState.pending} waiting`;
  }

  if (!offlineSyncState.online) {
    return `🟠 Offline · ${offlineSyncState.pending} waiting`;
  }

  if (offlineSyncState.pending > 0) {
    return `🟡 Online · ${offlineSyncState.pending} waiting`;
  }

  return "🟢 Online · Synced";
}

async function refreshOfflinePendingCount(matchId = selectedMatchId) {
  if (!matchId) return 0;

  const [
    pendingBalls,
    pendingKeeperChanges,
    pendingInningsTransitions,
    pendingStrikeSwaps,
    pendingServerUndo,
  ] = await Promise.all([
    getPendingOfflineBallCount(
      matchId
    ).catch(() => 0),

    getPendingOfflineKeeperChangeCount(
      matchId
    ).catch(() => 0),

    getPendingOfflineInningsTransitionCount(
      matchId
    ).catch(() => 0),

    getPendingOfflineStrikeSwapCount(
      matchId
    ).catch(() => 0),

    getPendingOfflineServerUndoCount(
      matchId
    ).catch(() => 0),
  ]);

  const pending =
    Number(pendingBalls || 0) +
    Number(
      pendingKeeperChanges ||
      0
    ) +
    Number(
      pendingInningsTransitions ||
      0
    ) +
    Number(
      pendingStrikeSwaps ||
      0
    ) +
    Number(
      pendingServerUndo ||
      0
    );

  setOfflineSyncState(
    (previous) => ({
      ...previous,
      pending,
    })
  );

  return pending;
}

function getOfflineLocalCompletionState(
  board,
  inningsNoValue
) {
  const inningsNo =
    Number(
      inningsNoValue ||
      board?.currentInnings ||
      1
    );

  const innings =
    board
      ?.innings
      ?.[inningsNo - 1] ||
    {};

  const oversPerInnings =
    Number(
      board
        ?.match
        ?.oversPerInnings ||
      matchDetail
        ?.oversPerInnings ||
      0
    );

  const maxLegalBalls =
    oversPerInnings > 0
      ? oversPerInnings * 6
      : 0;

  const maxWickets =
    Number(
      board
        ?.match
        ?.maxWicketsPerInnings ??
      matchDetail
        ?.maxWicketsPerInnings ??
      0
    );

  const legalBalls =
    Number(
      innings
        ?.legalBalls ||
      0
    );

  const wickets =
    Number(
      innings
        ?.wickets ||
      0
    );

  const currentRuns =
    Number(
      innings
        ?.runs ||
      0
    );

  /*
   * For offline scoring, prefer the local first-innings total for the
   * chase target. scoreboard.summary.target can still be a server-era
   * snapshot when innings 1 itself contains unsynced local balls.
   */
  const firstInningsRuns =
    Number(
      board
        ?.innings
        ?.[0]
        ?.runs ||
      0
    );

  const localTarget =
    firstInningsRuns >= 0
      ? firstInningsRuns + 1
      : Number(
          board
            ?.summary
            ?.target ||
          0
        );

  const targetReached =
    inningsNo === 2 &&
    localTarget > 0 &&
    currentRuns >=
      localTarget;

  const oversFinished =
    inningsNo === 2 &&
    maxLegalBalls > 0 &&
    legalBalls >=
      maxLegalBalls;

  const wicketsFinished =
    inningsNo === 2 &&
    maxWickets > 0 &&
    wickets >=
      maxWickets;

  return {
    complete:
      targetReached ||
      oversFinished ||
      wicketsFinished,

    targetReached,
    oversFinished,
    wicketsFinished,
    target:
      localTarget,
    runs:
      currentRuns,
    runsNeeded:
      inningsNo === 2 &&
      localTarget > 0
        ? Math.max(
            localTarget -
              currentRuns,
            0
          )
        : null,
    legalBalls,
    maxLegalBalls,
    wickets,
    maxWickets,
  };
}

function getLocalBallEnvelope(board, data) {
  const inningsNo = Number(data.inningsNo || board?.currentInnings || 1);
  const innings = board?.innings?.[inningsNo - 1] || {};
  const legalBallsBefore = Number(innings.legalBalls || 0);
  const legalDelivery = isLegalDelivery(data.extraType, data.wicketType);
  const ballInOver = (legalBallsBefore % 6) + 1;
  const overNo = Math.floor(legalBallsBefore / 6);

  return {
    ...data,
    inningsNo,
    legalDelivery,
    ballInOver,
    overNo,
    totalRuns: Number(data.runsOffBat || 0) + Number(data.extras || 0),
    isWicket:
      Number(data.isWicket) && data.wicketType !== "RETIRED_HURT"
        ? 1
        : 0,
  };
}

async function applyQueuedBallLocally({ data, previewBoard, event }) {
  const localBall = getLocalBallEnvelope(scoreboard, data);

  /*
   * previewScoreboardAfterBall() already runs the same applyBallOutcome()
   * logic and updates previewBoard.currentState. Use THAT exact state for the
   * next delivery instead of calculating a second independent copy.
   *
   * This keeps striker/non-striker rotation and end-of-over swaps perfectly
   * aligned with the locally displayed scoreboard.
   */
  const localCurrentState =
    previewBoard?.currentState || {};

  setScoreboard(previewBoard);
  setOptimisticScoreboard(null);
  setInstantDeliveryStatus("");
  setShowAdvancedSheet(false);

  const nextBallForm = {
    ...ballForm,
    inningsNo: Number(data.inningsNo),

    strikerId:
      localCurrentState.strikerId ??
      data.strikerId ??
      ballForm.strikerId,

    nonStrikerId:
      localCurrentState.nonStrikerId ??
      data.nonStrikerId ??
      ballForm.nonStrikerId,

    bowlerId:
      localCurrentState.bowlerId ??
      data.bowlerId ??
      ballForm.bowlerId,
    extraType: "NONE",
    runsOffBat: "0",
    extras: "0",
    isWicket: false,
    wicketType: "NONE",
    newBatterId: "",
    dismissedPlayerId: "",
    note: "",
    dismissal: "",
    fielderId: "",
    assistantFielderId: "",
    wicketNote: "",
  };

  setBallForm(nextBallForm);

  await cacheOfflineMatchSnapshot(selectedMatchId, {
    scoreboard: previewBoard,
    matchDetail: matchDetail || null,
    ballForm: nextBallForm,
    savedAt: new Date().toISOString(),
  }).catch(() => {});

  const pending = await refreshOfflinePendingCount(selectedMatchId);

  const innings = previewBoard?.innings?.[Number(data.inningsNo) - 1] || {};
  const maxLegalBalls = Number(previewBoard?.match?.oversPerInnings || 0) * 6;
  const maxWickets = Number(previewBoard?.match?.maxWicketsPerInnings || 0);
  const inningsEndedByOvers = maxLegalBalls > 0 && Number(innings.legalBalls || 0) >= maxLegalBalls;
  const inningsEndedByWickets = maxWickets > 0 && Number(innings.wickets || 0) >= maxWickets;
  const localCompletion =
    getOfflineLocalCompletionState(
      previewBoard,
      data.inningsNo
    );

  const targetReached =
    localCompletion
      .targetReached;

  const inningsEnded =
    inningsEndedByOvers ||
    inningsEndedByWickets ||
    Boolean(
      data
        .endInningsAfterWicket
    );

  if (Number(data.inningsNo) === 1 && inningsEnded) {
    /*
     * Move the LOCAL scoreboard into innings 2 as well. Without this, the
     * delivery setup would say innings 2 while the cached board still looked
     * like innings 1. The server will make the identical transition when the
     * queued first-innings final ball is replayed.
     */
    const localSecondInningsBoard =
      typeof structuredClone === "function"
        ? structuredClone(previewBoard)
        : JSON.parse(JSON.stringify(previewBoard));

    localSecondInningsBoard.currentInnings = 2;
    localSecondInningsBoard.currentState = {
      inningsNo: 2,
      strikerId: null,
      nonStrikerId: null,
      bowlerId: null,
      legalBalls: Number(localSecondInningsBoard?.innings?.[1]?.legalBalls || 0),
    };

    setScoreboard(localSecondInningsBoard);
    await cacheOfflineMatchSnapshot(selectedMatchId, {
      scoreboard: localSecondInningsBoard,
      matchDetail: matchDetail || null,
    }).catch(() => {});

    setPendingSecondInningsSetup(true);
    setBallForm((previous) => ({
      ...previous,
      inningsNo: 2,
      strikerId: "",
      nonStrikerId: "",
      bowlerId: "",
    }));
    setDeliverySetupReason(
      "🏏 1st innings completed locally. Setup the 2nd innings. Cric4All will sync both innings in order when the connection returns."
    );
    window.setTimeout(() => setShowDeliverySetupModal(true), 100);
  }

  if (
    Number(
      data.inningsNo
    ) === 2 &&
    localCompletion.complete
  ) {
    setOfflineLocalMatchComplete(
      true
    );

    const completionReason =
      localCompletion
        .targetReached
        ? "target reached"
        : localCompletion
            .oversFinished
          ? "scheduled overs completed"
          : "maximum wickets reached";

    const localResult =
      buildOfflineLocalResultText(
        previewBoard,
        buildLiveMatchCenter(
          previewBoard,
          true,
          dlsState
        )
      );

    setMessage(
      `🏁 ${
        localResult ||
        `Match completed locally (${completionReason})`
      } · ${pending} change${
        pending === 1
          ? ""
          : "s"
      } waiting to sync. Reconnect before locking/finalizing the match.`
    );

    return true;
  }

  /*
   * Never allow a stale local-complete flag from an earlier preview to
   * freeze a chase that is still live.
   */
  if (
    Number(
      data.inningsNo
    ) === 2 &&
    !localCompletion.complete
  ) {
    setOfflineLocalMatchComplete(
      false
    );
  }

  if (localBall.legalDelivery && Number(localBall.ballInOver) === 6) {
    setShowWicketModal(false);
    setWicketSubmissionInFlight(false);
    setPendingBallData(null);
    setMustChangeBowler(true);
    setBowlerSearchText("");
    window.setTimeout(() => setShowBowlerModal(true), 0);
  }

  setMessage(
    `📴 Delivery saved offline · ${pending} change${pending === 1 ? "" : "s"} waiting to sync.`
  );

  return true;
}

async function syncPendingOfflineBalls(matchId = selectedMatchId) {
  const numericMatchId = Number(matchId);
  if (!numericMatchId || offlineSyncRunningRef.current) return;

  if (
    typeof navigator !== "undefined" &&
    navigator.onLine === false
  ) {
    setOfflineSyncState((previous) => ({
      ...previous,
      online: false,
      syncing: false,
    }));

    return;
  }

  const [
    pendingEvents,
    pendingKeeperChanges,
    pendingInningsTransition,
    pendingStrikeSwaps,
    pendingServerUndo,
  ] = await Promise.all([
    listPendingOfflineBalls(
      numericMatchId
    ).catch(() => []),

    listPendingOfflineKeeperChanges(
      numericMatchId
    ).catch(() => []),

    getPendingOfflineInningsTransition(
      numericMatchId
    ).catch(() => null),

    listPendingOfflineStrikeSwaps(
      numericMatchId
    ).catch(() => []),

    getPendingOfflineServerUndo(
      numericMatchId
    ).catch(() => null),
  ]);

  const totalPending =
    pendingEvents.length +
    pendingKeeperChanges.length +
    (
      pendingInningsTransition
        ? 1
        : 0
    ) +
    pendingStrikeSwaps.length +
    (
      pendingServerUndo
        ? 1
        : 0
    );

  if (!totalPending) {
    setOfflineSyncState(
      (previous) => ({
        ...previous,
        online: true,
        pending: 0,
        syncing: false,
        conflict: null,
      })
    );
    return;
  }

  /*
   * QUEUED OFFLINE SERVER UNDO
   * ==========================
   * This action must run BEFORE sequence reconciliation and before any balls
   * scored locally after the undo.
   *
   * Lost-response safety:
   * - server == sequenceAfter  -> undo still needs to be applied
   * - server == sequenceBefore -> undo was already applied; just clear queue
   * - anything else            -> stop safely
   */
  if (
    pendingServerUndo
  ) {
    let undoBoard;

    try {
      undoBoard =
        await api(
          `/api/scoreboard/${numericMatchId}`
        );
    } catch (
      undoReadError
    ) {
      if (
        isOfflineRetryableError(
          undoReadError
        )
      ) {
        setOfflineSyncState(
          (
            previous
          ) => ({
            ...previous,

            online:
              false,

            syncing:
              false,

            lastError:
              "Undo sync paused until the connection is stable.",
          })
        );

        return;
      }

      throw undoReadError;
    }

    const undoInningsNo =
      Number(
        pendingServerUndo
          .inningsNo ||
        1
      );

    const currentSequence =
      Number(
        undoBoard
          ?.sync
          ?.serverSequences
          ?.[undoInningsNo] ??
        undoBoard
          ?.sync
          ?.serverSequences
          ?.[String(
            undoInningsNo
          )] ??
        0
      );

    const sequenceAfter =
      Number(
        pendingServerUndo
          .serverSequenceAfter ||
        0
      );

    const sequenceBefore =
      Number(
        pendingServerUndo
          .serverSequenceBefore ||
        Math.max(
          sequenceAfter -
            1,
          0
        )
      );

    if (
      currentSequence ===
      sequenceAfter
    ) {
      try {
        await api(
          `/api/matches/${numericMatchId}/undo`,
          {
            method:
              "POST",
          }
        );
      } catch (
        undoSyncError
      ) {
        if (
          isOfflineRetryableError(
            undoSyncError
          )
        ) {
          setOfflineSyncState(
            (
              previous
            ) => ({
              ...previous,

              online:
                false,

              syncing:
                false,

              lastError:
                "Undo sync paused until the connection is stable.",
            })
          );

          return;
        }

        setOfflineSyncState(
          (
            previous
          ) => ({
            ...previous,

            syncing:
              false,

            conflict: {
              message:
                undoSyncError
                  .message ||
                "The queued offline undo could not be applied safely.",
            },

            lastError:
              undoSyncError
                .message ||
              "The queued offline undo could not be applied safely.",
          })
        );

        setError(
          `Offline sync stopped: ${
            undoSyncError
              .message ||
            "queued Undo requires review."
          }`
        );

        return;
      }
    } else if (
      currentSequence !==
      sequenceBefore
    ) {
      const conflictMessage =
        `Queued Undo expected server sequence ${sequenceAfter} (or ${sequenceBefore} if already applied), but server is at ${currentSequence}.`;

      setOfflineSyncState(
        (
          previous
        ) => ({
          ...previous,

          syncing:
            false,

          conflict: {
            message:
              conflictMessage,

            expectedPreviousSequence:
              sequenceAfter,

            serverSequence:
              currentSequence,

            inningsNo:
              undoInningsNo,
          },

          lastError:
            conflictMessage,
        })
      );

      setError(
        "Offline sync conflict: queued Undo no longer matches the server. No local scoring changes were discarded."
      );

      return;
    }

    await removeOfflineServerUndo(
      numericMatchId
    );

    await clearOfflineServerUndoSnapshot(
      numericMatchId
    ).catch(
      () => {}
    );

    setOfflineSyncState(
      (
        previous
      ) => ({
        ...previous,

        pending:
          Math.max(
            0,
            Number(
              previous.pending ||
              totalPending
            ) -
              1
          ),
      })
    );
  }

  /*
   * SEQUENCE RECONCILIATION
   * =======================
   * expectedPreviousSequence stored on an individual offline event is a
   * convenience value, not the authoritative branch point.
   *
   * Example that caused the user's false conflict:
   *   stored expectedPreviousSequence = 23
   *   actual server sequence          = 21
   *
   * This can happen when local pending events that existed when the event
   * was created are later removed/replaced before reconnect. The server did
   * NOT change; the local expected value simply became stale.
   *
   * We now compare the server against the LOCAL CHAIN'S BASE sequence.
   * Only when the server still equals that base do we safely re-number the
   * pending chain 21 -> 22 -> 23 ... during replay.
   *
   * If the server is AHEAD of the base, another server-side scoring change
   * may exist and we preserve the 409-style safety stop.
   *
   * If the server is BEHIND the base, a server-side undo/correction may have
   * occurred and we also stop rather than silently rewriting history.
   */
  let authoritativeBoard;

  try {
    authoritativeBoard =
      await api(
        `/api/scoreboard/${numericMatchId}`
      );
  } catch (sequenceReadError) {
    if (
      isOfflineRetryableError(
        sequenceReadError
      )
    ) {
      setOfflineSyncState(
        (previous) => ({
          ...previous,
          online:
            false,
          syncing:
            false,
          lastError:
            "Sync paused until the connection is stable.",
        })
      );
      return;
    }

    throw sequenceReadError;
  }

  const authoritativeSequences = {
    1:
      Number(
        authoritativeBoard
          ?.sync
          ?.serverSequences
          ?.[1] ??
        authoritativeBoard
          ?.sync
          ?.serverSequences
          ?.["1"] ??
        0
      ),

    2:
      Number(
        authoritativeBoard
          ?.sync
          ?.serverSequences
          ?.[2] ??
        authoritativeBoard
          ?.sync
          ?.serverSequences
          ?.["2"] ??
        0
      ),
  };

  const eventsByInnings =
    pendingEvents.reduce(
      (
        map,
        event
      ) => {
        const inningsNo =
          Number(
            event
              ?.payload
              ?.inningsNo ||
            event
              ?.inningsNo ||
            1
          );

        if (!map[inningsNo]) {
          map[inningsNo] = [];
        }

        map[inningsNo].push(
          event
        );

        return map;
      },
      {}
    );

  const replaySequenceByInnings = {
    1:
      authoritativeSequences[1],
    2:
      authoritativeSequences[2],
  };

  /*
   * Automatic clientEventId reconciliation.
   *
   * /api/balls checks clientEventId before its sequence guard.
   * Therefore replay can safely start from the current authoritative server
   * sequence:
   *   - event already accepted -> idempotent 200
   *   - stale local expected sequence -> dynamically rebased
   *   - genuine different server change -> 409, sync pauses
   */
  for (const inningsKey of Object.keys(eventsByInnings)) {
    const inningsNo = Number(inningsKey);
    replaySequenceByInnings[inningsNo] =
      Number(authoritativeSequences[inningsNo] || 0);
  }

  offlineSyncRunningRef.current =
    true;

  setOfflineSyncState(
    (previous) => ({
      ...previous,
      online: true,
      syncing: true,
      pending:
        totalPending,
      conflict:
        null,
      lastError:
        "",
    })
  );

  try {
    let synced = 0;
    let syncedKeeperChanges = 0;
    let syncedInningsTransition = 0;
    let syncedStrikeSwaps = 0;
    let inningsTransitionApplied = false;
    let nextStrikeSwapIndex = 0;

    const syncStrikeSwapsBefore =
      async (
        localOrderLimit =
          Number.POSITIVE_INFINITY
      ) => {
        while (
          nextStrikeSwapIndex <
            pendingStrikeSwaps.length &&
          Number(
            pendingStrikeSwaps[
              nextStrikeSwapIndex
            ]?.localOrder ||
            0
          ) <
            Number(
              localOrderLimit
            )
        ) {
          const action =
            pendingStrikeSwaps[
              nextStrikeSwapIndex
            ];

          try {
            await api(
              "/api/events/swap-strike",
              {
                method:
                  "POST",

                body:
                  JSON.stringify({
                    matchId:
                      numericMatchId,

                    inningsNo:
                      action
                        .inningsNo,

                    strikerId:
                      action
                        .strikerId,

                    nonStrikerId:
                      action
                        .nonStrikerId,
                  }),
              }
            );

            await removeOfflineStrikeSwap(
              numericMatchId,
              action
                .clientActionId
            );

            nextStrikeSwapIndex +=
              1;

            syncedStrikeSwaps +=
              1;

            setOfflineSyncState(
              (
                previous
              ) => ({
                ...previous,

                pending:
                  Math.max(
                    0,
                    totalPending -
                      synced -
                      syncedKeeperChanges -
                      syncedInningsTransition -
                      syncedStrikeSwaps
                  ),
              })
            );
          } catch (
            swapSyncError
          ) {
            if (
              isOfflineRetryableError(
                swapSyncError
              )
            ) {
              setOfflineSyncState(
                (
                  previous
                ) => ({
                  ...previous,

                  online:
                    typeof navigator ===
                    "undefined"
                      ? false
                      : navigator
                          .onLine,

                  syncing:
                    false,

                  lastError:
                    swapSyncError
                      .message ||
                    "Strike-swap sync paused until the connection is stable.",
                })
              );

              return false;
            }

            setOfflineSyncState(
              (
                previous
              ) => ({
                ...previous,

                syncing:
                  false,

                conflict: {
                  message:
                    swapSyncError
                      .message ||
                    "A queued strike swap could not be synchronized safely.",
                },

                lastError:
                  swapSyncError
                    .message ||
                  "A queued strike swap could not be synchronized safely.",
              })
            );

            setError(
              `Offline sync stopped: ${
                swapSyncError
                  .message ||
                "strike swap requires review."
              }`
            );

            return false;
          }
        }

        return true;
      };

    const syncQueuedInningsTransition =
      async () => {
        if (
          !pendingInningsTransition ||
          inningsTransitionApplied
        ) {
          return true;
        }

        try {
          await api(
            `/api/matches/${numericMatchId}/end-innings`,
            {
              method:
                "POST",
            }
          );
        } catch (
          transitionError
        ) {
          /*
           * If the original online request reached the server but its
           * response was lost, retry may report that innings 1 is already
           * over. Verify the authoritative scoreboard before treating it
           * as a conflict.
           */
          if (
            !isOfflineRetryableError(
              transitionError
            )
          ) {
            try {
              const serverBoard =
                await api(
                  `/api/scoreboard/${numericMatchId}`
                );

              const serverInnings =
                Number(
                  serverBoard
                    ?.currentInnings ||
                  serverBoard
                    ?.currentState
                    ?.inningsNo ||
                  1
                );

              if (
                serverInnings >=
                2
              ) {
                await removeOfflineInningsTransition(
                  numericMatchId
                );

                inningsTransitionApplied =
                  true;

                syncedInningsTransition =
                  1;

                setOfflineSyncState(
                  (
                    previous
                  ) => ({
                    ...previous,

                    pending:
                      Math.max(
                        0,
                        totalPending -
                          synced -
                          syncedKeeperChanges -
                          syncedInningsTransition
                      ),
                  })
                );

                return true;
              }
            } catch {
              // Fall through to the normal error handling below.
            }
          }

          if (
            isOfflineRetryableError(
              transitionError
            )
          ) {
            setOfflineSyncState(
              (
                previous
              ) => ({
                ...previous,

                online:
                  typeof navigator ===
                  "undefined"
                    ? false
                    : navigator
                        .onLine,

                syncing:
                  false,

                lastError:
                  transitionError
                    .message ||
                  "First-innings sync paused until the connection is stable.",
              })
            );

            return false;
          }

          setOfflineSyncState(
            (
              previous
            ) => ({
              ...previous,

              syncing:
                false,

              conflict: {
                message:
                  transitionError
                    .message ||
                  "The queued first-innings transition could not be synchronized safely.",
              },

              lastError:
                transitionError
                  .message ||
                "The queued first-innings transition could not be synchronized safely.",
            })
          );

          setError(
            `Offline sync stopped: ${
              transitionError
                .message ||
              "first-innings transition requires review."
            }`
          );

          return false;
        }

        await removeOfflineInningsTransition(
          numericMatchId
        );

        inningsTransitionApplied =
          true;

        syncedInningsTransition =
          1;

        setOfflineSyncState(
          (
            previous
          ) => ({
            ...previous,

            pending:
              Math.max(
                0,
                totalPending -
                  synced -
                  syncedKeeperChanges -
                  syncedInningsTransition
              ),
          })
        );

        return true;
      };

    for (const event of pendingEvents) {
      const swapsSynced =
        await syncStrikeSwapsBefore(
          Number(
            event.localOrder ||
            Number.POSITIVE_INFINITY
          )
        );

      if (!swapsSynced) {
        return;
      }

      /*
       * Manual offline End 1st Innings must reach the server AFTER every
       * queued innings-1 delivery and BEFORE the first innings-2 delivery.
       */
      if (
        Number(
          event
            ?.payload
            ?.inningsNo ||
          1
        ) >=
          2 &&
        pendingInningsTransition &&
        !inningsTransitionApplied
      ) {
        const transitionSynced =
          await syncQueuedInningsTransition();

        if (
          !transitionSynced
        ) {
          return;
        }
      }

      try {
        const result = await api("/api/balls", {
          method: "POST",
          body: JSON.stringify({
            ...event.payload,
            clientEventId: event.clientEventId,
            clientDeviceId: event.clientDeviceId,
            clientCreatedAt: event.clientCreatedAt,
            expectedPreviousSequence:
              Number(
                replaySequenceByInnings[
                  Number(
                    event
                      ?.payload
                      ?.inningsNo ||
                    1
                  )
                ] ||
                0
              ),
          }),
        });

        await removeOfflineBall(event.clientEventId);
        synced += 1;

        const inningsNo =
          Number(
            event
              .payload
              ?.inningsNo ||
            1
          );

        const confirmedSequence =
          Number(
            result
              ?.sequence ||
            replaySequenceByInnings[
              inningsNo
            ] +
              1 ||
            0
          );

        replaySequenceByInnings[
          inningsNo
        ] =
          confirmedSequence;

        offlineServerSequencesRef.current = {
          ...offlineServerSequencesRef.current,
          matchId:
            numericMatchId,
          [inningsNo]:
            confirmedSequence,
        };

        setOfflineSyncState((previous) => ({
          ...previous,
          pending: Math.max(
            0,
            totalPending -
              synced -
              syncedKeeperChanges -
              syncedInningsTransition -
              syncedStrikeSwaps
          ),
        }));
      } catch (syncError) {
        if (syncError?.status === 409 || syncError?.code === "OFFLINE_SYNC_CONFLICT") {
          const conflict = {
            message:
              syncError?.data?.message ||
              syncError.message ||
              "The server score changed while this device was offline.",
            expectedPreviousSequence:
              syncError
                ?.data
                ?.expectedPreviousSequence ??
              replaySequenceByInnings[
                Number(
                  event
                    ?.payload
                    ?.inningsNo ||
                  1
                )
              ],
            serverSequence: syncError?.data?.serverSequence ?? null,
            inningsNo: syncError?.data?.inningsNo ?? event.payload?.inningsNo,
          };

          await updateOfflineBall(event.clientEventId, {
            lastError: conflict.message,
          }).catch(() => {});

          setOfflineSyncState((previous) => ({
            ...previous,
            syncing: false,
            conflict,
            lastError: conflict.message,
          }));
          setError(
            "Sync paused: server and local scoring history need reconciliation. Scoring can continue safely on this device."
          );

          setMessage(
            "🔴 Synchronization is paused, but ball-by-ball scoring can continue locally."
          );

          return;
        }

        if (isOfflineRetryableError(syncError)) {
          setOfflineSyncState((previous) => ({
            ...previous,
            online: typeof navigator === "undefined" ? false : navigator.onLine,
            syncing: false,
            lastError: syncError.message || "Sync paused until the connection is stable.",
          }));
          return;
        }

        await updateOfflineBall(event.clientEventId, {
          lastError: syncError.message || "Sync failed.",
        }).catch(() => {});

        setOfflineSyncState((previous) => ({
          ...previous,
          syncing: false,
          conflict: {
            message: syncError.message || "A queued delivery could not be applied safely.",
            inningsNo: event.payload?.inningsNo,
          },
          lastError: syncError.message || "A queued delivery could not be applied safely.",
        }));
        setError(
          `Offline sync stopped: ${syncError.message || "queued delivery requires review."}`
        );
        return;
      }
    }

    /*
     * The scorer may reconnect immediately after ending innings 1, before
     * recording any innings-2 ball. In that case there was no innings-2
     * event to trigger the transition inside the loop above.
     */
    if (
      pendingInningsTransition &&
      !inningsTransitionApplied
    ) {
      const transitionSynced =
        await syncQueuedInningsTransition();

      if (
        !transitionSynced
      ) {
        return;
      }
    }

    const remainingSwapsSynced =
      await syncStrikeSwapsBefore(
        Number.POSITIVE_INFINITY
      );

    if (!remainingSwapsSynced) {
      return;
    }

    /*
     * Replay queued wicketkeeper changes after the pending balls.
     *
     * Each change stores afterSequence from the local scoreboard at the
     * moment it was made, so the server can record the historical boundary
     * after the corresponding offline balls have been restored.
     */
    for (
      const keeperChange
      of pendingKeeperChanges
    ) {
      try {
        await api(
          `/api/matches/${numericMatchId}/wicketkeeper-change`,
          {
            method:
              "POST",

            body:
              JSON.stringify({
                inningsNo:
                  keeperChange
                    .inningsNo,

                newKeeperId:
                  keeperChange
                    .newKeeperId,

                note:
                  keeperChange
                    .note,

                afterSequence:
                  keeperChange
                    .afterSequence,

                ...(keeperChange
                  .teamId
                  ? {
                      teamId:
                        keeperChange
                          .teamId,
                    }
                  : {}),
              }),
          }
        );

        await removeOfflineKeeperChange(
          numericMatchId,
          keeperChange
            .clientActionId
        );

        syncedKeeperChanges +=
          1;

        setOfflineSyncState(
          (previous) => ({
            ...previous,

            pending:
              Math.max(
                0,
                totalPending -
                  synced -
                  syncedKeeperChanges
              ),
          })
        );
      } catch (
        keeperSyncError
      ) {
        if (
          isOfflineRetryableError(
            keeperSyncError
          )
        ) {
          setOfflineSyncState(
            (previous) => ({
              ...previous,

              online:
                typeof navigator ===
                "undefined"
                  ? false
                  : navigator
                      .onLine,

              syncing:
                false,

              lastError:
                keeperSyncError
                  .message ||
                "Wicketkeeper sync paused until the connection is stable.",
            })
          );

          return;
        }

        setOfflineSyncState(
          (previous) => ({
            ...previous,

            syncing:
              false,

            conflict: {
              message:
                keeperSyncError
                  .message ||
                "A queued wicketkeeper change could not be synchronized safely.",
            },

            lastError:
              keeperSyncError
                .message ||
              "A queued wicketkeeper change could not be synchronized safely.",
          })
        );

        setError(
          `Offline sync stopped: ${
            keeperSyncError
              .message ||
            "queued wicketkeeper change requires review."
          }`
        );

        return;
      }
    }

    /*
     * A scorer may record another delivery WHILE this replay pass is running.
     * That new event was not part of the snapshot captured at the beginning of
     * this function.
     *
     * Re-count IndexedDB BEFORE fetching the server scoreboard. If anything
     * was appended, keep the local scoreboard intact and drain another pass.
     * Fetching the server here would temporarily erase the newer local ball.
     */
    const remainingPending =
      await refreshOfflinePendingCount(
        numericMatchId
      );

    if (remainingPending > 0) {
      setOfflineSyncState((previous) => ({
        ...previous,
        online: true,
        pending: remainingPending,
        syncing: true,
        conflict: null,
        lastError: "",
      }));

      setMessage(
        `🔵 Synchronizing · ${remainingPending} change${
          remainingPending === 1 ? "" : "s"
        } remaining.`
      );

      /*
       * Run after this function's finally block releases
       * offlineSyncRunningRef.
       */
      window.setTimeout(() => {
        void syncPendingOfflineBalls(
          numericMatchId
        );
      }, 75);

      return;
    }

    const refreshedBoard = await loadSelectedMatch(numericMatchId, {
      syncBallForm: true,
    });

    setOfflineLocalMatchComplete(false);
    setOfflineSyncState((previous) => ({
      ...previous,
      online: true,
      pending: 0,
      syncing: false,
      conflict: null,
      lastError: "",
    }));

    const totalSynced =
      synced +
      syncedKeeperChanges +
      syncedInningsTransition +
      syncedStrikeSwaps;

    setMessage(
      `✅ Offline scoring synchronized${
        totalSynced
          ? ` · ${totalSynced} change${
              totalSynced === 1 ? "" : "s"
            }`
          : ""
      }.`
    );

    const finalStatus =
      String(
        refreshedBoard
          ?.match
          ?.status ||
        ""
      )
        .trim()
        .toUpperCase();

    /*
     * COMPLETED is the only state that represents the initial match-end
     * transition. Locked/corrected statuses are downstream administrative
     * states and must not create another custody prompt.
     */
    if (finalStatus === "COMPLETED") {
      await syncAndShowPostMatchKitPrompt(
        numericMatchId
      );
    }
  } finally {
    offlineSyncRunningRef.current = false;
  }
}

async function submitBall(data) {
  setMessage("");
  setError("");
setOverCompleteNotice("");

  if (
    offlineLocalMatchComplete
  ) {
    const localCompletion =
      getOfflineLocalCompletionState(
        scoreboard,
        ballForm
          ?.inningsNo
      );

    if (
      localCompletion.complete
    ) {
      const reason =
        localCompletion
          .targetReached
          ? "target reached"
          : localCompletion
              .oversFinished
            ? "scheduled overs completed"
            : "maximum wickets reached";

      setError(
        `Match is complete on this device (${reason}). Reconnect and sync before scoring again.`
      );

      return false;
    }

    /*
     * State was stale/incorrect. Clear it and allow scoring to continue.
     */
    setOfflineLocalMatchComplete(
      false
    );
  }

  if (ballSaveInFlight) {
    return false;
  }

  if (scoreboard?.match?.status === "COMPLETED") {
    setError("Match has already ended");
    return false;
  }

  if (!selectedMatchId) {
    setError("Please select a match");
    return false;
  }
const safeInningsNo =
  pendingSecondInningsSetup || Number(ballForm?.inningsNo) === 2
    ? 2
    : getSafeScoringInningsNo(scoreboard, data);

data = {
  ...data,
  inningsNo: safeInningsNo,
};
  if (
    !ballForm.strikerId ||
    !ballForm.nonStrikerId ||
    !ballForm.bowlerId
  ) {
    setDeliverySetupReason(
      "Please select striker, non-striker, and bowler before scoring this ball."
    );
    setShowDeliverySetupModal(true);
    return false;
  }

  if (isSavingBall) {
    return false;
  }

  const previewBoard = previewScoreboardAfterBall(scoreboard, data);
  const clientEventId = createClientEventId();
  let queuedEvent = null;

  /*
   * RECONNECT SERIALIZATION
   * -----------------------
   * If older local scoring changes are still waiting/syncing, this new ball
   * MUST join the same local queue instead of racing the replay worker with a
   * direct /api/balls request.
   */
  let mustQueueBehindExistingSync = false;

  try {
    const clientDeviceId = await getOfflineDeviceId();
    const existingPending = await listPendingOfflineBalls(selectedMatchId);

    mustQueueBehindExistingSync =
      existingPending.length > 0 ||
      offlineSyncRunningRef.current ||
      offlineSyncState.syncing ||
      Number(offlineSyncState.pending || 0) > 0;

    const sameInningsPending = existingPending.filter(
      (event) => Number(event.payload?.inningsNo) === Number(data.inningsNo)
    );

    const sequenceState = offlineServerSequencesRef.current;
    const knownServerSequence =
      Number(sequenceState?.matchId) === Number(selectedMatchId)
        ? Number(sequenceState?.[Number(data.inningsNo)] || 0)
        : Number(scoreboard?.sync?.serverSequences?.[Number(data.inningsNo)] || 0);

    queuedEvent = {
      clientEventId,
      clientDeviceId,
      clientCreatedAt: new Date().toISOString(),
      matchId: Number(selectedMatchId),
      inningsNo: Number(data.inningsNo),

      /*
       * baseServerSequence is the server position this LOCAL chain branched
       * from. Keep it unchanged for every pending ball in the same chain.
       *
       * expectedPreviousSequence can become stale when local pending events
       * are removed/replaced before reconnect (Undo, wicket replacement,
       * innings setup, etc.). The base sequence is what lets reconnect
       * safely rebuild the chain without weakening conflict detection.
       */
      baseServerSequence:
        Number(
          sameInningsPending
            ?.[0]
            ?.baseServerSequence ??
          sameInningsPending
            ?.[0]
            ?.boardBefore
            ?.sync
            ?.serverSequences
            ?.[Number(data.inningsNo)] ??
          sameInningsPending
            ?.[0]
            ?.boardBefore
            ?.sync
            ?.serverSequences
            ?.[String(Number(data.inningsNo))] ??
          knownServerSequence
        ),

      expectedPreviousSequence:
        knownServerSequence +
        sameInningsPending.length,

      payload: { ...data },
      boardBefore: scoreboard,
      ballFormBefore: { ...ballForm },
    };

    await queueOfflineBall(queuedEvent);
  } catch (offlineStoreError) {
    /*
     * IndexedDB failure must never break existing ONLINE scoring. Continue with
     * the old direct API path; only true offline persistence is unavailable.
     */
    console.error("[OFFLINE_SCORING_STORE_FAILED]", offlineStoreError);
    queuedEvent = null;
  }

  setIsSavingBall(true);
  setOptimisticScoreboard(previewBoard);

  /*
   * RECONNECT / ACTIVE-SYNC SCORING
   * ===============================
   * The scorer must never be blocked while Cric4All is draining the offline
   * queue. But the new delivery must NOT be sent directly to the server while
   * older deliveries are still replaying.
   *
   * It has already been placed in IndexedDB above, so apply it locally and let
   * the single replay chain send it after every earlier change.
   */
  if (
    queuedEvent &&
    mustQueueBehindExistingSync
  ) {
    try {
      setOfflineSyncState((previous) => ({
        ...previous,
        pending: Math.max(
          Number(previous.pending || 0),
          1
        ),
        lastError: "",
      }));

      return await applyQueuedBallLocally({
        data,
        previewBoard,
        event: queuedEvent,
      });
    } finally {
      setIsSavingBall(false);
      setInstantDeliveryStatus("");
    }
  }

  /*
   * A sync conflict pauses synchronization only.
   * It must never pause the live cricket match.
   */
  if (offlineSyncState?.conflict) {
    setOfflineSyncState((previous) => ({
      ...previous,
      online:
        typeof navigator === "undefined"
          ? previous.online
          : navigator.onLine,
      syncing: false,
      lastError:
        previous.lastError ||
        "Synchronization is paused. Scoring is continuing safely on this device.",
    }));

    /*
     * IMPORTANT:
     * setIsSavingBall(true) is called immediately before this branch.
     *
     * The old conflict path returned BEFORE entering the try/finally below,
     * so setIsSavingBall(false) never ran. The first click could show
     * "Ball recorded", but every later scoring click was silently ignored by:
     *
     *   if (isSavingBall) return false;
     *
     * This is why scoring appeared completely frozen after Retry Sync.
     */
    try {
      return await applyQueuedBallLocally({
        data,
        previewBoard,
        event: queuedEvent,
      });
    } finally {
      setIsSavingBall(false);
      setInstantDeliveryStatus("");
    }
  }

  try {
    const instantMessage = getInstantDeliveryStatus(data);
    setInstantDeliveryStatus(instantMessage);
/*console.log("SUBMIT BALL INNINGS DEBUG", {
  formInningsNo: ballForm?.inningsNo,
  dataInningsNo: data?.inningsNo,
  boardCurrentInnings: scoreboard?.currentInnings,
  boardStateInningsNo: scoreboard?.currentState?.inningsNo,
});
*/
    const savedBall = await api("/api/balls", {
      method: "POST",
      body: JSON.stringify({
        ...data,
        ...(queuedEvent
          ? {
              clientEventId: queuedEvent.clientEventId,
              clientDeviceId: queuedEvent.clientDeviceId,
              clientCreatedAt: queuedEvent.clientCreatedAt,
              expectedPreviousSequence: queuedEvent.expectedPreviousSequence,
            }
          : {}),
      }),
    });

    if (queuedEvent) {
      await removeOfflineBall(queuedEvent.clientEventId).catch(() => {});
      await refreshOfflinePendingCount(selectedMatchId);
    }

    offlineServerSequencesRef.current = {
      ...offlineServerSequencesRef.current,
      matchId: Number(selectedMatchId),
      [Number(data.inningsNo)]: Number(savedBall?.sequence || 0),
    };


    /*
     * OFFLINE UNDO SNAPSHOT
     * ---------------------
     * The ball has now been confirmed by the server, but `scoreboard` and
     * `ballForm` in this submit closure still represent the state BEFORE
     * this delivery.
     *
     * Preserve that exact state so if the scorer loses connectivity and
     * immediately taps Undo, Cric4All can rewind the UI locally and queue
     * the real server undo for reconnect.
     */
    await saveOfflineServerUndoSnapshot(
      selectedMatchId,
      {
        inningsNo:
          Number(
            data.inningsNo
          ),

        serverSequenceBefore:
          Math.max(
            Number(
              savedBall
                ?.sequence ||
              0
            ) -
              1,
            0
          ),

        serverSequenceAfter:
          Number(
            savedBall
              ?.sequence ||
            0
          ),

        clientEventId:
          savedBall
            ?.clientEventId ||
          queuedEvent
            ?.clientEventId ||
          null,

        boardBefore:
          scoreboard,

        ballFormBefore: {
          ...ballForm,
        },
      }
    ).catch(
      (
        snapshotError
      ) => {
        console.warn(
          "[OFFLINE_UNDO_SNAPSHOT_SAVE_FAILED]",
          snapshotError
        );
      }
    );

    if (
      Array.isArray(
        savedBall?.milestones
      ) &&
      savedBall.milestones.length
    ) {
      setMilestoneCelebration({
        primary:
          savedBall.milestones[0],

        all:
          savedBall.milestones,
      });
    }

    /*
     * A full historical reconcile is useful for correction safety, but it is
     * intentionally not awaited by the scoring controls. It only runs after
     * an actual milestone ball instead of after every tap.
     */
    if (
      Array.isArray(
        savedBall?.milestones
      ) &&
      savedBall.milestones.length
    ) {
      void api(
        "/api/milestones/reconcile",
        {
          method:
            "POST",

          body:
            JSON.stringify({
              matchId:
                Number(
                  selectedMatchId
                ),
            }),
        }
      ).catch(
        (
          milestoneError
        ) => {
          console.error(
            "[MILESTONE_BACKGROUND_RECONCILE_FAILED]",
            milestoneError
          );
        }
      );
    }
if (scoreboard?.currentState && !showDeliverySetupModal) {  
setBallForm((prev) => ({
  ...prev,
  inningsNo: Number(data.inningsNo),
  extraType: "NONE",
  runsOffBat: "0",
  extras: "0",
  isWicket: false,
  wicketType: "NONE",
  newBatterId: "",
  dismissedPlayerId: "",
  note: "",
  fielderId: "",
  assistantFielderId: "",
  wicketNote: "",
}));
  }
    setShowAdvancedSheet(false);

    const updatedBoard = await api(`/api/scoreboard/${selectedMatchId}`);

    const updatedCurrentInningsNo = Number(
      updatedBoard?.currentInnings || data.inningsNo
    );

    const updatedActiveInnings =
      updatedBoard?.innings?.[updatedCurrentInningsNo - 1];

    const updatedMaxLegalBalls =
      Number(updatedBoard?.match?.oversPerInnings || 0) * 6;

    const updatedIsSecondInnings = updatedCurrentInningsNo === 2;

    const updatedIsFinalBallBowled =
      updatedIsSecondInnings &&
      updatedMaxLegalBalls > 0 &&
      Number(updatedActiveInnings?.legalBalls || 0) >= updatedMaxLegalBalls;

    const updatedTarget = Number(updatedBoard?.summary?.target || 0);
    const updatedRuns = Number(updatedActiveInnings?.runs || 0);

    const updatedIsChaseComplete =
      updatedIsSecondInnings &&
      updatedTarget > 0 &&
      updatedRuns >= updatedTarget;

    const firstInningsJustEnded =
  Number(data.inningsNo) === 1 &&
  (
    (
      savedBall?.inningsEnded === true &&
      Number(savedBall?.nextInningsNo) === 2
    ) ||
    Number(updatedBoard?.currentInnings) === 2
  );

/*
 * FAST SCORING PATH
 *
 * updatedBoard was already fetched immediately above. Reuse it instead of
 * calling loadSelectedMatch(), which would make a second identical scoreboard
 * request after every delivery.
 */
setScoreboard(
  updatedBoard
);

if (
  updatedBoard?.currentState &&
  !showDeliverySetupModal
) {
  setBallForm(
    (
      previous
    ) => ({
      ...previous,

      strikerId:
        updatedBoard
          .currentState
          .strikerId ??
        previous.strikerId,

      nonStrikerId:
        updatedBoard
          .currentState
          .nonStrikerId ??
        previous.nonStrikerId,

      bowlerId:
        updatedBoard
          .currentState
          .bowlerId ??
        previous.bowlerId,
    })
  );
}

const overJustCompleted =
  Boolean(
    savedBall?.legalDelivery
  ) &&
  Number(
    savedBall?.ballInOver
  ) === 6;

//const legalBalls =
//  scoreboard.currentState.legalBalls + 1;

//const completedOvers = Math.floor(legalBalls / 6);

if (scorerMode && overJustCompleted) {
//  setOverCompleteNotice(
//`✅ Over complete `
    //    `✅ Over complete • ${legalBalls ?? 0}/${data.wickets ?? 0} • ${data.oversDisplay ?? 0} ov`
//  );
  setOverCompleteNotice("");

} else {
  setOverCompleteNotice("");
}

    setOptimisticScoreboard(null);
    setInstantDeliveryStatus("");

if (firstInningsJustEnded) {
  setShowBowlerModal(false);
  setShowDeliverySetupModal(false);
  setMustChangeBowler(false);
  setPendingBallData(null);
  setOptimisticScoreboard(null);
  setInstantDeliveryStatus("");

await loadSelectedMatch(selectedMatchId, {
  syncBallForm: false,
});
  //await loadMatches();

  setPendingSecondInningsSetup(true);
if (scoreboard?.currentState && !showDeliverySetupModal) { 
  setBallForm((prev) => ({
    ...prev,
    inningsNo: 2,
    strikerId: "",
    nonStrikerId: "",
    bowlerId: "",
    extraType: "NONE",
    runsOffBat: "0",
    extras: "0",
    isWicket: false,
    wicketType: "NONE",
    newBatterId: "",
    dismissedPlayerId: "",
    note: "",
    dismissal: "",
    fielderId: "",
    assistantFielderId: "",
    wicketNote: "",
  }));
}
  setDeliverySetupReason(
    "🏏 2nd innings is ready. Select the opening striker, non-striker, and bowler before scoring."
  );

  setMessage("✅ 1st innings ended. Setup 2nd innings to continue scoring.");

  setTimeout(() => {

    setShowDeliverySetupModal(true);
  }, 200);

  return true;
}
if (scoreboard?.currentState && !showDeliverySetupModal) { 
    setBallForm((prev) => ({
      ...prev,
      inningsNo: Number(data.inningsNo),
      extraType: "NONE",
      runsOffBat: "0",
      extras: "0",
      isWicket: false,
      wicketType: "NONE",
      newBatterId: "",
      dismissedPlayerId: "",
      note: "",
      dismissal: "",
      fielderId: "",
      assistantFielderId: "",
      wicketNote: "",
    }));
  }
    const updatedMatchStatus =
      String(
        updatedBoard
          ?.match
          ?.status ||
        ""
      )
        .trim()
        .toUpperCase();

    const updatedMatchCompleted =
      [
        "COMPLETED",
        "COMPLETED_LOCKED",
        "COMPLETED_CORRECTED",
      ].includes(
        updatedMatchStatus
      );

    /*
     * A tied main match can temporarily have COMPLETED status while a
     * Super Over is still required. Do not ask for final kit custody until
     * the tie-breaker itself is complete.
     */
    const updatedStatusText =
      String(
        updatedBoard
          ?.match
          ?.statusText ||
        updatedBoard
          ?.summary
          ?.resultText ||
        updatedBoard
          ?.resultText ||
        ""
      )
        .trim()
        .toLowerCase();

    const inningsOneRuns =
      Number(
        updatedBoard
          ?.innings
          ?.[0]
          ?.runs ??
        NaN
      );

    const inningsTwoRuns =
      Number(
        updatedBoard
          ?.innings
          ?.[1]
          ?.runs ??
        NaN
      );

    const scoreIsTied =
      Number.isFinite(
        inningsOneRuns
      ) &&
      Number.isFinite(
        inningsTwoRuns
      ) &&
      inningsOneRuns ===
        inningsTwoRuns;

    const superOverStillRequired =
      (
        updatedStatusText
          .includes("tied") ||
        scoreIsTied ||
        (
          updatedBoard
            ?.superOver
            ?.exists &&
          !updatedBoard
            ?.superOver
            ?.completed
        )
      ) &&
      !updatedBoard
        ?.superOver
        ?.completed;

    /*
     * POST-MATCH FOLLOW-UP MUST BE SERVER-AUTHORITATIVE
     * =================================================
     * Local/client calculations (including a revised DLS target) are useful
     * for the live HUD, but they must NEVER trigger kit-custody sync by
     * themselves.
     *
     * The kit endpoint correctly accepts only a genuinely COMPLETED match.
     * Therefore wait for the scoreboard returned by the server to confirm the
     * completed status first.
     *
     * This removes the DLS race:
     *   client sees revised target reached
     *   -> kit sync too early
     *   -> server still IN_PROGRESS
     *   -> 409
     */
    if (updatedMatchCompleted) {
      setShowBowlerModal(false);
      setMustChangeBowler(false);
      setPendingBallData(null);

      if (
        !superOverStillRequired
      ) {
        await syncAndShowPostMatchKitPrompt(
          selectedMatchId
        );
      }

      setMessage(
        superOverStillRequired
          ? "🏁 Main match tied. Complete the Super Over before confirming final kit custody."
          : "🏁 Match ended. Confirm who took the kit home, then review/lock the final scoreboard."
      );

      return true;
    }

    /*
     * Defensive diagnostic only:
     * if the client believes a chase/overs boundary has been reached but the
     * server has not completed the match, do not call kit custody. Continue
     * from the authoritative server state and surface a nonblocking message.
     *
     * With the DLS-aware /api/balls route this branch should normally not be
     * reached.
     */
    if (
      updatedIsFinalBallBowled ||
      updatedIsChaseComplete
    ) {
      setMessage(
        "Score saved. Cric4All is waiting for the server to confirm the final match state."
      );
    }

    const wasLegalLastBallOfOver =
      Boolean(
        savedBall?.legalDelivery
      ) &&
      Number(
        savedBall?.ballInOver
      ) === 6;

    if (wasLegalLastBallOfOver) {
      /*
       * The delivery has already been saved and confirmed by the updated
       * scoreboard. Clear wicket state before opening Change Bowler so the
       * Wicket Details dialog cannot race and reopen over it.
       */
      setShowWicketModal(
        false
      );

      setWicketSubmissionInFlight(
        false
      );

      setBallForm(
        (
          previous
        ) => ({
          ...previous,

          isWicket:
            false,

          wicketType:
            "NONE",

          dismissedPlayerId:
            "",

          newBatterId:
            "",

          fielderId:
            "",

          assistantFielderId:
            "",

          wicketNote:
            "",

          runsOffBat:
            "0",

          extras:
            "0",

          extraType:
            "NONE",
        })
      );

      setPendingBallData(
        null
      );

      setMustChangeBowler(
        true
      );

      setBowlerSearchText(
        ""
      );

      /*
       * Open on the next task after React receives the wicket cleanup.
       * This keeps the transition deterministic:
       * Wicket saved -> Wicket closed -> Change Bowler opened.
       */
      window.setTimeout(
        () => {
          setShowBowlerModal(
            true
          );
        },
        0
      );

      return true;
    }

    setMessage(instantMessage);
    return true;
  } catch (err) {
    setOptimisticScoreboard(null);
    setInstantDeliveryStatus("");

    if (
      queuedEvent &&
      (
        isOfflineRetryableError(err) ||
        isOfflineSyncConflictError(err)
      )
    ) {
      const isConflict =
        isOfflineSyncConflictError(err);

      setOfflineSyncState((previous) => ({
        ...previous,
        online:
          typeof navigator === "undefined"
            ? false
            : navigator.onLine,
        syncing: false,
        ...(isConflict
          ? {
              conflict: {
                message:
                  err?.data?.message ||
                  err.message ||
                  "Server and local scoring history need reconciliation.",
                expectedPreviousSequence:
                  err?.data?.expectedPreviousSequence,
                serverSequence:
                  err?.data?.serverSequence,
                inningsNo:
                  err?.data?.inningsNo,
              },
            }
          : {}),
        lastError:
          isConflict
            ? "Sync paused. Scoring can continue safely on this device."
            : err.message ||
              "Delivery queued for automatic sync.",
      }));

      return await applyQueuedBallLocally({
        data,
        previewBoard,
        event: queuedEvent,
      });
    }

    /*
     * A validation/permission error means the delivery was never accepted.
     * Remove its local queue record so it is not replayed later.
     */
    if (queuedEvent) {
      await removeOfflineBall(queuedEvent.clientEventId).catch(() => {});
      await refreshOfflinePendingCount(selectedMatchId);
    }

    if (err.message?.includes("BOWLER_CONSECUTIVE_OVER")) {
      setPendingBallData({
        matchId: Number(selectedMatchId),
        inningsNo: Number(data.inningsNo),
        strikerId: Number(data.strikerId),
        nonStrikerId: Number(data.nonStrikerId),
        bowlerId: Number(data.bowlerId),
        extraType: data.extraType,
        runsOffBat: Number(data.runsOffBat),
        extras: Number(data.extras),

        isWicket:
          data.isWicket && data.wicketType !== "RETIRED_HURT" ? 1 : 0,

        wicketType: data.isWicket ? data.wicketType : "NONE",

        dismissedPlayerId: data.isWicket
          ? Number(data.dismissedPlayerId || data.strikerId)
          : null,

        newBatterId: data.newBatterId ? Number(data.newBatterId) : null,

        note: data.note,
        matchStatus: data.matchStatus,
      });
      setBowlerSearchText("");
      setShowBowlerModal(true);
      return false;
    }

    setError(err.message);
    showToast("error", err.message);
    return false;
  } finally {
    setIsSavingBall(false);
    setInstantDeliveryStatus("");
  }
}
  

useEffect(() => {
  if (typeof window === "undefined") return undefined;

  let cancelled = false;

  const refresh = async () => {
    const online = navigator.onLine;
    const pending = selectedMatchId
      ? await getPendingOfflineBallCount(selectedMatchId).catch(() => 0)
      : 0;

    if (cancelled) return;

    setOfflineSyncState((previous) => ({
      ...previous,
      online,
      pending,
      ...(online ? {} : { syncing: false }),
    }));

    if (
      online &&
      pending > 0 &&
      selectedMatchId &&
      !offlineSyncState?.conflict
    ) {
      void syncPendingOfflineBalls(selectedMatchId);
    }
  };

  const handleOnline = () => {
    setOfflineSyncState((previous) => ({ ...previous, online: true }));
    void refresh();
  };

  const handleOffline = () => {
    setOfflineSyncState((previous) => ({
      ...previous,
      online: false,
      syncing: false,
    }));
  };

  window.addEventListener("online", handleOnline);
  window.addEventListener("offline", handleOffline);
  void refresh();

  return () => {
    cancelled = true;
    window.removeEventListener("online", handleOnline);
    window.removeEventListener("offline", handleOffline);
  };
}, [selectedMatchId]);

async function selectLeague(league) {
  setShowDeliverySetupModal(false);
  setPendingDeliverySetupAfterStart(false);
  setPendingSecondInningsSetup(false);
  setDeliverySetupReason("");

  const leagueId =
    Number(league?.id);

  if (
    !Number.isInteger(leagueId) ||
    leagueId <= 0
  ) {
    return;
  }

  /*
   * LEAGUE SELECTION IS A MANAGEMENT ACTION
   * =======================================
   * Growth Phase 2 can arrive at /dashboard with:
   *
   *   ?tab=scoring&leagueId=...&matchId=...
   *
   * If those query parameters remain in the URL, the dashboard deep-link
   * effect can legitimately reopen Scoring after the user later switches to
   * the Leagues tab and selects another league.
   *
   * Selecting a league manually means the user has taken control of
   * navigation. Clear the stale scoring deep-link and remain on Management.
   */
  scoringDeepLinkLoadedRef.current =
    "";

  setActiveLeagueId(
    leagueId
  );

  setSelectedMatchId(
    ""
  );

  setMatchDetail(
    null
  );

  setScoreboard(
    null
  );

  setStats(
    null
  );

  setMatches(
    []
  );

  setSelectedTeamId(
    ""
  );

  setActiveTab(
    "management"
  );

  /*
   * Replace rather than push so Back does not immediately re-enter the stale
   * scoring deep-link. Keep only the selected league context.
   */
  router.replace(
    `/dashboard?tab=management&leagueId=${encodeURIComponent(
      String(leagueId)
    )}`
  );

  fetch("/api/user/preferences", {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      activeLeagueId:
        leagueId,
      activeMatchId:
        null
    })
  }).catch(() => {});

  await loadMyLeaguePermissions(
    leagueId
  );

  await loadMatches(
    leagueId
  );
}
  const handleLeagueChange = (leagueId) => {
  setActiveLeagueId(leagueId);

  localStorage.setItem(
    "activeLeagueId",
    String(leagueId)
  );
};
const handleMatchChange = (matchId) => {
  setSelectedMatchId(matchId);

  localStorage.setItem(
    "selectedMatchId",
    String(matchId)
  );
};
function quickExtra(type) {
  setSelectedExtraType(type);
    setBallForm((prev) => ({
    ...prev,
    extraType: type
  }));
  setShowExtrasModal(true);
}

async function confirmExtra(extraRuns) {
  /*
   * IMPORTANT:
   * Wide / No Ball do not consume a legal delivery.
   *
   * Keep the extra type captured from the modal itself instead of relying on
   * ballForm.extraType after async React state updates. This is especially
   * important on the sixth attempted delivery of an over (0.5, 1.5, 2.5...),
   * where another scorer workflow can update ballForm while this request is
   * being saved.
   */
  if (isSavingBall) {
    return;
  }

  const extraTypeForThisDelivery =
    String(selectedExtraType || ballForm.extraType || "NONE").toUpperCase();

  const modalSnapshot = {
    selectedExtraType: extraTypeForThisDelivery,
    selectedExtraOption,
    ballForm: {
      ...ballForm,
    },
  };

  let runsOffBat = Number(ballForm.runsOffBat || 0);
  let extras = Number(ballForm.extras || 0);

  const displayLabel = String(extraRuns);

  setSelectedExtraOption(displayLabel);

  if (
    typeof extraRuns === "string" &&
    extraRuns.startsWith("WD")
  ) {
    const additionalRuns = extraRuns.includes("+")
      ? Number(extraRuns.split("+")[1])
      : 0;

    runsOffBat = 0;
    extras = 1 + additionalRuns;
  } else if (
    typeof extraRuns === "string" &&
    extraRuns.startsWith("NB")
  ) {
    const batRuns = extraRuns.includes("+")
      ? Number(extraRuns.split("+")[1])
      : 0;

    runsOffBat = batRuns;
    extras = 1;
  } else {
    runsOffBat = 0;
    extras = Number(extraRuns);
  }

  /*
   * Close the extra picker immediately.
   *
   * DO NOT automatically reopen it when submitBall() returns false.
   * A false return can intentionally mean that another workflow has taken
   * control (Change Bowler / Delivery Setup / duplicate-save guard). Reopening
   * the Extras modal in that situation caused the same Wide / No Ball popup
   * to appear repeatedly around .5 of every over.
   *
   * A genuine thrown/network error is handled by catch below and restores the
   * modal so the scorer can retry.
   */
  setShowExtrasModal(false);

  try {
    const saved = await submitBall({
      matchId: Number(selectedMatchId),
      inningsNo: Number(ballForm.inningsNo),
      strikerId: Number(ballForm.strikerId),
      nonStrikerId: Number(ballForm.nonStrikerId),
      bowlerId: Number(ballForm.bowlerId),

      // Use the modal snapshot, never a possibly stale ballForm value.
      extraType: extraTypeForThisDelivery,

      runsOffBat,
      extras,

      isWicket:
        ballForm.isWicket &&
        ballForm.wicketType !== "RETIRED_HURT"
          ? 1
          : 0,

      wicketType: ballForm.isWicket
        ? ballForm.wicketType
        : "NONE",

      dismissedPlayerId: ballForm.isWicket
        ? Number(
            ballForm.dismissedPlayerId ||
              ballForm.strikerId
          )
        : null,

      newBatterId:
        ballForm.isWicket &&
        ballForm.newBatterId
          ? Number(ballForm.newBatterId)
          : null,

      note: ballForm.note,

      matchStatus:
        scoreboard?.match?.status,
    });

    if (!saved) {
      /*
       * submitBall() has already displayed the relevant error or opened the
       * required scoring workflow. Leave Extras closed so it cannot fight
       * with that modal and reopen forever.
       */
      setSelectedExtraOption("");
      return;
    }

    const extraLabels = {
      WIDE: "Wide",
      NOBALL: "No Ball",
      BYE: "Bye",
      LEGBYE: "Leg Bye",
      NONE: "Extra",
    };

    const extraLabel =
      extraLabels[extraTypeForThisDelivery] ||
      extraTypeForThisDelivery;

    setMessage(
      `✅ ${displayLabel} added as ${extraLabel}.`
    );

    setSelectedExtraOption("");
  } catch (err) {
    /*
     * Only a genuine thrown/network failure restores the picker.
     * Intentional submitBall(false) flows stay closed.
     */
    setSelectedExtraType(
      modalSnapshot.selectedExtraType
    );

    setSelectedExtraOption(
      modalSnapshot.selectedExtraOption
    );

    setBallForm(
      modalSnapshot.ballForm
    );

    setShowExtrasModal(true);

    setError(err.message);
  }
}

async function quickWicket(type = "BOWLED") {
  setRunOutRuns(null);
  setEndInningsAfterWicket(false);
  setBallForm((prev) => ({
    ...prev,
    isWicket: true,
    wicketType: type,
    dismissedPlayerId: type === "RUN_OUT" ? prev.dismissedPlayerId || prev.strikerId : prev.strikerId,
    newBatterId: "",
    fielderId: "",
    assistantFielderId: "",
    wicketNote: "",
  }));

  setShowWicketModal(true);
}
async function confirmWicket() {
  if (
    isSavingBall ||
    wicketSubmissionInFlight
  ) {
    return;
  }

  setWicketSubmissionInFlight(
    true
  );

  try {
    if (mustChangeBowler) {
      setError(
        "Please select a new bowler before scoring the next ball."
      );

      setShowWicketModal(
        false
      );

      setShowRetiredHurtModal(
        false
      );

      setBowlerSearchText(
        ""
      );

      setShowBowlerModal(
        true
      );

      setWicketSubmissionInFlight(
        false
      );

      return;
    }

    const isRunOut =
      ballForm.wicketType ===
      "RUN_OUT";

    if (
      isRunOut &&
      runOutRuns ===
        null
    ) {
      setError(
        "Please select runs completed before the run out."
      );

      setWicketSubmissionInFlight(
        false
      );

      return;
    }

    const dismissedPlayerId =
      isRunOut
        ? Number(
            ballForm.dismissedPlayerId
          )
        : Number(
            ballForm.dismissedPlayerId ||
              ballForm.strikerId
          );

    if (
      !dismissedPlayerId
    ) {
      setError(
        "Please select who is out."
      );

      setWicketSubmissionInFlight(
        false
      );

      return;
    }

    const noMoreBattersAvailable =
      Array.isArray(
        wicketNewBatterOptions
      ) &&
      wicketNewBatterOptions.length ===
        0;

    if (
      !endInningsAfterWicket &&
      !ballForm.newBatterId &&
      !noMoreBattersAvailable
    ) {
      setError(
        "Please select a new batter or choose end innings."
      );

      setWicketSubmissionInFlight(
        false
      );

      return;
    }

    const selectedNewBatterIsValid =
      endInningsAfterWicket ||
      noMoreBattersAvailable ||
      wicketNewBatterOptions.some(
        (player) =>
          String(
            player.id
          ) ===
          String(
            ballForm.newBatterId
          )
      );

    if (
      !selectedNewBatterIsValid
    ) {
      setError(
        "Invalid new batter selected. Please select a valid replacement batter or choose end innings."
      );

      setBallForm(
        (
          previous
        ) => ({
          ...previous,
          newBatterId:
            "",
        })
      );

      setWicketSubmissionInFlight(
        false
      );

      return;
    }

    const runsOffBat =
      isRunOut
        ? Number(
            runOutRuns
          )
        : Number(
            ballForm.runsOffBat ||
              0
          );

    const dismissedPlayer =
      battingTeam?.players?.find(
        (player) =>
          Number(
            player.id
          ) ===
          dismissedPlayerId
      );

    const newBatter =
      noMoreBattersAvailable
        ? null
        : battingTeam?.players?.find(
            (player) =>
              Number(
                player.id
              ) ===
              Number(
                ballForm.newBatterId
              )
          );

    const modalSnapshot = {
      ballForm: {
        ...ballForm,
      },
      runOutRuns,
      endInningsAfterWicket,
    };

    /*
     * Hide the modal as soon as validation succeeds. submitBall() applies the
     * optimistic scoreboard immediately, so the scorer is not left staring at
     * a frozen Submit button.
     */
    setShowWicketModal(
      false
    );

    const saved =
      await submitBall({
        matchId:
          Number(
            selectedMatchId
          ),

        inningsNo:
          Number(
            ballForm.inningsNo
          ),

        strikerId:
          Number(
            ballForm.strikerId
          ),

        nonStrikerId:
          Number(
            ballForm.nonStrikerId
          ),

        bowlerId:
          Number(
            ballForm.bowlerId
          ),

        extraType:
          "NONE",

        runsOffBat,
        extras:
          0,

        isWicket:
          ballForm.isWicket &&
          ballForm.wicketType !==
            "RETIRED_HURT"
            ? 1
            : 0,

        wicketType:
          ballForm.isWicket
            ? ballForm.wicketType
            : "NONE",

        dismissedPlayerId,

        newBatterId:
          endInningsAfterWicket ||
          noMoreBattersAvailable
            ? null
            : Number(
                ballForm.newBatterId
              ),

        endInningsAfterWicket:
          Boolean(
            endInningsAfterWicket
          ),

        note:
          ballForm.note,

        matchStatus:
          scoreboard?.match
            ?.status,

        fielderId:
          ballForm.fielderId
            ? Number(
                ballForm.fielderId
              )
            : null,

        assistantFielderId:
          ballForm.assistantFielderId
            ? Number(
                ballForm.assistantFielderId
              )
            : null,

        wicketNote:
          ballForm.wicketNote ||
          null,
      });

    if (!saved) {
      setBallForm(
        modalSnapshot.ballForm
      );

      setRunOutRuns(
        modalSnapshot.runOutRuns
      );

      setEndInningsAfterWicket(
        modalSnapshot.endInningsAfterWicket
      );

      setWicketSubmissionInFlight(
        false
      );

      /*
       * Do not put Wicket Details back on top of a required Change
       * Bowler or Delivery Setup workflow.
       */
      if (
        !mustChangeBowler &&
        !showBowlerModal &&
        !showDeliverySetupModal
      ) {
        setShowWicketModal(
          true
        );
      }

      return;
    }

    const wicketText =
      ballForm.wicketType
        ?.replaceAll(
          "_",
          " "
        )
        ?.toLowerCase();

    if (
      noMoreBattersAvailable ||
      endInningsAfterWicket
    ) {
      setMessage(
        `🚨 ${dismissedPlayer?.name || "Batter"} is out (${wicketText}). ${runsOffBat} ${
          runsOffBat === 1
            ? "run"
            : "runs"
        } awarded. Innings ended.`
      );
    } else {
      setMessage(
        `🚨 ${dismissedPlayer?.name || "Batter"} is out (${wicketText}). ${runsOffBat} ${
          runsOffBat === 1
            ? "run"
            : "runs"
        } awarded. ${newBatter?.name || "New batter"} comes in.`
      );
    }

    /*
     * submitBall() already:
     * - saves the wicket
     * - fetches the updated scoreboard once
     * - applies striker/non-striker/bowler state
     * - opens second-innings setup when needed
     * - handles over completion and bowler change
     *
     * Do not call loadSelectedMatch() or loadMatches() again here.
     */
    setRunOutRuns(
      null
    );

    setEndInningsAfterWicket(
      false
    );

    setWicketSubmissionInFlight(
      false
    );

    setShowWicketModal(
      false
    );

    setBallForm(
      (
        previous
      ) => ({
        ...previous,

        isWicket:
          false,

        wicketType:
          "NONE",

        dismissedPlayerId:
          "",

        newBatterId:
          "",

        fielderId:
          "",

        assistantFielderId:
          "",

        wicketNote:
          "",

        runsOffBat:
          "0",

        extras:
          "0",

        extraType:
          "NONE",
      })
    );
  } catch (err) {
    setWicketSubmissionInFlight(
      false
    );

    if (
      !mustChangeBowler &&
      !showBowlerModal &&
      !showDeliverySetupModal
    ) {
      setShowWicketModal(
        true
      );
    }

    setError(
      err.message
    );
  }
}

async function swapBatters() {
  if (!selectedMatchId) {
    return;
  }

  const oldStrikerId =
    ballForm.strikerId;

  const oldNonStrikerId =
    ballForm.nonStrikerId;

  if (
    !oldStrikerId ||
    !oldNonStrikerId
  ) {
    setError(
      "Striker and non-striker must be selected before swapping strike."
    );
    return;
  }

  const newStrikerId =
    oldNonStrikerId;

  const newNonStrikerId =
    oldStrikerId;

  const applySwapLocally =
    async () => {
      const localBoard =
        scoreboard
          ? (
              typeof structuredClone ===
              "function"
                ? structuredClone(
                    scoreboard
                  )
                : JSON.parse(
                    JSON.stringify(
                      scoreboard
                    )
                  )
            )
          : null;

      if (
        localBoard?.currentState
      ) {
        const currentState =
          localBoard.currentState;

        const strikerName =
          currentState
            .strikerName;

        const nonStrikerName =
          currentState
            .nonStrikerName;

        const strikerStats =
          currentState
            .strikerStats;

        const nonStrikerStats =
          currentState
            .nonStrikerStats;

        currentState.strikerId =
          Number(
            newStrikerId
          );

        currentState.nonStrikerId =
          Number(
            newNonStrikerId
          );

        currentState.strikerName =
          nonStrikerName;

        currentState.nonStrikerName =
          strikerName;

        currentState.strikerStats =
          nonStrikerStats;

        currentState.nonStrikerStats =
          strikerStats;

        setScoreboard(
          localBoard
        );
      }

      const nextForm = {
        ...ballForm,

        strikerId:
          String(
            newStrikerId
          ),

        nonStrikerId:
          String(
            newNonStrikerId
          ),
      };

      setBallForm(
        nextForm
      );

      await cacheOfflineMatchSnapshot(
        selectedMatchId,
        {
          scoreboard:
            localBoard ||
            scoreboard,

          matchDetail:
            matchDetail ||
            null,

          ballForm:
            nextForm,

          savedAt:
            new Date()
              .toISOString(),
        }
      ).catch(
        (
          cacheError
        ) => {
          console.warn(
            "[OFFLINE_SWAP_CACHE_FAILED]",
            cacheError
          );
        }
      );
    };

  try {
    const browserIsOffline =
      typeof navigator !==
        "undefined" &&
      navigator.onLine ===
        false;

    const appIsOffline =
      offlineSyncState?.online === false ||
      Boolean(offlineSyncState?.conflict);

    if (
      browserIsOffline ||
      appIsOffline
    ) {
      await queueOfflineStrikeSwap({
        matchId:
          Number(
            selectedMatchId
          ),

        inningsNo:
          Number(
            ballForm.inningsNo
          ),

        strikerId:
          Number(
            newStrikerId
          ),

        nonStrikerId:
          Number(
            newNonStrikerId
          ),

        localOrder:
          Date.now() * 1000 +
          Math.floor(
            Math.random() * 999
          ),
      });

      await applySwapLocally();

      const pending =
        await refreshOfflinePendingCount(
          selectedMatchId
        );

      setError(
        ""
      );

      setMessage(
        `📴 Strike swapped locally · ${pending} change${
          pending === 1
            ? ""
            : "s"
        } waiting to sync.`
      );

      return;
    }

    await api(
      "/api/events/swap-strike",
      {
        method:
          "POST",

        body:
          JSON.stringify({
            matchId:
              selectedMatchId,

            inningsNo:
              ballForm.inningsNo,

            strikerId:
              newStrikerId,

            nonStrikerId:
              newNonStrikerId,
          }),
      }
    );

    await applySwapLocally();

    await loadSelectedMatch(
      selectedMatchId
    );

    setMessage(
      "🔄 Striker swapped successfully"
    );
  } catch (err) {
    if (
      isOfflineRetryableError(
        err
      )
    ) {
      try {
        await queueOfflineStrikeSwap({
          matchId:
            Number(
              selectedMatchId
            ),

          inningsNo:
            Number(
              ballForm.inningsNo
            ),

          strikerId:
            Number(
              newStrikerId
            ),

          nonStrikerId:
            Number(
              newNonStrikerId
            ),
        });

        await applySwapLocally();

        setOfflineSyncState(
          (
            previous
          ) => ({
            ...previous,

            online:
              false,

            syncing:
              false,
          })
        );

        const pending =
          await refreshOfflinePendingCount(
            selectedMatchId
          );

        setError(
          ""
        );

        setMessage(
          `📴 Strike swapped locally · ${pending} change${
            pending === 1
              ? ""
              : "s"
          } waiting to sync.`
        );

        return;
      } catch (
        queueError
      ) {
        console.error(
          "[OFFLINE_SWAP_QUEUE_FAILED]",
          queueError
        );
      }
    }

    setError(
      err.message
    );
  }
}

const handleBulkAddPlayers = async (e) => {
  e.preventDefault();

  try {

const names = playerForm.names
  .split("\n")
  .map((name) => name.trim())
  .filter(Boolean);

    const response = await fetch("/api/players/bulk", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        teamId: playerForm.teamId,
        names,
      }),
    });

    const data = await response.json();

    if (!response.ok) {
      throw new Error(
        data.error || "Failed to add players"
      );
    }

    await loadLeagues();

    setShowPlayerModal(false);

    setMessage(
      `${names.length} players added successfully`
    );
  } catch (error) {
    setError(error.message);
  }
};
async function handleMatchSelect(matchId) {
  const numericMatchId =
    Number(
      matchId
    );

  if (
    !Number.isInteger(
      numericMatchId
    ) ||
    numericMatchId <= 0
  ) {
    setError(
      "Unable to identify the selected match."
    );
    return;
  }

  const matchToOpen =
    matches.find(
      (match) =>
        Number(
          match.id
        ) ===
        numericMatchId
    ) ||
    null;

  const normalizedOpenStatus =
    String(
      matchToOpen
        ?.status ||
      ""
    )
      .trim()
      .replace(
        /[\s-]+/g,
        "_"
      )
      .toUpperCase();

  const openingCompletedMatch =
    normalizedOpenStatus
      .includes(
        "COMPLETED"
      ) ||
    normalizedOpenStatus ===
      "LOCKED" ||
    normalizedOpenStatus ===
      "ABANDONED";

  /*
   * Navigate immediately. The user should not sit on the Completed tab while
   * match data is loading.
   *
   * Existing desktop/mobile Scoreboard markup is unchanged.
   */
  setActiveTab(
    "scoring"
  );

  if (
    openingCompletedMatch
  ) {
    setScoringSubTab(
      "SCOREBOARD"
    );
  }

  if (
    String(
      selectedMatchId
    ) !==
    String(
      numericMatchId
    )
  ) {
    setScoreboard(
      null
    );

    setMatchDetail(
      null
    );

    setOptimisticScoreboard(
      null
    );
  }

  selectedMatchExplicitLoadRef
    .current =
    String(
      numericMatchId
    );

  setSelectedMatchId(
    String(
      numericMatchId
    )
  );

  /*
   * Completed Scoreboard does not need /api/stats before the normal
   * scorecard can render. Live/active match selection retains stats loading.
   */
  await loadSelectedMatch(
    numericMatchId,
    {
      loadDetail:
        true,

      loadStatsData:
        !openingCompletedMatch,

      syncBallForm:
        !openingCompletedMatch,
    }
  );

  /*
   * No explicit /api/user/preferences POST here.
   * The existing preferences effect persists the selected match once.
   */
}

function getWicketDismissedPlayerId(form) {
  const wicketType = String(form?.wicketType || "").toUpperCase();

  if (wicketType === "RUN_OUT") {
    return Number(form?.dismissedPlayerId || 0);
  }

  return Number(form?.dismissedPlayerId || form?.strikerId || 0);
}
function getWicketDismissedPlayerId(form) {
  const wicketType = String(form?.wicketType || "").toUpperCase();

  if (wicketType === "RUN_OUT") {
    return Number(form?.dismissedPlayerId || 0);
  }

  return Number(form?.dismissedPlayerId || form?.strikerId || 0);
}

function getUniqueBalls(...sources) {
  const map = new Map();

  sources.flat().filter(Boolean).forEach((ball) => {
    const key = ball.id || ball.sequence || `${ball.inningsNo}-${ball.overNo}-${ball.ballInOver}`;
    map.set(String(key), ball);
  });

  return [...map.values()];
}

const availableNewBatters = useMemo(() => {
  if (!battingTeam?.players?.length) return [];

  const inningsNo = Number(ballForm.inningsNo || scoreboard?.currentInnings || 1);

  const allBalls = getUniqueBalls(
    matchDetail?.balls || [],
    scoreboard?.balls || [],
    scoreboard?.match?.balls || []
  ).filter((ball) => Number(ball.inningsNo || inningsNo) === inningsNo);

  const alreadyOutIds = new Set(
    allBalls
      .filter((ball) => {
        const dismissedPlayerId = Number(ball.dismissedPlayerId);
        if (!dismissedPlayerId) return false;

        const wicketType = String(ball.wicketType || "").trim().toUpperCase();

        return Boolean(ball.isWicket) && wicketType !== "RETIRED_HURT";
      })
      .map((ball) => Number(ball.dismissedPlayerId))
  );

  const strikerId = Number(ballForm.strikerId || 0);
  const nonStrikerId = Number(ballForm.nonStrikerId || 0);
  const dismissedPlayerId = getWicketDismissedPlayerId(ballForm);

  return battingTeam.players.filter((player) => {
    const playerId = Number(player.id);

    if (!playerId) return false;
    if (alreadyOutIds.has(playerId)) return false;
    if (playerId === strikerId) return false;
    if (playerId === nonStrikerId) return false;
    if (dismissedPlayerId && playerId === dismissedPlayerId) return false;

    return true;
  });
}, [
  battingTeam?.players,
  ballForm.inningsNo,
  ballForm.strikerId,
  ballForm.nonStrikerId,
  ballForm.dismissedPlayerId,
  ballForm.wicketType,
  matchDetail?.balls,
  scoreboard?.balls,
  scoreboard?.match?.balls,
  scoreboard?.currentInnings,
]);
const wicketNewBatterOptions = useMemo(() => {
  if (
    !battingTeam?.players?.length
  ) {
    return [];
  }

  const inningsNo =
    Number(
      ballForm.inningsNo ||
      scoreboard?.currentInnings ||
      1
    );

  /*
   * Use both ball history and scorecard rows.
   *
   * Ball history is the authoritative source for dismissedPlayerId.
   * Scorecard rows provide a fallback when the lightweight scoreboard
   * response does not include every raw ball.
   */
  const allBalls =
    getUniqueBalls(
      matchDetail?.balls ||
        [],
      scoreboard?.balls ||
        [],
      scoreboard?.match
        ?.balls ||
        []
    ).filter(
      (ball) =>
        Number(
          ball.inningsNo ||
          inningsNo
        ) ===
        inningsNo
    );

  const alreadyOutIds =
    new Set();

  for (
    const ball of
    allBalls
  ) {
    const dismissedPlayerId =
      Number(
        ball.dismissedPlayerId
      );

    if (
      !dismissedPlayerId
    ) {
      continue;
    }

    const wicketType =
      String(
        ball.wicketType ||
        ""
      )
        .trim()
        .toUpperCase();

    const countedAsWicket =
      Boolean(
        Number(
          ball.isWicket
        )
      ) ||
      Boolean(
        ball.isWicket
      );

    if (
      countedAsWicket &&
      ![
        "RETIRED_HURT",
        "NONE",
        "",
      ].includes(
        wicketType
      )
    ) {
      alreadyOutIds.add(
        dismissedPlayerId
      );
    }
  }

  const activeInnings =
    scoreboard?.innings?.find(
      (innings) =>
        Number(
          innings.number ??
          innings.inningsNo
        ) ===
        inningsNo
    ) ||
    scoreboard?.innings?.[
      inningsNo -
      1
    ];

  const scorecardRows =
    activeInnings
      ?.battingRows ||
    activeInnings
      ?.batting ||
    activeInnings
      ?.battingStats ||
    [];

  for (
    const row of
    scorecardRows
  ) {
    const playerId =
      Number(
        row.playerId ??
        row.batterId ??
        row.batsmanId ??
        row.id
      );

    if (!playerId) {
      continue;
    }

    const dismissalText =
      String(
        row.dismissal ??
        row.dismissalText ??
        row.status ??
        row.howOut ??
        ""
      )
        .trim()
        .toLowerCase();

    const isExplicitlyOut =
      row.isOut ===
        true ||
      Number(
        row.isOut
      ) ===
        1 ||
      (
        dismissalText &&
        dismissalText !==
          "not out" &&
        dismissalText !==
          "notout" &&
        dismissalText !==
          "-" &&
        dismissalText !==
          "batting" &&
        !dismissalText.includes(
          "retired hurt"
        )
      );

    if (
      isExplicitlyOut
    ) {
      alreadyOutIds.add(
        playerId
      );
    }
  }

  const currentStrikerId =
    Number(
      ballForm.strikerId ||
      0
    );

  const currentNonStrikerId =
    Number(
      ballForm.nonStrikerId ||
      0
    );

  const currentDismissedId =
    getWicketDismissedPlayerId(
      ballForm
    );

  return battingTeam.players.filter(
    (player) => {
      const playerId =
        Number(
          player.id
        );

      if (!playerId) {
        return false;
      }

      if (
        alreadyOutIds.has(
          playerId
        )
      ) {
        return false;
      }

      if (
        playerId ===
        currentStrikerId
      ) {
        return false;
      }

      if (
        playerId ===
        currentNonStrikerId
      ) {
        return false;
      }

      if (
        currentDismissedId &&
        playerId ===
          currentDismissedId
      ) {
        return false;
      }

      return true;
    }
  );
}, [
  battingTeam?.players,
  ballForm.inningsNo,
  ballForm.strikerId,
  ballForm.nonStrikerId,
  ballForm.dismissedPlayerId,
  ballForm.wicketType,
  matchDetail?.balls,
  scoreboard?.balls,
  scoreboard?.match?.balls,
  scoreboard?.innings,
  scoreboard?.currentInnings,
]);
useEffect(() => {
  if (!ballForm.isWicket) return;
  if (!ballForm.newBatterId) return;

  const stillAllowed = wicketNewBatterOptions.some(
    (player) => String(player.id) === String(ballForm.newBatterId)
  );

  if (!stillAllowed) {
    setBallForm((prev) => ({
      ...prev,
      newBatterId: "",
    }));
  }
}, [
  ballForm.isWicket,
  ballForm.newBatterId,
  wicketNewBatterOptions,
]);

const availableReplacementBatters = useMemo(() => {
  if (!battingTeam?.players?.length) return [];

  const balls =
    matchDetail?.balls ||
    scoreboard?.balls ||
    scoreboard?.match?.balls ||
    [];

  const legitimatelyOutIds = new Set(
    balls
      .filter((ball) => {
        if (!ball.dismissedPlayerId) return false;

        const wicketType = String(ball.wicketType || "")
          .trim()
          .toUpperCase();

        return Boolean(ball.isWicket) && wicketType !== "RETIRED_HURT";
      })
      .map((ball) => Number(ball.dismissedPlayerId))
  );

  return battingTeam.players.filter((player) => {
    const playerId = Number(player.id);

    if (playerId === Number(ballForm.strikerId)) return false;
    if (playerId === Number(ballForm.nonStrikerId)) return false;
    if (legitimatelyOutIds.has(playerId)) return false;

    return true;
  });
}, [
  battingTeam,
  ballForm.strikerId,
  ballForm.nonStrikerId,
  matchDetail,
  scoreboard,
]);
function getNextAvailableBatter(players, strikerId, nonStrikerId, balls = []) {
  if (!players?.length) return null;

  const legitimatelyOutIds = new Set(
    balls
      .filter((ball) => {
        if (!ball.dismissedPlayerId) return false;

        const wicketType = String(ball.wicketType || "").toUpperCase();

        return (
          ball.isWicket &&
          wicketType !== "RETIRED_HURT"
        );
      })
      .map((ball) => Number(ball.dismissedPlayerId))
  );

  return players.find((player) => {
    const playerId = Number(player.id);

    return (
      playerId !== Number(strikerId) &&
      playerId !== Number(nonStrikerId) &&
      !legitimatelyOutIds.has(playerId)
    );
  });
}

async function handleRetiredHurtSubmit() {
  if (isSavingBall) {
    return;
  }

  if (mustChangeBowler) {
    setError(
      "Please select a new bowler before scoring the next ball."
    );

    setShowRetiredHurtModal(
      false
    );

    setShowWicketModal(
      false
    );

    setBowlerSearchText(
      ""
    );

    setShowBowlerModal(
      true
    );

    return;
  }

  if (
    !replacementPlayerId
  ) {
    setError(
      "Select replacement batter"
    );

    return;
  }

  const dismissedPlayerId =
    retiredPlayerType ===
    "STRIKER"
      ? Number(
          ballForm.strikerId
        )
      : Number(
          ballForm.nonStrikerId
        );

  const retiredPlayer =
    retiredPlayerType ===
    "STRIKER"
      ? battingTeam?.players?.find(
          (player) =>
            Number(
              player.id
            ) ===
            Number(
              ballForm.strikerId
            )
        )
      : battingTeam?.players?.find(
          (player) =>
            Number(
              player.id
            ) ===
            Number(
              ballForm.nonStrikerId
            )
        );

  const replacementPlayer =
    battingTeam?.players?.find(
      (player) =>
        Number(
          player.id
        ) ===
        Number(
          replacementPlayerId
        )
    );

  const modalSnapshot = {
    replacementPlayerId,
    retiredPlayerType,
    ballForm: {
      ...ballForm,
    },
  };

  /*
   * Retired Hurt is a non-legal event but can still use submitBall() so the
   * optimized single-scoreboard-refresh path is shared with every other
   * scoring action.
   */
  setShowRetiredHurtModal(
    false
  );

  try {
    const saved =
      await submitBall({
        ...ballForm,

        matchId:
          Number(
            selectedMatchId
          ),

        inningsNo:
          Number(
            ballForm.inningsNo
          ),

        strikerId:
          Number(
            ballForm.strikerId
          ),

        nonStrikerId:
          Number(
            ballForm.nonStrikerId
          ),

        bowlerId:
          Number(
            ballForm.bowlerId
          ),

        isWicket:
          0,

        wicketType:
          "RETIRED_HURT",

        dismissedPlayerId,

        newBatterId:
          Number(
            replacementPlayerId
          ),

        runsOffBat:
          0,

        extras:
          0,

        extraType:
          "NONE",

        legalDelivery:
          false,

        note:
          `Retired hurt: ${retiredPlayer?.name || "Batter"} replaced by ${replacementPlayer?.name || "replacement batter"}.`,

        matchStatus:
          scoreboard?.match
            ?.status,
      });

    if (!saved) {
      setReplacementPlayerId(
        modalSnapshot.replacementPlayerId
      );

      setRetiredPlayerType(
        modalSnapshot.retiredPlayerType
      );

      setBallForm(
        modalSnapshot.ballForm
      );

      setShowRetiredHurtModal(
        true
      );

      return;
    }

    setMessage(
      `✅ ${retiredPlayer?.name || "Batter"} is retired hurt and replaced by ${replacementPlayer?.name || "replacement batter"}.`
    );

    setReplacementPlayerId(
      ""
    );
  } catch (err) {
    setReplacementPlayerId(
      modalSnapshot.replacementPlayerId
    );

    setRetiredPlayerType(
      modalSnapshot.retiredPlayerType
    );

    setBallForm(
      modalSnapshot.ballForm
    );

    setShowRetiredHurtModal(
      true
    );

    setError(
      err.message ||
        "Failed to retire hurt a player"
    );
  }
}

async function loadMyLeaguePermissions(leagueId) {
  if (!leagueId) return;

  const requestedLeagueId = String(leagueId);

  try {
    setPermissionsLoading(true);

    const data = await api(
      `/api/leagues/${leagueId}/permissions/me`
    );

    permissionsLeagueIdRef.current = requestedLeagueId;

    /*
     * Keep the authoritative league role returned by /permissions/me together
     * with the Boolean permission flags.  Captain/Scorer invite visibility is
     * role-driven; dropping data.role here caused activeLeagueRole to become
     * blank for accounts whose league-list payload did not also include
     * membershipRole.
     */
    setPermissions({
      ...(data.permissions || {}),
      role: String(data.role || data.permissions?.role || "").trim().toUpperCase(),
      isOwner: data.isOwner === true,
      isMember: data.isMember !== false,
    });
  } catch (err) {
    console.error(err);

    const browserIsOffline =
      typeof navigator !== "undefined" &&
      navigator.onLine === false;

    const status = Number(err?.status || 0);

    const retryablePermissionFailure =
      browserIsOffline ||
      isOfflineRetryableError(err) ||
      status === 0 ||
      status === 408 ||
      status === 425 ||
      status === 429 ||
      status >= 500;

    const cachedPermissionsBelongToThisLeague =
      String(permissionsLeagueIdRef.current || "") ===
      requestedLeagueId;

    /*
     * A temporary network/API problem is not a permission revocation. If this
     * exact league already had a successfully loaded permission object, keep
     * it so authorized scorers do not suddenly lose their keypad mid-match.
     */
    if (
      retryablePermissionFailure &&
      cachedPermissionsBelongToThisLeague &&
      permissions
    ) {
      if (browserIsOffline) {
        setOfflineSyncState((previous) => ({
          ...previous,
          online: false,
        }));
      }

      return;
    }

    const selected = leagues.find(
      (league) => String(league.id) === requestedLeagueId
    );

    if (
      selected?.isFollowing &&
      !selected?.role &&
      !selected?.membershipRole
    ) {
      permissionsLeagueIdRef.current = requestedLeagueId;

      setPermissions({
        canViewDashboard: true,
        canViewStats: true,
        canViewMatches: true,
        canViewManagement: false,
        canViewScoring: false,
        canCreateLeague: false,
        canCreateTeam: false,
        canCreateMatch: false,
        canDeleteLeague: false,
        canDeleteTeam: false,
        canDeletePlayer: false,
        canDeleteMatch: false,
        canScoreMatch: false,
        canEditScore: false,
        canUndoBall: false,
      });

      return;
    }

    /*
     * Do not carry a different league's permission state into this league.
     * 401/403 and other non-retryable responses remain authoritative.
     */
    permissionsLeagueIdRef.current = requestedLeagueId;
    setPermissions(null);
    setError(err.message);
  } finally {
    setPermissionsLoading(false);
  }
}
async function generateInviteLink(leagueId, role = selectedInviteRole) {
  if (!leagueId || inviteGenerating) return;

  if (!allowedInviteRolesForCurrentUser.includes(role)) {
    setError("Your current league role cannot create this type of invitation.");
    return;
  }

  if (
    role === "OWNER" &&
    typeof window !== "undefined" &&
    !window.confirm(
      "Owner access grants the highest league privileges, including member and permission management. Create this Owner invite link?"
    )
  ) {
    return;
  }

  try {
    setInviteGenerating(true);
    setError("");

    const data = await api(
      `/api/leagues/${leagueId}/invite`,
      {
        method: "POST",
        body: JSON.stringify({ role }),
      }
    );

    await navigator.clipboard.writeText(data.inviteLink);

    setShowInviteRoleModal(false);
    setMessage(
      `✅ ${data.roleLabel || ROLE_LABELS[role] || role} invite link copied.`
    );
    showToast(
      "success",
      `✅ ${data.roleLabel || ROLE_LABELS[role] || role} invite link copied`
    );
  } catch (inviteError) {
    setError(inviteError?.message || "Unable to create invitation link.");
  } finally {
    setInviteGenerating(false);
  }
}
function showPostMatchKitPrompt(result) {
  const nextAction =
    result?.nextAction || {};

  const kitCustody =
    result?.kitCustody || {};

  /*
   * The kit-custody prompt belongs to the first transition into a finished
   * match. Later transitions such as COMPLETED -> COMPLETED_LOCKED must not
   * reopen the same post-match workflow.
   */
  const promptedMatchId =
    Number(
      nextAction.matchId ||
      selectedMatchId
    );

  if (
    Number.isInteger(promptedMatchId) &&
    promptedMatchId > 0
  ) {
    postMatchKitAutoPromptedRef
      .current
      .add(promptedMatchId);
  }

  const selectedMatch =
    matches.find(
      (match) =>
        String(match.id) ===
        String(selectedMatchId)
    );

  const fallbackMatchLabel =
    selectedMatch
      ? `${
          selectedMatch.teamAName ||
          selectedMatch.teamA?.name ||
          "Team A"
        } vs ${
          selectedMatch.teamBName ||
          selectedMatch.teamB?.name ||
          "Team B"
        }`
      : "Completed match";

  setPostMatchKitPrompt({
    matchId:
      nextAction.matchId ||
      selectedMatchId,

    leagueId:
      nextAction.leagueId ||
      activeLeagueId,

    matchLabel:
      nextAction.matchLabel ||
      fallbackMatchLabel,

    taskCount:
      Number(
        kitCustody.pendingTaskCount ||
        0
      ),

    warning:
      kitCustody.warning || "",
  });
}

/*
 * AUTO-COMPLETION KIT FOLLOW-UP
 * =============================
 * A match can become COMPLETED directly from the final scored delivery
 * (target reached, final legal ball, all-out, etc.) without the scorer
 * pressing "End Match".
 *
 * The manual End / Lock / DLS routes already return kitCustody + nextAction.
 * The automatic scoring path did not, so Scorer Mode had no result object
 * to pass to showPostMatchKitPrompt().
 *
 * This helper calls a small sync-only endpoint. It DOES NOT change:
 * - the match result,
 * - scores,
 * - status text,
 * - innings,
 * - lock state,
 * - Super Over result.
 *
 * It only makes sure the completed match has its pending custody task(s)
 * and then opens the existing KitPostMatchPrompt.
 *
 * IMPORTANT:
 * A future/next scheduled match is NOT required. Custody belongs to the
 * match that just ended.
 */
async function syncAndShowPostMatchKitPrompt(
  matchId
) {
  const numericMatchId =
    Number(matchId);

  if (
    !Number.isInteger(
      numericMatchId
    ) ||
    numericMatchId <= 0
  ) {
    return;
  }

  /*
   * Prevent the automatic scoring path from opening the same popup more
   * than once if several scoreboard refreshes observe COMPLETED.
   *
   * Manual End/DLS may show the prompt when the match first finishes.
   * Lock is excluded because it is a later administrative state.
   */
  if (
    postMatchKitAutoPromptedRef
      .current
      .has(numericMatchId)
  ) {
    return;
  }

  postMatchKitAutoPromptedRef
    .current
    .add(numericMatchId);

  dispatchLeagueMatchAlert(
    numericMatchId,
    "MATCH_RESULT"
  );

  try {
    const result =
      await api(
        `/api/matches/${numericMatchId}/kit-custody/sync`,
        {
          method:
            "POST",
        }
      );

    showPostMatchKitPrompt(
      result
    );
  } catch (err) {
    console.error(
      "[POST_MATCH_KIT_AUTO_SYNC_FAILED]",
      err
    );

    /*
     * Still show the existing popup. The scorer must never lose the
     * post-match custody action merely because the background task sync
     * encountered a temporary problem.
     */
    showPostMatchKitPrompt({
      nextAction: {
        type:
          "RECORD_KIT_CUSTODY",

        leagueId:
          activeLeagueId,

        matchId:
          numericMatchId,
      },

      kitCustody: {
        pendingTaskCount:
          0,

        warning:
          err?.message ||
          "The match completed, but Cric4All could not verify the kit-custody task. Open Kit to confirm who took the kit home.",
      },
    });
  }
}

function openKitFromPostMatchPrompt() {
  const targetLeagueId =
    postMatchKitPrompt?.leagueId;

  const targetMatchId =
    postMatchKitPrompt?.matchId;

  const handledMatchId =
    Number(
      targetMatchId ||
      selectedMatchId
    );

  if (
    Number.isInteger(handledMatchId) &&
    handledMatchId > 0
  ) {
    postMatchKitAutoPromptedRef
      .current
      .add(handledMatchId);
  }

  if (targetLeagueId) {
    setActiveLeagueId(
      Number(targetLeagueId)
    );
  }

  if (targetMatchId) {
    setSelectedMatchId(
      String(targetMatchId)
    );
  }

  /*
   * Keep the existing Matches navigation and open the existing KIT subtab.
   * This preserves the Create / Active / Scheduled / Kit / Completed row.
   */
  setActiveTab("matches");
  setMatchesSubTab("KIT");
  setPostMatchKitPrompt(null);

  setMessage(
    "🧳 Record the final kit holder below. The completed match can be locked from the Match completed panel at the top of this Kit tab."
  );
}



function getSuperOverTeam(
  state,
  teamId
) {
  if (!state?.teams) return null;

  if (
    Number(state.teams.teamA?.id) ===
    Number(teamId)
  ) {
    return state.teams.teamA;
  }

  if (
    Number(state.teams.teamB?.id) ===
    Number(teamId)
  ) {
    return state.teams.teamB;
  }

  return null;
}

function superOverPlayerName(
  state,
  playerId
) {
  if (!playerId) return "—";

  const players = [
    ...(state?.teams?.teamA?.players || []),
    ...(state?.teams?.teamB?.players || []),
  ];

  return (
    players.find(
      (player) =>
        Number(player.id) ===
        Number(playerId)
    )?.name ||
    "Player"
  );
}

async function fetchSuperOverState(
  matchId
) {
  return api(
    `/api/matches/${matchId}/super-over`
  );
}

async function openSuperOver(
  matchOrId
) {
  const matchId =
    Number(
      typeof matchOrId === "object"
        ? matchOrId?.id
        : matchOrId
    );

  if (
    !Number.isInteger(matchId) ||
    matchId <= 0
  ) {
    setError(
      "Unable to identify the tied match for Super Over."
    );
    return;
  }

  try {
    setSuperOverBusy(true);
    setSuperOverError("");

    const state =
      await fetchSuperOverState(
        matchId
      );

    if (
      !state.eligible &&
      !state.exists
    ) {
      throw new Error(
        "Super Over is available only after a tied match."
      );
    }

    /*
     * Match History passes its formatted match object.
     * Scorer Mode only needs the match id, so build the small display object
     * from the API response there. This keeps one modal/flow for both places.
     */
    setSuperOverMatch({
      id: matchId,
      teamAId:
        state.teams?.teamA?.id ||
        matchOrId?.teamAId,
      teamBId:
        state.teams?.teamB?.id ||
        matchOrId?.teamBId,
      teamAName:
        state.teams?.teamA?.name ||
        matchOrId?.teamAName ||
        "Team A",
      teamBName:
        state.teams?.teamB?.name ||
        matchOrId?.teamBName ||
        "Team B",
    });

    setSuperOverState(state);

    setSuperOverSetup({
      batter1Id: "",
      batter2Id: "",
      batter3Id: "",
      bowlerId: "",
    });

    setShowSuperOverModal(true);
  } catch (err) {
    const message =
      err.message ||
      "Unable to open Super Over.";

    /*
     * When opened from Scorer Mode, keep the error visible in the scorer.
     * When opened from Match History, the existing global error area still
     * receives the same message.
     */
    setSuperOverError(message);
    setError(message);
  } finally {
    setSuperOverBusy(false);
  }
}

async function startSuperOverRound() {
  if (!superOverMatch?.id) return;

  try {
    setSuperOverBusy(true);
    setSuperOverError("");

    const result = await api(
      `/api/matches/${superOverMatch.id}/super-over`,
      {
        method: "POST",
        body: JSON.stringify({
          action:
            "START_ROUND",
        }),
      }
    );

    setSuperOverState(
      result.state
    );

    setSuperOverSetup({
      batter1Id: "",
      batter2Id: "",
      batter3Id: "",
      bowlerId: "",
    });

    await loadMatches();
  } catch (err) {
    setSuperOverError(
      err.message ||
      "Unable to start Super Over."
    );
  } finally {
    setSuperOverBusy(false);
  }
}

async function setupSuperOverInnings() {
  if (
    !superOverMatch?.id ||
    !superOverState?.currentSuperInnings
  ) {
    return;
  }

  try {
    setSuperOverBusy(true);
    setSuperOverError("");

    const result = await api(
      `/api/matches/${superOverMatch.id}/super-over`,
      {
        method: "POST",
        body: JSON.stringify({
          action: "SETUP",
          superInnings:
            superOverState.currentSuperInnings,
          batter1Id:
            Number(
              superOverSetup.batter1Id
            ),
          batter2Id:
            Number(
              superOverSetup.batter2Id
            ),
          batter3Id:
            superOverSetup.batter3Id
              ? Number(
                  superOverSetup.batter3Id
                )
              : null,
          bowlerId:
            Number(
              superOverSetup.bowlerId
            ),
        }),
      }
    );

    setSuperOverState(
      result.state
    );
  } catch (err) {
    setSuperOverError(
      err.message ||
      "Unable to set Super Over players."
    );
  } finally {
    setSuperOverBusy(false);
  }
}

async function scoreSuperOverBall({
  runsOffBat = 0,
  extras = 0,
  extraType = "NONE",
  isWicket = false,
}) {
  if (!superOverMatch?.id) return;

  try {
    setSuperOverBusy(true);
    setSuperOverError("");

    const result = await api(
      `/api/matches/${superOverMatch.id}/super-over`,
      {
        method: "POST",
        body: JSON.stringify({
          action: "BALL",
          runsOffBat,
          extras,
          extraType,
          isWicket,
        }),
      }
    );

    setSuperOverState(
      result.state
    );

    // Keep the main scorer/scoreboard in sync with MatchEvent-based
    // Super Over state. This is essential because Match.status remains
    // COMPLETED throughout the tie-breaker flow.
    await loadSelectedMatch(superOverMatch.id, {
      loadDetail: true,
      loadStatsData: false,
      syncBallForm: false,
    });

    if (result.state?.completed) {
      setScorerMode(false);
      setScorerDrawer(null);
      setScoringSubTab("SCOREBOARD");

      /*
       * A tied main match deliberately skips the automatic custody popup.
       * Once the Super Over has a final result, this is the true end of
       * the match and custody must be confirmed even when no future match
       * has been scheduled.
       */
      await syncAndShowPostMatchKitPrompt(
        superOverMatch.id
      );
    }

    if (
      result.state?.currentSuperInnings &&
      (
        (
          result.state.currentSuperInnings === 2 &&
          !result.state.second?.setup
        ) ||
        (
          result.state.currentSuperInnings === 1 &&
          !result.state.first?.setup
        )
      )
    ) {
      setSuperOverSetup({
        batter1Id: "",
        batter2Id: "",
        batter3Id: "",
        bowlerId: "",
      });
    }

    if (
      result.state?.completed ||
      result.state?.tied
    ) {
      await loadMatches();
    }
  } catch (err) {
    setSuperOverError(
      err.message ||
      "Unable to save Super Over delivery."
    );
  } finally {
    setSuperOverBusy(false);
  }
}

async function undoSuperOverBall() {
  if (!superOverMatch?.id) return;

  try {
    setSuperOverBusy(true);
    setSuperOverError("");

    const result = await api(
      `/api/matches/${superOverMatch.id}/super-over`,
      {
        method: "POST",
        body: JSON.stringify({
          action: "UNDO",
        }),
      }
    );

    setSuperOverState(
      result.state
    );
  } catch (err) {
    setSuperOverError(
      err.message ||
      "Unable to undo Super Over delivery."
    );
  } finally {
    setSuperOverBusy(false);
  }
}

async function openDlsModal() {
  if (!selectedMatchId || !scoreboard) return;

  const currentInnings = Number(
    scoreboard.currentInnings ||
    ballForm.inningsNo ||
    1
  );

  try {
    setDlsBusy(true);
    setError("");

    const state = await api(
      `/api/matches/${selectedMatchId}/dls`
    );

    setDlsState(state);

    const allocation =
      currentInnings === 1
        ? state.innings1Allocation
        : state.innings2Allocation;

    setDlsError("");

    setDlsForm((prev) => ({
      ...prev,
      mode: "STANDARD",
      officialAction: "",

      /*
       * Do NOT pre-fill the current allocation.
       * A DLS revision must reduce the available overs, so pre-filling "20"
       * when the current allocation is already 20 looks actionable but is
       * actually invalid.
       */
      revisedOvers: "",

      target:
        state.latest?.target != null
          ? String(state.latest.target)
          : "",
      par:
        state.latest?.par != null
          ? String(state.latest.par)
          : "",
      note: "",
    }));

    setShowDlsModal(true);
  } catch (err) {
    setError(
      err.message ||
      "Unable to load DLS."
    );
  } finally {
    setDlsBusy(false);
  }
}

async function handleApplyDls() {
  if (!selectedMatchId || !scoreboard) return;

  const inningsNo = Number(
    scoreboard.currentInnings ||
    ballForm.inningsNo ||
    1
  );

  const currentAllocation =
    inningsNo === 1
      ? Number(dlsState?.innings1Allocation || 0)
      : Number(dlsState?.innings2Allocation || 0);

  const revisedOvers =
    Number(dlsForm.revisedOvers);

  setDlsError("");

  if (
    !Number.isFinite(revisedOvers) ||
    revisedOvers <= 0
  ) {
    setDlsError(
      "Enter the new reduced total overs before applying the revision."
    );
    return;
  }

  if (
    dlsForm.mode === "STANDARD" &&
    currentAllocation > 0 &&
    revisedOvers >= currentAllocation
  ) {
    setDlsError(
      `Revised total overs must be lower than the current allocation of ${currentAllocation} overs.`
    );
    return;
  }

  if (
    dlsForm.mode === "OFFICIAL_OVERRIDE" &&
    dlsForm.officialAction === "RESUME" &&
    (
      !Number.isInteger(
        Number(dlsForm.target)
      ) ||
      Number(dlsForm.target) <= 0
    )
  ) {
    setDlsError(
      "Enter the revised target supplied by the official or authorized DLS calculator."
    );
    return;
  }

  try {
    setDlsBusy(true);
    setError("");
    setDlsError("");

    const action =
      dlsForm.mode ===
      "OFFICIAL_OVERRIDE"
        ? "OFFICIAL_OVERRIDE"
        : "STANDARD_INTERRUPTION";

    const result = await api(
      `/api/matches/${selectedMatchId}/dls`,
      {
        method: "POST",
        body: JSON.stringify({
          action,
          inningsNo,
          revisedOvers,
          target:
            dlsForm.target,
          par:
            dlsForm.par,
          note:
            dlsForm.note,
        }),
      }
    );

    setDlsState(
      result.state
    );

    await loadSelectedMatch(
      selectedMatchId
    );

    setShowDlsModal(false);

    setMessage(
      action ===
        "OFFICIAL_OVERRIDE"
        ? "Official DLS revision applied. Continue the chase using the revised target."
        : inningsNo === 2
          ? `D/L Standard target revised to ${result.event.target}.`
          : "First-innings rain interruption recorded."
    );
  } catch (err) {
    const message =
      err.message ||
      "Unable to apply DLS.";

    /*
     * DLS errors must be visible INSIDE the modal. The global scorer error
     * sits behind this fixed dialog and previously made the button look dead.
     */
    setDlsError(message);
  } finally {
    setDlsBusy(false);
  }
}

async function handleEndOfficialDls() {
  if (
    !selectedMatchId ||
    !scoreboard
  ) {
    return;
  }

  setDlsError("");

  const inningsNo =
    Number(
      scoreboard.currentInnings ||
      ballForm.inningsNo ||
      1
    );

  if (
    inningsNo !== 2
  ) {
    setDlsError(
      "An official DLS result can be finalized only during the second innings."
    );
    return;
  }

  const officialPar =
    Number(
      dlsForm.par
    );

  if (
    !Number.isInteger(
      officialPar
    ) ||
    officialPar < 0
  ) {
    setDlsError(
      "Enter the official DLS par at the exact point play was suspended."
    );
    return;
  }

  /*
   * The authorized calculator may also provide a revised target. If this
   * match already has an official/revised target, preserve it. Otherwise use
   * the currently active target only as the transport value required by the
   * existing OFFICIAL_OVERRIDE endpoint; the termination result itself is
   * determined from the official PAR entered above.
   */
  const officialTarget =
    Number(
      dlsForm.target ||
      dlsState
        ?.latest
        ?.target ||
      scoreboard
        ?.summary
        ?.dls
        ?.target ||
      scoreboard
        ?.summary
        ?.target ||
      0
    );

  if (
    !Number.isInteger(
      officialTarget
    ) ||
    officialTarget <= 0
  ) {
    setDlsError(
      "Enter the official target supplied with the DLS calculation before ending the match."
    );
    return;
  }

  const currentAllocation =
    Number(
      dlsState
        ?.innings2Allocation ||
      scoreboard
        ?.match
        ?.oversPerInnings ||
      0
    );

  const officialAllocation =
    Number(
      dlsForm.revisedOvers ||
      currentAllocation
    );

  if (
    !Number.isFinite(
      officialAllocation
    ) ||
    officialAllocation <= 0
  ) {
    setDlsError(
      "Unable to determine the innings allocation. Enter the revised total overs supplied with the official DLS calculation."
    );
    return;
  }

  const currentRuns =
    Number(
      scoreboard
        ?.innings
        ?.[1]
        ?.runs ||
      0
    );

  const difference =
    currentRuns -
    officialPar;

  const positionText =
    difference > 0
      ? `The chasing side is ${difference} run${
          difference === 1
            ? ""
            : "s"
        } above the official par.`
      : difference < 0
        ? `The chasing side is ${Math.abs(
            difference
          )} run${
            Math.abs(
              difference
            ) === 1
              ? ""
              : "s"
          } below the official par.`
        : "The score is exactly level with the official par.";

  const confirmed =
    window.confirm(
      `${positionText}\n\nEnd the match now using official DLS par ${officialPar}?`
    );

  if (
    !confirmed
  ) {
    return;
  }

  try {
    setDlsBusy(true);
    setError("");
    setDlsError("");

    /*
     * Save exactly the externally supplied Official DLS figures first.
     * Cric4All does not calculate or substitute an official par.
     */
    const overrideResult =
      await api(
        `/api/matches/${selectedMatchId}/dls`,
        {
          method:
            "POST",

          body:
            JSON.stringify({
              action:
                "OFFICIAL_OVERRIDE",

              inningsNo:
                2,

              revisedOvers:
                officialAllocation,

              target:
                officialTarget,

              par:
                officialPar,

              note:
                dlsForm.note,
            }),
        }
      );

    setDlsState(
      overrideResult.state
    );

    const dlsResult =
      await api(
        `/api/matches/${selectedMatchId}/dls`,
        {
          method:
            "POST",

          body:
            JSON.stringify({
              action:
                "TERMINATE",

              inningsNo:
                2,
            }),
        }
      );

    const resultText =
      dlsResult
        ?.event
        ?.resultText;

    if (
      !resultText
    ) {
      throw new Error(
        "Unable to determine the official DLS result from the entered par."
      );
    }

    const endResult =
      await api(
        `/api/matches/${selectedMatchId}/end`,
        {
          method:
            "POST",

          body:
            JSON.stringify({
              matchEndType:
                "DLS",

              statusText:
                resultText,
            }),
        }
      );

    setShowDlsModal(
      false
    );

    await loadMatches();

    await loadSelectedMatch(
      selectedMatchId
    );

    setMessage(
      resultText
    );

    dispatchLeagueMatchAlert(
      selectedMatchId,
      "MATCH_RESULT"
    );

    showPostMatchKitPrompt(
      endResult
    );
  } catch (err) {
    setDlsError(
      err.message ||
      "Unable to end the match using Official DLS."
    );
  } finally {
    setDlsBusy(false);
  }
}

async function handleEndByDls() {
  if (!selectedMatchId) return;

  setDlsError("");

  const confirmed =
    window.confirm(
      "End this match now using the current DLS par score?"
    );

  if (!confirmed) return;

  try {
    setDlsBusy(true);
    setError("");
    setDlsError("");

    const dlsResult =
      await api(
        `/api/matches/${selectedMatchId}/dls`,
        {
          method: "POST",
          body:
            JSON.stringify({
              action:
                "TERMINATE",
              inningsNo: 2,
            }),
        }
      );

    const resultText =
      dlsResult?.event
        ?.resultText;

    if (!resultText) {
      throw new Error(
        "Unable to determine the DLS result."
      );
    }

    const endResult =
      await api(
        `/api/matches/${selectedMatchId}/end`,
        {
          method: "POST",
          body:
            JSON.stringify({
              matchEndType:
                "DLS",
              statusText:
                resultText,
            }),
        }
      );

    setShowDlsModal(false);

    await loadMatches();
    await loadSelectedMatch(
      selectedMatchId
    );

    setMessage(resultText);

    dispatchLeagueMatchAlert(
      selectedMatchId,
      "MATCH_RESULT"
    );

    showPostMatchKitPrompt(
      endResult
    );
  } catch (err) {
    const message =
      err.message ||
      "Unable to end match by DLS.";

    setDlsError(message);
  } finally {
    setDlsBusy(false);
  }
}

async function handleEndMatch() {
  if (offlineSyncState.pending > 0 || offlineSyncState.syncing) {
    setError("Sync all offline scoring changes before finalizing or locking this match.");
    return;
  }

  const confirmed = window.confirm(
    "End this match? No more scoring will be allowed."
  );

  if (!confirmed) return;

  try {
    const result = await api(
      `/api/matches/${selectedMatchId}/end`,
      {
        method: "POST",
        body: JSON.stringify({
          matchEndType: "End",
        }),
      }
    );

    await loadMatches();
    await loadSelectedMatch(
      selectedMatchId
    );

    setMessage(
      "Match ended successfully. Confirm who took the kit home."
    );

    dispatchLeagueMatchAlert(
      selectedMatchId,
      "MATCH_RESULT"
    );

    showPostMatchKitPrompt(result);
  } catch (err) {
    setError(
      err.message ||
      "Failed to end match"
    );
  }
}
async function handleLockMatch() {
  if (
    offlineSyncState.pending > 0 ||
    offlineSyncState.syncing ||
    offlineSyncState.conflict
  ) {
    setError(
      "Sync all offline scoring changes before finalizing or locking this match."
    );
    return;
  }

  const confirmed =
    window.confirm(
      "Lock this match? Once locked, this match cannot be edited or scored further."
    );

  if (!confirmed) return;

  const numericMatchId =
    Number(selectedMatchId);

  /*
   * LOCK + KIT CUSTODY FALLBACK
   * ===========================
   * Normally the kit prompt is shown when the match first becomes COMPLETED.
   * DLS/offline/server timing can, however, allow the scorer to reach Lock
   * without ever seeing that prompt.
   *
   * Do NOT mark the match as already prompted before Lock. After the server
   * confirms the lock, show the workflow only when it has not already been
   * presented for this match.
   */
  const kitPromptWasAlreadyShown =
    Number.isInteger(numericMatchId) &&
    numericMatchId > 0 &&
    postMatchKitAutoPromptedRef
      .current
      .has(numericMatchId);

  setPostMatchKitPrompt(null);

  try {
    const result = await api(
      `/api/matches/${selectedMatchId}/end`,
      {
        method: "POST",
        body: JSON.stringify({
          matchEndType: "Lock",
        }),
      }
    );

    await loadMatches();
    await loadSelectedMatch(
      selectedMatchId
    );

    if (
      !kitPromptWasAlreadyShown &&
      Number.isInteger(numericMatchId) &&
      numericMatchId > 0
    ) {
      if (
        result?.nextAction ||
        result?.kitCustody
      ) {
        showPostMatchKitPrompt(result);
      } else {
        await syncAndShowPostMatchKitPrompt(
          numericMatchId
        );
      }
    }

    setMessage(
      kitPromptWasAlreadyShown
        ? "🔒 Match locked successfully."
        : "🔒 Match locked successfully. Confirm who took the kit home."
    );
  } catch (err) {
    setError(
      err.message ||
      "Failed to lock match"
    );
  }
}
async function handleAbandonMatch() {
  const confirmed = window.confirm(
    "Abandon this match? Once abandoned, this match cannot be edited or scored further."
  );

  if (!confirmed) return;

  try {
    const result = await api(
      `/api/matches/${selectedMatchId}/end`,
      {
        method: "POST",
        body: JSON.stringify({
          matchEndType: "Abandon",
        }),
      }
    );

    await loadMatches();
    await loadSelectedMatch(
      selectedMatchId
    );

    setMessage(
      "Match abandoned. Confirm whether someone took the kit home."
    );

    dispatchLeagueMatchAlert(
      selectedMatchId,
      "MATCH_RESULT"
    );

    showPostMatchKitPrompt(result);
  } catch (err) {
    setError(
      err.message ||
      "Failed to abandon match"
    );
  }
}
async function confirmBowlerChange() {
  try {
    const newBowlerId =
      Number(
        ballForm.bowlerId
      );

    if (!newBowlerId) {
      setError(
        "Please select a new bowler."
      );

      return;
    }

    const selectedBowler =
      bowlingTeam
        ?.players
        ?.find(
          (player) =>
            Number(
              player.id
            ) ===
            newBowlerId
        );

    /*
     * OFFLINE SCORING:
     * ----------------
     * A bowler change at the start of a new over is local scoring state,
     * not a delivery by itself.
     *
     * When Chrome/Capacitor is offline, do NOT call the server
     * /change-bowler endpoint. The next queued Ball already carries
     * bowlerId, and that delivery is what will be replayed to the server
     * when connectivity returns.
     *
     * This also prevents the mandatory Change Bowler modal from becoming
     * impossible to close while offline.
     */
    const browserIsOffline =
      typeof navigator !==
        "undefined" &&
      navigator.onLine ===
        false;

    const appIsOffline =
      offlineSyncState?.online === false ||
      Boolean(offlineSyncState?.conflict);

    if (
      browserIsOffline ||
      appIsOffline
    ) {
      const localBoard =
        scoreboard
          ? {
              ...scoreboard,

              currentState:
                scoreboard
                  .currentState
                  ? {
                      ...scoreboard
                        .currentState,

                      bowlerId:
                        newBowlerId,

                      bowlerName:
                        selectedBowler
                          ?.name ||
                        scoreboard
                          .currentState
                          .bowlerName,

                      /*
                       * A new over begins with fresh bowler figures for the
                       * live popup only if the existing scoreboard does not
                       * already have this bowler's current spell data.
                       * Do not fabricate server statistics here.
                       */
                    }
                  : scoreboard
                      .currentState,
            }
          : scoreboard;

      if (localBoard) {
        setScoreboard(
          localBoard
        );

        /*
         * Persist the locally selected bowler with the cached match
         * snapshot. If the scorer refreshes while still offline, the
         * selected bowler remains available for the next delivery.
         */
        await cacheOfflineMatchSnapshot(
          selectedMatchId,
          {
            scoreboard:
              localBoard,

            matchDetail:
              matchDetail ||
              null,

            ballForm: {
              ...ballForm,

              bowlerId:
                newBowlerId,
            },

            savedAt:
              new Date()
                .toISOString(),
          }
        ).catch(
          (
            cacheError
          ) => {
            console.warn(
              "[OFFLINE_BOWLER_CACHE_FAILED]",
              cacheError
            );
          }
        );
      }

      setBallForm(
        (
          previous
        ) => ({
          ...previous,

          bowlerId:
            newBowlerId,

          isWicket:
            false,

          wicketType:
            "NONE",

          dismissedPlayerId:
            "",

          newBatterId:
            "",
        })
      );

      setMustChangeBowler(
        false
      );

      setShowBowlerModal(
        false
      );

      setShowWicketModal(
        false
      );

      setWicketSubmissionInFlight(
        false
      );

      setPendingBallData(
        null
      );

      setBowlerSearchText(
        ""
      );

      setError(
        ""
      );

      setMessage(
        `📴 ${
          selectedBowler
            ?.name ||
          "Selected bowler"
        } selected for the next over · saved locally.`
      );

      return;
    }

    /*
     * ONLINE PATH:
     * Preserve the existing server behavior exactly as before.
     */
    await api(
      `/api/matches/${selectedMatchId}/change-bowler`,
      {
        method:
          "POST",

        body:
          JSON.stringify({
            bowlerId:
              newBowlerId,

            inningsNo:
              Number(
                ballForm.inningsNo
              ),

            strikerId:
              Number(
                ballForm.strikerId
              ),

            nonStrikerId:
              Number(
                ballForm.nonStrikerId
              ),
          }),
      }
    );

    /*
     * Fetch only the scoreboard. A full match + match-list reload can
     * overwrite the just-confirmed wicket/replacement state.
     */
    const updatedBoard =
      await api(
        `/api/scoreboard/${selectedMatchId}`
      );

    setScoreboard(
      updatedBoard
    );

    setBallForm(
      (
        previous
      ) => ({
        ...previous,

        strikerId:
          updatedBoard
            ?.currentState
            ?.strikerId ??
          previous.strikerId,

        nonStrikerId:
          updatedBoard
            ?.currentState
            ?.nonStrikerId ??
          previous.nonStrikerId,

        bowlerId:
          newBowlerId,

        isWicket:
          false,

        wicketType:
          "NONE",

        dismissedPlayerId:
          "",

        newBatterId:
          "",
      })
    );

    setMustChangeBowler(
      false
    );

    setShowBowlerModal(
      false
    );

    setShowWicketModal(
      false
    );

    setWicketSubmissionInFlight(
      false
    );

    setPendingBallData(
      null
    );

    setBowlerSearchText(
      ""
    );

    setMessage(
      `✅ Bowler changed to ${
        selectedBowler?.name ||
        "selected bowler"
      }.`
    );
  } catch (err) {
    /*
     * If connectivity disappears between the online/offline check and the
     * request itself, treat the selection as an offline bowler change
     * instead of trapping the scorer in the mandatory modal.
     */
    if (
      isOfflineRetryableError(
        err
      )
    ) {
      const newBowlerId =
        Number(
          ballForm.bowlerId
        );

      const selectedBowler =
        bowlingTeam
          ?.players
          ?.find(
            (player) =>
              Number(
                player.id
              ) ===
              newBowlerId
          );

      setBallForm(
        (
          previous
        ) => ({
          ...previous,

          bowlerId:
            newBowlerId,

          isWicket:
            false,

          wicketType:
            "NONE",

          dismissedPlayerId:
            "",

          newBatterId:
            "",
        })
      );

      setMustChangeBowler(
        false
      );

      setShowBowlerModal(
        false
      );

      setShowWicketModal(
        false
      );

      setWicketSubmissionInFlight(
        false
      );

      setPendingBallData(
        null
      );

      setBowlerSearchText(
        ""
      );

      setOfflineSyncState(
        (
          previous
        ) => ({
          ...previous,

          online:
            false,

          syncing:
            false,

          lastError:
            "Bowler selection saved locally. It will be carried by the next queued delivery.",
        })
      );

      setError(
        ""
      );

      setMessage(
        `📴 ${
          selectedBowler
            ?.name ||
          "Selected bowler"
        } selected for the next over · saved locally.`
      );

      return;
    }

    setError(
      err.message
    );
  }
}

function handleCloseBowlerModal() {
  if (mustChangeBowler) {
    setError("Please select a new bowler before scoring the next ball.");
    setBowlerSearchText("");
    setShowBowlerModal(true);
    return;
  }

  setShowBowlerModal(false);
  setPendingBallData(null);
}
function normalizeStatus(status) {
  return String(status || "")
    .trim()
    .replace(/([a-z])([A-Z])/g, "$1_$2")
    .replace(/[\s-]+/g, "_")
    .toUpperCase();
}

function isCompletedStatus(status) {
  const s = normalizeStatus(status);

  return (
    s === "COMPLETED" ||
    s === "COMPLETED_LOCKED" ||
    s === "COMPLETED_CORRECTED" ||
    s === "COMPLETED_ABANDONED" ||
    s === "LOCKED" ||
    s === "ABANDONED" ||
    s.includes("COMPLETED") ||
    s.includes("LOCKED")
  );
}

function isActiveStatus(status) {
  const s = normalizeStatus(status);

  return (
    s === "LIVE" ||
    s === "IN_PROGRESS" ||
    s === "STARTED"
  );
}

const activeMatches = matches.filter((m) =>
  isActiveStatus(m.status)
);

const completedMatches = matches.filter((m) =>
  isCompletedStatus(m.status)
);



async function confirmStartMatch() {
  const matchId = Number(startMatchData.matchId || selectedMatchId);

  if (!matchId || !startMatchData.battingFirstTeamId) {
    setError("Please select batting first team.");
    return;
  }

  try {
    await api(`/api/matches/${matchId}/start`, {
      method: "POST",
      body: JSON.stringify({
        battingFirstTeamId: Number(startMatchData.battingFirstTeamId),
      }),
    });

    dispatchLeagueMatchAlert(
      matchId,
      "MATCH_START"
    );

    setShowStartMatchModal(false);
    setMessage("✅ Match started. Opening scoring...");

    await loadMatches(activeLeagueId);

    await openScoringAfterBattingFirst(matchId);
  } catch (err) {
    setError(err.message || "Unable to start match.");
  }
}
useEffect(() => {
  if (!pendingDeliverySetupAfterStart) return;
  if (activeTab !== "scoring") return;
  if (!selectedMatchId) return;
  if (!scoreboard?.match) return;
  if (!matchDetail) return;
  if (showStartMatchModal) return;

  const hasBalls =
    (matchDetail?.balls || []).length > 0;

  if (hasBalls) {
    setPendingDeliverySetupAfterStart(false);
    return;
  }

  setDeliverySetupReason(
    "Select opening striker, non-striker, and bowler before scoring the first ball."
  );

  setShowDeliverySetupModal(true);
  setPendingDeliverySetupAfterStart(false);
}, [
  pendingDeliverySetupAfterStart,
  activeTab,
  selectedMatchId,
  scoreboard?.match?.id,
  matchDetail?.id,
  showStartMatchModal,
]);

useEffect(() => {
  if (activeTab !== "scoring") return;

  if (!selectedMatchId) {
    setMatchDetail(null);
    setScoreboard(null);
    setStats({ batting: [], bowling: [] });
    setOptimisticScoreboard(null);
    setShowAdvancedSheet(false);
    setShowBowlerModal(false);
    setShowWicketModal(false);
    setShowExtrasModal(false);
    setShowRetiredHurtModal(false);
  }
}, [activeTab, selectedMatchId]);

useEffect(() => {
  if (!pendingSecondInningsSetup) return;

  setShowDeliverySetupModal(true);
  setPendingSecondInningsSetup(false);
}, [pendingSecondInningsSetup]);



const scoringMatches = useMemo(() => {
  let list = [...(matches || [])];

  if (activeLeagueId) {
    list = list.filter(
      (match) => Number(match.leagueId) === Number(activeLeagueId)
    );
  }

  if (contextFilters?.seriesIds?.length) {
    list = list.filter((match) =>
      contextFilters.seriesIds.includes(Number(match.seriesId))
    );
  }

  if (contextFilters?.years?.length) {
    list = list.filter((match) => {
      const matchDate =
        match.startedAt || match.scheduledAt || match.endedAt || match.createdAt;

      if (!matchDate) return false;

      return contextFilters.years.includes(new Date(matchDate).getFullYear());
    });
  }

  return sortMatchesForSelection(list);
}, [matches, activeLeagueId, contextFilters]);

useEffect(() => {
  if (!selectedMatchId) return;

  const stillExists = scoringMatches.some(
    (match) => Number(match.id) === Number(selectedMatchId)
  );

  if (!stillExists) {
    const preserveOfflineResumeMatch =
      isTrueOfflineResume &&
      requestedDashboardTab === "scoring" &&
      Number(requestedMatchId) === Number(selectedMatchId);

    /*
     * Offline resume has no server-backed scoringMatches list. The selected
     * match is restored from IndexedDB, so an empty online list must not be
     * interpreted as "match no longer exists".
     */
    if (preserveOfflineResumeMatch) {
      return;
    }

    setSelectedMatchId("");
    setMatchDetail(null);
    setScoreboard(null);
    setOptimisticScoreboard(null);
  }
}, [
  scoringMatches,
  selectedMatchId,
  isTrueOfflineResume,
  requestedDashboardTab,
  requestedMatchId,
]);

function triggerQuickAction(actionKey, callback) {
  setActiveQuickAction(actionKey);

  callback();

  setTimeout(() => {
    setActiveQuickAction(null);
  }, 50); // was 400
}

const editMatchLeagueTeams = useMemo(() => {
  if (!editingMatch) return [];

  const targetLeagueId = Number(
    editingMatch.leagueId || activeLeagueId
  );

  return [...(teams || [])]
    .filter(
      (team) =>
        Number(team.leagueId) === targetLeagueId
    )
    .sort((first, second) =>
      String(first.name || "").localeCompare(
        String(second.name || ""),
        undefined,
        {
          sensitivity: "base",
          numeric: true,
        }
      )
    );
}, [teams, editingMatch, activeLeagueId]);

const editTeamA = useMemo(
  () =>
    editMatchLeagueTeams.find(
      (team) =>
        Number(team.id) ===
        Number(editMatchForm.teamAId)
    ) || null,
  [editMatchLeagueTeams, editMatchForm.teamAId]
);

const editTeamB = useMemo(
  () =>
    editMatchLeagueTeams.find(
      (team) =>
        Number(team.id) ===
        Number(editMatchForm.teamBId)
    ) || null,
  [editMatchLeagueTeams, editMatchForm.teamBId]
);

const displayScoreboard =
  optimisticScoreboard ||
  scoreboard;

const liveMatchCenter =
  buildLiveMatchCenter(
    displayScoreboard ||
      scoreboard,
    hasOfflineLocalState,
    dlsState
  );

const dlsActiveForDisplay =
  Boolean(
    liveMatchCenter
      ?.dlsActive ||
    displayScoreboard
      ?.summary
      ?.dls
      ?.active
  );

const dlsAwareResultText =
  dlsActiveForDisplay
    ? buildOfflineLocalResultText(
        displayScoreboard ||
          scoreboard,
        liveMatchCenter
      )
    : "";

const offlineLocalResultText =
  hasOfflineLocalState
    ? buildOfflineLocalResultText(
        displayScoreboard ||
          scoreboard,
        liveMatchCenter
      )
    : "";

const matchInsights =
  buildMatchInsights(
    filterScoreboardForPlayerAnalytics(
      displayScoreboard
    )
  );

const dashboardResultText =
  displayScoreboard
    ?.superOver
    ?.completed
    ? (
        displayScoreboard
          .superOver
          .resultText ||
        "Match completed via Super Over"
      )
    : dlsAwareResultText ||
      offlineLocalResultText ||
      (
        displayScoreboard
          ?.summary
          ?.statusText &&
        String(
          displayScoreboard
            .summary
            .statusText
        )
          .toUpperCase()
          .includes("DLS")
          ? displayScoreboard
              .summary
              .statusText
          : matchInsights
              ?.resultText
      );

const combinedCommentary = [
  ...(scoreboard?.commentary || []),
  ...(scoreboard?.superOver?.commentary || []),
];

const normalizedMatchStatus = String(
  scoreboard?.match?.status || ""
)
  .trim()
  .replace(/[\s-]+/g, "_")
  .toUpperCase();

const canShowAiAnalysis =
  normalizedMatchStatus === "COMPLETED" ||
  normalizedMatchStatus === "COMPLETED_LOCKED" ||
  normalizedMatchStatus === "COMPLETED_CORRECTED";

const activeInnings = useMemo(() => {
  const innings = displayScoreboard?.innings || [];

  if (!innings.length) return null;

  const currentInningsNo =
    Number(displayScoreboard?.currentInnings) ||
    Number(ballForm?.inningsNo) ||
    1;

  return innings[currentInningsNo - 1] || innings[0];
}, [displayScoreboard, ballForm?.inningsNo]);


const recentBalls =
  displayScoreboard?.recentBalls || [];
const effectiveOversForCompletion =
  Number(
    liveMatchCenter
      ?.activeOversPerInnings ||
    matchDetail
      ?.oversPerInnings ||
    scoreboard
      ?.match
      ?.oversPerInnings ||
    0
  );

const maxLegalBalls =
  effectiveOversForCompletion *
  6;

const activeInningsLegalBalls =
  Number(activeInnings?.legalBalls || 0);

const isSecondInnings =
  Number(scoreboard?.currentInnings || ballForm?.inningsNo) === 2;

const isFinalBallBowled =
  isSecondInnings &&
  maxLegalBalls > 0 &&
  activeInningsLegalBalls >= maxLegalBalls;

const isChaseComplete =
  isSecondInnings &&
  scoreboard?.summary?.target &&
  Number(activeInnings?.runs || 0) >= Number(scoreboard.summary.target);

const isMatchReadyToLock =
  isFinalBallBowled ||
  isChaseComplete ||
  ["COMPLETED", "COMPLETED_LOCKED", "COMPLETED_CORRECTED", "ABANDONED"].includes(
    String(scoreboard?.match?.status || "").toUpperCase()
  );

const currentInningsNo = Number(scoreboard?.currentInnings || ballForm.inningsNo || 1);

const activeInningsBalls =
  scoreboard?.innings?.[currentInningsNo - 1]?.balls || 0;

const needsDeliverySetup =
  activeTab === "scoring" &&
  scoringSubTab === "ADVANCED" &&
  matchDetail &&
  scoreboard &&
  !isMatchReadyToLock &&
  (
    !ballForm.strikerId ||
    !ballForm.nonStrikerId ||
    !ballForm.bowlerId
  );

const canCreateMatch =
  activeLeague?.teams?.length >= 2;

const selectedMatch = matches.find(
  (m) => String(m.id) === String(selectedMatchId)
);
const selectedMatchStatus = String(selectedMatch?.status || "")
  .trim()
  .replace(/[\s-]+/g, "_")
  .toUpperCase();

const selectedSuperOverState =
  displayScoreboard?.superOver ||
  scoreboard?.superOver ||
  null;

const selectedStatusText = String(
  selectedSuperOverState?.resultText ||
  displayScoreboard?.summary?.statusText ||
  scoreboard?.summary?.statusText ||
  selectedMatch?.statusText ||
  ""
).toLowerCase();

const selectedRegulationTiePending =
  selectedMatchStatus === "COMPLETED" &&
  !selectedSuperOverState?.completed &&
  (
    selectedSuperOverState?.active ||
    selectedSuperOverState?.tied ||
    selectedStatusText.includes("tied") ||
    selectedStatusText.includes("super over")
  );

const isSelectedMatchCompleted =
  selectedMatchStatus === "COMPLETED_LOCKED" ||
  selectedMatchStatus === "COMPLETED_CORRECTED" ||
  (
    selectedMatchStatus === "COMPLETED" &&
    !selectedRegulationTiePending
  ) ||
  Boolean(selectedSuperOverState?.completed);

const effectiveScoringSubTab =
  isSelectedMatchCompleted && scoringSubTab === "ADVANCED"
    ? "SCOREBOARD"
    : scoringSubTab;

function normalizeStatus(status) {
  return String(status || "")
    .trim()
    .replace(/[\s-]+/g, "_")
    .toUpperCase();
}

function toggleFilterValue(type, value) {
  setContextFilters((prev) => {
    const exists = prev[type].includes(value);

    return {
      ...prev,
      [type]: exists
        ? prev[type].filter((v) => v !== value)
        : [...prev[type], value]
    };
  });
}
function getNextBallLabel() {
  const state = scoreboard?.currentState;

  if (!state) return "-";

  if (state.nextBallLabel) {
    return state.nextBallLabel;
  }

  if (
    state.nextOver !== undefined &&
    state.nextBallInOver !== undefined
  ) {
    return `${state.nextOver}.${state.nextBallInOver}`;
  }

  if (
    state.nextOverNo !== undefined &&
    state.nextBallInOver !== undefined
  ) {
    return `${state.nextOverNo}.${state.nextBallInOver}`;
  }

  if (
    state.nextOverNo !== undefined &&
    state.nextBallNo !== undefined
  ) {
    return `${state.nextOverNo}.${state.nextBallNo}`;
  }

  return "-";
}
async function handleDeleteSeries(seriesId, seriesName) {
  const ok = window.confirm(
    `Delete series "${seriesName}"? This cannot be undone.`
  );

  if (!ok) return;

  try {
    await api(`/api/series/${seriesId}`, {
      method: "DELETE"
    });

    setSelectedSeriesId("");

    setContextFilters((prev) => ({
      ...prev,
      seriesIds: [],
      years: []
    }));

    await loadSeries();

    setMessage(`Series "${seriesName}" deleted successfully.`);
  } catch (err) {
    setError(err.message || "Failed to delete series.");
  }
}
const currentBowlerStats =
  displayScoreboard?.currentState?.bowlerStats;
const bowlerChangeScore = {
  score: activeInnings
    ? `${activeInnings.runs}/${activeInnings.wickets}`
    : "-",
  overs: activeInnings?.oversDisplay || "0.0",
  crr: liveMatchCenter?.crr || "-",
};
const previousOverInfo = (() => {
  const latestBall = recentBalls?.[0];

  if (!latestBall) {
    return {
      overNo: "",
      balls: [],
    };
  }

  const label = String(latestBall.label || "");
  const overNo = label.split(".")[0];

  const balls = (recentBalls || [])
    .filter((ball) => {
      const ballLabel = String(ball.label || "");
      return ballLabel.split(".")[0] === overNo;
    })
    .reverse();

  return {
    overNo,
    balls,
  };
})();

function getMatchOptionLabel(match) {
  const teams = `${match.teamAName || "Team A"} vs ${
    match.teamBName || "Team B"
  }`;

  const status = String(match.status || "")
    .replaceAll("_", " ")
    .toUpperCase();

  const timeline = getMatchTimelineText(match);

  const score =
    match.scoreSummary ||
    match.liveScore ||
    `${match.oversPerInnings || "-"} overs`;

    if (match.status === "COMPLETED_LOCKED") {
        return `${teams} • ${status} • ${score}`;
    }
    if (match.status === "COMPLETED") {
        return `${teams} • ${status} • ${score}`;
    }
    if (match.status === "COMPLETED_CORRECTED") {
        return `${teams} • ${status} • ${score}`;
    }
    if (match.status === "ABANDONED") {
        return `${teams} • ${status}`;
    }
    if (match.status === "SCHEDULED") {
        return `${teams} • ${status} • ${timeline}`;
    }
    if (match.status === "IN_PROGRESS") {
        return `${teams} • ${status} • ${timeline} • ${score}`;
    }else{
            return `${teams} • ${status} • ${timeline}` // • ${score};
    }   
}

function getMatchSortTime(match) {
  return new Date(
    match.startedAt ||
      match.scheduledAt ||
      match.endedAt ||
      match.createdAt ||
      0
  ).getTime();
}

function sortMatchesForSelection(matches) {
  const statusRank = {
    IN_PROGRESS: 1,
    ACTIVE: 1,
    SCHEDULED: 2,
    COMPLETED: 3,
    COMPLETED_LOCKED: 3,
    COMPLETED_CORRECTED: 3,
    ABANDONED: 4,
  };

  return [...matches].sort((a, b) => {
    const aStatus = String(a.status || "").toUpperCase();
    const bStatus = String(b.status || "").toUpperCase();

    const rankDiff =
      (statusRank[aStatus] || 9) - (statusRank[bStatus] || 9);

    if (rankDiff !== 0) return rankDiff;

    if (aStatus === "SCHEDULED") {
      return getMatchSortTime(a) - getMatchSortTime(b);
    }

    return getMatchSortTime(b) - getMatchSortTime(a);
  });
}

function clearContextFilters() {
  setContextFilters({
    teamIds: [],
    matchIds: [],
    playerNames: [],
    statuses: [],
    roles: [],
    seriesIds: [],
    years: []
  });
}
function matchPassesContextFilters(match) {
  const teamIds = (contextFilters.teamIds || []).map(Number);
  const matchIds = (contextFilters.matchIds || []).map(Number);
  const statuses = (contextFilters.statuses || []).map(normalizeStatus);
  const seriesIds = (contextFilters.seriesIds || []).map(Number);
  const years = (contextFilters.years || []).map(Number);

  if (
    teamIds.length &&
    !teamIds.includes(Number(match.teamAId)) &&
    !teamIds.includes(Number(match.teamBId))
  ) {
    return false;
  }

  if (matchIds.length && !matchIds.includes(Number(match.id))) {
    return false;
  }

  if (statuses.length && !statuses.includes(normalizeStatus(match.status))) {
    return false;
  }

  if (seriesIds.length && !seriesIds.includes(Number(match.seriesId))) {
    return false;
  }

  if (years.length) {
    const matchYear =
      Number(match.year) ||
      Number(match.seriesYear) ||
      new Date(match.createdAt).getFullYear();

    if (!years.includes(matchYear)) {
      return false;
    }
  }

  return true;
}
const isSurpriseLeague =
  String(activeLeague?.name || "")
    .trim()
    .toLowerCase() === "surprise cricket league";

const availablePlayersForFilter = (() => {
  const map = new Map();

  const selectedTeamIds = contextFilters.teamIds.map(Number);

  const activeLeagueTeams = (teams || []).filter((team) => {
    const isInActiveLeague =
      Number(team.leagueId) === Number(activeLeagueId);

    if (!isInActiveLeague) return false;

    if (!isSurpriseLeague && selectedTeamIds.length) {
      return selectedTeamIds.includes(Number(team.id));
    }

    return true;
  });

  activeLeagueTeams.forEach((team) => {
    [...(team.players || [])]
  .sort((a, b) => a.name.localeCompare(b.name))
  .map((player) => {
      const normalizedName = String(player.name || "")
        .trim()
        .toLowerCase();

      if (!normalizedName) return;

      if (!map.has(normalizedName)) {
        map.set(normalizedName, {
          name: player.name.trim(),
          normalizedName,
          teams: new Set()
        });
      }

      map.get(normalizedName).teams.add(team.name);
  });
  });

  return [...map.values()]
    .map((player) => ({
      ...player,
      teamNames: [...player.teams].sort()
    }))
    .sort((a, b) =>
      String(a.name || "").localeCompare(String(b.name || ""))
    );
})();

function playerPassesContextFilters(row) {
  const teamIds = contextFilters.teamIds.map(Number);
  const playerNames = contextFilters.playerNames || [];

  if (teamIds.length) {
    const selectedTeamNames = teams
      .filter((t) => teamIds.includes(Number(t.id)))
      .map((t) =>
        String(t.name || "")
          .trim()
          .toLowerCase()
      );

    const rowTeamId = Number(row.teamId);

    const rowTeamName = String(row.teamName || "")
      .trim()
      .toLowerCase();

    const rowTeamNames = String(
      row.teamNames ||
        row.teams ||
        row.teamName ||
        ""
    )
      .split(/[,&/|]+/)
      .map((x) => x.trim().toLowerCase())
      .filter(Boolean);

    const matchesTeamId = teamIds.includes(rowTeamId);

    const matchesTeamName =
      selectedTeamNames.includes(rowTeamName) ||
      rowTeamNames.some((name) =>
        selectedTeamNames.includes(name)
      );

    if (!matchesTeamId && !matchesTeamName) {
      return false;
    }
  }

  if (playerNames.length) {
    const rowName = String(row.playerName || "")
      .trim()
      .toLowerCase();

    if (!playerNames.includes(rowName)) {
      return false;
    }
  }

  return true;
}
useEffect(() => {
  const SpeechRecognition =
    window.SpeechRecognition || window.webkitSpeechRecognition;

  setVoiceSupported(Boolean(SpeechRecognition));
}, []);

useEffect(() => {
  if (!isMobile || !scorerMode) {
    return;
  }

  const previousHtmlOverflow =
    document.documentElement.style.overflow;
  const previousBodyOverflow =
    document.body.style.overflow;
  const previousBodyPosition =
    document.body.style.position;
  const previousBodyWidth =
    document.body.style.width;
  const previousBodyTop =
    document.body.style.top;

  const scrollY = window.scrollY;

  document.documentElement.classList.add(
    "mobile-scorer-open"
  );
  document.body.classList.add(
    "mobile-scorer-open"
  );

  document.documentElement.style.overflow =
    "hidden";
  document.body.style.overflow = "hidden";
  document.body.style.position = "fixed";
  document.body.style.width = "100%";
  document.body.style.top = `-${scrollY}px`;

  return () => {
    document.documentElement.classList.remove(
      "mobile-scorer-open"
    );
    document.body.classList.remove(
      "mobile-scorer-open"
    );

    document.documentElement.style.overflow =
      previousHtmlOverflow;
    document.body.style.overflow =
      previousBodyOverflow;
    document.body.style.position =
      previousBodyPosition;
    document.body.style.width =
      previousBodyWidth;
    document.body.style.top =
      previousBodyTop;

    window.scrollTo(0, scrollY);
  };
}, [isMobile, scorerMode]);

useEffect(() => {
  if (!scorerMode) {
    setShowScorerAccountMenu(false);
  }
}, [scorerMode]);

/*
 * If the server positively resolves the active league and scoring permission
 * is no longer present, leave full-screen Scorer Mode immediately. This avoids
 * a blank, body-locked screen after a real permission revocation.
 */
useEffect(() => {
  if (!scorerMode || permissionsLoading || !activeLeagueId) {
    return;
  }

  const permissionResolvedForActiveLeague =
    String(permissionsLeagueIdRef.current || "") ===
    String(activeLeagueId);

  if (
    permissionResolvedForActiveLeague &&
    !permissions?.canScoreMatch
  ) {
    setShowScorerAccountMenu(false);
    setScorerDrawer(null);
    setScorerMode(false);
    setError(
      "Scoring access is not enabled for this account in the selected league."
    );
  }
}, [
  scorerMode,
  permissionsLoading,
  activeLeagueId,
  permissions?.canScoreMatch,
]);

function handleVoiceCommand(command) {
  const text = String(command || "").toLowerCase().trim();

  if (!scorerMode) return;
  if (isSavingBall || isMatchCompleted || isMatchLocked || isMatchAbandoned) return;

  if (text.includes("dot") || text.includes("zero")) {
    quickNormalBall(0);
  } else if (text.includes("one") || text.includes("single")) {
    quickNormalBall(1);
  } else if (text.includes("two")) {
    quickNormalBall(2);
  } else if (text.includes("three")) {
    quickNormalBall(3);
  } else if (text.includes("four")) {
    quickNormalBall(4);
  } else if (text.includes("six")) {
    quickNormalBall(6);
  } else if (text.includes("wide")) {
    quickExtra("WIDE");
  } else if (text.includes("no ball") || text.includes("noball")) {
    quickExtra("NOBALL");
  } else if (text.includes("leg bye")) {
    quickExtra("LEGBYE");
  } else if (text.includes("bye")) {
    quickExtra("BYE");
  } else if (text.includes("wicket")) {
    quickWicket("BOWLED");
  } else if (text.includes("undo")) {
    handleUndoBall();
  } else {
    setVoiceStatus(`Heard: "${command}"`);
  }
}
useEffect(() => {
  if (!voiceScoringOn || !scorerMode) return;

  const SpeechRecognition =
    window.SpeechRecognition || window.webkitSpeechRecognition;

  if (!SpeechRecognition) {
    setVoiceStatus("Voice scoring is not supported in this browser.");
    return;
  }

  const recognition = new SpeechRecognition();
  recognition.continuous = true;
  recognition.interimResults = false;
  recognition.lang = "en-US";

  recognition.onstart = () => {
    setVoiceStatus("🎙️ Listening...");
  };

  recognition.onresult = (event) => {
    const transcript =
      event.results[event.results.length - 1][0].transcript;

    setVoiceStatus(`Heard: ${transcript}`);
    handleVoiceCommand(transcript);
  };

  recognition.onerror = (event) => {
    setVoiceStatus(`Voice error: ${event.error}`);
  };

  recognition.onend = () => {
    if (voiceScoringOn && scorerMode) {
      try {
        recognition.start();
      } catch {setVoiceStatus("");}
    }
  };

  recognition.start();

  return () => {
    recognition.onend = null;
    recognition.stop();
  };
}, [
  voiceScoringOn,
  scorerMode,
  isSavingBall,
  isMatchCompleted,
  isMatchLocked,
  isMatchAbandoned,
]);

const rankedSelectedRanking =
  (selectedRanking || []).map((row, index) => ({
    ...row,
    actualRank: index + 1
  }));

const filteredSelectedRanking =
  rankedSelectedRanking.filter(playerPassesContextFilters);

function pointsPassesContextFilters(row) {
  const teamIds = contextFilters.teamIds.map(Number);

  if (
    teamIds.length &&
    !teamIds.includes(Number(row.teamId))
  ) {
    return false;
  }

  return true;
}
const availablePlayers = (() => {
  const map = new Map();

  const addPlayer = (row) => {
    if (!row?.playerId) return;

    map.set(Number(row.playerId), {
      id: Number(row.playerId),
      name: row.playerName,
      teamId: Number(row.teamId),
      teamName: row.teamName
    });
  };

  (leagueStats?.batting || []).forEach(addPlayer);
  (leagueStats?.bowling || []).forEach(addPlayer);
  (leagueStats?.fielding || []).forEach(addPlayer);

  return [...map.values()].sort((a, b) =>
    String(a.name || "").localeCompare(String(b.name || ""))
  );
})();

const filteredActiveMatches =
  activeMatches.filter(matchPassesContextFilters);

const filteredScheduledMatches =
  scheduledMatches.filter(matchPassesContextFilters);

/*
 * COMPLETED MATCH DEDUPLICATION
 * =============================
 * DLS, undo/re-score, correction and lock transitions must update the same
 * Match record; they must never render the same database match twice.
 *
 * Deduplicate ONLY by real match.id. Do not deduplicate by team names/date,
 * because two legitimate matches can involve the same teams on the same day.
 */
const uniqueCompletedMatches = (() => {
  const seenMatchIds = new Set();

  return completedMatches.filter((match) => {
    const matchId = Number(match?.id);

    if (!Number.isInteger(matchId) || matchId <= 0) {
      return true;
    }

    if (seenMatchIds.has(matchId)) {
      return false;
    }

    seenMatchIds.add(matchId);
    return true;
  });
})();

const filteredCompletedMatches =
  uniqueCompletedMatches.filter(matchPassesContextFilters);

const visibleCompletedMatches =
  filteredCompletedMatches.slice(
    0,
    completedMatchRenderLimit
  );

const hasMoreCompletedMatches =
  visibleCompletedMatches.length <
  filteredCompletedMatches.length;

useEffect(() => {
  setCompletedMatchRenderLimit(
    COMPLETED_MATCH_RENDER_PAGE_SIZE
  );
}, [
  activeLeagueId,
  contextFilters?.teamIds,
  contextFilters?.seriesIds,
]);

function normalizeStatName(name) {
  return String(name || "")
    .trim()
    .toLowerCase()
    .replace(/\s+/g, " ");
}

function combineCaptaincyRows(rows = [], shouldCombine = false) {
  if (!shouldCombine) return rows || [];

  const map = new Map();

  rows.forEach((row) => {
    const key = normalizeStatName(row.playerName);
    if (!key) return;

    if (!map.has(key)) {
      map.set(key, {
        ...row,
        playerIds: new Set(),
        teamNamesSet: new Set(),
        played: 0,
        won: 0,
        lost: 0,
      });
    }

    const combined = map.get(key);

    if (row.playerId) combined.playerIds.add(Number(row.playerId));
    if (row.teamName) combined.teamNamesSet.add(row.teamName);

    combined.played += Number(row.played || 0);
    combined.won += Number(row.won || 0);
    combined.lost += Number(row.lost || 0);
  });

  return [...map.values()].map((row) => ({
    ...row,
    playerId: [...row.playerIds][0],
    teamName: [...row.teamNamesSet].sort().join(" / "),
    teamNames: [...row.teamNamesSet].sort().join(" / "),
    winPct: row.played ? ((row.won / row.played) * 100).toFixed(1) : "0.0",
  }));
}

function combineWicketkeepingRows(rows = [], shouldCombine = false) {
  if (!shouldCombine) return rows || [];

  const map = new Map();

  rows.forEach((row) => {
    const key = normalizeStatName(row.playerName);
    if (!key) return;

    if (!map.has(key)) {
      map.set(key, {
        ...row,
        playerIds: new Set(),
        teamNamesSet: new Set(),
        catches: 0,
        stumpings: 0,
        runOuts: 0,
        dismissals: 0,
      });
    }

    const combined = map.get(key);

    if (row.playerId) combined.playerIds.add(Number(row.playerId));
    if (row.teamName) combined.teamNamesSet.add(row.teamName);

    combined.catches += Number(row.catches || 0);
    combined.stumpings += Number(row.stumpings || 0);
    combined.runOuts += Number(row.runOuts || 0);
  });

  return [...map.values()].map((row) => ({
    ...row,
    playerId: [...row.playerIds][0],
    teamName: [...row.teamNamesSet].sort().join(" / "),
    teamNames: [...row.teamNamesSet].sort().join(" / "),
    dismissals:
      Number(row.catches || 0) +
      Number(row.stumpings || 0) +
      Number(row.runOuts || 0),
  }));
}  

const rankedBatting =
  (leagueStats?.batting || []).map((row, index) => ({
    ...row,
    actualRank: index + 1
  }));

const rankedBowling =
  (leagueStats?.bowling || []).map((row, index) => ({
    ...row,
    actualRank: index + 1
  }));

const rankedFielding =
  (leagueStats?.fielding || []).map((row, index) => ({
    ...row,
    actualRank: index + 1
  }));

const filteredBatting =
  rankedBatting.filter(playerPassesContextFilters);

const filteredBowling =
  rankedBowling.filter(playerPassesContextFilters);

const filteredFielding =
  rankedFielding.filter(playerPassesContextFilters);

const combinedCaptaincy = combineCaptaincyRows(
  captaincyRows || [],
  isSurpriseLeague
);

const combinedWicketkeeping = combineWicketkeepingRows(
  wicketkeepingRows || [],
  isSurpriseLeague
);

const filteredCaptaincy = combinedCaptaincy.filter(playerPassesContextFilters);

const filteredWicketkeeping =
  combinedWicketkeeping.filter(playerPassesContextFilters);

/*
 * DASHBOARD LEADERS
 * =================
 * These calculations intentionally reuse the already-loaded league Stats API
 * rows. That keeps Dashboard -> Stats -> Leaders aligned with the detailed
 * Batting/Bowling/Fielding records and avoids a second scoring engine.
 *
 * The current Smart Filters are applied first, so Leaders always reflects the
 * same team/player/series context the signed-in user is viewing.
 */
const dashboardTopRunScorer = [...filteredBatting]
  .filter((row) => Number(row.runs || 0) > 0)
  .sort(
    (a, b) =>
      Number(b.runs || 0) - Number(a.runs || 0) ||
      Number(b.strikeRate || 0) - Number(a.strikeRate || 0)
  )[0];

const dashboardTopSixHitter = [...filteredBatting]
  .filter((row) => Number(row.sixes || 0) > 0)
  .sort(
    (a, b) =>
      Number(b.sixes || 0) - Number(a.sixes || 0) ||
      Number(b.runs || 0) - Number(a.runs || 0)
  )[0];

const dashboardTopFourHitter = [...filteredBatting]
  .filter((row) => Number(row.fours || 0) > 0)
  .sort(
    (a, b) =>
      Number(b.fours || 0) - Number(a.fours || 0) ||
      Number(b.runs || 0) - Number(a.runs || 0)
  )[0];

const dashboardBestStrikeRate = [...filteredBatting]
  .filter((row) => Number(row.balls || 0) >= 5)
  .sort(
    (a, b) =>
      Number(b.strikeRate || 0) - Number(a.strikeRate || 0) ||
      Number(b.runs || 0) - Number(a.runs || 0)
  )[0];

const dashboardBestRunsPerMatch = [...filteredBatting]
  .filter((row) => Number(row.matches || 0) > 0)
  .map((row) => ({
    ...row,
    runsPerMatch:
      Number(row.runs || 0) /
      Math.max(1, Number(row.matches || 0)),
  }))
  .sort(
    (a, b) =>
      b.runsPerMatch - a.runsPerMatch ||
      Number(b.runs || 0) - Number(a.runs || 0)
  )[0];

const dashboardTopWicketTaker = [...filteredBowling]
  .filter((row) => Number(row.wickets || 0) > 0)
  .sort(
    (a, b) =>
      Number(b.wickets || 0) - Number(a.wickets || 0) ||
      Number(a.economy || 0) - Number(b.economy || 0)
  )[0];

const dashboardBestEconomy = [...filteredBowling]
  .filter((row) => Number(row.bowlingBalls || 0) >= 6)
  .sort(
    (a, b) =>
      Number(a.economy || 0) - Number(b.economy || 0) ||
      Number(b.wickets || 0) - Number(a.wickets || 0)
  )[0];

const dashboardTopDotBowler = [...filteredBowling]
  .filter((row) => Number(row.dots || 0) > 0)
  .sort(
    (a, b) =>
      Number(b.dots || 0) - Number(a.dots || 0) ||
      Number(b.wickets || 0) - Number(a.wickets || 0)
  )[0];

const dashboardBestBowlingStrikeRate = [...filteredBowling]
  .filter(
    (row) =>
      Number(row.wickets || 0) > 0 &&
      Number(row.bowlingBalls || 0) > 0
  )
  .sort(
    (a, b) =>
      Number(a.bowlingStrikeRate || 0) -
        Number(b.bowlingStrikeRate || 0) ||
      Number(b.wickets || 0) - Number(a.wickets || 0)
  )[0];

const dashboardBowlingWorkhorse = [...filteredBowling]
  .filter((row) => Number(row.bowlingBalls || 0) > 0)
  .sort(
    (a, b) =>
      Number(b.bowlingBalls || 0) - Number(a.bowlingBalls || 0) ||
      Number(b.wickets || 0) - Number(a.wickets || 0)
  )[0];

const dashboardTopFielder = [...filteredFielding]
  .filter((row) => Number(row.fieldingTotal || 0) > 0)
  .sort(
    (a, b) =>
      Number(b.fieldingTotal || 0) - Number(a.fieldingTotal || 0) ||
      Number(b.catches || 0) - Number(a.catches || 0)
  )[0];

const dashboardSafestHands = [...filteredFielding]
  .filter((row) => Number(row.catches || 0) > 0)
  .sort(
    (a, b) =>
      Number(b.catches || 0) - Number(a.catches || 0) ||
      Number(b.fieldingTotal || 0) - Number(a.fieldingTotal || 0)
  )[0];

const dashboardRunOutSpecialist = [...filteredFielding]
  .filter((row) => Number(row.runOuts || 0) > 0)
  .sort(
    (a, b) =>
      Number(b.runOuts || 0) - Number(a.runOuts || 0) ||
      Number(b.fieldingTotal || 0) - Number(a.fieldingTotal || 0)
  )[0];

const dashboardAssistLeader = [...filteredFielding]
  .filter((row) => Number(row.assists || 0) > 0)
  .sort(
    (a, b) =>
      Number(b.assists || 0) - Number(a.assists || 0) ||
      Number(b.fieldingTotal || 0) - Number(a.fieldingTotal || 0)
  )[0];

const dashboardStumpingLeader = [...filteredFielding]
  .filter((row) => Number(row.stumpings || 0) > 0)
  .sort(
    (a, b) =>
      Number(b.stumpings || 0) - Number(a.stumpings || 0) ||
      Number(b.fieldingTotal || 0) - Number(a.fieldingTotal || 0)
  )[0];

/*
 * IMPORTANT:
 * All-Round must use the complete player rows already merged by the league
 * Stats API. Surprise Cricket League can use name-based analytics identities,
 * so converting those identities to Number in the browser can collapse
 * unrelated players into one record and inherit another player's wickets.
 */
const dashboardAllRoundRows =
  (
    leagueStats
      ?.rankings
      ?.bestAllRounders ||
    []
  )
    .filter(
      playerPassesContextFilters
    );

const dashboardTopImpactPlayer =
  dashboardAllRoundRows[0];

const dashboardBalancedForce = [...dashboardAllRoundRows]
  .filter(
    (row) =>
      Number(row.runs || 0) > 0 &&
      Number(row.wickets || 0) > 0
  )
  .map((row) => ({
    ...row,
    twoWayPoints:
      Number(row.runs || 0) +
      Number(row.wickets || 0) * 25,
  }))
  .sort(
    (a, b) =>
      b.twoWayPoints - a.twoWayPoints ||
      Number(b.allRounderPoints || 0) -
        Number(a.allRounderPoints || 0)
  )[0];

const dashboardThreeDimensionalPlayer = [...dashboardAllRoundRows]
  .filter(
    (row) =>
      Number(row.runs || 0) > 0 &&
      Number(row.wickets || 0) > 0 &&
      Number(row.fieldingTotal || 0) > 0
  )
  .sort(
    (a, b) =>
      Number(b.allRounderPoints || 0) -
      Number(a.allRounderPoints || 0)
  )[0];

const dashboardBestImpactPerMatch = [...dashboardAllRoundRows]
  .filter((row) => Number(row.matches || 0) >= 2)
  .map((row) => ({
    ...row,
    impactPerMatch:
      Number(row.allRounderPoints || 0) /
      Math.max(1, Number(row.matches || 0)),
  }))
  .sort(
    (a, b) =>
      b.impactPerMatch - a.impactPerMatch ||
      Number(b.allRounderPoints || 0) -
        Number(a.allRounderPoints || 0)
  )[0];

const dashboardCompletePackage = [...dashboardAllRoundRows]
  .map((row) => ({
    ...row,
    disciplines:
      Number(Number(row.runs || 0) > 0) +
      Number(Number(row.wickets || 0) > 0) +
      Number(Number(row.fieldingTotal || 0) > 0),
  }))
  .filter((row) => row.disciplines >= 2)
  .sort(
    (a, b) =>
      b.disciplines - a.disciplines ||
      Number(b.allRounderPoints || 0) -
        Number(a.allRounderPoints || 0)
  )[0];

const filteredPointsTable =
  pointsTable?.filter(pointsPassesContextFilters) || [];

const uniqueMatchesForFilter = (() => {
  const map = new Map();

  (matches || []).forEach((match) => {
    if (!match?.id) return;
    map.set(Number(match.id), match);
  });

  return [...map.values()];
})();  
const selectedYears = (contextFilters.years || []).map(Number);
const selectedSeriesIds = (contextFilters.seriesIds || []).map(Number);
const selectedTeamIds = (contextFilters.teamIds || []).map(Number);

const correctionInningsNo = Number(correctionForm.inningsNo || 1);

const correctionBattingTeamId =
  correctionInningsNo === 1
    ? matchDetail?.battingFirstTeamId
    : matchDetail?.teamAId === matchDetail?.battingFirstTeamId
    ? matchDetail?.teamBId
    : matchDetail?.teamAId;

const correctionBattingTeam =
  Number(matchDetail?.teamAId) === Number(correctionBattingTeamId)
    ? matchDetail?.teamA
    : matchDetail?.teamB;

const correctionPlayers =
  (correctionBattingTeam?.players || []).sort((a, b) =>
    a.name.localeCompare(b.name)
  );

const filteredSeriesForContextLens = (seriesList || [])
  .filter((series) => {
    if (
      selectedYears.length &&
      !selectedYears.includes(Number(series.year))
    ) {
      return false;
    }

    return true;
  });

const filteredMatchesForContextLens = uniqueMatchesForFilter
  .filter((match) => {
    const selectedYears = (contextFilters.years || []).map(Number);
    const selectedSeriesIds = (contextFilters.seriesIds || []).map(Number);
    const selectedTeamIds = (contextFilters.teamIds || []).map(Number);
    const selectedStatuses = (contextFilters.statuses || []).map(normalizeStatus);

    if (
      selectedYears.length &&
      !selectedYears.includes(
        Number(match.seriesYear) ||
          new Date(match.createdAt).getFullYear()
      )
    ) {
      return false;
    }

    if (
      selectedSeriesIds.length &&
      !selectedSeriesIds.includes(Number(match.seriesId))
    ) {
      return false;
    }

    if (
      selectedTeamIds.length &&
      !selectedTeamIds.includes(Number(match.teamAId)) &&
      !selectedTeamIds.includes(Number(match.teamBId))
    ) {
      return false;
    }

    if (
      selectedStatuses.length &&
      !selectedStatuses.includes(normalizeStatus(match.status))
    ) {
      return false;
    }

    return true;
  });
  async function handleWicketKeeperChange() {
  try {
    const bowlingTeamId =
      Number(ballForm.inningsNo) === 1
        ? Number(matchDetail?.teamAId) === Number(matchDetail?.battingFirstTeamId)
          ? matchDetail?.teamBId
          : matchDetail?.teamAId
        : Number(matchDetail?.teamAId) === Number(matchDetail?.battingFirstTeamId)
        ? matchDetail?.teamAId
        : matchDetail?.teamBId;

    await api(`/api/matches/${selectedMatchId}/wicketkeeper-change`, {
      method: "POST",
      body: JSON.stringify({
        inningsNo: keeperChangeForm.inningsNo,
        afterSequence: keeperChangeForm.afterSequence || scoreboard?.currentState?.lastSequence || 0,
        teamId: bowlingTeamId,
        newKeeperId: keeperChangeForm.newKeeperId,
        note: keeperChangeForm.note,
      }),
    });

    await loadSelectedMatch(selectedMatchId);
    setShowKeeperChangeModal(false);
    setMessage("✅ Wicketkeeper changed successfully.");
  } catch (err) {
    setError(err.message);
  }
}
function applyWicketKeeperChangeLocally({
  newKeeperId,
  newKeeper,
}) {
  setMatchDetail(
    (previous) => {
      if (!previous) {
        return previous;
      }

      const isTeamA =
        Number(
          bowlingTeam?.id
        ) ===
        Number(
          previous.teamAId
        );

      return {
        ...previous,

        ...(isTeamA
          ? {
              teamAWicketKeeperId:
                newKeeperId,

              teamAWicketKeeperName:
                newKeeper?.name ||
                previous
                  .teamAWicketKeeperName,
            }
          : {
              teamBWicketKeeperId:
                newKeeperId,

              teamBWicketKeeperName:
                newKeeper?.name ||
                previous
                  .teamBWicketKeeperName,
            }),
      };
    }
  );

  setMatches(
    (previousMatches) =>
      (
        previousMatches ||
        []
      ).map(
        (match) => {
          if (
            Number(
              match.id
            ) !==
            Number(
              selectedMatchId
            )
          ) {
            return match;
          }

          const isTeamA =
            Number(
              bowlingTeam?.id
            ) ===
            Number(
              match.teamAId
            );

          return {
            ...match,

            ...(isTeamA
              ? {
                  teamAWicketKeeperId:
                    newKeeperId,

                  teamAWicketKeeperName:
                    newKeeper?.name ||
                    match
                      .teamAWicketKeeperName,
                }
              : {
                  teamBWicketKeeperId:
                    newKeeperId,

                  teamBWicketKeeperName:
                    newKeeper?.name ||
                    match
                      .teamBWicketKeeperName,
                }),
          };
        }
      )
  );
}

async function handleLiveWicketKeeperChange() {
  if (
    keeperChangeSaving
  ) {
    return;
  }

  const snapshot = {
    ...keeperChangeForm,
  };

  try {
    if (!selectedMatchId) {
      setError(
        "Please select a match first."
      );
      return;
    }

    if (
      !keeperChangeForm.newKeeperId
    ) {
      setError(
        "Please select the new wicketkeeper."
      );
      return;
    }

    const newKeeperId =
      Number(
        keeperChangeForm
          .newKeeperId
      );

    const newKeeper =
      bowlingTeam
        ?.players
        ?.find(
          (player) =>
            Number(
              player.id
            ) ===
            newKeeperId
        );

    setKeeperChangeSaving(
      true
    );

    /*
     * OFFLINE WICKETKEEPER CHANGE
     * ---------------------------
     * Unlike bowler change, wicketkeeper change is NOT encoded in the next
     * Ball payload. Therefore it must be queued as its own offline action.
     *
     * Save it to IndexedDB, update the UI locally, and close the modal
     * immediately. When connectivity returns, syncPendingOfflineBalls()
     * replays the keeper-change request as well.
     */
    const browserIsOffline =
      typeof navigator !==
        "undefined" &&
      navigator.onLine ===
        false;

    const appIsOffline =
      offlineSyncState?.online === false ||
      Boolean(offlineSyncState?.conflict);

    const afterSequence =
      Number(
        scoreboard
          ?.currentState
          ?.lastSequence ||
        0
      );

    if (
      browserIsOffline ||
      appIsOffline
    ) {
      await queueOfflineKeeperChange({
        matchId:
          Number(
            selectedMatchId
          ),

        inningsNo:
          Number(
            ballForm.inningsNo
          ),

        newKeeperId,

        note:
          keeperChangeForm.note ||
          "",

        afterSequence,

        teamId:
          Number(
            bowlingTeam?.id ||
            0
          ) ||
          null,

        keeperName:
          newKeeper?.name ||
          "",

        localOrder:
          Date.now() * 1000 +
          Math.floor(
            Math.random() * 999
          ),
      });

      applyWicketKeeperChangeLocally({
        newKeeperId,
        newKeeper,
      });

      setKeeperChangeForm({
        newKeeperId:
          "",
        note:
          "",
      });

      setShowKeeperChangeModal(
        false
      );

      setError(
        ""
      );

      const pending =
        await refreshOfflinePendingCount(
          selectedMatchId
        );

      setMessage(
        `📴 Wicketkeeper changed to ${
          newKeeper?.name ||
          "the selected player"
        } locally · ${pending} change${
          pending === 1 ? "" : "s"
        } waiting to sync.`
      );

      return;
    }

    /*
     * ONLINE PATH:
     * Preserve existing API behavior.
     */
    setShowKeeperChangeModal(
      false
    );

    await api(
      `/api/matches/${selectedMatchId}/wicketkeeper-change`,
      {
        method:
          "POST",

        body:
          JSON.stringify({
            inningsNo:
              ballForm.inningsNo,

            newKeeperId,

            note:
              keeperChangeForm.note,
          }),
      }
    );

    applyWicketKeeperChangeLocally({
      newKeeperId,
      newKeeper,
    });

    setKeeperChangeForm({
      newKeeperId:
        "",
      note:
        "",
    });

    setMessage(
      `✅ Wicketkeeper changed to ${
        newKeeper?.name ||
        "the selected player"
      } from this point onward.`
    );
  } catch (err) {
    /*
     * Race-condition safety:
     * connectivity may disappear after the online check but before the
     * request reaches the server. Queue the keeper change instead of
     * reopening the same modal forever.
     */
    if (
      isOfflineRetryableError(
        err
      )
    ) {
      const newKeeperId =
        Number(
          snapshot.newKeeperId
        );

      const newKeeper =
        bowlingTeam
          ?.players
          ?.find(
            (player) =>
              Number(
                player.id
              ) ===
              newKeeperId
          );

      try {
        await queueOfflineKeeperChange({
          matchId:
            Number(
              selectedMatchId
            ),

          inningsNo:
            Number(
              ballForm.inningsNo
            ),

          newKeeperId,

          note:
            snapshot.note ||
            "",

          afterSequence:
            Number(
              scoreboard
                ?.currentState
                ?.lastSequence ||
              0
            ),

          teamId:
            Number(
              bowlingTeam?.id ||
              0
            ) ||
            null,

          keeperName:
            newKeeper?.name ||
            "",
        });

        applyWicketKeeperChangeLocally({
          newKeeperId,
          newKeeper,
        });

        setKeeperChangeForm({
          newKeeperId:
            "",
          note:
            "",
        });

        setShowKeeperChangeModal(
          false
        );

        setOfflineSyncState(
          (previous) => ({
            ...previous,
            online:
              false,
            syncing:
              false,
          })
        );

        const pending =
          await refreshOfflinePendingCount(
            selectedMatchId
          );

        setError(
          ""
        );

        setMessage(
          `📴 Wicketkeeper changed to ${
            newKeeper?.name ||
            "the selected player"
          } locally · ${pending} change${
            pending === 1 ? "" : "s"
          } waiting to sync.`
        );

        return;
      } catch (
        queueError
      ) {
        console.error(
          "[OFFLINE_KEEPER_QUEUE_FAILED]",
          queueError
        );
      }
    }

    setKeeperChangeForm(
      snapshot
    );

    setShowKeeperChangeModal(
      true
    );

    setError(
      err.message
    );
  } finally {
    setKeeperChangeSaving(
      false
    );
  }
}


const scoringComboMatches = (() => {
  let list = [...(matches || [])];

  const seriesIds = contextFilters?.seriesIds || [];
  const years = contextFilters?.years || [];
  const statuses = contextFilters?.statuses || [];
  const teamIds = contextFilters?.teamIds || [];
  const matchIds = contextFilters?.matchIds || [];

  if (activeLeagueId) {
    list = list.filter(
      (match) => Number(match.leagueId) === Number(activeLeagueId)
    );
  }

  if (statuses.length) {
    list = list.filter((match) =>
      statuses
        .map((s) => String(s).toUpperCase())
        .includes(String(match.status || "").toUpperCase())
    );
  }

  if (teamIds.length) {
    list = list.filter(
      (match) =>
        teamIds.map(Number).includes(Number(match.teamAId)) ||
        teamIds.map(Number).includes(Number(match.teamBId))
    );
  }

  if (matchIds.length) {
    list = list.filter((match) =>
      matchIds.map(Number).includes(Number(match.id))
    );
  }

  if (seriesIds.length) {
    list = list.filter((match) =>
      seriesIds.map(Number).includes(Number(match.seriesId))
    );
  }

  if (years.length) {
    list = list.filter((match) => {
      const dateValue =
        match.startedAt ||
        match.scheduledAt ||
        match.endedAt ||
        match.createdAt;

      if (!dateValue) return false;

      return years.map(Number).includes(new Date(dateValue).getFullYear());
    });
  }

  return sortMatchesForSelection(list);
})();

useEffect(() => {
  if (!selectedMatchId) return;

  const exists = scoringComboMatches.some(
    (match) => Number(match.id) === Number(selectedMatchId)
  );

  if (!exists) {
    // Explicit offline-resume navigation intentionally restores a cached match
    // even when the server-backed `matches` list is unavailable or empty.
    if (
      isTrueOfflineResume
    ) {
      return;
    }

    setSelectedMatchId("");
    setMatchDetail(null);
    setScoreboard(null);
    setOptimisticScoreboard(null);
  }
}, [
  contextFilters,
  activeLeagueId,
  selectedMatchId,
  matches,
  isTrueOfflineResume,
]);

async function handleScoringMatchSelect(matchId) {
  if (!matchId) {
    setSelectedMatchId("");
    setMatchDetail(null);
    setScoreboard(null);
    setOptimisticScoreboard(null);
    return;
  }

  const match = scoringComboMatches.find(
    (m) => Number(m.id) === Number(matchId)
  );

  if (!match) {
    setError("Selected match was not found.");
    return;
  }

  const status = String(match.status || "").toUpperCase();
  const isScheduled = status === "SCHEDULED";

  if (isScheduled) {
    setSelectedMatchId(String(match.id));
    setEditingMatch(match);

    const hasBattingFirst =
      match.battingFirstTeamId ||
      match.battingFirstTeam?.id;

    if (!hasBattingFirst) {
      setMatchDetail(null);
      setScoreboard(null);
      setOptimisticScoreboard(null);
      setShowStartMatchModal(true);
      return;
    }
  }

  await handleMatchSelect(match.id);
}
async function openScoringAfterBattingFirst(matchId) {
  const safeMatchId = Number(matchId);

  if (!safeMatchId) {
    setError("Match was not found.");
    return;
  }

  setMessage("");
  setError("");

  setSelectedMatchId(String(safeMatchId));
  setActiveTab("scoring");
  setScoringSubTab("ADVANCED");

  setBallForm((prev) => ({
    ...prev,
    inningsNo: "1",
    strikerId: "",
    nonStrikerId: "",
    bowlerId: "",
    extraType: "NONE",
    runsOffBat: "0",
    extras: "0",
    isWicket: false,
    wicketType: "NONE",
    dismissedPlayerId: "",
    newBatterId: "",
    note: "",
    fielderId: "",
    assistantFielderId: "",
    wicketNote: "",
  }));

  await loadSelectedMatch(safeMatchId, {
    loadDetail: true,
    loadStatsData: false,
    syncBallForm: false,
  });

  setDeliverySetupReason(
    "Select opening striker, non-striker, and bowler before scoring the first ball."
  );

  setPendingDeliverySetupAfterStart(true);
}

const setupTeamA = matchDetail?.teamA;
const setupTeamB = matchDetail?.teamB;

const setupTeamAId = Number(matchDetail?.teamAId || setupTeamA?.id);
const setupTeamBId = Number(matchDetail?.teamBId || setupTeamB?.id);
const setupBattingFirstTeamId = Number(
  matchDetail?.battingFirstTeamId ||
    scoreboard?.match?.battingFirstTeamId ||
    selectedMatch?.battingFirstTeamId
);

const setupInningsNo = Number(ballForm?.inningsNo || 1);

const setupBattingTeamId =
  setupInningsNo === 1
    ? setupBattingFirstTeamId
    : setupBattingFirstTeamId === setupTeamAId
    ? setupTeamBId
    : setupTeamAId;

const setupBowlingTeamId =
setupBattingTeamId === setupTeamAId ? setupTeamBId : setupTeamAId;

const setupBatters =
  Number(matchDetail?.teamAId) === setupBattingTeamId
    ? matchDetail?.teamA?.players || []
    : matchDetail?.teamB?.players || [];

const setupBowlers =
  Number(matchDetail?.teamAId) === setupBowlingTeamId
    ? matchDetail?.teamA?.players || []
    : matchDetail?.teamB?.players || [];

function playerNameFromTeam(team, playerId) {
  const id = Number(playerId);
  const players = team?.players || [];
  const player = players.find(
    (p) => Number(p.id) === id
  );

  return player?.name || "-";
}

function getAvailableNewBatters(battingTeam, ballForm, recentBalls = []) {
  const unavailableIds = new Set();

  recentBalls.forEach((ball) => {
    if (ball.dismissedPlayerId) {
      unavailableIds.add(Number(ball.dismissedPlayerId));
    }
  });

  if (ballForm?.dismissedPlayerId) {
    unavailableIds.add(Number(ballForm.dismissedPlayerId));
  }

  return (battingTeam?.players || []).filter((player) => {
    const id = Number(player.id);

    return (
      id !== Number(ballForm.strikerId) &&
      id !== Number(ballForm.nonStrikerId) &&
      !unavailableIds.has(id)
    );
  });
}
const availableNewBatters1 = getAvailableNewBatters(
  battingTeam,
  ballForm,
  recentBalls
);

const noNewBatterAvailable =
  ballForm?.dismissedPlayerId &&
  wicketNewBatterOptions.length === 0;

function getSafeScoringInningsNo(board, form) {
  const inningsFromBoard = Number(
    board?.currentInnings ||
      board?.currentState?.inningsNo ||
      board?.activeInningsNo ||
      0
  );

  if (inningsFromBoard === 1 || inningsFromBoard === 2) {
    return inningsFromBoard;
  }

  const inningsFromForm = Number(form?.inningsNo || 0);

  if (inningsFromForm === 1 || inningsFromForm === 2) {
    return inningsFromForm;
  }

  return 1;
}
  useEffect(() => {
  if (!scorerMode) return;

  window.addEventListener("keydown", handleScorerKeyPress);

  return () => {
    window.removeEventListener("keydown", handleScorerKeyPress);
  };
}, [
  scorerMode,
  isSavingBall,
  isMatchCompleted,
  isMatchLocked,
  isMatchAbandoned,
  ballForm,
  scoreboard,
]);
const lastScoredBall = recentBalls?.[0];

const lastBallText = lastScoredBall?.label
  ? String(lastScoredBall.label)
      .split(" ")
      .slice(1)
      .join(" ")
      .replace(/[()]/g, "") || lastScoredBall.label
  : "Waiting for first ball";

  function handleScorerKeyPress(e) {
  if (!scorerMode) return;
  if (isSavingBall || isMatchCompleted || isMatchLocked || isMatchAbandoned) return;

  const tag = document.activeElement?.tagName?.toLowerCase();
  if (["input", "select", "textarea"].includes(tag)) return;

  const key = e.key.toLowerCase();

  if (key === "0") quickNormalBall(0);
  if (key === "1") quickNormalBall(1);
  if (key === "2") quickNormalBall(2);
  if (key === "3") quickNormalBall(3);
  if (key === "4") quickNormalBall(4);
  if (key === "6") quickNormalBall(6);

  if (key === "w") quickWicket("BOWLED");
  if (key === "d") quickExtra("WIDE");
  if (key === "n") quickExtra("NOBALL");
  if (key === "b") quickExtra("BYE");
  if (key === "l") quickExtra("LEGBYE");

  if (key === "u") handleUndoBall();
}
async function startVoiceScoring() {
  try {
    if (!scorerMode) {
      setVoiceMessage("Open Scorer Mode first.");
      return;
    }

    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });

    const recorder = new MediaRecorder(stream);
    const chunks = [];

    recorder.ondataavailable = (event) => {
      if (event.data.size > 0) chunks.push(event.data);
    };

    recorder.onstop = async () => {
      stream.getTracks().forEach((track) => track.stop());

      const audioBlob = new Blob(chunks, { type: "audio/webm" });
      await sendVoiceCommand(audioBlob);
    };

    recorder.start();
    setVoiceRecorder(recorder);
    setVoiceChunks(chunks);
    setVoiceRecording(true);
    setVoiceMessage("🎙️ Listening...");
  } catch (err) {
    setVoiceMessage("Microphone permission denied or unavailable.");
  }
}

function stopVoiceScoring() {
  if (voiceRecorder && voiceRecorder.state !== "inactive") {
    voiceRecorder.stop();
  }

  setVoiceRecording(false);
}
async function sendVoiceCommand(audioBlob) {
  try {
    setVoiceBusy(true);
    setVoiceMessage("Understanding command...");

    const formData = new FormData();
    formData.append("audio", audioBlob, "voice-command.webm");

    const res = await fetch("/api/voice-score", {
      method: "POST",
      body: formData,
    });

    const data = await res.json();

    if (!res.ok) {
      throw new Error(data.error || "Voice scoring failed");
    }

    setVoiceMessage(`Heard: ${data.transcript}`);

    executeVoiceCommand(data.command);
    
  } catch (err) {
    setVoiceMessage(err.message);
  } finally {
    setVoiceBusy(false);
  }
}

function executeVoiceCommand(command) {
  if (!command || !command.action) return;

  if (isSavingBall || isMatchCompleted || isMatchLocked || isMatchAbandoned) {
    setVoiceMessage("Cannot score right now.");
    return;
  }

  switch (command.action) {
    case "RUN":
      quickNormalBall(Number(command.runs || 0));
      break;

    case "WIDE":
      quickExtra("WIDE", Number(command.runs || 1));
      break;

    case "NOBALL":
      quickExtra("NOBALL", Number(command.runs || 1));
      break;

    case "BYE":
      quickExtra("BYE", Number(command.runs || 1));
      break;

    case "LEGBYE":
      quickExtra("LEGBYE", Number(command.runs || 1));
      break;

    case "WICKET":
      quickWicket(command.wicketType || "BOWLED");
      break;

    case "UNDO":
      handleUndoBall();
      break;

    case "SWAP":
      swapBatters();
      break;

    case "RETIRED_HURT":
      setShowRetiredHurtModal(true);
      break;

    default:
      setVoiceMessage("Command not understood. Try: one, four, wide, wicket.");
  }
}

async function refreshPlayerLists() {
  await loadTeams();

  if (activeLeagueId) {
    await loadLeagues();
  }
}
const shouldPollMatch =
  pageVisible &&
  selectedMatchId &&
  activeTab === "scoring" &&
  effectiveScoringSubTab === "ADVANCED" &&
  !isMatchCompleted &&
  !isMatchLocked;

/*  useEffect(() => {
  if (!shouldPollMatch) return;
if (!pageVisible) return;
  const id = setInterval(() => {
    loadSelectedMatch(selectedMatchId);
  }, 5000);

  return () => clearInterval(id);
}, [shouldPollMatch, selectedMatchId]);
*/
useEffect(() => {
  if (!selectedMatchId) return;
  if (!pageVisible) return;
  if (ballSaveInFlight) return;
  if (showDeliverySetupModal) return;

  /*
   * Do not poll the server while the device is intentionally offline or
   * while local scoring changes are waiting to sync. The local scoreboard
   * is authoritative during that period.
   *
   * This also avoids repeatedly loading an older cached snapshot every
   * eight seconds while offline.
   */
  if (
    offlineSyncState?.online === false ||
    Number(offlineSyncState?.pending || 0) > 0
  ) {
    return;
  }

  const interval = setInterval(() => {
    loadSelectedMatch(selectedMatchId, {
      syncBallForm: false,
    });
  }, 8000);

  return () => clearInterval(interval);
}, [
  selectedMatchId,
  pageVisible,
  ballSaveInFlight,
  showDeliverySetupModal,
  offlineSyncState?.online,
  offlineSyncState?.pending,
]);

useEffect(() => {
  if (!dashboardReady) return;
  if (activeTab !== "Points") return;
  if (!activeLeagueId) return;

  loadPointsTable(activeLeagueId);
}, [dashboardReady, activeTab, activeLeagueId]);

useEffect(() => {
  if (!dashboardReady) return;
  if (activeTab !== "stats") return;
  if (!activeLeagueId) return;

  loadLeagueStats(
    activeLeagueId,
    {
      seriesIds:
        contextFilters?.seriesIds ||
        [],
    }
  );
}, [
  dashboardReady,
  activeTab,
  activeLeagueId,
  contextFilters?.seriesIds?.join(","),
]);

function safeSetJsonState(setter) {
  return (next) => {
    setter((prev) => {
      if (JSON.stringify(prev) === JSON.stringify(next)) {
        return prev;
      }
      return next;
    });
  };
}
useEffect(() => {
  return () => {
    try {
      recognitionRef.current?.stop?.();
    } catch {}
  };
}, []);
useEffect(() => {
  if (!scorerMode) {
    setVoiceScoringOn(false);
    try {
      recognitionRef.current?.stop?.();
    } catch {}
  }
}, [scorerMode]);

function startBrowserVoiceScore() {
  const SpeechRecognition =
    window.SpeechRecognition || window.webkitSpeechRecognition;

  if (!SpeechRecognition) {
    setVoiceStatus("Voice scoring is not supported in this browser.");
    return;
  }

  const recognition = new SpeechRecognition();
  recognition.lang = "en-US";
  recognition.interimResults = false;
  recognition.continuous = false;

  recognition.onstart = () => setVoiceStatus("🎙️ Listening...");

  recognition.onresult = (event) => {
    const transcript = event.results[0][0].transcript;
    setVoiceStatus(`Heard: ${transcript}`);
    handleVoiceCommand(transcript);
  };

  recognition.onerror = (event) => {
    setVoiceStatus(`Voice error: ${event.error}`);
  };

  recognition.onend = () => setVoiceStatus("");

  recognition.start();
}

const matchEnded =
  ["COMPLETED", "COMPLETED_LOCKED", "COMPLETED_CORRECTED"].includes(
    String(scoreboard?.match?.status || "").toUpperCase()
  );

const regulationMatchTied = (() => {
  const innings =
    displayScoreboard?.innings ||
    scoreboard?.innings ||
    [];

  const first =
    innings?.[0];

  const second =
    innings?.[1];

  const statusText =
    String(
      displayScoreboard?.summary?.statusText ||
      scoreboard?.summary?.statusText ||
      scoreboard?.match?.statusText ||
      ""
    )
      .trim()
      .toLowerCase();

  const sameScore =
    first &&
    second &&
    Number(first.runs) ===
      Number(second.runs);

  return Boolean(
    matchEnded &&
    (
      sameScore ||
      statusText.includes("match tied") ||
      statusText === "tied" ||
      statusText.includes(" tied")
    )
  );
})();

const scorerStatusText =
  selectedSuperOverState?.completed
    ? (selectedSuperOverState.resultText || "Match completed via Super Over")
    : selectedSuperOverState?.active
      ? `Super Over ${selectedSuperOverState.round || 1} in progress`
      : selectedSuperOverState?.tied
        ? `Super Over ${selectedSuperOverState.round || 1} tied — another Super Over required`
        : regulationMatchTied
          ? "Match tied — Super Over required"
          : (
              displayScoreboard?.summary?.statusText ||
              scoreboard?.summary?.statusText ||
              "Ready for next ball"
            );

const teamsInLeague =
  teams.filter(
    (t) => String(t.leagueId) === String(activeLeagueId)
  ) || [];

const minimumTeamsReady = teamsInLeague.length >= 2;

const minimumPlayersReady =
  minimumTeamsReady &&
  teamsInLeague.every(
    (team) =>
      (team.players?.length || 0) >= 2
  );

const leagueReadyForMatches =
  minimumTeamsReady &&
  minimumPlayersReady;

async function loadCorrectionHistory(matchId = selectedMatchId) {
  if (!matchId) return;

  const data = await api(`/api/matches/${matchId}/corrections`);
  setCorrectionHistory(Array.isArray(data) ? data : []);
}

async function applyCorrection() {
  if (!selectedMatchId) return;
setCorrectionError("");
  try {
    setCorrectionLoading(true);

    await api(`/api/matches/${selectedMatchId}/corrections`, {
      method: "POST",
      body: JSON.stringify({
        correctionType,
        payload: {
  ...correctionForm,
  inningsNo: correctionInnings,
},
        reason: correctionReason,
      }),
    });

    await loadSelectedMatch(selectedMatchId, {
      loadDetail: true,
      loadStatsData: true,
      syncBallForm: true,
    });

    await loadCorrectionHistory(selectedMatchId);

    setCorrectionReason("");
    setCorrectionForm({});

    await api(
      "/api/milestones/reconcile",
      {
        method:
          "POST",

        body:
          JSON.stringify({
            matchId:
              Number(
                selectedMatchId
              ),
          }),
      }
    );

    showToast("success", "✅ Scorecard correction applied.");
  } catch (err) {
  const message = err.message || "Correction failed.";
  setCorrectionError(message);
  showToast("error", message);
  } finally {
    setCorrectionLoading(false);
  }
}

async function rollbackCorrection(correctionId) {
  if (!selectedMatchId) return;

  if (!confirm("Rollback this correction?")) return;

  try {
    await api(`/api/matches/${selectedMatchId}/corrections/${correctionId}/rollback`, {
      method: "POST",
    });

    await api(
      "/api/milestones/reconcile",
      {
        method:
          "POST",

        body:
          JSON.stringify({
            matchId:
              Number(
                selectedMatchId
              ),
          }),
      }
    );

    await loadSelectedMatch(selectedMatchId, {
      loadDetail: true,
      loadStatsData: true,
      syncBallForm: true,
    });

    await loadCorrectionHistory(selectedMatchId);

    showToast("success", "↩️ Correction rolled back.");
  } catch (err) {
    setError(err.message);
    showToast("error", err.message);
  }
}

function getTeamById(teamId) {
  if (!matchDetail) return null;

  if (String(matchDetail.teamA?.id) === String(teamId)) {
    return matchDetail.teamA;
  }

  if (String(matchDetail.teamB?.id) === String(teamId)) {
    return matchDetail.teamB;
  }

  return null;
}

const battingFirstTeamId =
  matchDetail?.battingFirstTeamId ||
  matchDetail?.battingFirstTeam?.id ||
  selectedMatch?.battingFirstTeamId;

const teamAId = matchDetail?.teamA?.id;
const teamBId = matchDetail?.teamB?.id;

const battingPlayersForCorrection =
  battingTeamForCorrection?.players || [];

const bowlingPlayersForCorrection =
  bowlingTeamForCorrection?.players || [];

async function openCorrectionCenter(matchIdFromButton = null) {
  const matchIdToUse =
    Number(matchIdFromButton) ||
    Number(selectedMatchId) ||
    Number(selectedMatch?.id) ||
    Number(scoreboard?.match?.id) ||
    Number(matchDetail?.id);

  if (!matchIdToUse) {
    setError("Please select a match first.");
    return;
  }

  setSelectedMatchId(String(matchIdToUse));

  await loadSelectedMatch(matchIdToUse, {
    loadDetail: true,
    loadStatsData: true,
    syncBallForm: false,
  });

  await loadCorrectionHistory(matchIdToUse);

  setCorrectionInnings(1);
  setCorrectionForm({});
  setCorrectionReason("");
  setShowCorrectionCenter(true);
}

const wicketBallsForCorrection =
  (matchDetail?.balls || [])
    .filter(
      (ball) =>
        Number(ball.inningsNo) === Number(correctionInnings) &&
        Boolean(ball.isWicket)
    )
    .sort((a, b) => Number(a.sequence) - Number(b.sequence));

const oversForCorrection = [
  ...new Set(
    (matchDetail?.balls || [])
      .filter((b) => Number(b.inningsNo) === Number(correctionInnings))
      .map((b) => Number(b.overNo))
      .filter((n) => !Number.isNaN(n))
  ),
].sort((a, b) => a - b);

const [correctionError, setCorrectionError] = useState("");

const retiredHurtBallsForCorrection = (matchDetail?.balls || [])
  .filter(
    (ball) =>
      Number(ball.inningsNo) === Number(correctionInnings) &&
      String(ball.wicketType || "").toUpperCase() === "RETIRED_HURT"
  )
  .sort((a, b) => Number(a.sequence) - Number(b.sequence));

const scoreboardInnings = scoreboard?.innings || [];

const activeInningsForScoreboard =
  scoreboardInnings.find(
    (inn) => Number(inn.number) === Number(activeScoreboardInnings)
  ) || scoreboardInnings[0];

  
const auditLeagueGroups = Object.values(
  (auditLogs || []).reduce((groups, log) => {
    const key = String(log.leagueId ?? log.leagueName ?? "NO_LEAGUE");

    const label =
      log.leagueName ||
      (log.leagueId ? `League #${log.leagueId}` : "System / No League");

    if (!groups[key]) {
      groups[key] = {
        key,
        label,
        logs: [],
      };
    }

    groups[key].logs.push(log);
    return groups;
  }, {})
);

const visibleAuditLogs =
  selectedAuditLeagueKey === "ALL"
    ? auditLogs
    : auditLeagueGroups.find(
        (group) => String(group.key) === String(selectedAuditLeagueKey)
      )?.logs || [];

const groupedRecentLogins = Object.values(
  (userActivity?.recentLogins || []).reduce((groups, login) => {
    const key = login.userId || login.email || login.id;

    if (!groups[key]) {
      groups[key] = {
        key,
        name: login.name || "Unknown User",
        email: login.email,
        logins: [],
      };
    }

    groups[key].logins.push(login);
    return groups;
  }, {})
);      

async function handleSaveSeries(e) {
  e.preventDefault();

  const isEditing = Boolean(editingSeries?.id);

  const url = isEditing
    ? `/api/series/${editingSeries.id}`
    : "/api/series";

  const method = isEditing ? "PATCH" : "POST";

  await api(url, {
    method,
    body: JSON.stringify({
      leagueId: activeLeagueId,
      name: seriesForm.name.trim(),
      year: Number(seriesForm.year),
      status: seriesForm.status || "ACTIVE",
    }),
  });

  setShowSeriesModal(false);
  setEditingSeries(null);
  setSeriesForm({
    name: "",
    year: new Date().getFullYear(),
    status: "ACTIVE",
  });

  await loadSeries(activeLeagueId);
}

async function handleDeleteSeries(seriesId, seriesName) {
  const confirmed = window.confirm(
    `Delete series "${seriesName}"?\n\nThis is only allowed when no matches are linked to this series.`
  );

  if (!confirmed) return;

  try {
    await api(`/api/series/${seriesId}`, {
      method: "DELETE",
    });

    if (String(selectedSeriesId) === String(seriesId)) {
      setSelectedSeriesId("");
    }

    await loadSeries(activeLeagueId);
  } catch (err) {
    console.error("Delete series failed:", err);
    alert(err.message || "Series cannot be deleted.");
  }
}

const canUseAvailabilityBuilder =
  Boolean(permissions?.canUseTeamBuilder) ||
  Boolean(permissions?.canScoreMatch);

async function handleShareScheduledMatch(match) {
  const shareCode =
    match?.shareCode ||
    match?.sharecode ||
    match?.publicShareCode;

  if (!shareCode) {
    alert("Share code is not available for this match.");
    return;
  }

  const shareUrl =
    `${spectatorShareSiteUrl}/live/${encodeURIComponent(
      shareCode
    )}/share-v1`;

  const shareText = `🏏 ${match.teamAName} vs ${match.teamBName}

📅 ${
    match.scheduledAt
      ? formatDate(match.scheduledAt)
      : "Schedule not decided"
  }

Follow the live score on Cric4All:
${shareUrl}`;

  try {
    const result =
      await shareCric4All({
        title: `${match.teamAName} vs ${match.teamBName}`,
        text: shareText,
        url: shareUrl,
        dialogTitle: "Share scheduled Cric4All match",
      });

    if (result?.cancelled) {
      return;
    }

    if (result?.unsupported) {
      await navigator.clipboard.writeText(
        shareUrl
      );

      alert(
        "Match link copied."
      );
    }
  } catch (error) {
    console.error(
      "Share scheduled match failed:",
      error
    );

    try {
      await navigator.clipboard.writeText(
        shareUrl
      );

      alert(
        "Match link copied."
      );
    } catch {
      alert(
        "Unable to share this match right now."
      );
    }
  }
}

async function handleShareActiveMatch(match) {
  const shareCode =
    match?.shareCode ||
    match?.sharecode ||
    match?.publicShareCode;

  if (!shareCode) {
    alert("Share code is not available for this match.");
    return;
  }

  const shareUrl =
    `${spectatorShareSiteUrl}/live/${encodeURIComponent(
      shareCode
    )}/share-v1`;

  const shareText = `🏏 ${match.teamAName} vs ${match.teamBName}

Follow the live score on Cric4All:
${shareUrl}`;

  try {
    const result =
      await shareCric4All({
        title: `${match.teamAName} vs ${match.teamBName}`,
        text: shareText,
        url: shareUrl,
        dialogTitle: "Share live Cric4All match",
      });

    if (result?.cancelled) {
      return;
    }

    if (result?.unsupported) {
      await navigator.clipboard.writeText(
        shareUrl
      );

      alert(
        "Live match link copied."
      );
    }
  } catch (error) {
    console.error(
      "Share active match failed:",
      error
    );

    try {
      await navigator.clipboard.writeText(
        shareUrl
      );

      alert(
        "Live match link copied."
      );
    } catch {
      alert(
        "Unable to share this match right now."
      );
    }
  }
}

function getRecentBallText(ball) {
  const directText =
    ball?.shortText ||
    ball?.displayText ||
    ball?.resultText;

  if (directText) {
    return String(directText)
      .replace(/[()]/g, "")
      .trim();
  }

  const label = String(ball?.label || "").trim();

  /*
    Handles labels such as:
    "4.1 2"
    "4.2 W"
    "5.1 Wd"
  */
  return (
    label.replace(/^\s*\d+\.\d+\s*/, "") ||
    label ||
    "-"
  )
    .replace(/[()]/g, "")
    .trim();
}

function openScoringFormSheet() {
  /*
    Do not close Scorer Mode.
    The scoring form opens above it as a modal sheet.
  */
  setScorerDrawer(null);
  setShowScoringFormSheet(true);
}

function closeScoringFormSheet() {
  setShowScoringFormSheet(false);
}

const availableBowlerOptions = (bowlingTeam?.players || [])
  .filter(
    (player) =>
      String(player.id) !==
      String(pendingBallData?.bowlerId)
  )
  .filter((player) =>
    String(player.name || "")
      .toLowerCase()
      .includes(
        bowlerSearchText.trim().toLowerCase()
      )
  )
  .sort((first, second) =>
    String(first.name || "").localeCompare(
      String(second.name || "")
    )
  );

  async function handleScoringFormSheetSubmit(event) {
  event.preventDefault();

  if (scoringFormSubmitting) return;

  setScoringFormSubmitting(true);

  try {
    const saved = await handleAddBall(event);

    if (!saved) {
      return;
    }

    /*
      Close only after the API and existing refresh logic
      have completed successfully.
    */
    setShowScoringFormSheet(false);

    /*
      Keep Scorer Mode open and clear any sheet-only scroll.
    */
    setScorerDrawer(null);
  } finally {
    setScoringFormSubmitting(false);
  }
}
const activeScoringInningsNo =
  Number(
    ballForm?.inningsNo ??
    displayScoreboard?.currentState?.inningsNo ??
    scoreboard?.currentState?.inningsNo ??
    1
  ) || 1;

useEffect(() => {
  /*
    Clear UI-only scorer drawers when innings changes.
    The filtered API deliveries will rebuild the recent-over
    panel using only the new innings.
  */
  setScorerDrawer(null);
}, [activeScoringInningsNo]);

const mobileRecentDeliveryItems = useMemo(() => {
  const sourceBalls = Array.isArray(recentBalls)
    ? recentBalls
    : [];

  /*
    Your recentBalls array already arrives newest-first.

    Do not reverse it:
    index 0 = newest delivery shown on the left.
  */
  return sourceBalls
    .slice(0, 24)
    .map((ball, index) => {
      const inningsNo =
        getRecentBallInningsNo(ball);

      const overNumber =
        getRecentBallOverNumber(ball);

      return {
        key:
          ball?.id ??
          ball?.sequence ??
          `recent-${index}`,

        ball,
        inningsNo,
        overNumber,

        /*
          Unique boundary key prevents innings 1 over 1
          and innings 2 over 1 from being treated alike.
        */
        overKey:
          inningsNo !== null &&
          overNumber !== null
            ? `${inningsNo}-${overNumber}`
            : overNumber !== null
              ? `unknown-${overNumber}`
              : null,
      };
    });
}, [recentBalls]);

const extrasModalCurrentOver = useMemo(() => {
  const balls = Array.isArray(recentBalls)
    ? recentBalls
    : [];

  /*
    Cricket overs such as 1.2 mean:
    one completed over plus two balls in the second over.

    The stored over number is normally zero-based:
    0 = first over
    1 = second over
  */
  const currentOverIndex = Math.floor(
    Number(bowlerChangeScore?.overs || 0)
  );

  function readOverNumber(ball) {
    const directValue =
      ball?.overNumber ??
      ball?.overNo ??
      ball?.deliveryOver ??
      ball?.over;

    const directNumber = Number(directValue);

    if (Number.isFinite(directNumber)) {
      return directNumber;
    }

    const rawLabel = String(
      ball?.label ||
      ball?.shortText ||
      ball?.displayText ||
      ""
    );

    const match = rawLabel.match(
      /^\s*(\d+)\.(\d+)/
    );

    return match ? Number(match[1]) : null;
  }

  function readSequence(ball, fallbackIndex) {
    const values = [
      ball?.sequence,
      ball?.sequenceNo,
      ball?.deliverySequence,
      ball?.ballSequence,
      ball?.id,
    ];

    for (const value of values) {
      const parsed = Number(value);

      if (Number.isFinite(parsed)) {
        return parsed;
      }
    }

    return fallbackIndex;
  }

  const currentBalls = balls
    .map((ball, index) => ({
      ...ball,
      __overNumber: readOverNumber(ball),
      __sequence: readSequence(ball, index),
    }))
    .filter(
      (ball) =>
        ball.__overNumber === currentOverIndex
    )
    /*
      Descending order:
      latest delivery appears on the left.
    */
    .sort(
      (first, second) =>
        second.__sequence - first.__sequence
    );

  return {
    overNo: currentOverIndex + 1,
    balls: currentBalls,
  };
}, [recentBalls, bowlerChangeScore?.overs]);

/*
 * Resolve the signed-in user's role for the active league.
 *
 * /permissions/me may return only Boolean permissions in some existing
 * deployments. Defaulting a missing role to VIEWER incorrectly made
 * Super Admins and permission managers appear read-only in the dashboard.
 *
 * Use only an explicitly supplied VIEWER role to activate Viewer lock-down.
 */
const activeLeagueRole =
  String(
    permissions?.role ||
    activeLeague?.membershipRole ||
    activeLeague?.role ||
    selectedLeague?.membershipRole ||
    selectedLeague?.role ||
    ""
  )
    .trim()
    .toUpperCase();

const allowedInviteRolesForCurrentUser = getAllowedInviteRoles({
  role: activeLeagueRole,
  permissions,
  isSuperAdmin,
});

const canUnregisterLeagueMembers = Boolean(
  isSuperAdmin ||
  activeLeagueRole === "OWNER"
);

/*
 * The Leagues tab is the universal entry point for every authenticated
 * Cric4All user. A user must be able to open League Management even when
 * they do not belong to any league yet, because this is where they create
 * their first league. League-specific actions inside the page remain guarded
 * by activeLeagueId and the existing permission checks.
 */
const canShowManagementTab = true;

function openInviteRoleComposer() {
  if (!activeLeague || !allowedInviteRolesForCurrentUser.length) {
    setError("Your current league role cannot create member invitation links.");
    return;
  }

  const firstAllowedRole = allowedInviteRolesForCurrentUser[0];

  setSelectedInviteRole((currentRole) =>
    allowedInviteRolesForCurrentUser.includes(currentRole)
      ? currentRole
      : firstAllowedRole
  );
  setShowInviteRoleModal(true);
}

/*
 * Add Players access is intentionally narrower than canCreatePlayer.
 * It is available only to Super Admin, OWNER, ADMIN, CAPTAIN, or a
 * member explicitly granted canManagePermissions.
 */
const canAddPlayers = Boolean(
  isSuperAdmin ||
    permissions?.canManagePermissions === true ||
    ["OWNER", "ADMIN", "CAPTAIN"].includes(activeLeagueRole)
);

/*
 * Player editing must not disappear for league Owners/Admins merely because
 * an older LeagueMember record does not contain canEditPlayer=true.
 *
 * Preserve explicit permission grants for custom roles, while treating
 * OWNER / ADMIN / permission managers as authoritative management roles.
 *
 * Delete remains controlled separately by canDeletePlayer so this does not
 * broaden destructive access.
 */
const canEditPlayers = Boolean(
  isSuperAdmin ||
    permissions?.canEditPlayer === true ||
    permissions?.canManagePermissions === true ||
    ["OWNER", "ADMIN"].includes(activeLeagueRole)
);

async function shareCompletedMatch(match) {
  if (!match?.id) return;

  const leagueSlug = String(
    activeLeagueSlug || selectedLeague?.slug || ""
  ).trim();

  const visibility = String(
    selectedLeague?.visibility || ""
  ).toUpperCase();

  const usePublicPage =
    Boolean(leagueSlug) &&
    ["PUBLIC", "UNLISTED"].includes(visibility);

  const path = usePublicPage
    ? `/leagues/${encodeURIComponent(leagueSlug)}/matches/${match.id}`
    : match.shareCode
      ? `/live/${encodeURIComponent(match.shareCode)}/share-v1`
      : "";

  if (!path) {
    setError("This match does not have a shareable link yet.");
    return;
  }

  const configuredSiteUrl =
    String(
      process.env.NEXT_PUBLIC_SITE_URL ||
      "https://cric4all.app"
    )
      .trim()
      .replace(/\/+$/, "");

  const cleanUrl =
    `${configuredSiteUrl}${path}`;

  /*
   * WhatsApp/social apps cache URL previews aggressively. The stable Match
   * Center remains canonical, while this harmless query gives a corrected
   * Phase-6 share a fresh scrape after the earlier broken OG response.
   */
  const url =
    usePublicPage
      ? `${cleanUrl}/share-v5`
      : cleanUrl;

  const teamA = match.teamAName || match.teamA?.name || "Team A";
  const teamB = match.teamBName || match.teamB?.name || "Team B";
  const result = String(match.statusText || "").trim();

  const normalizedResult =
    result
      .replace(/-/g, "_")
      .toUpperCase();

  const technicalStatuses =
    new Set([
      "",
      "LIVE",
      "SCHEDULED",
      "IN_PROGRESS",
      "IN PROGRESS",
      "COMPLETED",
      "COMPLETED_LOCKED",
      "COMPLETED LOCKED",
      "COMPLETED_CORRECTED",
      "COMPLETED CORRECTED",
      "MATCH COMPLETED",
      "LOCKED",
    ]);

  const shareableResult =
    technicalStatuses.has(
      normalizedResult
    )
      ? ""
      : result;

  const text =
    shareableResult &&
    !["LIVE", "SCHEDULED", "MATCH COMPLETED"].includes(shareableResult.toUpperCase())
      ? `🏏 ${teamA} vs ${teamB}\n🏆 ${shareableResult}\n\nView the Cric4All scorecard:`
      : `🏏 ${teamA} vs ${teamB}\n\nView the Cric4All scorecard:`;

  fetch("/api/growth/event", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    keepalive: true,
    body: JSON.stringify({
      eventType: "SHARE_SCORECARD",
      leagueId: activeLeagueId ? Number(activeLeagueId) : null,
      matchId: Number(match.id),
      source: "COMPLETED_MATCH",
      path: window.location.pathname,
      metadata: {
        shareTarget: usePublicPage ? "PUBLIC_MATCH_CENTER" : "LIVE_SHARE",
      },
    }),
  }).catch(() => {});

  try {
    const result =
      await shareCric4All({
        title: `${teamA} vs ${teamB} | Cric4All`,
        text,
        url,
        dialogTitle: "Share Cric4All match result",
      });

    if (result?.cancelled) {
      return;
    }

    if (result?.unsupported) {
      await navigator.clipboard.writeText(
        `${text}\n${url}`
      );

      setMessage(
        "🔗 Match result link copied."
      );

      showToast?.(
        "success",
        "🔗 Match result link copied"
      );
    }
  } catch (error) {
    try {
      await navigator.clipboard.writeText(
        `${text}\n${url}`
      );

      setMessage(
        "🔗 Match result link copied."
      );
    } catch {
      setError(
        "Unable to share this match from this device."
      );
    }
  }
}

const canImportLeagueRoster = Boolean(
  isSuperAdmin ||
    permissions?.canManagePermissions === true ||
    ["OWNER", "ADMIN"].includes(activeLeagueRole) ||
    (
      permissions?.canCreateTeam === true &&
      permissions?.canCreatePlayer === true
    )
);

const activeLeagueSlug = String(
  activeLeague?.slug ||
    selectedLeague?.slug ||
    ""
).trim();

function getPlayerCardHref(playerId) {
  const player = (selectedTeam?.players || []).find(
    (item) => Number(item.id) === Number(playerId)
  );

  if (
    shouldExcludePlayerFromLeagueAnalytics(
      activeLeague || selectedLeague,
      player
    )
  ) {
    return "";
  }

  if (!activeLeagueSlug || !playerId) {
    return "";
  }

  const returnTo =
    `/dashboard?tab=management` +
    `&leagueId=${encodeURIComponent(
      String(
        activeLeagueId ||
          ""
      )
    )}` +
    `&teamId=${encodeURIComponent(
      String(
        selectedTeamId ||
          ""
      )
    )}` +
    `&section=players`;

  return (
    `/leagues/${encodeURIComponent(
      activeLeagueSlug
    )}` +
    `/players/${encodeURIComponent(
      String(
        playerId
      )
    )}` +
    `?returnTo=${encodeURIComponent(
      returnTo
    )}` +
    `&from=players`
  );
}

useEffect(() => {
  if (!canAddPlayers && showPlayerModal) {
    setShowPlayerModal(false);
  }
}, [canAddPlayers, showPlayerModal]);

const isExplicitBirthdayViewer =
  !isSuperAdmin &&
  activeLeagueRole ===
    "VIEWER";

const canViewBirthdayTools =
  Boolean(
    isSuperAdmin ||
    permissions
      ?.canManagePermissions ===
      true ||
    permissions
      ?.canScoreMatch ===
      true ||
    isExplicitBirthdayViewer
  );

/*
 * Privileged access takes precedence when role information is absent.
 * An explicitly identified VIEWER remains read-only even if canScoreMatch
 * is true, exactly as required.
 */
const canManageBirthdayTools =
  Boolean(
    isSuperAdmin ||
    (
      !isExplicitBirthdayViewer &&
      permissions
        ?.canManagePermissions ===
        true
    )
  );

const canManagePlayerInactivityAlerts =
  Boolean(
    isSuperAdmin ||
    activeLeagueRole ===
      "OWNER"
  );

const canDeletePlayers =
  Boolean(
    isSuperAdmin ||
    activeLeagueRole ===
      "OWNER" ||
    permissions?.canDeletePlayer ===
      true
  );

const canViewLeagueKitShortcut =
  Boolean(
    isSuperAdmin ||
    permissions
      ?.canManagePermissions ===
      true ||
    permissions
      ?.canScoreMatch ===
      true
  );

function MobileMatchSetup({ match, includeTimeline = false }) {
  return (
    <details className="mobile-match-setup">
      <summary className="mobile-match-setup-summary">
        <div>
          <span className="mobile-match-setup-icon">⚙️</span>

          <span>
            <strong>Match Setup & Roles</strong>
            <small>Rules, captains and wicketkeepers</small>
          </span>
        </div>

        <i>⌄</i>
      </summary>

      <div className="mobile-match-setup-body">
        <div className="mobile-match-facts">
          <div>
            <span>🏏 Bat first</span>
            <strong>
              {match.battingFirstTeamName || "Not decided"}
            </strong>
          </div>

          <div>
            <span>🎯 Overs</span>
            <strong>{match.oversPerInnings}</strong>
          </div>

          <div>
            <span>⚾ Wickets</span>
            <strong>
              {match.maxWicketsPerInnings ?? "∞"}
            </strong>
          </div>

          <div>
            <span>⚡ Powerplay</span>
            <strong>
              {match.powerplayOversInnings ?? 0}
            </strong>
          </div>

          <div>
            <span>🎳 Max / Bowler</span>
            <strong>
              {match.maxOversPerBowler ?? "∞"}
            </strong>
          </div>
        </div>

        <div className="mobile-match-role-list">
          <div>
            <span>🧤 {match.teamAName}</span>
            <strong>
              {match.teamAWicketKeeperName ||
                "Wicketkeeper not selected"}
            </strong>
          </div>

          <div>
            <span>🧤 {match.teamBName}</span>
            <strong>
              {match.teamBWicketKeeperName ||
                "Wicketkeeper not selected"}
            </strong>
          </div>

          <div>
            <span>👑 {match.teamAName}</span>
            <strong>
              {match.teamACaptainName ||
                "Captain not selected"}
            </strong>
          </div>

          <div>
            <span>👑 {match.teamBName}</span>
            <strong>
              {match.teamBCaptainName ||
                "Captain not selected"}
            </strong>
          </div>
        </div>

        {includeTimeline &&
          (match.startedAt ||
            match.endedAt ||
            match.lockedAt) && (
            <div className="mobile-match-timeline">
              {match.startedAt && (
                <div>
                  <span>Started</span>
                  <strong>
                    {formatMatchDateTime(match.startedAt)}
                  </strong>
                </div>
              )}

              {match.endedAt && (
                <div>
                  <span>Ended</span>
                  <strong>
                    {formatMatchDateTime(match.endedAt)}
                  </strong>
                </div>
              )}

              {match.lockedAt && (
                <div>
                  <span>Locked</span>
                  <strong>
                    {formatMatchDateTime(match.lockedAt)}
                  </strong>
                </div>
              )}
            </div>
          )}
      </div>
    </details>
  );
}

function ContextLens() {
  const totalFilters =
    (contextFilters.teamIds?.length || 0) +
    (contextFilters.matchIds?.length || 0) +
    (contextFilters.playerNames?.length || 0) +
    (contextFilters.statuses?.length || 0) +
    (contextFilters.roles?.length || 0) +
    (contextFilters.seriesIds?.length || 0) +
    (contextFilters.years?.length || 0);

  return (
    <div className="smart-filter-pill">
      <button
        type="button"
        className="smart-filter-main"
        onClick={() => setOpenFilter("filterCenter")}
      >
        <span className="smart-filter-icon">🔎</span>

        <span className="smart-filter-text">
          <strong>Smart Filters</strong>
          <small>
            {totalFilters
              ? `${totalFilters} active`
              : "All records"}
          </small>
        </span>

        <span className="smart-filter-action">
          Open
        </span>
      </button>

      {totalFilters > 0 && (
        <button
          type="button"
          className="smart-filter-reset"
          onClick={() => {
            clearContextFilters();
            setFilterSearch("");
            setFilterCategory("teams");
          }}
        >
          Reset
        </button>
      )}
    </div>
  );
}

return (
  <>
{Boolean(returnTo) && (
  <div
    className={matchDayNavStyles.returnBar}
    role="navigation"
    aria-label="Return navigation"
  >
    <Link
      href={returnTo}
      className={matchDayNavStyles.returnButton}
    >
      <span aria-hidden="true">←</span>
      <span>
        {returningToMatchDay
          ? "Back to Match Day"
          : "Back"}
      </span>
    </Link>

    {returningToMatchDay && (
      <span className={matchDayNavStyles.returnContext}>
        Return to the selected match workflow
      </span>
    )}
  </div>
)}

<div
  className={`dashboard-tabs-wrap ${
    tabsScrolled ? "scrolled" : ""
  } ${matchDayNavStyles.matchDayTabsWrap}`}
>

<div
  className="dashboard-tabs"
  onScroll={(e) => {
    if (e.currentTarget.scrollLeft > 10) {
      setTabsScrolled(true);
    }
  }}
>
{!dashboardReady || permissionsLoading ? (
  <div className="dashboard-tabs-loading">
    Loading dashboard...
  </div>
) : (
  <>
      {canShowManagementTab && (
        <button
          className={`dashboard-tab ${
            activeTab === "management"
              ? "active"
              : ""
          }`}
          onClick={() =>
            setActiveTab("management")
          }
        >
          <span
            className={matchDayNavStyles.tabIcon}
            aria-hidden="true"
          >
            ⚙️
          </span>
          <span className={matchDayNavStyles.tabLabel}>
            Leagues
          </span>
        </button>
      )}

      {permissions?.canViewMatches && (
        <button
          className={`dashboard-tab ${
            activeTab === "matches"
              ? "active"
              : ""
          }`}
          onClick={() =>
            setActiveTab("matches")
          }
        >
          <span
            className={matchDayNavStyles.tabIcon}
            aria-hidden="true"
          >
            📋
          </span>
          <span className={matchDayNavStyles.tabLabel}>
            Matches
          </span>
        </button>
      )}

      {permissions?.canViewMatches && (
        <button
          type="button"
          className="dashboard-tab"
          disabled={!activeLeagueId}
          title={
            activeLeagueId
              ? "Open Match Day Command Center"
              : "Select a league first"
          }
          onClick={() => {
            if (!activeLeagueId) {
              setError(
                "Select a league before opening Match Day."
              );
              return;
            }

            router.push(
              `/leagues/${activeLeagueId}/match-day`
            );
          }}
        >
          <span
            className={matchDayNavStyles.tabIcon}
            aria-hidden="true"
          >
            🎛️
          </span>
          <span className={matchDayNavStyles.tabLabel}>
            Match Day
          </span>
        </button>
      )}

      {permissions?.canViewScoring && (
        <button
          className={`dashboard-tab ${
            activeTab === "scoring"
              ? "active"
              : ""
          }`}
          onClick={() =>
            setActiveTab("scoring")
          }
        >
          <span
            className={matchDayNavStyles.tabIcon}
            aria-hidden="true"
          >
            🏏
          </span>
          <span className={matchDayNavStyles.tabLabel}>
            Scoring
          </span>
        </button>
      )}
        <button
          className={`dashboard-tab ${
            activeTab === "Points"
              ? "active"
              : ""
          }`}
          onClick={() =>
            setActiveTab("Points")
          }
        >
          <span
            className={matchDayNavStyles.tabIcon}
            aria-hidden="true"
          >
            🥇
          </span>
          <span className={matchDayNavStyles.tabLabel}>
            Points
          </span>
        </button>

      {permissions?.canViewStats && (
        <button
          className={`dashboard-tab ${
            activeTab === "stats"
              ? "active"
              : ""
          }`}
onClick={() => {
  setActiveTab("stats");
  loadLeagueStats(activeLeagueId);
}}
        >
          <span
            className={matchDayNavStyles.tabIcon}
            aria-hidden="true"
          >
            📊
          </span>
          <span className={matchDayNavStyles.tabLabel}>
            Stats
          </span>
        </button>
      )}

      {permissions?.canManagePermissions && (
        <button
          className={`dashboard-tab ${
            activeTab === "permissions"
              ? "active"
              : ""
          }`}
          onClick={() =>
            setActiveTab("permissions")
          }
        >
          <span
            className={matchDayNavStyles.tabIcon}
            aria-hidden="true"
          >
            🔐
          </span>
          <span className={matchDayNavStyles.tabLabel}>
            Access
          </span>
        </button>
      )}

      <button
          className={`dashboard-tab ${
            activeTab === "help"
              ? "active"
              : ""
          }`}
        onClick={() =>
          setActiveTab("help")
        }
      >
        <span
          className={matchDayNavStyles.tabIcon}
          aria-hidden="true"
        >
          ❓
        </span>
        <span className={matchDayNavStyles.tabLabel}>
          Help
        </span>
      </button>

      <button
          className={`dashboard-tab ${
            activeTab === "about"
              ? "active"
              : ""
          }`}
        onClick={() =>
          setActiveTab("about")
        }
      >
        <span
          className={matchDayNavStyles.tabIcon}
          aria-hidden="true"
        >
          ℹ️
        </span>
        <span className={matchDayNavStyles.tabLabel}>
          About
        </span>
      </button>
{session?.user?.email === "surprisecricket11@gmail.com" && (
  <button
    className={`dashboard-tab ${activeTab === "admin" ? "active" : ""}`}
    onClick={() => setActiveTab("admin")}
  >
    🛡️ Admin
  </button>
)}
    </>
  )}
</div>
</div>

  {activeTab === "scoring" && (
<div className="scoring-layout">

<Card
  title="🏏 Match Center"
  defaultCollapsed={true}
>
<div className="match-center compact-match-center"> 
<div className="match-command-single">
  <div className="match-command-top">
    <div className="match-command-league-inline">
      <span>🏆 League</span>
      <strong>
        {leagues.find((l) => Number(l.id) === Number(activeLeagueId))?.name ||
          "No league selected"}
      </strong>
    </div>

    <div className="match-command-context">
      <ContextLens />
    </div>
  </div>

  <button
    type="button"
    className="match-command-selected full"
    onClick={() => setShowMatchPicker((prev) => !prev)}
  >
    <div>
      <span>🏏 Match</span>
      <strong>
        {selectedMatch
          ? `${selectedMatch.teamAName} vs ${selectedMatch.teamBName}`
          : "Choose a match"}
      </strong>
      <small>
        {selectedMatch
          ? `${selectedMatch.status || "SCHEDULED"} • ${
              selectedMatch.battingFirstTeamName
                ? `Bat 1st: ${selectedMatch.battingFirstTeamName}`
                : "Batting first not decided"
            }`
          : "Tap to select active, scheduled, or completed match"}
      </small>
    </div>

    <b>{showMatchPicker ? "⌃" : "⌄"}</b>
  </button>

  {showMatchPicker && (
    <div className="match-choice-panel match-choice-panel-wow inside">
      {scoringComboMatches.map((match) => (
        <button
          key={match.id}
          type="button"
          className={`match-choice-card ${
            String(selectedMatchId) === String(match.id) ? "active" : ""
          }`}
          onClick={() => {
            handleScoringMatchSelect(match.id);
            setShowMatchPicker(false);
          }}
        >
          <div>
            <strong>{match.teamAName} vs {match.teamBName}</strong>
            <span>{getMatchOptionLabel(match)}</span>
          </div>

          <b>{String(selectedMatchId) === String(match.id) ? "✓" : "→"}</b>
        </button>
      ))}
    </div>
  )}
</div>
</div>
</Card>
<Card title = "Score Details" 
    right={
    selectedMatchId ? (
      <button
        type="button"
        className="share-score-btn"
        onClick={handleShareMatch}
      >
        📤 Share - Spectator View
      </button>
    ) : null
  }
>
{selectedMatchId && (
  <div className="score-hub-shell">
    {matchDetail && (
      <details className="match-setup-wow">
        <summary className="match-setup-wow-summary">
          <div className="match-setup-wow-left">
            <div className="match-setup-wow-icon">📋</div>

            <div className="match-setup-wow-text">
              <div className="match-setup-wow-title-row">
                <span>Match Setup</span>
                <b>▼</b>
              </div>

              <small>
                {selectedMatch
                  ? `${selectedMatch.teamAName} vs ${selectedMatch.teamBName}`
                  : "Tap to view match details"}
              </small>
            </div>
          </div>

          <div className="match-setup-wow-status">
            {selectedMatch?.status || "MATCH"}
          </div>
        </summary>

        <div className="match-setup-wow-body">
          {selectedMatch && (
            <div className="selected-match-banner">
              <div>
                <strong>
                  {selectedMatch.teamAName} vs {selectedMatch.teamBName}
                </strong>
                <span>
                  {selectedMatch.battingFirstTeamName
                    ? `Batting first: ${selectedMatch.battingFirstTeamName}`
                    : "Batting first not decided"}
                </span>
              </div>

              <span className="pill">{selectedMatch.status}</span>
            </div>
          )}

          <div className="match-setup-grid">
            <div>
              <span>Overs</span>
              <strong>{matchDetail?.oversPerInnings || "-"}</strong>
            </div>

            <div>
              <span>Wickets</span>
              <strong>{matchDetail?.maxWicketsPerInnings || "Unlimited"}</strong>
            </div>

            <div>
              <span>Powerplay</span>
              <strong>{matchDetail?.powerplayOversInnings ?? 0}</strong>
            </div>

            <div>
              <span>Max / Bowler</span>
              <strong>{matchDetail?.maxOversPerBowler || "Unlimited"}</strong>
            </div>
          </div>

          <div className="match-officials-pills">
            <div className="team-official-pill">
              <strong>{matchDetail?.teamA?.name || "Team A"}</strong>
              <span>
                🧢 {playerNameFromTeam(matchDetail?.teamA, matchDetail?.teamACaptainId)}
              </span>
              <span>
                🧤 {playerNameFromTeam(matchDetail?.teamA, matchDetail?.teamAWicketKeeperId)}
              </span>
            </div>

            <div className="team-official-pill">
              <strong>{matchDetail?.teamB?.name || "Team B"}</strong>
              <span>
                🧢 {playerNameFromTeam(matchDetail?.teamB, matchDetail?.teamBCaptainId)}
              </span>
              <span>
                🧤 {playerNameFromTeam(matchDetail?.teamB, matchDetail?.teamBWicketKeeperId)}
              </span>
            </div>
          </div>
        </div>
      </details>
    )}

<div className="score-hub-tabs wow-main-tabs">
  {!isSelectedMatchCompleted && (
    <button
      type="button"
      className={`wow-score-tab ${
        effectiveScoringSubTab === "ADVANCED"
          ? "active"
          : ""
      }`}
      onClick={() => {
        setScorerMode(false);
        setScorerDrawer(null);
        setScoringSubTab("ADVANCED");
      }}
      aria-label="Open Scoring"
      title="Scoring"
    >
      <span className="wow-tab-icon">🎯</span>

      <span className="wow-tab-copy">
        <strong>Scoring</strong>
        <small>Ball-by-ball scoring</small>
      </span>
    </button>
  )}

  <button
    type="button"
    className={`wow-score-tab ${
      effectiveScoringSubTab === "SCOREBOARD"
        ? "active"
        : ""
    }`}
    onClick={() => {
      setScorerMode(false);
      setScorerDrawer(null);
      setScoringSubTab("SCOREBOARD");
    }}
    aria-label="Open Scorecard"
    title="Scorecard"
  >
    <span className="wow-tab-icon">📋</span>

    <span className="wow-tab-copy">
      <strong>Scorecard</strong>
      <small>Batting and bowling</small>
    </span>
  </button>

  <button
    type="button"
    className={`wow-score-tab ${
      effectiveScoringSubTab === "COMMENTARY"
        ? "active"
        : ""
    }`}
    onClick={() => {
      setScorerMode(false);
      setScorerDrawer(null);
      setScoringSubTab("COMMENTARY");
    }}
    aria-label="Open Commentary"
    title="Commentary"
  >
    <span className="wow-tab-icon">📝</span>

    <span className="wow-tab-copy">
      <strong>Commentary</strong>
      <small>Ball-by-ball history</small>
    </span>
  </button>
</div>
  </div>
)}
{selectedMatchId && effectiveScoringSubTab === "SCOREBOARD" && (
<Card title="🏟️ Scoreboard" defaultCollapsed={false}>
  {!scoreboard ? (
    <p className="muted">Select a match to view scoreboard.</p>
  ) : (
    <>
                  <div className="pro-score-hero compact-score-hero">
                <div>
                  <h3>
                    {scoreboard.match?.teamAName} vs {scoreboard.match?.teamBName}
                  </h3>
                  </div>  
                  <div>                
                  <span className="pill scoreboard-status-top" align="right">
                    {scoreboard.match?.status}
                  </span>

                </div>
              </div>
      {matchInsights && (
        <div className="match-insights-card">
          {dashboardResultText && (
            <div className="insight-result">
              <span>🏆 Match Result</span>
              <strong>{dashboardResultText}</strong>
            </div>
          )}

          {matchInsights.potm && (
            <div className="insight-mini">
              <span>⭐ Player of the Match</span>
              <strong>{matchInsights.potm.playerName}</strong>
              <small>
                {matchInsights.potm.summary?.join(" & ") || "Top performer"}
              </small>
            </div>
          )}

          {matchInsights.winProbability && (
            <div className="insight-mini">
              <span>📈 Win Probability</span>

              <div className="win-prob-row">
                <b>{matchInsights.winProbability.bowlingTeam}</b>
                <div className="win-prob-track">
                  <i
                    style={{
                      width: `${matchInsights.winProbability.bowlingChance}%`,
                    }}
                  />
                </div>
                <b>{matchInsights.winProbability.bowlingChance}%</b>
              </div>

              <div className="win-prob-row">
                <b>{matchInsights.winProbability.battingTeam}</b>
                <div className="win-prob-track chase">
                  <i
                    style={{
                      width: `${matchInsights.winProbability.battingChance}%`,
                    }}
                  />
                </div>
                <b>{matchInsights.winProbability.battingChance}%</b>
              </div>
            </div>
          )}
        </div>
      )}

      <div className="pro-scoreboard">
        {(() => {
          const scoreboardInnings = scoreboard.innings || [];

          const activeInningsForScoreboard =
            scoreboardInnings.find(
              (x, idx) =>
        Number(x.number ?? idx + 1) === Number(activeScoreboardInnings)
    ) || scoreboardInnings[0];

          const activeInnIdx = scoreboardInnings.findIndex(
           (x, idx) =>
      Number(x.number ?? idx + 1) === Number(activeScoreboardInnings)
  );
  if (!activeInningsForScoreboard) return null;

const inningsNo = Number(activeInningsForScoreboard?.number ?? activeInnIdx + 1);

const teamAId = Number(matchDetail?.teamAId);
const teamBId = Number(matchDetail?.teamBId);
const battingFirstTeamId = Number(matchDetail?.battingFirstTeamId);

const inningsTeamName =
  activeInningsForScoreboard?.teamName ||
  activeInningsForScoreboard?.battingTeamName ||
  activeInningsForScoreboard?.team ||
  "";

let activeBattingTeamId =
  Number(activeInningsForScoreboard?.battingTeamId) ||
  Number(activeInningsForScoreboard?.teamId) ||
  null;

if (!activeBattingTeamId && inningsTeamName) {
  if (inningsTeamName === matchDetail?.teamAName) {
    activeBattingTeamId = teamAId;
  } else if (inningsTeamName === matchDetail?.teamBName) {
    activeBattingTeamId = teamBId;
  }
}

if (!activeBattingTeamId) {
  activeBattingTeamId =
    inningsNo === 1
      ? battingFirstTeamId
      : battingFirstTeamId === teamAId
        ? teamBId
        : teamAId;
}

const isTeamABatting = Number(activeBattingTeamId) === Number(teamAId);

const captainId = isTeamABatting
  ? matchDetail?.teamACaptainId ?? matchDetail?.teamAcaptainId
  : matchDetail?.teamBCaptainId ?? matchDetail?.teamBcaptainId;

const wicketKeeperId = isTeamABatting
  ? matchDetail?.teamAWicketKeeperId
  : matchDetail?.teamBWicketKeeperId;

const captainName = isTeamABatting
  ? matchDetail?.teamACaptainName
  : matchDetail?.teamBCaptainName;

const wicketKeeperName = isTeamABatting
  ? matchDetail?.teamAWicketKeeperName
  : matchDetail?.teamBWicketKeeperName;

const playerRoleBadge = (row) => {
  const badges = [];

  const samePlayer = (roleId, roleName) => {
    if (roleId && row.playerId && Number(row.playerId) === Number(roleId)) {
      return true;
    }

    return (
      roleName &&
      row.playerName &&
      String(row.playerName).trim().toLowerCase() ===
        String(roleName).trim().toLowerCase()
    );
  };

  if (samePlayer(captainId, captainName)) {
    badges.push("(c)");
  }

  if (samePlayer(wicketKeeperId, wicketKeeperName)) {
    badges.push("(wk)");
  }

  return badges.length ? ` ${badges.join(" ")}` : "";
};

          return (
            <>
<div className="innings-score-cards clickable-innings-cards">
  {(scoreboard.innings || []).map((inn, idx) => {
    const inningsNo = Number(inn.number ?? idx + 1);
    const isActive = Number(activeScoreboardInnings) === inningsNo;

    return (
      <button
        type="button"
        key={`innings-summary-${inningsNo}`}
        className={`innings-score-card innings-click-card ${
          isActive ? "active" : ""
        }`}
        onClick={() => setActiveScoreboardInnings(inningsNo)}
      >
<div className="innings-tab-header">
  <span>Tap • Inn {inningsNo}</span>
  {isActive && <b>✓</b>}
</div>

<div className="innings-tab-team">
  {inn.teamName || inn.battingTeamName || inn.team || "Team"}
</div>

<div className="innings-tab-main">
  <strong>{inn.runs}/{inn.wickets}</strong>
</div>

<div className="innings-bottom-row">
  {inn.oversDisplay} ov • RR {inn.runRate}
</div>
      </button>
    );
  })}
</div>

<SuperOverScorecard superOver={scoreboard?.superOver} />

              {scoreboard.currentState &&
                !(
                  selectedMatch &&
                  [
                    "COMPLETED",
                    "COMPLETED_LOCKED",
                    "COMPLETED_CORRECTED",
                  ].includes(String(selectedMatch.status || "").toUpperCase())
                ) && (
                  <>
                    <div className="innings-state-grid compact-innings-state">
                      <div className="innings-mini-box">
                        <span>🏏 Innings</span>
                        <strong>
                          {scoreboard?.currentState?.inningsNo ||
                            scoreboard?.currentInnings ||
                            ballForm?.inningsNo ||
                            "-"}
                        </strong>
                      </div>

                      <div className="innings-mini-box">
                        <span>Next Ball</span>
                        <strong>
                          {scoreboard?.currentState?.nextBallLabel ||
                            `${
                              scoreboard?.currentState?.nextOverNo ??
                              scoreboard?.currentState?.nextOver ??
                              0
                            }.${
                              scoreboard?.currentState?.nextBallInOver ??
                              scoreboard?.currentState?.nextBallNo ??
                              0
                            }`}
                        </strong>
                      </div>

                      <div className="innings-mini-box striker-box">
                        <span>⚡ Striker</span>
                        <strong>
                          {scoreboard?.currentState?.strikerName || "-"}
                          {scoreboard?.currentState?.strikerStats && (
                            <b>
                              {scoreboard.currentState.strikerStats.runs || 0} (
                              {scoreboard.currentState.strikerStats.balls || 0})
                            </b>
                          )}
                        </strong>
                      </div>

                      <div className="innings-mini-box striker-box">
                        <span>🏃 Non-Striker</span>
                        <strong>
                          {scoreboard?.currentState?.nonStrikerName || "-"}
                          {scoreboard?.currentState?.nonStrikerStats && (
                            <b>
                              {scoreboard.currentState.nonStrikerStats.runs || 0} (
                              {scoreboard.currentState.nonStrikerStats.balls || 0})
                            </b>
                          )}
                        </strong>
                      </div>

                      <div className="innings-mini-box bowler-box">
                        <span>🎯 Bowler</span>
                        <strong>
                          {scoreboard?.currentState?.bowlerName || "-"}
                          {scoreboard?.currentState?.bowlerStats && (
                            <b>
                              {scoreboard.currentState.bowlerStats.wickets || 0}/
                              {scoreboard.currentState.bowlerStats.runs || 0} (
                              {scoreboard.currentState.bowlerStats.overs || "0.0"})
                            </b>
                          )}
                        </strong>
                      </div>
                    </div>

                    {/* Mobile compact live state */}
                    <div className="live-match-state compact-live-state">
                      <div className="live-top-strip">
                        <div>
                          <span>🏏 Inn</span>
                          <strong>
                            {scoreboard?.currentState?.inningsNo ||
                              scoreboard?.currentInnings ||
                              ballForm?.inningsNo ||
                              "-"}
                          </strong>
                        </div>

                        <div>
                          <span>Next</span>
                          <strong>
                            {scoreboard?.currentState?.nextBallLabel ||
                              `${
                                scoreboard?.currentState?.nextOverNo ??
                                scoreboard?.currentState?.nextOver ??
                                0
                              }.${
                                scoreboard?.currentState?.nextBallInOver ??
                                scoreboard?.currentState?.nextBallNo ??
                                0
                              }`}
                          </strong>
                        </div>
                      </div>

                      <div className="compact-player-row striker">
                        <span>⚡ Striker</span>
                        <strong>{scoreboard?.currentState?.strikerName || "-"}</strong>
                        <b>
                          {scoreboard?.currentState?.strikerStats
                            ? `${
                                scoreboard.currentState.strikerStats.runs || 0
                              } (${scoreboard.currentState.strikerStats.balls || 0})`
                            : ""}
                        </b>
                      </div>

                      <div className="compact-player-row non-striker">
                        <span>🏃 Non-striker</span>
                        <strong>
                          {scoreboard?.currentState?.nonStrikerName || "-"}
                        </strong>
                        <b>
                          {scoreboard?.currentState?.nonStrikerStats
                            ? `${
                                scoreboard.currentState.nonStrikerStats.runs || 0
                              } (${scoreboard.currentState.nonStrikerStats.balls || 0})`
                            : ""}
                        </b>
                      </div>

                      <div className="compact-player-row bowler">
                        <span>🎯 Bowler</span>
                        <strong>{scoreboard?.currentState?.bowlerName || "-"}</strong>
                        <b>
                          {scoreboard?.currentState?.bowlerStats
                            ? `${
                                scoreboard.currentState.bowlerStats.wickets || 0
                              }/${scoreboard.currentState.bowlerStats.runs || 0} (${
                                scoreboard.currentState.bowlerStats.overs || "0.0"
                              })`
                            : ""}
                        </b>
                      </div>
                    </div>
                  </>
                )}

              {activeInningsForScoreboard && (
<div
  key={`innings-detail-${activeInningsForScoreboard.number ?? activeInnIdx}`}
  className="full-innings-card active-innings-tab-panel"
>
                  <div className="innings-section-header">
                    <div>
                      <h3>
                        Innings {activeInningsForScoreboard.number}: {" "}
                        {activeInningsForScoreboard.teamName ||
                          activeInningsForScoreboard.battingTeamName ||
                          activeInningsForScoreboard.team ||
                          "Team"}
                      </h3>
                    </div>
                                          <div className="innings-tab-header">
                      <small>
                        Extras: {activeInningsForScoreboard.extras?.total ?? 0} • Wd {" "}
                        {activeInningsForScoreboard.extras?.wides ?? 0} • Nb {" "}
                        {activeInningsForScoreboard.extras?.noBalls ?? 0} • B {" "}
                        {activeInningsForScoreboard.extras?.byes ?? 0} • LB {" "}
                        {activeInningsForScoreboard.extras?.legByes ?? 0}
                      </small>
                      </div>
                  </div>
                  <details className="scorecard-wow-collapse">
                    <summary className="scorecard-wow-summary">
                      <div className="scorecard-wow-left">
                        <span className="scorecard-wow-icon">🏏</span>
                        <div>
                          <strong>Batting Scorecard</strong>
                          <small>Tap to view batting details</small>
                        </div>
                      </div>
                      <span className="scorecard-wow-caret">⌄</span>
                    </summary>

                    <div className="scorecard-wow-content">
                      <MobileBattingCards
                        rows={
                          activeInningsForScoreboard.battingRows ||
                          activeInningsForScoreboard.batting ||
                          []
                        }
                        currentStrikerId={scoreboard.currentState?.strikerId}
                      />

                      <div className="score-table-scroll desktop-score-table">
                        <table className="score-table sticky-first-col pro-table">
                          <thead>
                            <tr>
                              <th>Batter</th>
                              <th>Dismissal</th>
                              <th>R</th>
                              <th>B</th>
                              <th>4s</th>
                              <th>6s</th>
                              <th>SR</th>
                            </tr>
                          </thead>

                          <tbody>
                            {(
                              activeInningsForScoreboard.battingRows ||
                              activeInningsForScoreboard.batting ||
                              []
                            ).length ? (
                              (
                                activeInningsForScoreboard.battingRows ||
                                activeInningsForScoreboard.batting ||
                                []
                              ).map((row, rowIdx) => (
                                <tr
                                  key={`bat-${
                                    activeInningsForScoreboard.number ?? activeInnIdx
                                  }-${row.playerId ?? rowIdx}-${rowIdx}`}
                                >
                                  <td>
                                    <strong>
                                      {row.playerName}
                                        {playerRoleBadge(row)}
                                        {Number(scoreboard.currentState?.strikerId) === Number(row.playerId)
                                          ? " *"
                                          : ""}
                                    </strong>
                                  </td>
                                  <td>
                                    {row.dismissal !== "not out"
                                      ? row.dismissal
                                      : "not out"}
                                  </td>
                                  <td>{row.runs}</td>
                                  <td>{row.balls}</td>
                                  <td>{row.fours}</td>
                                  <td>{row.sixes}</td>
                                  <td>{row.strikeRate}</td>
                                </tr>
                              ))
                            ) : (
                              <tr>
                                <td colSpan="7" className="muted">
                                  Batting details not available yet.
                                </td>
                              </tr>
                            )}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  </details>

                  <details className="scorecard-wow-collapse">
                    <summary className="scorecard-wow-summary">
                      <div className="scorecard-wow-left">
                        <span className="scorecard-wow-icon">🎯</span>
                        <div>
                          <strong>Bowling Scorecard</strong>
                          <small>Tap to view bowling figures</small>
                        </div>
                      </div>
                      <span className="scorecard-wow-caret">⌄</span>
                    </summary>

                    <div className="scorecard-wow-content">
                      <MobileBowlingCards
                        rows={
                          activeInningsForScoreboard.bowlingRows ||
                          activeInningsForScoreboard.bowling ||
                          []
                        }
                      />

                      <div className="score-table-scroll desktop-score-table">
                        <table className="score-table sticky-first-col pro-table bowling-table">
                          <thead>
                            <tr>
                              <th>Bowler</th>
                              <th>O</th>
                              <th>R</th>
                              <th>W</th>
                              <th>Wd</th>
                              <th>Nb</th>
                              <th>Eco</th>
                            </tr>
                          </thead>

                          <tbody>
                            {(
                              activeInningsForScoreboard.bowlingRows ||
                              activeInningsForScoreboard.bowling ||
                              []
                            ).length ? (
                              (
                                activeInningsForScoreboard.bowlingRows ||
                                activeInningsForScoreboard.bowling ||
                                []
                              ).map((row, rowIdx) => (
                                <tr
                                  key={`bowl-${
                                    activeInningsForScoreboard.number ?? activeInnIdx
                                  }-${row.playerId ?? rowIdx}-${rowIdx}`}
                                >
                                  <td>
                                    <strong>{row.playerName}</strong>
                                  </td>
                                  <td>{row.overs}</td>
                                  <td>{row.runs}</td>
                                  <td>{row.wickets}</td>
                                  <td>{row.wides || 0}</td>
                                  <td>{row.noBalls || 0}</td>
                                  <td>{row.economy}</td>
                                </tr>
                              ))
                            ) : (
                              <tr>
                                <td colSpan="7" className="muted">
                                  Bowling details not available yet.
                                </td>
                              </tr>
                            )}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  </details>

                  <details className="scorecard-wow-collapse">
                    <summary className="scorecard-wow-summary">
                      <div className="scorecard-wow-left">
                        <span className="scorecard-wow-icon">💥</span>
                        <div>
                          <strong>Fall of Wickets</strong>
                          <small>Tap to view wicket timeline</small>
                        </div>
                      </div>
                      <span className="scorecard-wow-caret">⌄</span>
                    </summary>

                    <div className="scorecard-wow-content">
                      {!activeInningsForScoreboard.fallOfWickets?.length ? (
                        <p className="muted">No wickets yet.</p>
                      ) : (
                        <div className="fow-list">
                          {activeInningsForScoreboard.fallOfWickets.map(
                            (w, wicketIdx) => (
                              <div
                                key={`fow-${
                                  activeInningsForScoreboard.number ?? activeInnIdx
                                }-${w.wicketNumber ?? wicketIdx}-${
                                  w.over ?? "over"
                                }-${wicketIdx}`}
                                className="fow-chip"
                              >
                                <strong>{w.score}</strong>
                                <span>{w.playerOut}</span>
                                <small>{w.over} ov</small>
                              </div>
                            )
                          )}
                        </div>
                      )}
                    </div>
                  </details>

<details className="scorecard-wow-collapse">
  <summary className="scorecard-wow-summary">
    <div className="scorecard-wow-left">
      <span className="scorecard-wow-icon">🤝</span>
      <div>
        <strong>Partnerships</strong>
        <small>Tap to view batting partnerships</small>
      </div>
    </div>
    <span className="scorecard-wow-caret">⌄</span>
  </summary>

  <div className="scorecard-wow-content">
    {!activeInningsForScoreboard.partnerships?.length ? (
      <p className="muted">No partnerships yet.</p>
    ) : (
      <>
        <div className="mobile-partnership-list">
          {activeInningsForScoreboard.partnerships.map((p, pIdx) => (
            <div
              key={`mobile-partnership-${activeInningsForScoreboard.number ?? activeInnIdx}-${pIdx}`}
              className="mobile-partnership-card"
            >
              <div className="mobile-partnership-title">
                <strong>{p.batter1 || "Batter 1"}</strong>
                <span>+</span>
                <strong>{p.batter2 || "Batter 2"}</strong>
              </div>

              <div className="mobile-partnership-stats">
                <div>
                  <span>Runs</span>
                  <strong>{p.runs ?? 0}</strong>
                </div>
                <div>
                  <span>Balls</span>
                  <strong>{p.balls ?? 0}</strong>
                </div>
                <div>
                  <span>Status</span>
                  <strong>{p.ongoing ? "Current" : `Wkt ${p.wicketNumber ?? "-"}`}</strong>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="score-table-scroll desktop-partnership-table">
          <table className="score-table sticky-first-col pro-table">
            <thead>
              <tr>
                <th>Batters</th>
                <th>Runs</th>
                <th>Balls</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              {activeInningsForScoreboard.partnerships.map((p, pIdx) => (
                <tr
                  key={`partnership-${activeInningsForScoreboard.number ?? activeInnIdx}-${p.batter1 || "b1"}-${
                    p.batter2 || "b2"
                  }-${pIdx}`}
                >
                  <td>{p.batter1} & {p.batter2}</td>
                  <td>{p.runs}</td>
                  <td>{p.balls}</td>
                  <td>{p.ongoing ? "Current" : `wicket ${p.wicketNumber}`}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </>
    )}
  </div>
</details>
                </div>
              )}
            </>
          );
        })()}
      </div>
    </>
  )}
</Card>

)}
{selectedMatchId && effectiveScoringSubTab === "COMMENTARY" && (
  <Card title="🎙️ Commentary" defaultCollapsed={false}>
    {!scoreboard ? (
      <p className="muted">Select a match to view commentary.</p>
    ) : !combinedCommentary.length ? (
      <div className="commentary-empty">
        📝 No commentary yet. Start scoring to build the live timeline.
      </div>
    ) : (
      <>
        {matchInsights && (
          <div className="match-insights-card">
            {dashboardResultText && (
              <div className="insight-result">
                <span>🏆 Match Result</span>
                <strong>{dashboardResultText}</strong>
              </div>
            )}

            {matchInsights.potm && (
              <div className="insight-mini">
                <span>⭐ Player of the Match</span>
                <strong>{matchInsights.potm.playerName}</strong>
                <small>
                  {matchInsights.potm.summary?.join(" & ") || "Top performer"}
                </small>
              </div>
            )}

            {matchInsights.winProbability && (
              <div className="insight-mini">
                <span>📈 Win Probability</span>

                <div className="win-prob-row">
                  <b>{matchInsights.winProbability.bowlingTeam}</b>
                  <div className="win-prob-track">
                    <i style={{ width: `${matchInsights.winProbability.bowlingChance}%` }} />
                  </div>
                  <b>{matchInsights.winProbability.bowlingChance}%</b>
                </div>

                <div className="win-prob-row">
                  <b>{matchInsights.winProbability.battingTeam}</b>
                  <div className="win-prob-track chase">
                    <i style={{ width: `${matchInsights.winProbability.battingChance}%` }} />
                  </div>
                  <b>{matchInsights.winProbability.battingChance}%</b>
                </div>
              </div>
            )}
          </div>
        )}
        <div className="commentary-feed pretty-commentary">
          {combinedCommentary.map((section, sectionIndex) => (
<details
  key={`innings-${section.inningsNo}-${sectionIndex}`}
  className="innings-wow-collapse"
>
  <summary className="innings-wow-summary">
    <div className="innings-wow-left">
      <span className="innings-wow-icon">🏏</span>

      <div>
        <strong>{section.title}</strong>
        <small>Tap to view detailed ball-by-ball commentary</small>
      </div>
    </div>

    <div className="innings-wow-right">
      <span className="innings-wow-count">
        {section.items?.length || 0} updates
      </span>
      <span className="innings-wow-caret">⌄</span>
    </div>
  </summary>

  <div className="commentary-innings-section innings-wow-content">
    {section.items.map((item, itemIndex) => (
      <div
        key={`commentary-${section.inningsNo}-${item.id ?? itemIndex}`}
        className={`commentary-item pretty-commentary-item ${
          item.type === "OVER_SUMMARY" ? "over-summary-item" : ""
        }`}
      >
        <div className={`commentary-ball ${item.badgeClass || ""}`}>
          {item.badge || item.over}
        </div>

        <div className="commentary-body">
          {item.type === "BALL" && item.badge !== "END" ? (
            <details className="commentary-inline-details">
              <summary className="commentary-inline-summary">
                <span className="commentary-main">{item.text}</span>
                <span className="commentary-inline-score">{item.score}</span>
                <span className="commentary-inline-caret">⌄</span>
              </summary>

              <div className="commentary-inline-stats">
                <span>🏏 {item.strikerSummary}</span>
                <span>🏃 {item.nonStrikerSummary}</span>
                <span>🎯 {item.bowlerSummary}</span>
              </div>
            </details>
          ) : item.type === "OVER_SUMMARY" ? (
            <details className="commentary-inline-details">
              <summary className="commentary-inline-summary">
                <span className="commentary-main">{item.text}</span>
                <span className="commentary-inline-score">{item.score}</span>
                <span className="commentary-inline-caret">⌄</span>
              </summary>

              <div className="commentary-inline-stats">
                <span>🎯 {item.bowlerSummary}</span>
              </div>
            </details>
          ) : (
            <div className="commentary-main">{item.text}</div>
          )}
        </div>
      </div>
    ))}
  </div>
</details>
          ))}
        </div>
      </>
    )}
  </Card>
)}
{selectedMatchId && !isSelectedMatchCompleted && scoringSubTab === "ADVANCED" && ( 
<Card
  className="scoring-console mobile-scorer-console-card"
  title="🎯 Advanced Scoring"
  defaultCollapsed={false}
  right={
    selectedMatchId &&
    !isSelectedMatchCompleted &&
    !isMobile &&
    canScoreCurrentLeague ? (
      <div className="advanced-scoring-actions">
        <span
          style={{
            marginRight: 8,
            fontSize: 12,
            fontWeight: 800,
          }}
        >
          {getOfflineStatusLabel()}
        </span>
        <button
          type="button"
          className="scorer-mode-btn"
          onClick={() => {
            setScorerMode(true);
            setScorerDrawer(null);
          }}
        >
          🎯 Scorer Mode
        </button>
      </div>
    ) : null
  }
>
  {isMobile &&
  selectedMatchId &&
  !isSelectedMatchCompleted &&
  !scorerMode && (
    <>
      <div className="mobile-match-control-heading">
        <div className="mobile-match-control-copy">
          <span className="mobile-match-control-icon">🏏</span>

          <div>
            <strong>Match Control</strong>
            <small>Review the match or open focused scoring</small>
          </div>
        </div>

        <span className="mobile-match-control-status">
          {String(
            selectedMatch?.status ||
              scoreboard?.match?.status ||
              "ACTIVE"
          ).replaceAll("_", " ")}
        </span>
      </div>

      <section className="mobile-scoring-launch-card">
        <div className="mobile-scoring-launch-icon">🎯</div>

        <div className="mobile-scoring-launch-copy">
          <span>Ball-by-ball scoring</span>
          <strong>Open Scorer Mode</strong>
          <small>
            Score every delivery in a focused full-screen mobile workspace.
          </small>
        </div>

        {permissionsLoading && !canScoreCurrentLeague ? (
          <button
            type="button"
            className="mobile-scoring-launch-btn"
            disabled
          >
            Checking access…
          </button>
        ) : canScoreCurrentLeague ? (
          <button
            type="button"
            className="mobile-scoring-launch-btn"
            onClick={() => {
              setScorerDrawer(null);
              setShowScorerAccountMenu(false);
              setScorerMode(true);
            }}
          >
            Start Scoring
            <b>›</b>
          </button>
        ) : (
          <div className="mobile-scoring-access-note">
            🔒 Scoring access is not enabled for this account.
          </div>
        )}
      </section>
    </>
  )}
          {!matchDetail ? (
            <p className="muted">Please select a match to view scoring, scoreboard, and commentary.</p>
          ) : (
            <>
<div
  className={`scorer-mode-shell ${
    scorerMode ? "active" : ""
  } ${
    scorerMode && !isMobile
      ? "desktop-scorer-modal-shell"
      : ""
  }`}
  style={
    scorerMode && !isMobile
      ? {
          maxHeight: "100dvh",
          overflowY: "auto",
          overflowX: "hidden",
          overscrollBehavior: "contain",
          WebkitOverflowScrolling: "touch",
          scrollbarGutter: "stable",
        }
      : undefined
  }
>
{scorerMode && !isMobile && (
  <div className="scorer-mode-banner mobile-scorer-mode-banner">
    <div className="scorer-mode-banner-copy">
      <span>🎯</span>

      <div>
        <strong>Scorer Mode</strong>
        <small>Focused ball-by-ball scoring</small>
        <small
          style={{
            display: "inline-block",
            marginTop: 4,
            fontWeight: 800,
          }}
        >
          {getOfflineStatusLabel()}
        </small>
        {offlineSyncState.conflict && (
          <button
            type="button"
            className="btn"
            style={{
              display: "block",
              marginTop: 6,
              padding: "5px 10px",
              fontSize: 11,
              fontWeight: 900,
            }}
            disabled={
              offlineSyncState.syncing ||
              offlineSyncState.online === false
            }
            onClick={() => {
              /*
               * Defensive recovery for sessions that entered conflict mode
               * before this fix and may still have a stale saving flag.
               */
              setIsSavingBall(false);
              setInstantDeliveryStatus("");

              setOfflineSyncState((previous) => ({
                ...previous,
                conflict: null,
                lastError: "",
              }));

              void syncPendingOfflineBalls(selectedMatchId);
            }}
          >
            🔄 Retry Sync
          </button>
        )}
      </div>
    </div>

    <button
      type="button"
      className="scorer-mode-exit-btn"
      onClick={() => {
        setScorerDrawer(null);
        setScorerMode(false);
        setScoringSubTab("ADVANCED");

        window.requestAnimationFrame(() => {
          document
            .querySelector(".score-hub-tabs")
            ?.scrollIntoView({
              behavior: "smooth",
              block: "start",
            });
        });
      }}
    >
      ✕ Exit
    </button>
  </div>
)}
{isMobile && scorerMode && canScoreCurrentLeague && liveMatchCenter && (
  <div className="mobile-scorer-overlay-v3">
    <section
      className="mobile-scorer-cockpit-v3"
      role="dialog"
      aria-modal="true"
      aria-label="Cric4All Scorer Mode"
    >
      {/* SCORE + EXIT */}
      <header className="msc-v3-header">
        <div className="msc-v3-score-block">
          <span className="msc-v3-live">
            <i />
            Live
          </span>

          <div className="msc-v3-score-line">
            <strong>
              {liveMatchCenter.runs}/{liveMatchCenter.wickets}
            </strong>

            <small>
              Inn {liveMatchCenter.inningsNo} •{" "}
              {liveMatchCenter.oversDisplay} ov
            </small>
          </div>
        </div>

        <div className="msc-v3-header-actions">
          <button
            type="button"
            className="msc-v3-account"
            onClick={() =>
              setShowScorerAccountMenu((previous) => !previous)
            }
            aria-expanded={showScorerAccountMenu}
            aria-label="Open account menu"
          >
            👤 Account
          </button>

          <button
            type="button"
            className="msc-v3-exit"
            onClick={() => {
              setShowScorerAccountMenu(false);
              setScorerDrawer(null);
              setScorerMode(false);
              setScoringSubTab("ADVANCED");
            }}
          >
            ✕ Exit
          </button>
        </div>
      </header>

      {showScorerAccountMenu && (
        <div
          className="msc-v3-account-backdrop"
          onClick={() => setShowScorerAccountMenu(false)}
        >
          <div
            className="msc-v3-account-panel"
            role="dialog"
            aria-modal="true"
            aria-label="Cric4All account"
            onClick={(event) => event.stopPropagation()}
          >
            <div className="msc-v3-account-title">
              <span>👤</span>
              <div>
                <strong>
                  {session?.user?.name || "Cric4All Account"}
                </strong>
                <small>{session?.user?.email || "Signed in"}</small>
              </div>
            </div>

            <button
              type="button"
              className="msc-v3-account-close"
              onClick={() => setShowScorerAccountMenu(false)}
            >
              Continue Scoring
            </button>

            <button
              type="button"
              className="msc-v3-account-signout"
              onClick={handleScorerSignOut}
            >
              Sign Out
            </button>
          </div>
        </div>
      )}

      <div className="msc-v3-status">
        {error ||
          instantDeliveryStatus ||
          message ||
          overCompleteNotice ||
          scorerStatusText ||
          "Ready for next delivery"}
      </div>

      <div
        style={{
          padding: "6px 10px",
          fontSize: 12,
          fontWeight: 900,
          textAlign: "center",
        }}
        aria-live="polite"
      >
        {getOfflineStatusLabel()}

        {offlineSyncState.conflict && (
          <button
            type="button"
            className="btn"
            style={{
              marginLeft: 8,
              padding: "4px 8px",
              fontSize: 11,
              fontWeight: 900,
            }}
            disabled={
              offlineSyncState.syncing ||
              offlineSyncState.online === false
            }
            onClick={() => {
              /*
               * Defensive recovery for sessions that entered conflict mode
               * before this fix and may still have a stale saving flag.
               */
              setIsSavingBall(false);
              setInstantDeliveryStatus("");

              setOfflineSyncState((previous) => ({
                ...previous,
                conflict: null,
                lastError: "",
              }));

              void syncPendingOfflineBalls(selectedMatchId);
            }}
          >
            🔄 Retry Sync
          </button>
        )}
      </div>

      {/* PLAYERS */}
      {!matchEnded && scoreboard?.currentState && (
        <div className="msc-v3-players">
          <div className="msc-v3-player striker">
            <span>⚡ Striker</span>

            <div>
              <strong>
                {displayScoreboard?.currentState?.strikerName ||
                  "Not selected"}
              </strong>

              <b>
                {displayScoreboard?.currentState?.strikerStats
                  ? `${displayScoreboard.currentState.strikerStats.runs} (${displayScoreboard.currentState.strikerStats.balls})`
                  : "0 (0)"}
              </b>
            </div>
          </div>

          <div className="msc-v3-player non-striker">
            <span>🏃 Non-striker</span>

            <div>
              <strong>
                {displayScoreboard?.currentState?.nonStrikerName ||
                  "Not selected"}
              </strong>

              <b>
                {displayScoreboard?.currentState?.nonStrikerStats
                  ? `${displayScoreboard.currentState.nonStrikerStats.runs} (${displayScoreboard.currentState.nonStrikerStats.balls})`
                  : "0 (0)"}
              </b>
            </div>
          </div>

          <div className="msc-v3-player bowler">
            <span>🎯 Bowler</span>

            <div>
              <strong>
                {displayScoreboard?.currentState?.bowlerName ||
                  "Not selected"}
              </strong>

              <b>
                {displayScoreboard?.currentState?.bowlerStats
                  ? `${displayScoreboard.currentState.bowlerStats.wickets}/${displayScoreboard.currentState.bowlerStats.runs} (${displayScoreboard.currentState.bowlerStats.overs} ov)`
                  : "0/0"}
              </b>
            </div>
          </div>
        </div>
      )}

      {/* METRICS */}
      <div className="msc-v3-metrics">
        <div>
          <span>CRR</span>
          <strong>{liveMatchCenter.crr}</strong>
        </div>

        <div>
          <span>RRR</span>
          <strong>{liveMatchCenter.rrr}</strong>
        </div>

        <div>
          <span>Proj</span>
          <strong>{liveMatchCenter.projected}</strong>
        </div>

        <div>
          <span>P'ship</span>
          <strong>
            {liveMatchCenter.partnershipRuns} (
            {liveMatchCenter.partnershipBalls})
          </strong>
        </div>
      </div>

      {liveMatchCenter?.isSecondInnings &&
        liveMatchCenter?.target > 0 && (
          <>
            <div className="msc-v3-chase">
              <span>
                {dlsActiveForDisplay ? "🌧 Target" : "Target"}{" "}
                <b>{liveMatchCenter.target}</b>
              </span>

              <span>
                Need <b>{liveMatchCenter.runsRequired}</b>
              </span>

              <span>
                Balls <b>{liveMatchCenter.ballsRemaining}</b>
              </span>
            </div>

            {liveMatchCenter?.chasePar != null && (
              <div
                aria-label="Cric4All Chase Par"
                style={{
                  margin:
                    "6px 10px 0",
                  padding:
                    "7px 10px",
                  display:
                    "grid",
                  gridTemplateColumns:
                    "minmax(0, 1fr) minmax(0, 1fr)",
                  gap:
                    8,
                  alignItems:
                    "center",
                  borderRadius:
                    10,
                  background:
                    "rgba(15, 23, 42, 0.68)",
                  border:
                    "1px solid rgba(148, 163, 184, 0.20)",
                  fontSize:
                    12,
                  lineHeight:
                    1.15,
                  overflow:
                    "hidden",
                }}
              >
                <span
                  style={{
                    minWidth:
                      0,
                    whiteSpace:
                      "nowrap",
                    overflow:
                      "hidden",
                    textOverflow:
                      "ellipsis",
                  }}
                >
                  C4A Par{" "}
                  <b>
                    {liveMatchCenter.chasePar}
                  </b>
                </span>

                <span
                  style={{
                    minWidth:
                      0,
                    textAlign:
                      "right",
                    fontWeight:
                      900,
                    whiteSpace:
                      "nowrap",
                    overflow:
                      "hidden",
                    textOverflow:
                      "ellipsis",
                  }}
                >
                  {liveMatchCenter.parState === "AHEAD"
                    ? "▲ "
                    : liveMatchCenter.parState === "BEHIND"
                      ? "▼ "
                      : "● "}
                  {liveMatchCenter.parDeltaLabel}
                  {" "}
                  {liveMatchCenter.parState === "AHEAD"
                    ? "Ahead"
                    : liveMatchCenter.parState === "BEHIND"
                      ? "Behind"
                      : "Level"}
                </span>
              </div>
            )}
          </>
        )}

      {/* SEPARATION + RECENT BALLS */}
      <div className="msc-v3-delivery-head">
        <span />
        <b>Delivery Controls</b>
        <span />
      </div>

<div className="msc-v3-recent-simple">
  <div className="msc-v3-recent-simple-strip">
{mobileRecentDeliveryItems.length ? (
  mobileRecentDeliveryItems.map(
    (item, index) => {
      const nextOlderItem =
        mobileRecentDeliveryItems[index + 1] ||
        null;

      const result =
        getRecentBallDisplayText(item.ball);

      const normalized =
        result.toUpperCase();

      const ballClass =
        normalized === "W" ||
        normalized === "WKT"
          ? "wicket"
          : normalized === "4" ||
              normalized === "6"
            ? "boundary"
            : normalized.startsWith("WD") ||
                normalized.startsWith("NB")
              ? "extra"
              : "";

      const isNewest = index === 0;

      /*
        In newest-first display, the separator belongs
        AFTER the newest ball of an over and BEFORE the
        oldest ball of the next earlier over.

        Example with 15 legal balls:

        [15][14][13] | OVER | [12]...[7] | OVER | [6]...[1]
      */
      const inningsChanged =
        nextOlderItem &&
        item.inningsNo !== null &&
        nextOlderItem.inningsNo !== null &&
        item.inningsNo !==
          nextOlderItem.inningsNo;

      const overChanged =
        nextOlderItem &&
        !inningsChanged &&
        item.overKey !== null &&
        nextOlderItem.overKey !== null &&
        item.overKey !==
          nextOlderItem.overKey;

      return (
        <div
          key={item.key}
          className="msc-v3-recent-entry"
        >
          <div
            className={`msc-v3-recent-ball-wrap ${
              isNewest ? "newest" : ""
            }`}
          >
            {isNewest && (
              <span className="msc-v3-new-ball-label">
                NEW
              </span>
            )}

            <b
              className={`msc-v3-recent-ball ${ballClass}`}
            >
              {result || "-"}
            </b>
          </div>

          {inningsChanged ? (
            <span
              className="msc-v3-innings-divider"
              aria-label="New innings"
              title="New innings"
            >
              <i />

              <b>
                INNINGS {item.inningsNo}
              </b>

              <i />
            </span>
          ) : overChanged ? (
            <span
              className="msc-v3-over-separator"
              aria-label="Over boundary"
              title="Over boundary"
            >
              <i />

              <b>OVER</b>

              <i />
            </span>
          ) : null}
        </div>
      );
    }
  )
) : (
  <span className="msc-v3-recent-simple-empty">
    No deliveries yet
  </span>
)}
  </div>
</div>

      {/* THUMB-REACH CONTROLS */}
      <div className="msc-v3-control-zone">
        {needsDeliverySetup ? (
          <button
            type="button"
            className="msc-v3-setup"
            onClick={() => setShowDeliverySetupModal(true)}
          >
            🎯 Select striker, non-striker and bowler
          </button>
        ) : (
          canScoreCurrentLeague && (
            <>
              <div className="msc-v3-keypad">
                {[0, 1, 2, 3, 4, 6].map((run) => (
                  <button
                    key={run}
                    type="button"
                    disabled={
                      isEffectiveMatchCompleted ||
                      isMatchLocked ||
                      isMatchAbandoned
                    }
                    className={`msc-v3-key ${
                      run === 4 ? "four" : ""
                    } ${run === 6 ? "six" : ""} ${
                      activeQuickAction === String(run)
                        ? "active"
                        : ""
                    }`}
                    onClick={() =>
                      triggerQuickAction(
                        String(run),
                        () => quickNormalBall(run)
                      )
                    }
                  >
                    {run}
                  </button>
                ))}

                <button
                  type="button"
                  className="msc-v3-key extra"
                  disabled={
                    isEffectiveMatchCompleted ||
                    isMatchLocked ||
                    isMatchAbandoned
                  }
                  onClick={() =>
                    triggerQuickAction(
                      "Wd",
                      () => quickExtra("WIDE")
                    )
                  }
                >
                  WD
                </button>

                <button
                  type="button"
                  className="msc-v3-key extra"
                  disabled={
                    isEffectiveMatchCompleted ||
                    isMatchLocked ||
                    isMatchAbandoned
                  }
                  onClick={() =>
                    triggerQuickAction(
                      "Nb",
                      () => quickExtra("NOBALL")
                    )
                  }
                >
                  NB
                </button>

                <button
                  type="button"
                  className="msc-v3-key"
                  disabled={
                    isEffectiveMatchCompleted ||
                    isMatchLocked ||
                    isMatchAbandoned
                  }
                  onClick={() =>
                    triggerQuickAction(
                      "B",
                      () => quickExtra("BYE")
                    )
                  }
                >
                  B
                </button>

                <button
                  type="button"
                  className="msc-v3-key"
                  disabled={
                    isEffectiveMatchCompleted ||
                    isMatchLocked ||
                    isMatchAbandoned
                  }
                  onClick={() =>
                    triggerQuickAction(
                      "LB",
                      () => quickExtra("LEGBYE")
                    )
                  }
                >
                  LB
                </button>

                <button
                  type="button"
                  className="msc-v3-key wicket"
                  disabled={
                    isEffectiveMatchCompleted ||
                    isMatchLocked ||
                    isMatchAbandoned
                  }
                  onClick={() =>
                    triggerQuickAction(
                      "W",
                      () => quickWicket("BOWLED")
                    )
                  }
                >
                  WKT
                </button>

                <button
                  type="button"
                  className="msc-v3-key retired"
                  disabled={
                    isEffectiveMatchCompleted ||
                    isMatchLocked ||
                    isMatchAbandoned
                  }
                  onClick={() => setShowRetiredHurtModal(true)}
                >
                  RTD
                </button>
              </div>

              <div className="msc-v3-safety">
                <button
                  type="button"
                  className="swap"
                  disabled={
                    isEffectiveMatchCompleted ||
                    isMatchLocked ||
                    isMatchAbandoned
                  }
                  onClick={swapBatters}
                >
                  ⇄ Swap
                </button>

                <button
                  type="button"
                  className="undo"
                  disabled={isMatchLocked}
                  onClick={() =>
                    triggerQuickAction(
                      "Undo",
                      handleUndoBall
                    )
                  }
                >
                  ↩ Undo
                </button>
              </div>

              <div className="msc-v3-tools">
                <button
                  type="button"
                  disabled={
                    isEffectiveMatchCompleted ||
                    isMatchLocked ||
                    isMatchAbandoned
                  }
                  onClick={() => setShowKeeperChangeModal(true)}
                >
                  🧤 Change WK
                </button>

                {lastCorrectionId && (
                  <button
                    type="button"
                    disabled={rollbackSaving}
                    onClick={() =>
                      rollbackCorrection(lastCorrectionId)
                    }
                  >
                    {rollbackSaving
                      ? "Restoring..."
                      : "↶ Rollback"}
                  </button>
                )}

                {Number(ballForm.inningsNo) === 1 &&
                  scoreboard?.match?.status !== "COMPLETED" &&
                  scoreboard?.match?.status !== "COMPLETED_LOCKED" &&
                  scoreboard?.match?.status !== "COMPLETED_CORRECTED" && (
                    <button
                      type="button"
                      className="end"
                      onClick={handleEndFirstInnings}
                    >
                      🔴 End innings
                    </button>
                  )}
              </div>
{/* This is outside msc-v3-tools */}
<button
  type="button"
  className="msc-v3-scoring-form-btn"
  onClick={openScoringFormSheet}
>
  <span>⚙️</span>

  <div>
    <strong>Scoring Form</strong>
  </div>
</button>         
            </>
          )
        )}
      </div>
    </section>
  </div>
)}
<div
  className={`${
    scorerMode
      ? "scorer-wow-console scorer-mode-flat"
      : "tv-score-console scorer-wow-console"
  } mobile-original-scorer-console`}
>
  {liveMatchCenter && (
    <>
      {displayScoreboard && !isMobile && (
  <div
    className={`match-insights-card scorer-insights-strip ${
      scorerMode ? "desktop-scorer-insights" : ""
    }`}
  >
          {dashboardResultText && (
            <div className="insight-result">
              <span>🏆 Match Result</span>
              <strong>{dashboardResultText}</strong>
            </div>
          )}

          {matchInsights.potm && (
            <div className="insight-mini">
              <span>⭐ POTM</span>
              <strong>{matchInsights.potm.playerName}</strong>
            </div>
          )}

          {matchInsights.winProbability && (
            <div className="insight-mini">
              <span>📈 Win Probability</span>
              <strong>
                {matchInsights.winProbability.battingTeam}{" "}
                {matchInsights.winProbability.battingChance}%
              </strong>
            </div>
          )}
        </div>
      )}

      <div className="scorer-live-hud normal-mobile-live-hud">
        <div className="scorer-hud-main">
          <div>
            <span className="tv-live-pill">● LIVE</span>
            <strong>
              {liveMatchCenter.runs}/{liveMatchCenter.wickets}
            </strong>
            <small>
              Inn {liveMatchCenter.inningsNo} • {liveMatchCenter.oversDisplay} ov
            </small>
          </div>

        </div>
          {!matchEnded && scoreboard?.currentState && (
  <>
        <div className="scorer-hud-players">

          <div className="striker">
            <span>⚡ Striker</span>
            <strong>{displayScoreboard?.currentState?.strikerName || "-"}</strong>
            <b>
              {displayScoreboard?.currentState?.strikerStats
                ? `${displayScoreboard.currentState.strikerStats.runs} (${displayScoreboard.currentState.strikerStats.balls})`
                : "0 (0)"}
            </b>
          </div>

          
          <div className="non-striker ">
            <span>🏃 Non-striker</span>
            <strong>{displayScoreboard?.currentState?.nonStrikerName || "-"}</strong>
            <b>
              {displayScoreboard?.currentState?.nonStrikerStats
                ? `${displayScoreboard.currentState.nonStrikerStats.runs} (${displayScoreboard.currentState.nonStrikerStats.balls})`
                : "0 (0)"}
            </b>
          </div>

          <div className="bowler">
            <span>🎯 Bowler</span>
            <strong>{displayScoreboard?.currentState?.bowlerName || "-"}</strong>
            <b>
              {displayScoreboard?.currentState?.bowlerStats
                ? `${displayScoreboard.currentState.bowlerStats.wickets}/${displayScoreboard.currentState.bowlerStats.runs} (${displayScoreboard.currentState.bowlerStats.overs} ov)`
                : "0/0"}
            </b>
          </div>

        </div>

        <div className="scorer-hud-metrics">
          <span>CRR <b>{liveMatchCenter.crr}</b></span>
          <span>RRR <b>{liveMatchCenter.rrr}</b></span>
          <span>Proj <b>{liveMatchCenter.projected}</b></span>
          <span>P’ship <b>{liveMatchCenter.partnershipRuns} ({liveMatchCenter.partnershipBalls})</b></span>
        </div>
  </>
)}        
      </div>
      {needsDeliverySetup ? (
        <div className="tv-status-banner setup">
          <strong>🎯 Setup required</strong>
          <span>
            {Number(ballForm.inningsNo) === 2
              ? "2nd innings is ready. Select striker, non-striker, and bowler."
              : "Select striker, non-striker, and bowler before scoring."}
          </span>

          <button
            type="button"
            className="mgmt-clean-btn"
            onClick={() => setShowDeliverySetupModal(true)}
          >
            Setup Delivery
          </button>
        </div>
      ) : (
        !(
          selectedMatch &&
          ["COMPLETED", "COMPLETED_LOCKED", "COMPLETED_CORRECTED"].includes(
            String(selectedMatch.status || "").toUpperCase()
          )
        ) && (
          <div className="normal-mobile-delivery-status">
            {error ||
              instantDeliveryStatus ||
              message ||
              overCompleteNotice ||
              "🏏 Ready for next delivery"}
                      </div>
        )
      )}

      <div className="scorer-recent-wow normal-mobile-recent-balls">
        <span>
          Recent <small>last 10</small>
        </span>

        <div className="recent-ball-strip">
          {recentBalls.length ? (
            recentBalls.slice(0, 10).map((ball, index) => {
              const label = ball.label || "";
              const recent10 = recentBalls.slice(0, 10);
              const currentOver = label.split(".")[0];

              const prevOver =
                index > 0
                  ? recent10[index - 1]?.label?.split(".")[0]
                  : currentOver;

              const ballResult = (
                label.split(" ").slice(1).join(" ") || label
              ).replace(/[()]/g, "");

              return (
                <React.Fragment key={ball.id || index}>
                  {index > 0 && currentOver !== prevOver && (
                    <span className="over-separator">|</span>
                  )}

                  <span
                    className={`ball-chip ${
                      ballResult === "W"
                        ? "ball-wicket"
                        : ballResult === "4" || ballResult === "6"
                        ? "ball-boundary"
                        : ""
                    }`}
                  >
                    {ballResult}
                  </span>
                </React.Fragment>
              );
            })
          ) : (
            <span className="muted">No recent balls</span>
          )}
        </div>
      </div>
      {liveMatchCenter?.isSecondInnings && liveMatchCenter?.target > 0 && (
        <>
          <div className="tv-chase-mini scorer-chase-wow normal-mobile-chase-strip">
            <span>
              {dlsActiveForDisplay ? "🌧 Target" : "Target"}{" "}
              <b>{liveMatchCenter.target}</b>
            </span>
            <span>Need <b>{liveMatchCenter.runsRequired}</b></span>
            <span>Balls <b>{liveMatchCenter.ballsRemaining}</b></span>
          </div>

          {liveMatchCenter?.chasePar != null && (
            <div
              aria-label="Cric4All Chase Par"
              style={{
                marginTop:
                  6,
                display:
                  "flex",
                alignItems:
                  "center",
                justifyContent:
                  "center",
                gap:
                  14,
                flexWrap:
                  "wrap",
                padding:
                  "7px 10px",
                borderRadius:
                  10,
                background:
                  "rgba(15, 23, 42, 0.58)",
                border:
                  "1px solid rgba(148, 163, 184, 0.18)",
                fontSize:
                  12,
                lineHeight:
                  1.15,
              }}
            >
              <span
                style={{
                  whiteSpace:
                    "nowrap",
                }}
              >
                Cric4All Par:{" "}
                <b>
                  {liveMatchCenter.chasePar}
                </b>
                {" runs"}
              </span>

              <span
                style={{
                  whiteSpace:
                    "nowrap",
                  fontWeight:
                    900,
                }}
              >
                {liveMatchCenter.parState === "AHEAD"
                  ? "▲ "
                  : liveMatchCenter.parState === "BEHIND"
                    ? "▼ "
                    : "● "}
                {liveMatchCenter.parDeltaLabel}
                {liveMatchCenter.parState === "AHEAD"
                  ? " ahead"
                  : liveMatchCenter.parState === "BEHIND"
                    ? " behind"
                    : " level"}
              </span>

              <small
                style={{
                  whiteSpace:
                    "nowrap",
                  opacity:
                    0.72,
                }}
              >
                {liveMatchCenter.parState === "AHEAD"
                  ? "Ahead"
                  : liveMatchCenter.parState === "BEHIND"
                    ? "Behind"
                    : "Level"}
              </small>
            </div>
          )}
        </>
      )}
    </>
  )}
{scorerMode && scorerDrawer === "setup" && (
  <div className="scorer-workspace open">
    <div className="scorer-workspace-panel">
      <div className="scorer-workspace-head">
<strong>⚙️ Match Setup</strong>

        <button type="button" onClick={() => setScorerDrawer(null)}>
          ✕
        </button>
      </div>

      <div className="scorer-workspace-body">

{scorerDrawer === "setup" && (
  <div className="scorer-setup-panel">
    <div className="scorer-drawer-grid">
      <div className="drawer-stat-card">
        <span>Overs / Innings</span>
        <strong>{matchDetail?.oversPerInnings || "-"}</strong>
      </div>

      <div className="drawer-stat-card">
        <span>Powerplay</span>
        <strong>{matchDetail?.powerplayOversInnings ?? 0}</strong>
      </div>

      <div className="drawer-stat-card">
        <span>Wickets</span>
        <strong>{matchDetail?.maxWicketsPerInnings || "∞"}</strong>
      </div>

      <div className="drawer-stat-card">
        <span>Max / Bowler</span>
        <strong>{matchDetail?.maxOversPerBowler || "∞"}</strong>
      </div>

      <div className="drawer-stat-card">
        <span>Status</span>
        <strong>{selectedMatch?.status || matchDetail?.status || "-"}</strong>
      </div>

      <div className="drawer-stat-card">
        <span>Batting First</span>
        <strong>
          {selectedMatch?.battingFirstTeamName ||
            playerNameFromTeam(matchDetail?.teamA, matchDetail?.battingFirstTeamId) ||
            "Not decided"}
        </strong>
      </div>
    </div>

    <div className="scorer-officials-grid">
      <div className="scorer-official-card">
        <strong>{matchDetail?.teamA?.name || "Team A"}</strong>

        <span>
          🧢 Captain:{" "}
          {playerNameFromTeam(matchDetail?.teamA, matchDetail?.teamACaptainId) ||
            "Not selected"}
        </span>

        <span>
          🧤 WK:{" "}
          {playerNameFromTeam(matchDetail?.teamA, matchDetail?.teamAWicketKeeperId) ||
            "Not selected"}
        </span>
      </div>

      <div className="scorer-official-card">
        <strong>{matchDetail?.teamB?.name || "Team B"}</strong>

        <span>
          🧢 Captain:{" "}
          {playerNameFromTeam(matchDetail?.teamB, matchDetail?.teamBCaptainId) ||
            "Not selected"}
        </span>

        <span>
          🧤 WK:{" "}
          {playerNameFromTeam(matchDetail?.teamB, matchDetail?.teamBWicketKeeperId) ||
            "Not selected"}
        </span>
      </div>
    </div>
  </div>
)}
      </div>
    </div>
  </div>
)}  
{canScoreCurrentLeague && (
  <div className="scorer-actions-panel mobile-original-actions-panel normal-mobile-scoring-actions">
<div className="quick-actions scorer-run-buttons scorer-mobile-pad">
  {[0, 1, 2, 3, 4, 6].map((run) => (
    <button
      key={run}
      type="button"
      disabled={isEffectiveMatchCompleted || isMatchLocked || isMatchAbandoned}
      className={`chip score-chip ${activeQuickAction === String(run) ? "chip-active" : ""}`}
      onClick={() => triggerQuickAction(String(run), () => quickNormalBall(run))}
    >
      {run}
    </button>
  ))}

  <button type="button" className={`chip score-chip ${activeQuickAction === "Wd" ? "chip-active" : ""}`} disabled={isEffectiveMatchCompleted || isMatchLocked || isMatchAbandoned} onClick={() => triggerQuickAction("Wd", () => quickExtra("WIDE"))}>Wd</button>
  <button type="button" className={`chip score-chip ${activeQuickAction === "Nb" ? "chip-active" : ""}`} disabled={isEffectiveMatchCompleted || isMatchLocked || isMatchAbandoned} onClick={() => triggerQuickAction("Nb", () => quickExtra("NOBALL"))}>Nb</button>
  <button type="button" className={`chip score-chip ${activeQuickAction === "B" ? "chip-active" : ""}`} disabled={isEffectiveMatchCompleted || isMatchLocked || isMatchAbandoned} onClick={() => triggerQuickAction("B", () => quickExtra("BYE"))}>B</button>
  <button type="button" className={`chip score-chip ${activeQuickAction === "LB" ? "chip-active" : ""}`} disabled={isEffectiveMatchCompleted || isMatchLocked || isMatchAbandoned} onClick={() => triggerQuickAction("LB", () => quickExtra("LEGBYE"))}>LB</button>

  <button type="button" className={`chip score-chip score-wide ${activeQuickAction === "W" ? "chip-active" : ""}`} disabled={isEffectiveMatchCompleted || isMatchLocked || isMatchAbandoned} onClick={() => triggerQuickAction("W", () => quickWicket("BOWLED"))}>Wkt</button>

  <button type="button" className="chip score-chip score-wide chip-retired-hurt" disabled={isEffectiveMatchCompleted || isMatchLocked || isMatchAbandoned} onClick={() => setShowRetiredHurtModal(true)}>Rtd H</button>

  <button type="button" className="chip score-chip score-wide chip-swap" disabled={isEffectiveMatchCompleted || isMatchLocked || isMatchAbandoned} onClick={swapBatters}>⇄ Swap</button>

  <button
    type="button"
    className="chip score-chip score-wide score-undo"
    disabled={
      isMatchLocked ||
      undoSaving
    }
    onClick={handleUndoBall}
  >
    {undoSaving
      ? "Undoing..."
      : "↩ Undo"}
  </button>
</div>

    <div className="mobile-secondary-actions scorer-secondary-row">
      <button type="button" className="btn btn-outline action-change-wk" disabled={isEffectiveMatchCompleted || isMatchLocked || isMatchAbandoned} onClick={() => setShowKeeperChangeModal(true)}>
        🧤 Change WK
      </button>

      {lastCorrectionId && (
        <button type="button" className={`btn btn-outline ${rollbackSaving ? "btn-loading" : ""}`} disabled={rollbackSaving} onClick={() => rollbackCorrection(lastCorrectionId)}>
          {rollbackSaving ? "Restoring..." : "Rollback"}
        </button>
      )}
      {Number(ballForm.inningsNo) === 1 &&
        scoreboard?.match?.status !== "COMPLETED" &&
        scoreboard?.match?.status !== "COMPLETED_LOCKED" &&
        scoreboard?.match?.status !== "COMPLETED_CORRECTED" && (
          <button type="button" className="end-innings-pill action-end-innings" onClick={handleEndFirstInnings}>
            <span>🛑 End 1st Innings</span>
            <small>Finished batting?</small>
          </button>
        )}
    </div>
  </div>
)}
    {(isEffectiveMatchCompleted || isMatchLocked || isMatchCorrected) && (
      regulationMatchTied &&
      !selectedSuperOverState?.completed &&
      !isOfflineMatchCompleted ? (
        <div className="scorer-tie-super-over-panel">
          <div>
            <span>
              ⚡ MATCH TIED
            </span>

            <strong>
              Super Over required
            </strong>

            <small>
              Regulation scoring is complete. Start the tie-breaker now.
            </small>
          </div>

          {canScoreCurrentLeague ? (
            <button
              type="button"
              className="btn scoring-btn scoring-btn-primary scorer-start-super-over-btn"
              disabled={superOverBusy}
              onClick={() =>
                openSuperOver(
                  selectedMatchId
                )
              }
            >
              {superOverBusy
                ? "Opening…"
                : selectedSuperOverState?.active
                  ? "⚡ Continue Super Over"
                  : selectedSuperOverState?.tied
                    ? `⚡ Start Super Over ${Number(selectedSuperOverState.round || 1) + 1}`
                    : "⚡ Start Super Over"}
            </button>
          ) : (
            <span className="scorer-super-over-readonly">
              Waiting for an authorized scorer
            </span>
          )}
        </div>
      ) : (
        <div className="scorer-local-complete-panel">
          <button
            type="button"
            className="btn scoring-btn scoring-btn-primary"
            disabled
          >
            {isOfflineMatchCompleted
              ? "🏁 Match Ended Locally"
              : "✅ Match Ended"}
          </button>

          {isEffectiveMatchCompleted &&
            !isMatchLocked &&
            canScoreCurrentLeague && (
            <>
              {isOfflineMatchCompleted && (
                <small
                  style={{
                    display: "block",
                    marginTop: "8px",
                    opacity: 0.85,
                    textAlign: "center",
                  }}
                >
                  {offlineSyncState.pending > 0
                    ? `${offlineSyncState.pending} offline change${
                        offlineSyncState.pending === 1 ? "" : "s"
                      } must sync before the match can be locked.`
                    : offlineSyncState.online === false
                      ? "Reconnect so Cric4All can finalize the server result before locking."
                      : "Offline scoring is synchronized. You can now lock the completed match."}
                </small>
              )}

              <button
                type="button"
                className="btn scoring-btn"
                disabled={
                  offlineSyncState.pending > 0 ||
                  offlineSyncState.syncing ||
                  offlineSyncState.online === false ||
                  Boolean(offlineSyncState.conflict)
                }
                onClick={handleLockMatch}
                title={
                  offlineSyncState.pending > 0 ||
                  offlineSyncState.online === false
                    ? "Reconnect and synchronize all offline changes before locking."
                    : "Lock this completed match."
                }
                style={{
                  marginTop: "8px",
                  width: "100%",
                }}
              >
                🔒 Lock Match
                {offlineSyncState.pending > 0
                  ? " · Sync Required"
                  : ""}
              </button>
            </>
          )}
        </div>
      )
    )}

    {isMatchAbandoned && (
      <button type="submit" form="add-ball-form" className="btn scoring-btn scoring-btn-primary" disabled>
        ⛔ Match Abandoned
      </button>
    )}
{scorerMode && voiceStatus && (
  <div className="voice-score-status">
    {voiceStatus}
  </div>
)}

{!isMobile && (
  <>
      <div className="msc-v3-delivery-head">
        <span> Keyboard shortcuts: 0 1 2 3 4 6 • W wicket • D wide • N no-ball • U undo </span>
      </div>
</>
)}
      </div>

{canScoreCurrentLeague && (isMobile ? (
  <>
    <button
  type="button"
  className="chip score-chip score-wide mobile-normal-scoring-form-btn"
  onClick={() => setShowAdvancedSheet(true)}
>
  ⚙️ Scoring Form
</button>
{showAdvancedSheet && (
  <>
    <div
      className="sheet-backdrop"
      onClick={() =>
        setShowAdvancedSheet(false)
      }
    />

    <div className="advanced-sheet mobile-normal-scoring-sheet">

      <div className="sheet-header">

        <div className="sheet-handle" />

        <h3>
          ⚙️ Scoring form for manual updates
        </h3>

        <button
          type="button"
          className="sheet-close"
          onClick={() =>
            setShowAdvancedSheet(false)
          }
        >
          ✕
        </button>

      </div>

      <div className="sheet-content">

              <form id="add-ball-form" className="form grid-2" onSubmit={handleAddBall}>
                <label>
                  <span>Innings</span>
                  <select
                    value={ballForm.inningsNo || ""}
                    onChange={(e) =>
                      setBallForm((prev) => ({ ...prev, inningsNo: e.target.value }))
                    }
                  >
                    <option value="1">Innings 1</option>
                    <option value="2">Innings 2</option>
                  </select>
                </label>
                  <label>
                  <span>Bowler</span>
                  <select
                    value={ballForm.bowlerId || ""}
                    onChange={(e) =>
                      setBallForm((prev) => ({ ...prev, bowlerId: e.target.value }))
                    }
                    required
                  >
                    <option value="">Select bowler</option>
                    {(bowlingTeam?.players || []).map((p) => (
                      <option key={p.id} value={p.id}>{p.name}</option>
                    ))}
                  </select>
                </label>
              
  {/* Striker */}
  <label>
    <span>Striker</span>

    <select
      value={ballForm.strikerId || ""}
      onChange={(e) =>
        setBallForm((prev) => ({
          ...prev,
          strikerId: e.target.value,
          dismissedPlayerId: e.target.value
        }))
      }
      required
    >
      <option value="">Select striker</option>

      {(battingTeam?.players || []).map((p) => (
        <option key={p.id} value={p.id}>
          {p.name}
        </option>
      ))}
    </select>
     {/* Bowler */}
  </label>
  <label>
  {/* Non Striker */}
    <span>Non-striker</span>

    <select
      value={ballForm.nonStrikerId || ""}
      onChange={(e) =>
        setBallForm((prev) => ({
          ...prev,
          nonStrikerId: e.target.value
        }))
      }
      required
    >
      <option value="">Select non-striker</option>

      {(battingTeam?.players || []).map((p) => (
        <option key={p.id} value={p.id}>
          {p.name}
        </option>
      ))}
    </select>
  </label>
                <label>
                  <span>Extra Type</span>
                  <select
                    value={ballForm.extraType || ""}
                    onChange={(e) =>
                      setBallForm((prev) => ({ ...prev, extraType: e.target.value }))
                    }
                  >
                    {EXTRA_TYPES.map((type) => (
                      <option key={type} value={type}>{type}</option>
                    ))}
                  </select>
                </label>

                <label>
                  <span>Runs Off Bat</span>
                  <input
                    type="number"
                    min="0"
                    value={ballForm.runsOffBat || ""}
                    onChange={(e) =>
                      setBallForm((prev) => ({ ...prev, runsOffBat: e.target.value }))
                    }
                    required
                  />
                </label>

                <label>
                  <span>Extras</span>
                  <input
                    type="number"
                    min="0"
                    value={ballForm.extras || ""}
                    onChange={(e) =>
                      setBallForm((prev) => ({ ...prev, extras: e.target.value }))
                    }
                    required
                  />
                </label>

                <label className="checkbox-row">
                  <span>Wicket</span>
                  <input
                    type="checkbox"
                    checked={ballForm.isWicket}
 onChange={(e) => {
  const nextType = e.target.value;

  setRunOutRuns(null);

  setBallForm((prev) => ({
    ...prev,
    wicketType: nextType,
    dismissedPlayerId:
      nextType === "RUN_OUT"
        ? prev.dismissedPlayerId || prev.strikerId
        : prev.strikerId,
    newBatterId: "",
    fielderId: "",
    assistantFielderId: "",
  }));
}}
                  />
                </label>

                <label>
                  <span>Wicket Type</span>
                  <select
                    value={ballForm.wicketType || ""}
                    onChange={(e) =>
                      setBallForm((prev) => ({ ...prev, wicketType: e.target.value }))
                    }
                    disabled={!ballForm.isWicket}
                  >
                    {WICKET_TYPES
  .filter((type) => type !== "RETIRED_HURT")
  .map((type) => (
                      <option key={type} value={type}>{type}</option>
                    ))}
                  </select>
                </label>

                <label>
                  <span>Dismissed Player</span>
                  <select
                    value={ballForm.dismissedPlayerId || ""}
                    onChange={(e) =>
                      setBallForm((prev) => ({ ...prev, dismissedPlayerId: e.target.value }))
                    }
                    disabled={!ballForm.isWicket}
                  >
                    <option value="">Select dismissed player</option>
                    {(battingTeam?.players || []).map((p) => (
                      <option key={p.id} value={p.id}>{p.name}</option>
                    ))}
                  </select>
                </label>
{["CAUGHT", "STUMPED", "RUN_OUT"].includes(ballForm.wicketType) && (
  <label>
    <span>
      {ballForm.wicketType === "CAUGHT"
        ? "Caught By"
        : ballForm.wicketType === "STUMPED"
          ? "Stumped By / Wicketkeeper"
          : "Run Out By"}
    </span>

    <select
      value={ballForm.fielderId || ""}
      onChange={(e) =>
        setBallForm((prev) => ({
          ...prev,
          fielderId: e.target.value
        }))
      }
      disabled={!ballForm.isWicket}
    >
      <option value="">Select fielder</option>

      {(bowlingTeam?.players || []).map((p) => (
        <option key={p.id} value={p.id}>
          {p.name}
        </option>
      ))}
    </select>
  </label>
)}

{ballForm.wicketType === "RUN_OUT" && (
  <label>
    <span>Assisted By / Stumps Broken By</span>

    <select
      value={ballForm.assistantFielderId || ""}
      onChange={(e) =>
        setBallForm((prev) => ({
          ...prev,
          assistantFielderId: e.target.value
        }))
      }
      disabled={!ballForm.isWicket}
    >
      <option value="">Optional</option>

      {(bowlingTeam?.players || []).map((p) => (
        <option key={p.id} value={p.id}>
          {p.name}
        </option>
      ))}
    </select>
  </label>
)}
                <label>
                  <span>New Batter</span>
                  <select
                    value={ballForm.newBatterId || ""}
                    onChange={(e) =>
                      setBallForm((prev) => ({ ...prev, newBatterId: e.target.value }))
                    }
                    disabled={!ballForm.isWicket}
                  >
                    <option value="">Select new batter</option>
                    {wicketNewBatterOptions.map((p) => (
                      <option key={p.id} value={p.id}>{p.name}</option>
                    ))}
                  </select>
                </label>

                <label className="full-span">
                  <span>Note</span>
                  <input
                    type="text"
                    value={ballForm.note || ""}
                    onChange={(e) =>
                      setBallForm((prev) => ({ ...prev, note: e.target.value }))
                    }
                    placeholder="Optional note"
                  />
                </label>
</form>

<div className="sheet-actions">
  <button
    type="button"
    className="btn btn-outline"
    onClick={() => setShowAdvancedSheet(false)}
  >
    Done
  </button>
</div>

      </div>
    </div>
  </>
)}
  </>
) : (
<div
  className="desktop-scoring-form-anchor"
  onClick={(event) => {
    const summary = event.target.closest("summary");

    if (!summary) return;

    window.setTimeout(() => {
      const formSection = summary.closest(
        ".desktop-scoring-form-anchor"
      );

      formSection?.scrollIntoView({
        behavior: "smooth",
        block: "start",
      });
    }, 80);
  }}
>
  <CollapsibleSection
    title="🏏 Scoring Form"
    defaultOpen={false}
  >
                <form id="add-ball-form" className="form grid-2" onSubmit={handleAddBall}>
                <label>
                  <span>Innings</span>
                  <select
                    value={ballForm.inningsNo || ""}
                    onChange={(e) =>
                      setBallForm((prev) => ({ ...prev, inningsNo: e.target.value }))
                    }
                  >
                    <option value="1">Innings 1</option>
                    <option value="2">Innings 2</option>
                  </select>
                </label>
                  <label>
                  <span>Bowler</span>
                  <select
                    value={ballForm.bowlerId || ""}
                    onChange={(e) =>
                      setBallForm((prev) => ({ ...prev, bowlerId: e.target.value }))
                    }
                    required
                  >
                    <option value="">Select bowler</option>
                    {(bowlingTeam?.players || []).map((p) => (
                      <option key={p.id} value={p.id}>{p.name}</option>
                    ))}
                  </select>
                </label>
              
  {/* Striker */}
  <label>
    <span>Striker</span>

    <select
      value={ballForm.strikerId || ""}
      onChange={(e) =>
        setBallForm((prev) => ({
          ...prev,
          strikerId: e.target.value,
          dismissedPlayerId: e.target.value
        }))
      }
      required
    >
      <option value="">Select striker</option>

      {(battingTeam?.players || []).map((p) => (
        <option key={p.id} value={p.id}>
          {p.name}
        </option>
      ))}
    </select>
     {/* Bowler */}
  </label>
  <label>
  {/* Non Striker */}
    <span>Non-striker</span>

    <select
      value={ballForm.nonStrikerId || ""}
      onChange={(e) =>
        setBallForm((prev) => ({
          ...prev,
          nonStrikerId: e.target.value
        }))
      }
      required
    >
      <option value="">Select non-striker</option>

      {(battingTeam?.players || []).map((p) => (
        <option key={p.id} value={p.id}>
          {p.name}
        </option>
      ))}
    </select>
  </label>
                <label>
                  <span>Extra Type</span>
                  <select
                    value={ballForm.extraType || ""}
                    onChange={(e) =>
                      setBallForm((prev) => ({ ...prev, extraType: e.target.value }))
                    }
                  >
                    {EXTRA_TYPES.map((type) => (
                      <option key={type} value={type}>{type}</option>
                    ))}
                  </select>
                </label>

                <label>
                  <span>Runs Off Bat</span>
                  <input
                    type="number"
                    min="0"
                    value={ballForm.runsOffBat || ""}
                    onChange={(e) =>
                      setBallForm((prev) => ({ ...prev, runsOffBat: e.target.value }))
                    }
                    required
                  />
                </label>

                <label>
                  <span>Extras</span>
                  <input
                    type="number"
                    min="0"
                    value={ballForm.extras || ""}
                    onChange={(e) =>
                      setBallForm((prev) => ({ ...prev, extras: e.target.value }))
                    }
                    required
                  />
                </label>

                <label className="checkbox-row">
                  <span>Wicket</span>
                  <input
                    type="checkbox"
                    checked={ballForm.isWicket}
                    onChange={(e) =>
                      setBallForm((prev) => ({
                        ...prev,
                        isWicket: e.target.checked,
                        wicketType: e.target.checked ? "BOWLED" : "NONE"
                      }))
                    }
                  />
                </label>

                <label>
                  <span>Wicket Type</span>
                  <select
                    value={ballForm.wicketType || ""}
                    onChange={(e) =>
                      setBallForm((prev) => ({ ...prev, wicketType: e.target.value }))
                    }
                    disabled={!ballForm.isWicket}
                  >
                    {WICKET_TYPES
  .filter((type) => type !== "RETIRED_HURT")
  .map((type) => (
                      <option key={type} value={type}>{type}</option>
                    ))}
                  </select>
                </label>

                <label>
                  <span>Dismissed Player</span>
                  <select
                    value={ballForm.dismissedPlayerId || ""}
                    onChange={(e) =>
                      setBallForm((prev) => ({ ...prev, dismissedPlayerId: e.target.value }))
                    }
                    disabled={!ballForm.isWicket}
                  >
                    <option value="">Select dismissed player</option>
                    {(battingTeam?.players || []).map((p) => (
                      <option key={p.id} value={p.id}>{p.name}</option>
                    ))}
                  </select>
                </label>
{["CAUGHT", "STUMPED", "RUN_OUT"].includes(ballForm.wicketType) && (
  <label>
    <span>
      {ballForm.wicketType === "CAUGHT"
        ? "Caught By"
        : ballForm.wicketType === "STUMPED"
          ? "Stumped By / Wicketkeeper"
          : "Run Out By"}
    </span>

    <select
      value={ballForm.fielderId || ""}
      onChange={(e) =>
        setBallForm((prev) => ({
          ...prev,
          fielderId: e.target.value
        }))
      }
      disabled={!ballForm.isWicket}
    >
      <option value="">Select fielder</option>

      {(bowlingTeam?.players || []).map((p) => (
        <option key={p.id} value={p.id}>
          {p.name}
        </option>
      ))}
    </select>
  </label>
)}

{ballForm.wicketType === "RUN_OUT" && (
  <label>
    <span>Assisted By / Stumps Broken By</span>

    <select
      value={ballForm.assistantFielderId || ""}
      onChange={(e) =>
        setBallForm((prev) => ({
          ...prev,
          assistantFielderId: e.target.value
        }))
      }
      disabled={!ballForm.isWicket}
    >
      <option value="">Optional</option>

      {(bowlingTeam?.players || []).map((p) => (
        <option key={p.id} value={p.id}>
          {p.name}
        </option>
      ))}
    </select>
  </label>
)}
                <label>
                  <span>New Batter</span>
                  <select
                    value={ballForm.newBatterId || ""}
                    onChange={(e) =>
                      setBallForm((prev) => ({ ...prev, newBatterId: e.target.value }))
                    }
                    disabled={!ballForm.isWicket}
                  >
                    <option value="">Select new batter</option>
                    {availableNewBatters.map((p) => (
                      <option key={p.id} value={p.id}>{p.name}</option>
                    ))}
                  </select>
                </label>

                <label className="full-span">
                  <span>Note</span>
                  <input
                    type="text"
                    value={ballForm.note || ""}
                    onChange={(e) =>
                      setBallForm((prev) => ({ ...prev, note: e.target.value }))
                    }
                    placeholder="Optional note"
                  />
                </label>
</form>
              </CollapsibleSection> </div>
)
    )}           
    </div>
            </>            
          )}

        </Card>
)}        
{selectedMatchId && permissions?.canScoreMatch && !(
  selectedMatch &&
  ["COMPLETED_LOCKED"].includes(
    String(selectedMatch.status || "").toUpperCase()
  )
) &&(
<div>
  <div className="match-control-bar">
    <button
      type="button"
      className="match-control-btn lock"
      disabled={isMatchLocked}
      onClick={handleLockMatch}
    >
        <span>🔒</span>
    <label>Lock</label>
    </button>
{(!isMatchAbandoned && !isMatchCompleted && !isMatchLocked) && (
    <button
      type="button"
      className="match-control-btn dls"
      disabled={dlsBusy}
      onClick={openDlsModal}
      title="Rain interruption / DLS"
    >
      <span>🌧️</span>
      <label>DLS</label>
    </button>
)}
{(!isMatchAbandoned && !isMatchCompleted && !isMatchLocked) && (
    <button
      type="button"
      className="match-control-btn abandon"
      disabled={isMatchLocked || isMatchCompleted}
      onClick={handleAbandonMatch}
    >
      <span>⛔</span>
    <label>Abandon</label>
    </button>
    
)}    
{(ballForm.inningsNo != 1 && !isMatchLocked && !isMatchAbandoned && !isMatchCompleted) && (
  <button
  type="button"
  className="match-control-btn end"
  onClick={handleEndMatch}
>
      <span>🏁</span>
    <label>End Match</label>
</button>
)}
  </div>

  <div className="match-warning">
    ⚠️ Once locked, this match cannot be edited or scored further.
  </div>
</div>
)}</Card>
    </div>    
)}


{showSuperOverModal &&
  superOverMatch &&
  superOverState &&
  typeof document !== "undefined" &&
  createPortal(
    <div
      className="super-over-backdrop"
      role="presentation"
      onMouseDown={(event) => {
        if (
          event.currentTarget ===
          event.target
        ) {
          setShowSuperOverModal(false);
        }
      }}
    >
      <section
        className="super-over-modal"
        role="dialog"
        aria-modal="true"
        aria-label="Super Over scorer"
      >
        <header className="super-over-head">
          <div>
            <span>
              ⚡ SUPER OVER
            </span>

            <h3>
              {superOverMatch.teamAName}
              {" vs "}
              {superOverMatch.teamBName}
            </h3>

            <p>
              One over · two wickets · repeated until there is a winner
            </p>
          </div>

          <button
            type="button"
            onClick={() =>
              setShowSuperOverModal(false)
            }
            aria-label="Close Super Over"
          >
            ×
          </button>
        </header>

        {superOverError && (
          <div className="super-over-error">
            {superOverError}
          </div>
        )}

        {!superOverState.exists && (
          <div className="super-over-start-card">
            <span>
              Main match tied
            </span>

            <strong>
              Start the deciding Super Over
            </strong>

            <p>
              The team that batted second in the match will bat first.
              Super Over deliveries are kept separate from normal player
              career statistics.
            </p>

            <button
              type="button"
              disabled={superOverBusy}
              onClick={
                startSuperOverRound
              }
            >
              ⚡ Start Super Over
            </button>
          </div>
        )}

        {superOverState.exists && (
          <>
            <div className="super-over-score-grid">
              <article>
                <span>
                  Super Over
                </span>
                <strong>
                  #{superOverState.round}
                </strong>
              </article>

              <article>
                <span>
                  {
                    getSuperOverTeam(
                      superOverState,
                      superOverState.firstBattingTeamId
                    )?.name ||
                    "Team 1"
                  }
                </span>
                <strong>
                  {superOverState.first?.runs || 0}/
                  {superOverState.first?.wickets || 0}
                </strong>
                <small>
                  {superOverState.first?.overs || "0.0"} ov
                </small>
              </article>

              <article>
                <span>
                  {
                    getSuperOverTeam(
                      superOverState,
                      superOverState.secondBattingTeamId
                    )?.name ||
                    "Team 2"
                  }
                </span>
                <strong>
                  {superOverState.second?.runs || 0}/
                  {superOverState.second?.wickets || 0}
                </strong>
                <small>
                  {superOverState.second?.overs || "0.0"} ov
                </small>
              </article>

              {superOverState.target && (
                <article>
                  <span>
                    Target
                  </span>
                  <strong>
                    {superOverState.target}
                  </strong>
                </article>
              )}
            </div>

            {superOverState.active &&
              superOverState.currentSuperInnings > 0 &&
              (() => {
                const superInnings =
                  Number(
                    superOverState.currentSuperInnings
                  );

                const innings =
                  superInnings === 1
                    ? superOverState.first
                    : superOverState.second;

                const battingTeamId =
                  superInnings === 1
                    ? superOverState.firstBattingTeamId
                    : superOverState.secondBattingTeamId;

                const bowlingTeamId =
                  superInnings === 1
                    ? superOverState.secondBattingTeamId
                    : superOverState.firstBattingTeamId;

                const battingTeam =
                  getSuperOverTeam(
                    superOverState,
                    battingTeamId
                  );

                const bowlingTeam =
                  getSuperOverTeam(
                    superOverState,
                    bowlingTeamId
                  );

                if (!innings?.setup) {
                  return (
                    <div className="super-over-setup">
                      <div className="super-over-section-title">
                        <span>
                          Innings {superInnings}
                        </span>

                        <strong>
                          {battingTeam?.name || "Batting team"} batting
                        </strong>
                      </div>

                      <div className="super-over-setup-grid">
                        <label>
                          <span>
                            Striker
                          </span>

                          <select
                            value={
                              superOverSetup.batter1Id
                            }
                            onChange={(event) =>
                              setSuperOverSetup((prev) => ({
                                ...prev,
                                batter1Id:
                                  event.target.value,
                              }))
                            }
                          >
                            <option value="">
                              Select striker
                            </option>

                            {(battingTeam?.players || []).map(
                              (player) => (
                                <option
                                  key={player.id}
                                  value={player.id}
                                >
                                  {player.name}
                                </option>
                              )
                            )}
                          </select>
                        </label>

                        <label>
                          <span>
                            Non-striker
                          </span>

                          <select
                            value={
                              superOverSetup.batter2Id
                            }
                            onChange={(event) =>
                              setSuperOverSetup((prev) => ({
                                ...prev,
                                batter2Id:
                                  event.target.value,
                              }))
                            }
                          >
                            <option value="">
                              Select non-striker
                            </option>

                            {(battingTeam?.players || []).map(
                              (player) => (
                                <option
                                  key={player.id}
                                  value={player.id}
                                >
                                  {player.name}
                                </option>
                              )
                            )}
                          </select>
                        </label>

                        <label>
                          <span>
                            Third batter
                          </span>

                          <select
                            value={
                              superOverSetup.batter3Id
                            }
                            onChange={(event) =>
                              setSuperOverSetup((prev) => ({
                                ...prev,
                                batter3Id:
                                  event.target.value,
                              }))
                            }
                          >
                            <option value="">
                              Optional
                            </option>

                            {(battingTeam?.players || []).map(
                              (player) => (
                                <option
                                  key={player.id}
                                  value={player.id}
                                >
                                  {player.name}
                                </option>
                              )
                            )}
                          </select>
                        </label>

                        <label>
                          <span>
                            Bowler
                          </span>

                          <select
                            value={
                              superOverSetup.bowlerId
                            }
                            onChange={(event) =>
                              setSuperOverSetup((prev) => ({
                                ...prev,
                                bowlerId:
                                  event.target.value,
                              }))
                            }
                          >
                            <option value="">
                              Select bowler
                            </option>

                            {(bowlingTeam?.players || []).map(
                              (player) => (
                                <option
                                  key={player.id}
                                  value={player.id}
                                >
                                  {player.name}
                                </option>
                              )
                            )}
                          </select>
                        </label>
                      </div>

                      <button
                        type="button"
                        className="super-over-primary"
                        disabled={superOverBusy}
                        onClick={
                          setupSuperOverInnings
                        }
                      >
                        Continue to scoring
                      </button>
                    </div>
                  );
                }

                return (
                  <div className="super-over-live">
                    <div className="super-over-live-head">
                      <div>
                        <small>
                          BATTING
                        </small>

                        <strong>
                          {battingTeam?.name}
                        </strong>
                      </div>

                      <div>
                        <small>
                          SCORE
                        </small>

                        <strong>
                          {innings.runs}/{innings.wickets}
                          {" · "}
                          {innings.overs}
                        </strong>
                      </div>
                    </div>

                    <div className="super-over-players">
                      <article>
                        <span>
                          ⚡ Striker
                        </span>
                        <strong>
                          {superOverPlayerName(
                            superOverState,
                            innings.strikerId
                          )}
                        </strong>
                      </article>

                      <article>
                        <span>
                          Non-striker
                        </span>
                        <strong>
                          {superOverPlayerName(
                            superOverState,
                            innings.nonStrikerId
                          )}
                        </strong>
                      </article>

                      <article>
                        <span>
                          🎯 Bowler
                        </span>
                        <strong>
                          {superOverPlayerName(
                            superOverState,
                            innings.bowlerId
                          )}
                        </strong>
                      </article>
                    </div>

                    {superInnings === 2 &&
                      superOverState.target && (
                        <div className="super-over-chase">
                          Need{" "}
                          {Math.max(
                            Number(superOverState.target) -
                            Number(innings.runs || 0),
                            0
                          )}
                          {" run(s) from "}
                          {Math.max(
                            6 -
                            Number(innings.legalBalls || 0),
                            0
                          )}
                          {" legal ball(s)"}
                        </div>
                      )}

                    <div className="super-over-run-buttons">
                      {[0, 1, 2, 3, 4, 6].map(
                        (runs) => (
                          <button
                            key={`so-run-${runs}`}
                            type="button"
                            disabled={superOverBusy}
                            onClick={() =>
                              scoreSuperOverBall({
                                runsOffBat: runs,
                              })
                            }
                          >
                            {runs}
                          </button>
                        )
                      )}

                      <button
                        type="button"
                        disabled={superOverBusy}
                        onClick={() =>
                          scoreSuperOverBall({
                            extras: 1,
                            extraType: "WIDE",
                          })
                        }
                      >
                        Wd
                      </button>

                      <button
                        type="button"
                        disabled={superOverBusy}
                        onClick={() =>
                          scoreSuperOverBall({
                            extras: 1,
                            extraType: "NOBALL",
                          })
                        }
                      >
                        Nb
                      </button>

                      <button
                        type="button"
                        className="wicket"
                        disabled={superOverBusy}
                        onClick={() =>
                          scoreSuperOverBall({
                            isWicket: true,
                          })
                        }
                      >
                        Wkt
                      </button>
                    </div>

                    <div className="super-over-secondary-actions">
                      <button
                        type="button"
                        disabled={
                          superOverBusy ||
                          !innings.balls?.length
                        }
                        onClick={
                          undoSuperOverBall
                        }
                      >
                        ↶ Undo
                      </button>
                    </div>
                  </div>
                );
              })()}

            {superOverState.tied && (
              <div className="super-over-tied-card">
                <span>
                  Super Over {superOverState.round} tied
                </span>

                <strong>
                  Another Super Over is required
                </strong>

                <p>
                  The side that batted second in the previous Super Over
                  will bat first in the next one.
                </p>

                <button
                  type="button"
                  disabled={superOverBusy}
                  onClick={
                    startSuperOverRound
                  }
                >
                  ⚡ Start Super Over{" "}
                  {Number(superOverState.round) + 1}
                </button>
              </div>
            )}

            {superOverState.completed && (
              <div className="super-over-winner-card">
                <span>
                  🏆 RESULT
                </span>

                <strong>
                  {superOverState.resultText ||
                  "Super Over completed"}
                </strong>

                <button
                  type="button"
                  onClick={async () => {
                    setShowSuperOverModal(false);
                    await loadMatches();
                  }}
                >
                  Done
                </button>
              </div>
            )}

            {(superOverState.history || []).length > 0 && (
              <details className="super-over-history">
                <summary>
                  Super Over history
                </summary>

                <div>
                  {(superOverState.history || []).map(
                    (round) => {
                      const firstName =
                        getSuperOverTeam(
                          superOverState,
                          round.firstBattingTeamId
                        )?.name ||
                        "Team";

                      const secondName =
                        getSuperOverTeam(
                          superOverState,
                          round.secondBattingTeamId
                        )?.name ||
                        "Team";

                      return (
                        <article
                          key={`so-history-${round.round}`}
                        >
                          <strong>
                            Round {round.round}
                          </strong>

                          <span>
                            {firstName}:{" "}
                            {round.first.runs}/
                            {round.first.wickets} (
                            {round.first.overs})
                          </span>

                          <span>
                            {secondName}:{" "}
                            {round.second.runs}/
                            {round.second.wickets} (
                            {round.second.overs})
                          </span>
                        </article>
                      );
                    }
                  )}
                </div>
              </details>
            )}
          </>
        )}
      </section>
    </div>,
    document.body
  )}

{showDlsModal && scoreboard && (
  <div
    className="dls-modal-backdrop"
    role="presentation"
    onMouseDown={(event) => {
      if (
        event.target ===
        event.currentTarget
      ) {
        setShowDlsModal(false);
      }
    }}
  >
    <section
      className="dls-modal"
      role="dialog"
      aria-modal="true"
      aria-label="Rain and DLS"
    >
      <div className="dls-modal-head">
        <div>
          <span className="dls-kicker">
            🌧️ Rain / DLS
          </span>
          <h3>
            Revised Match Target
          </h3>
        </div>

        <button
          type="button"
          className="dls-close"
          onClick={() =>
            setShowDlsModal(false)
          }
          aria-label="Close DLS"
        >
          ×
        </button>
      </div>

      <div className="dls-current-grid">
        <div>
          <span>Innings</span>
          <strong>
            {scoreboard.currentInnings || 1}
          </strong>
        </div>

        <div>
          <span>Score</span>
          <strong>
            {(
              scoreboard.innings?.[
                Number(
                  scoreboard.currentInnings ||
                  1
                ) - 1
              ]?.runs || 0
            )}
            /
            {(
              scoreboard.innings?.[
                Number(
                  scoreboard.currentInnings ||
                  1
                ) - 1
              ]?.wickets || 0
            )}
          </strong>
        </div>

        <div>
          <span>Current allocation</span>
          <strong>
            {Number(
              scoreboard.currentInnings ||
              1
            ) === 1
              ? dlsState?.innings1Allocation
              : dlsState?.innings2Allocation}
            {" "}overs
          </strong>
        </div>

        {scoreboard.summary?.dls?.active && (
          <div>
            <span>Current target</span>
            <strong>
              {scoreboard.summary.dls.target || "—"}
            </strong>
          </div>
        )}
      </div>

      <div className="dls-mode-tabs">
        <button
          type="button"
          className={
            dlsForm.mode === "STANDARD"
              ? "active"
              : ""
          }
          onClick={() => {
            setDlsError("");
            setDlsForm((prev) => ({
              ...prev,
              mode: "STANDARD",
            }));
          }}
        >
          Cric4All Standard
        </button>

        <button
          type="button"
          className={
            dlsForm.mode ===
            "OFFICIAL_OVERRIDE"
              ? "active"
              : ""
          }
          onClick={() => {
            setDlsError("");
            setDlsForm((prev) => ({
              ...prev,
              mode:
                "OFFICIAL_OVERRIDE",

              officialAction:
                "",
            }));
          }}
        >
          Official DLS
        </button>
      </div>

      {dlsForm.mode === "STANDARD" ? (
        <div className="dls-form">
          <label>
            <span>
              Revised total overs
            </span>
            <input
              type="number"
              min="1"
              max={
                Math.max(
                  1,
                  Number(
                    Number(
                      scoreboard.currentInnings ||
                      1
                    ) === 1
                      ? dlsState?.innings1Allocation
                      : dlsState?.innings2Allocation
                  ) - 1
                )
              }
              step="1"
              placeholder={
                `Less than ${
                  Number(
                    scoreboard.currentInnings ||
                    1
                  ) === 1
                    ? dlsState?.innings1Allocation
                    : dlsState?.innings2Allocation
                }`
              }
              value={
                dlsForm.revisedOvers
              }
              onChange={(event) => {
                setDlsError("");
                setDlsForm((prev) => ({
                  ...prev,
                  revisedOvers:
                    event.target.value,
                }));
              }}
            />
          </label>

          <p className="dls-help">
            Uses the published D/L Standard Edition resource table. Cric4All
            interpolates between adjacent table rows so Standard mode can be
            applied at any legal-delivery boundary, including 3.1, 3.2, 3.3,
            3.4 or 3.5 overs. This remains Cric4All Standard, not Official DLS.
          </p>
        </div>
      ) : (
        <div className="dls-form dls-official-grid">
          <div
            className="dls-full"
            style={{
              padding:
                "10px 12px",
              borderRadius:
                10,
              border:
                "1px solid rgba(56, 189, 248, 0.28)",
              background:
                "rgba(14, 116, 144, 0.10)",
              lineHeight:
                1.35,
            }}
          >
            <strong
              style={{
                display:
                  "block",
                marginBottom:
                  4,
              }}
            >
              Official DLS figures come from your competition's authorized DLS calculator
            </strong>

            <span
              style={{
                display:
                  "block",
                fontSize:
                  12,
                opacity:
                  0.82,
              }}
            >
              Cric4All records and applies those figures. It does not calculate Official DLS or substitute the Cric4All tactical Par.
            </span>
          </div>

          <div
            className="dls-full"
            style={{
              display:
                "grid",
              gridTemplateColumns:
                "repeat(auto-fit, minmax(180px, 1fr))",
              gap:
                10,
              width:
                "100%",
            }}
          >
            <button
              type="button"
              aria-pressed={
                dlsForm.officialAction ===
                "RESUME"
              }
              onClick={() => {
                setDlsError("");

                setDlsForm(
                  (prev) => ({
                    ...prev,
                    officialAction:
                      "RESUME",
                    par:
                      "",
                  })
                );
              }}
              style={{
                width:
                  "100%",
                minHeight:
                  52,
                padding:
                  "10px 14px",
                borderRadius:
                  12,
                border:
                  dlsForm.officialAction ===
                  "RESUME"
                    ? "2px solid rgba(56, 189, 248, 0.95)"
                    : "1px solid rgba(96, 165, 250, 0.55)",
                background:
                  dlsForm.officialAction ===
                  "RESUME"
                    ? "linear-gradient(135deg, rgba(37, 99, 235, 0.95), rgba(14, 165, 233, 0.95))"
                    : "linear-gradient(135deg, rgba(30, 64, 175, 0.55), rgba(14, 116, 144, 0.55))",
                color:
                  "#ffffff",
                fontWeight:
                  900,
                fontSize:
                  14,
                lineHeight:
                  1.15,
                cursor:
                  "pointer",
                boxShadow:
                  dlsForm.officialAction ===
                  "RESUME"
                    ? "0 8px 20px rgba(14, 165, 233, 0.24)"
                    : "none",
                whiteSpace:
                  "normal",
                overflowWrap:
                  "anywhere",
              }}
            >
              ▶ Revise & Resume
            </button>

            <button
              type="button"
              aria-pressed={
                dlsForm.officialAction ===
                "END"
              }
              disabled={
                Number(
                  scoreboard.currentInnings ||
                  1
                ) !== 2
              }
              onClick={() => {
                setDlsError("");

                setDlsForm(
                  (prev) => ({
                    ...prev,
                    officialAction:
                      "END",
                  })
                );
              }}
              style={{
                width:
                  "100%",
                minHeight:
                  52,
                padding:
                  "10px 14px",
                borderRadius:
                  12,
                border:
                  dlsForm.officialAction ===
                  "END"
                    ? "2px solid rgba(248, 113, 113, 0.95)"
                    : "1px solid rgba(248, 113, 113, 0.55)",
                background:
                  dlsForm.officialAction ===
                  "END"
                    ? "linear-gradient(135deg, rgba(185, 28, 28, 0.95), rgba(239, 68, 68, 0.95))"
                    : "linear-gradient(135deg, rgba(127, 29, 29, 0.62), rgba(153, 27, 27, 0.50))",
                color:
                  "#ffffff",
                fontWeight:
                  900,
                fontSize:
                  14,
                lineHeight:
                  1.15,
                cursor:
                  Number(
                    scoreboard.currentInnings ||
                    1
                  ) === 2
                    ? "pointer"
                    : "not-allowed",
                opacity:
                  Number(
                    scoreboard.currentInnings ||
                    1
                  ) === 2
                    ? 1
                    : 0.48,
                boxShadow:
                  dlsForm.officialAction ===
                  "END"
                    ? "0 8px 20px rgba(239, 68, 68, 0.20)"
                    : "none",
                whiteSpace:
                  "normal",
                overflowWrap:
                  "anywhere",
              }}
            >
              🏁 End Match Now
            </button>
          </div>

          {!dlsForm.officialAction && (
            <div
              className="dls-full"
              style={{
                padding:
                  "10px 12px",
                borderRadius:
                  10,
                background:
                  "rgba(15, 23, 42, 0.58)",
                border:
                  "1px solid rgba(148, 163, 184, 0.18)",
                fontSize:
                  12,
                lineHeight:
                  1.4,
              }}
            >
              <strong
                style={{
                  display:
                    "block",
                  marginBottom:
                    4,
                }}
              >
                What happens next?
              </strong>

              <span>
                Choose <b>Revise & Resume</b> if play will continue after the interruption, or <b>End Match Now</b> if play cannot resume.
              </span>
            </div>
          )}

          {dlsForm.officialAction ===
          "RESUME" ? (
            <>
              <div
                className="dls-full"
                style={{
                  padding:
                    "10px 12px",
                  borderRadius:
                    10,
                  background:
                    "rgba(15, 23, 42, 0.55)",
                  border:
                    "1px solid rgba(148, 163, 184, 0.18)",
                  fontSize:
                    12,
                  lineHeight:
                    1.45,
                }}
              >
                <strong
                  style={{
                    display:
                      "block",
                    marginBottom:
                      5,
                  }}
                >
                  Where do I get these numbers?
                </strong>

                <span
                  style={{
                    display:
                      "block",
                    marginBottom:
                      5,
                  }}
                >
                  <b>Revised innings overs</b> comes from the match officials after deciding how many total overs the chasing side can now receive.
                </span>

                <span
                  style={{
                    display:
                      "block",
                    marginBottom:
                      5,
                  }}
                >
                  <b>Revised target to win</b> comes from the official/authorized DLS calculator after it uses the interruption details, wickets and resources remaining.
                </span>

                <span
                  style={{
                    display:
                      "block",
                    opacity:
                      0.84,
                  }}
                >
                  Cric4All does not calculate Official DLS. If your league does not have an authorized DLS source, use Cric4All Standard instead of guessing these values.
                </span>
              </div>

              <label>
                <span>
                  Revised innings overs
                </span>

                <input
                  type="number"
                  min="1"
                  step="0.1"
                  inputMode="decimal"
                  placeholder="e.g. 8"
                  value={
                    dlsForm.revisedOvers
                  }
                  onChange={(event) => {
                    setDlsError("");

                    setDlsForm(
                      (prev) => ({
                        ...prev,

                        revisedOvers:
                          event.target.value,
                      })
                    );
                  }}
                />
              </label>

              <label>
                <span>
                  Revised target to win
                </span>

                <input
                  type="number"
                  min="1"
                  step="1"
                  inputMode="numeric"
                  placeholder="Official target"
                  value={
                    dlsForm.target
                  }
                  onChange={(event) => {
                    setDlsError("");

                    setDlsForm(
                      (prev) => ({
                        ...prev,

                        target:
                          event.target.value,

                        /*
                         * Do NOT manufacture Official Par as target - 1.
                         * The official par at a suspension point is a separate
                         * DLS output and may be very different.
                         */
                        par:
                          "",
                      })
                    );
                  }}
                />
              </label>
            </>
          ) : (
            <>
              <div
                className="dls-full"
                style={{
                  fontSize:
                    12,
                  lineHeight:
                    1.4,
                  opacity:
                    0.82,
                }}
              >
                Use this only when play cannot resume. Enter the official par for the exact score/overs/wickets at suspension. Cric4All will preview the position before final confirmation.
              </div>

              <label>
                <span>
                  Official target
                </span>

                <input
                  type="number"
                  min="1"
                  step="1"
                  inputMode="numeric"
                  placeholder="Target supplied by DLS"
                  value={
                    dlsForm.target
                  }
                  onChange={(event) => {
                    setDlsError("");

                    setDlsForm(
                      (prev) => ({
                        ...prev,

                        target:
                          event.target.value,
                      })
                    );
                  }}
                />

                <small>
                  Keep the current revised target if one was already applied.
                </small>
              </label>

              <label>
                <span>
                  Official par at suspension
                </span>

                <input
                  type="number"
                  min="0"
                  step="1"
                  inputMode="numeric"
                  placeholder="Par from official DLS"
                  value={
                    dlsForm.par
                  }
                  onChange={(event) => {
                    setDlsError("");

                    setDlsForm(
                      (prev) => ({
                        ...prev,

                        par:
                          event.target.value,
                      })
                    );
                  }}
                />

                <small>
                  Do not use Cric4All Chase Par here.
                </small>
              </label>

              {Number.isInteger(
                Number(
                  dlsForm.par
                )
              ) &&
                Number(
                  dlsForm.par
                ) >= 0 && (
                  <div
                    className="dls-full"
                    style={{
                      padding:
                        "10px 12px",
                      borderRadius:
                        10,
                      background:
                        "rgba(15, 23, 42, 0.60)",
                      border:
                        "1px solid rgba(148, 163, 184, 0.20)",
                      display:
                        "grid",
                      gap:
                        4,
                      fontSize:
                        12,
                    }}
                  >
                    <span>
                      Current score:{" "}
                      <b>
                        {Number(
                          scoreboard
                            ?.innings
                            ?.[1]
                            ?.runs ||
                          0
                        )}
                      </b>
                    </span>

                    <span>
                      Official par:{" "}
                      <b>
                        {Number(
                          dlsForm.par
                        )}
                      </b>
                    </span>

                    <strong>
                      {Number(
                        scoreboard
                          ?.innings
                          ?.[1]
                          ?.runs ||
                        0
                      ) >
                      Number(
                        dlsForm.par
                      )
                        ? `▲ Chasing side is ${
                            Number(
                              scoreboard
                                ?.innings
                                ?.[1]
                                ?.runs ||
                              0
                            ) -
                            Number(
                              dlsForm.par
                            )
                          } run(s) above par`
                        : Number(
                            scoreboard
                              ?.innings
                              ?.[1]
                              ?.runs ||
                            0
                          ) <
                          Number(
                            dlsForm.par
                          )
                          ? `▼ Chasing side is ${
                              Number(
                                dlsForm.par
                              ) -
                              Number(
                                scoreboard
                                  ?.innings
                                  ?.[1]
                                  ?.runs ||
                                0
                              )
                            } run(s) below par`
                          : "● Score is level with official par"}
                    </strong>
                  </div>
                )}
            </>
          )}

          <label className="dls-full">
            <span>
              Source / umpire note
            </span>

            <input
              type="text"
              value={
                dlsForm.note
              }
              onChange={(event) =>
                setDlsForm((prev) => ({
                  ...prev,

                  note:
                    event.target.value,
                }))
              }
              placeholder="Optional: DLS calculator / umpire / competition source"
            />
          </label>
        </div>
      )}

      {dlsError && (
        <div
          className="dls-inline-error"
          role="alert"
        >
          <strong>
            Unable to continue
          </strong>

          <span>
            {dlsError}
          </span>
        </div>
      )}

      {dlsState?.latest && (
        <div className="dls-result-card">
          <span>
            Active adjustment
          </span>

          <strong>
            {dlsState.latest.mode ===
            "OFFICIAL_OVERRIDE"
              ? "Official DLS"
              : "D/L Standard"}
          </strong>

          {dlsState.latest.target ? (
            <b>
              Target{" "}
              {dlsState.latest.target}
              {dlsState.latest.par != null &&
              dlsState.latest.par !== ""
                ? ` · Par ${dlsState.latest.par}`
                : ""}
            </b>
          ) : (
            <b>
              Resource adjustment saved
            </b>
          )}
        </div>
      )}

      <div className="dls-actions">
        <button
          type="button"
          className="secondary"
          onClick={() =>
            setShowDlsModal(false)
          }
          disabled={dlsBusy}
        >
          Cancel
        </button>

        {dlsForm.mode ===
        "STANDARD" ? (
          <>
            <button
              type="button"
              className="primary"
              onClick={
                handleApplyDls
              }
              disabled={
                dlsBusy
              }
            >
              {dlsBusy
                ? "Applying…"
                : "Apply Reduced Overs"}
            </button>

            {Number(
              scoreboard.currentInnings ||
              1
            ) === 2 && (
              <button
                type="button"
                className="danger"
                onClick={
                  handleEndByDls
                }
                disabled={
                  dlsBusy
                }
              >
                End by DLS
              </button>
            )}
          </>
        ) : dlsForm.officialAction ===
          "RESUME" ? (
          <button
            type="button"
            className="primary"
            onClick={
              handleApplyDls
            }
            disabled={
              dlsBusy
            }
          >
            {dlsBusy
              ? "Applying…"
              : "Apply Revision & Resume"}
          </button>
        ) : dlsForm.officialAction ===
          "END" ? (
          <button
            type="button"
            className="danger"
            onClick={
              handleEndOfficialDls
            }
            disabled={
              dlsBusy ||
              Number(
                scoreboard.currentInnings ||
                1
              ) !== 2
            }
          >
            {dlsBusy
              ? "Ending…"
              : "Confirm & End by Official DLS"}
          </button>
        ) : (
          <span
            style={{
              alignSelf:
                "center",
              fontSize:
                12,
              opacity:
                0.72,
            }}
          >
            Choose an Official DLS action above.
          </span>
        )}
      </div>
    </section>
  </div>
)}

{activeTab === "matches" && (
  <div className="matches-page">
    {(message || error) && (
      <div className="match-alert">
        {message && <p className="success">{message}</p>}
        {error && <p className="error">{error}</p>}
      </div>
    )}
    {!activeLeagueId && (
      <Card title="📋 Matches">
        <div className="empty-state">
          Select a league to view or create matches.
        </div>
      </Card>
    )}
<Card title = "Matches">
<div className="matches-command-center">
  <div className="match-league-picker">
    <div>
      <span className="command-kicker">🏆 Active League</span>
      <strong>
        {leagues.find((l) => Number(l.id) === Number(activeLeagueId))?.name ||
          "Select a league"}
      </strong>
      </div>
      <div className="combo-visual-cue" aria-hidden="true">
  <span className="combo-ripple" />
</div>
    <select
      value={activeLeagueId || ""}
      onChange={(e) => {
        const value = e.target.value;
        setActiveLeagueId(value ? Number(value) : null);
        setSelectedMatchId("");
      }}
    >
      <option value="">Select League</option>
      {leagues.map((league) => (
        <option key={league.id} value={league.id}>
          {league.name}
        </option>
      ))}
    </select>

    <span className="picker-arrow">⌄</span>
  </div>

  <div className="match-filter-action">
    <ContextLens />
  </div>
</div>

<div
  className={`matches-subtabs pro-match-tabs ${mobileKitStyles.matchTabs}`}
>
  {[
    ["CREATE MATCH", "➕", "Create"],
    ["ACTIVE", "🟢", "Active"],
    ["SCHEDULED", "📅", "Scheduled"],
    ["KIT", "🧳", "Kit"],
    ["COMPLETED", "✅", "Completed"],
  ].map(([key, icon, label]) => (
    <button
      key={key}
      type="button"
      className={matchesSubTab === key ? "active" : ""}
      onClick={() => {
        if (key === "COMPLETED") {
          setCompletedMatchRenderLimit(
            COMPLETED_MATCH_RENDER_PAGE_SIZE
          );
        }

        setMatchesSubTab(key);
      }}
    >
      <span className="tab-icon">{icon}</span>
      <span className="tab-label">{label}</span>
    </button>
  ))}
</div> 
    {activeLeagueId && matchesSubTab === "CREATE MATCH" && (
<Card title="➕ Create Match">
  <form className="form create-match-form pro-create-match-form" onSubmit={handleCreateMatch}>
    <div className="create-match-topbar">
      <div>
        <span>Active League</span>
        <strong>
          {leagues.find((l) => Number(l.id) === Number(activeLeagueId))?.name ||
            "No league selected"}
        </strong>
      </div>

      <div>
        <span>Series</span>
        <small>Optional for tournaments, cups, seasons, or years.</small>
      </div>
    </div>

    <section className="create-match-section">
      <h3>🏆 Match Info</h3>

      <label>
        <span>Series / Season</span>
        <select
          value={matchForm.seriesId || ""}
          onChange={(e) =>
            setMatchForm((prev) => ({
              ...prev,
              seriesId: e.target.value,
            }))
          }
        >
          <option value="">No Series (Optional)</option>
          {seriesList.map((series) => (
            <option key={series.id} value={series.id}>
              {series.name} • {series.year}
            </option>
          ))}
        </select>
      </label>

      <div className="form-two-col">
        <label>
          <span>Team A</span>
          <select
            value={matchForm.teamAId || ""}
            onChange={(e) => {
              const teamId = e.target.value;
              const team = teamsForMatch.find((t) => Number(t.id) === Number(teamId));
              setMatchForm((prev) => ({
                ...prev,
                teamAId: teamId,
                teamACaptainId: team?.defaultCaptainId ? String(team.defaultCaptainId) : "",
                teamAViceCaptainId: team?.defaultViceCaptainId ? String(team.defaultViceCaptainId) : "",
                teamAWicketKeeperId: team?.defaultWicketKeeperId ? String(team.defaultWicketKeeperId) : "",
              }));
            }}
            required
          >
            <option value="">Select Team A</option>
            {teamsForMatch.map((team) => (
              <option key={team.id} value={team.id}>
                {team.name}
              </option>
            ))}
          </select>
        </label>

        <label>
          <span>Team B</span>
          <select
            value={matchForm.teamBId || ""}
            onChange={(e) => {
              const teamId = e.target.value;
              const team = teamsForMatch.find((t) => Number(t.id) === Number(teamId));
              setMatchForm((prev) => ({
                ...prev,
                teamBId: teamId,
                teamBCaptainId: team?.defaultCaptainId ? String(team.defaultCaptainId) : "",
                teamBViceCaptainId: team?.defaultViceCaptainId ? String(team.defaultViceCaptainId) : "",
                teamBWicketKeeperId: team?.defaultWicketKeeperId ? String(team.defaultWicketKeeperId) : "",
              }));
            }}
            required
          >
            <option value="">Select Team B</option>
            {teamsForMatch.map((team) => (
              <option key={team.id} value={team.id}>
                {team.name}
              </option>
            ))}
          </select>
        </label>
      </div>

      <div className="form-two-col">
        <label>
          <span>Batting First</span>
          <select
            value={matchForm.battingFirstTeamId || ""}
            onChange={(e) =>
              setMatchForm((prev) => ({
                ...prev,
                battingFirstTeamId: e.target.value,
              }))
            }
          >
            <option value="">Decide when match starts</option>
            {teams
              .filter((t) =>
                [matchForm.teamAId, matchForm.teamBId].includes(String(t.id))
              )
              .map((team) => (
                <option key={team.id} value={team.id}>
                  {team.name}
                </option>
              ))}
          </select>
        </label>

        <label>
          <span>Scheduled Start</span>
          <input
            type="datetime-local"
            value={matchForm.scheduledAt || ""}
            onChange={(e) =>
              setMatchForm((prev) => ({
                ...prev,
                scheduledAt: e.target.value,
              }))
            }
          />
        </label>
      </div>

      <div className="form-two-col">
        <label>
          <span>📍 Venue / Ground</span>
          <input
            type="text"
            maxLength={160}
            placeholder="e.g. Woodley Cricket Fields"
            value={matchForm.venueName || ""}
            onChange={(e) =>
              setMatchForm((prev) => ({
                ...prev,
                venueName: e.target.value,
              }))
            }
          />
          <small>
            Optional, but recommended for spectators and public match discovery.
          </small>
        </label>

        <label>
          <span>🗺️ Venue Address</span>
          <input
            type="text"
            maxLength={300}
            placeholder="Street, city, state/province, postal code, country"
            value={matchForm.venueAddress || ""}
            onChange={(e) =>
              setMatchForm((prev) => ({
                ...prev,
                venueAddress: e.target.value,
              }))
            }
          />
          <small>
            Use a real physical address. Cric4All never invents location data.
          </small>
        </label>
      </div>
    </section>

    <section className="create-match-section">
      <h3>👥 Captains, Vice-Captains & Wicketkeepers</h3>

      <div className="form-two-col">
        <label>
          <span>Team A Captain</span>
          <select
            value={matchForm.teamACaptainId || ""}
            onChange={(e) =>
              setMatchForm((prev) => ({
                ...prev,
                teamACaptainId: e.target.value,
              }))
            }
          >
            <option value="">Optional</option>
            {teams
              .find((t) => Number(t.id) === Number(matchForm.teamAId))
              ?.players?.map((player) => (
                <option key={player.id} value={player.id}>
                  {player.name}
                </option>
              ))}
          </select>
        </label>

        <label>
          <span>Team B Captain</span>
          <select
            value={matchForm.teamBCaptainId || ""}
            onChange={(e) =>
              setMatchForm((prev) => ({
                ...prev,
                teamBCaptainId: e.target.value,
              }))
            }
          >
            <option value="">Optional</option>
            {teams
              .find((t) => Number(t.id) === Number(matchForm.teamBId))
              ?.players?.map((player) => (
                <option key={player.id} value={player.id}>
                  {player.name}
                </option>
              ))}
          </select>
        </label>

        <label>
          <span>Team A Vice-Captain</span>
          <select
            value={matchForm.teamAViceCaptainId || ""}
            onChange={(e) => setMatchForm((prev) => ({ ...prev, teamAViceCaptainId: e.target.value }))}
          >
            <option value="">Optional</option>
            {teams.find((t) => Number(t.id) === Number(matchForm.teamAId))?.players?.map((player) => (
              <option key={player.id} value={player.id} disabled={String(player.id) === String(matchForm.teamACaptainId)}>
                {player.name}
              </option>
            ))}
          </select>
        </label>

        <label>
          <span>Team B Vice-Captain</span>
          <select
            value={matchForm.teamBViceCaptainId || ""}
            onChange={(e) => setMatchForm((prev) => ({ ...prev, teamBViceCaptainId: e.target.value }))}
          >
            <option value="">Optional</option>
            {teams.find((t) => Number(t.id) === Number(matchForm.teamBId))?.players?.map((player) => (
              <option key={player.id} value={player.id} disabled={String(player.id) === String(matchForm.teamBCaptainId)}>
                {player.name}
              </option>
            ))}
          </select>
        </label>

        <label>
          <span>Team A Wicketkeeper</span>
          <select
            value={matchForm.teamAWicketKeeperId || ""}
            onChange={(e) =>
              setMatchForm((prev) => ({
                ...prev,
                teamAWicketKeeperId: e.target.value,
              }))
            }
          >
            <option value="">Optional</option>
            {teams
              .find((t) => Number(t.id) === Number(matchForm.teamAId))
              ?.players?.map((player) => (
                <option key={player.id} value={player.id}>
                  {player.name}
                </option>
              ))}
          </select>
        </label>

        <label>
          <span>Team B Wicketkeeper</span>
          <select
            value={matchForm.teamBWicketKeeperId || ""}
            onChange={(e) =>
              setMatchForm((prev) => ({
                ...prev,
                teamBWicketKeeperId: e.target.value,
              }))
            }
          >
            <option value="">Optional</option>
            {teams
              .find((t) => Number(t.id) === Number(matchForm.teamBId))
              ?.players?.map((player) => (
                <option key={player.id} value={player.id}>
                  {player.name}
                </option>
              ))}
          </select>
        </label>
      </div>
    </section>

    <section className="create-match-section">
      <h3>⚙️ Match Rules</h3>

      <div className="form-two-col">
        <label>
          <span>Overs / Innings</span>
          <input
            type="number"
            min="1"
            value={matchForm.oversPerInnings}
            onChange={(e) =>
              setMatchForm((prev) => ({
                ...prev,
                oversPerInnings: e.target.value,
              }))
            }
            required
          />
        </label>

        <label>
          <span>Powerplay Overs</span>
          <input
            type="number"
            min="0"
            value={matchForm.powerplayOversInnings}
            onChange={(e) =>
              setMatchForm((prev) => ({
                ...prev,
                powerplayOversInnings: e.target.value,
              }))
            }
          />
        </label>

        <label>
          <span>Max Wickets</span>
          <input
            type="number"
            value={matchForm.maxWicketsPerInnings}
            onChange={(e) =>
              setMatchForm((prev) => ({
                ...prev,
                maxWicketsPerInnings: e.target.value,
              }))
            }
          />
          <small className="muted">Empty = unlimited</small>
        </label>

        <label>
          <span>Max/Bowler</span>
          <input
            type="number"
            min="1"
            value={matchForm.maxOversPerBowler}
            onChange={(e) =>
              setMatchForm((prev) => ({
                ...prev,
                maxOversPerBowler: e.target.value,
              }))
            }
          />
          <small className="muted">Example: 4 in T20</small>
        </label>
      </div>
    </section>

    {!canScoreCurrentLeague ? (
      <div className="permission-warning">
        👉 You do not have permission to create a match.
      </div>
    ) : (
      <button type="submit" className="btn create-match-btn pro-create-submit">
        ✅ Create Match
      </button>
    )}
  </form>
</Card>
    )}

{activeLeagueId && matchesSubTab === "ACTIVE" && (
  <Card title="🟢 Active Matches">
    {activeMatches.length === 0 ? (
      <div className="empty-state">
        No active matches found.
      </div>
    ) : (
      <>
        {/* =====================================================
            DESKTOP / LAPTOP VIEW
            Existing layout remains unchanged
        ====================================================== */}
        <div className="matches-desktop-only">
          <div className="pro-active-list">
            {filteredActiveMatches.map((match) => {
              const isSelected =
                String(selectedMatchId) === String(match.id);

              const shareCode =
                match?.shareCode ||
                match?.sharecode ||
                match?.publicShareCode;

              return (
                <article
                  key={`desktop-active-${match.id}`}
                  className={`pro-active-card ${
                    isSelected ? "selected" : ""
                  }`}
                >
                  <div className="pro-active-card-topbar">
                    <div className="active-status-row">
                      <span className="status-pill live-status-pill">
                        ● {match.status}
                      </span>

                      <button
                        type="button"
                        className="active-share-icon-btn"
                        title="Share spectator link"
                        aria-label={`Share ${match.teamAName} versus ${match.teamBName}`}
                        onClick={() =>
                          handleShareActiveMatch(match)
                        }
                        disabled={!shareCode}
                      >
                        📤
                      </button>
                    </div>
                  </div>

                  <button
                    type="button"
                    className="pro-active-main"
                    onClick={() => {
                      setSelectedMatchId(String(match.id));
                      handleMatchSelect(match.id);
                    }}
                  >
                    <div className="pro-active-header">
                      <div className="pro-active-main-info">
                        <h3>
                          {match.teamAName}
                          <b>vs</b>
                          {match.teamBName}
                        </h3>

                        <p>
                          🕒 {getMatchTimelineText(match)}
                        </p>
                      </div>

                      <div className="pro-live-score-box">
                        <span>Live Score</span>

                        <strong>
                          {match.scoreSummary ||
                            match.liveScore ||
                            "Open match to view"}
                        </strong>
                      </div>
                    </div>
                  </button>

                  <div className="pro-active-actions">
                    {canScoreCurrentLeague && (
                      <button
                        type="button"
                        className={`start-match-btn ${
                          isSelected ? "is-open" : ""
                        }`}
                        onClick={() => {
                          setSelectedMatchId(
                            String(match.id)
                          );
                          handleMatchSelect(match.id);
                        }}
                      >
                        {isSelected
                          ? "✅ Scoring Open"
                          : "🏏 Open Scoring"}
                      </button>
                    )}
                    {permissions?.canDeleteMatch && (
                      <button
                        type="button"
                        className="mini-action-btn danger-mini-btn"
                        title={`Delete ${match.teamAName} vs ${match.teamBName}`}
                        aria-label={`Delete ${match.teamAName} versus ${match.teamBName}`}
                        onClick={() =>
                          handleDeleteMatch(match.id)
                        }
                      >
                        🗑️
                      </button>
                    )}
                  </div>

                  <details className="active-match-facts-collapse">
                    <summary className="active-match-facts-summary">
                      <div className="active-match-facts-summary-left">
                        <span className="active-match-facts-icon">
                          ⚙️
                        </span>

                        <div>
                          <strong>
                            Match Setup & Team Roles
                          </strong>

                          <small>
                            Overs, wickets, powerplay,
                            captains and wicketkeepers
                          </small>
                        </div>
                      </div>

                      <div className="active-match-facts-summary-right">
                        <span className="active-match-facts-count">
                          9 details
                        </span>

                        <span className="active-match-facts-arrow">
                          ⌄
                        </span>
                      </div>
                    </summary>

                    <div className="active-match-facts-grid">
                      <div className="active-match-fact-item">
                        <span>🏏 Batting First</span>
                        <strong>
                          {match.battingFirstTeamName ||
                            "Not decided"}
                        </strong>
                      </div>

                      <div className="active-match-fact-item">
                        <span>🎯 Overs</span>
                        <strong>
                          {match.oversPerInnings}
                        </strong>
                      </div>

                      <div className="active-match-fact-item">
                        <span>⚾ Wickets</span>
                        <strong>
                          {match.maxWicketsPerInnings ??
                            "∞"}
                        </strong>
                      </div>

                      <div className="active-match-fact-item">
                        <span>⚡ Powerplay</span>
                        <strong>
                          {match.powerplayOversInnings ??
                            0}
                        </strong>
                      </div>

                      <div className="active-match-fact-item">
                        <span>🎳 Max / Bowler</span>
                        <strong>
                          {match.maxOversPerBowler ??
                            "∞"}
                        </strong>
                      </div>

                      <div className="active-match-fact-item role-item">
                        <span>
                          🧤 {match.teamAName} Wicketkeeper
                        </span>
                        <strong>
                          {match.teamAWicketKeeperName ||
                            "Not selected"}
                        </strong>
                      </div>

                      <div className="active-match-fact-item role-item">
                        <span>
                          🧤 {match.teamBName} Wicketkeeper
                        </span>
                        <strong>
                          {match.teamBWicketKeeperName ||
                            "Not selected"}
                        </strong>
                      </div>

                      <div className="active-match-fact-item role-item">
                        <span>
                          👑 {match.teamAName} Captain
                        </span>
                        <strong>
                          {match.teamACaptainName ||
                            "Not selected"}
                        </strong>
                      </div>

                      <div className="active-match-fact-item role-item">
                        <span>
                          👑 {match.teamBName} Captain
                        </span>
                        <strong>
                          {match.teamBCaptainName ||
                            "Not selected"}
                        </strong>
                      </div>
                    </div>
                  </details>
                </article>
              );
            })}
          </div>
        </div>

        {/* =====================================================
            MOBILE VIEW
            New compact and sleek design
        ====================================================== */}
        <div className="matches-mobile-only">
<div className="mobile-wow-match-list">
  {filteredActiveMatches.map((match) => {
    const isSelected =
      String(selectedMatchId) === String(match.id);

    const shareCode =
      match?.shareCode ||
      match?.sharecode ||
      match?.publicShareCode;

    const statusLabel = String(match.status || "ACTIVE")
      .replaceAll("_", " ")
      .trim();

    return (
      <article
        key={`mobile-active-${match.id}`}
        className={`mobile-wow-card mobile-wow-active ${
          isSelected ? "is-selected" : ""
        }`}
      >
        {/* Header */}
        <div className="mobile-wow-top">
          <span className="mobile-wow-status live">
            <i />
            {statusLabel}
          </span>

          <button
            type="button"
            className="mobile-wow-icon-btn"
            title="Share spectator link"
            aria-label={`Share ${match.teamAName} versus ${match.teamBName}`}
            onClick={() => handleShareActiveMatch(match)}
            disabled={!shareCode}
          >
            📤
          </button>
        </div>

        {/* Teams */}
        <div className="mobile-wow-teams">
          <strong>{match.teamAName}</strong>
          <span>VS</span>
          <strong>{match.teamBName}</strong>
        </div>

        <div className="mobile-wow-subtitle">
          🕒 {getMatchTimelineText(match)}
        </div>

        {/* Large live-score presentation */}
        <button
          type="button"
          className="mobile-wow-live-score"
          onClick={() => {
            setSelectedMatchId(String(match.id));
            handleMatchSelect(match.id);
          }}
        >
          <div>
            <span>
              <i />
              Live score
            </span>

            <strong>
              {match.scoreSummary ||
                match.liveScore ||
                "Tap to view live score"}
            </strong>
          </div>

          <b>›</b>
        </button>

        {/* Actions */}
        <div className="mobile-wow-actions">
          {canScoreCurrentLeague && (
            <button
              type="button"
              className={`mobile-wow-primary ${
                isSelected ? "is-open" : ""
              }`}
              onClick={() => {
                setSelectedMatchId(String(match.id));
                handleMatchSelect(match.id);
              }}
            >
              {isSelected
                ? "✅ Continue Scoring"
                : "🏏 Open Scoring"}
            </button>
          )}
          {permissions?.canDeleteMatch && (
            <button
              type="button"
              className="mobile-wow-delete"
              title="Delete match"
              aria-label={`Delete ${match.teamAName} versus ${match.teamBName}`}
              onClick={() => handleDeleteMatch(match.id)}
            >
              🗑️
            </button>
          )}
        </div>

        {/* One simple expandable area */}
        <details className="mobile-wow-details">
          <summary>
            <div>
              <span>⚙️</span>

              <strong>Match Setup & Team Roles</strong>
            </div>

            <i>⌄</i>
          </summary>

          <div className="mobile-wow-details-body">
            <div className="mobile-wow-rule-list">
              <div>
                <span>Batting first</span>
                <strong>
                  {match.battingFirstTeamName || "Not decided"}
                </strong>
              </div>

              <div>
                <span>Overs</span>
                <strong>{match.oversPerInnings}</strong>
              </div>

              <div>
                <span>Wickets</span>
                <strong>
                  {match.maxWicketsPerInnings ?? "Unlimited"}
                </strong>
              </div>

              <div>
                <span>Powerplay</span>
                <strong>
                  {match.powerplayOversInnings ?? 0}
                </strong>
              </div>

              <div>
                <span>Max overs / bowler</span>
                <strong>
                  {match.maxOversPerBowler ?? "Unlimited"}
                </strong>
              </div>
            </div>

            <div className="mobile-wow-role-section">
              <h4>Team Roles</h4>

              <div>
                <span>🧤 {match.teamAName} wicketkeeper</span>
                <strong>
                  {match.teamAWicketKeeperName ||
                    "Not selected"}
                </strong>
              </div>

              <div>
                <span>👑 {match.teamAName} captain</span>
                <strong>
                  {match.teamACaptainName ||
                    "Not selected"}
                </strong>
              </div>

              <div>
                <span>🧤 {match.teamBName} wicketkeeper</span>
                <strong>
                  {match.teamBWicketKeeperName ||
                    "Not selected"}
                </strong>
              </div>

              <div>
                <span>👑 {match.teamBName} captain</span>
                <strong>
                  {match.teamBCaptainName ||
                    "Not selected"}
                </strong>
              </div>
            </div>
          </div>
        </details>
      </article>
    );
  })}
</div>
        </div>
      </>
    )}
  </Card>
)}
{activeLeagueId &&
  matchesSubTab === "KIT" && (
    <>
      {selectedMatchId &&
        isEffectiveMatchCompleted &&
        !isMatchLocked &&
        canScoreCurrentLeague && (
          <div
            className="post-match-kit-lock-banner"
            style={{
              marginBottom: 14,
              padding: 14,
              borderRadius: 14,
              border:
                "1px solid rgba(99, 179, 237, 0.35)",
              background:
                "rgba(18, 38, 68, 0.78)",
            }}
          >
            <div
              style={{
                display: "flex",
                gap: 12,
                alignItems: "center",
                justifyContent: "space-between",
                flexWrap: "wrap",
              }}
            >
              <div>
                <strong
                  style={{
                    display: "block",
                    marginBottom: 4,
                  }}
                >
                  🏁 Match completed
                </strong>

                <span
                  style={{
                    opacity: 0.82,
                    fontSize: 13,
                  }}
                >
                  Record the final kit holder below,
                  then lock this completed match here.
                </span>
              </div>

              <button
                type="button"
                className="btn scoring-btn"
                disabled={
                  offlineSyncState.pending > 0 ||
                  offlineSyncState.syncing ||
                  offlineSyncState.online === false ||
                  Boolean(
                    offlineSyncState.conflict
                  )
                }
                onClick={
                  handleLockMatch
                }
                title={
                  offlineSyncState.pending > 0 ||
                  offlineSyncState.syncing ||
                  offlineSyncState.online === false ||
                  Boolean(
                    offlineSyncState.conflict
                  )
                    ? "Synchronize all offline scoring changes before locking."
                    : "Lock this completed match."
                }
              >
                🔒 Lock Match
                {offlineSyncState.pending > 0
                  ? " · Sync Required"
                  : ""}
              </button>
            </div>

            {(offlineSyncState.pending > 0 ||
              offlineSyncState.conflict) && (
              <small
                style={{
                  display: "block",
                  marginTop: 8,
                  opacity: 0.78,
                }}
              >
                {offlineSyncState.conflict
                  ? "Synchronization is paused. Resolve/retry sync before locking; kit custody can still be recorded."
                  : `${offlineSyncState.pending} offline change${
                      offlineSyncState.pending === 1
                        ? ""
                        : "s"
                    } still need to sync before locking.`}
              </small>
            )}
          </div>
        )}

      <TeamKitManagement
        leagueId={activeLeagueId}
        leagueName={activeLeague?.name || ""}
        onMessage={(message) => {
          setMessage(message);
          setError("");
        }}
        onError={(message) => {
          setError(message);
        }}
      />
    </>
  )}
 {activeLeagueId && matchesSubTab === "SCHEDULED" && (
  <Card title="📅 Scheduled Matches">
    {scheduledMatches.length === 0 ? (
      <div className="empty-state">
        No scheduled matches found.
      </div>
    ) : (
      <>
        {/* =====================================================
            DESKTOP / LAPTOP VIEW
            Keep existing layout and functionality
        ====================================================== */}
        <div className="matches-desktop-only">
          <div className="pro-scheduled-list">
            {filteredScheduledMatches.map((match) => {
              const shareCode =
                match?.shareCode ||
                match?.sharecode ||
                match?.publicShareCode;

              return (
                <article
                  key={`desktop-scheduled-${match.id}`}
                  className="pro-scheduled-card"
                >
                  <div className="pro-scheduled-header">
                    <div className="pro-scheduled-main-info">
                      <div className="scheduled-card-topline">
                        <span className="status-pill">
                          {match.status}
                        </span>

                        <button
                          type="button"
                          className="active-share-icon-btn"
                          title="Share spectator link"
                          aria-label={`Share ${match.teamAName} versus ${match.teamBName}`}
                          onClick={() =>
                            handleShareScheduledMatch(match)
                          }
                          disabled={!shareCode}
                        >
                          📤
                        </button>
                      </div>

                      <h3>
                        {match.teamAName}
                        <b>vs</b>
                        {match.teamBName}
                      </h3>

                      <p>
                        📅{" "}
                        {match.scheduledAt
                          ? formatDate(match.scheduledAt)
                          : "Schedule not decided"}
                      </p>
                    </div>

                    <div className="pro-scheduled-actions">
                      {canScoreCurrentLeague && (
                        <button
                          type="button"
                          className="start-match-btn"
                          onClick={() =>
                            handleStartMatch(match)
                          }
                        >
                          ▶ Start
                        </button>
                      )}

                      {normalizeStatus(match.status) ===
                        "SCHEDULED" && (
                        <button
                          type="button"
                          className="mini-action-btn"
                          onClick={() =>
                            openEditMatchModal(match)
                          }
                        >
                          ✏️ Edit
                        </button>
                      )}
                      {permissions?.canDeleteMatch && (
                        <button
                          type="button"
                          className="mini-action-btn danger-mini-btn"
                          title={`Delete ${match.teamAName} vs ${match.teamBName}`}
                          aria-label={`Delete ${match.teamAName} versus ${match.teamBName}`}
                          onClick={() =>
                            handleDeleteMatch(match.id)
                          }
                        >
                          🗑️
                        </button>
                      )}
                    </div>
                  </div>

                  <details className="scheduled-facts-wow">
                    <summary className="scheduled-facts-wow-summary">
                      <div>
                        <strong>
                          📌 Match Setup & Roles
                        </strong>

                        <small>
                          Click to view match rules,
                          captains & wicketkeepers
                        </small>
                      </div>

                      <span>⌄</span>
                    </summary>

                    <div className="scheduled-facts-wow-grid">
                      <div>
                        <span>🏏 Bat 1st</span>
                        <strong>
                          {match.battingFirstTeamName ||
                            "Not decided"}
                        </strong>
                      </div>

                      <div>
                        <span>🎯 Overs</span>
                        <strong>
                          {match.oversPerInnings}
                        </strong>
                      </div>

                      <div>
                        <span>⚾ Wickets</span>
                        <strong>
                          {match.maxWicketsPerInnings ??
                            "∞"}
                        </strong>
                      </div>

                      <div>
                        <span>⚡ Powerplay</span>
                        <strong>
                          {match.powerplayOversInnings ??
                            0}
                        </strong>
                      </div>

                      <div>
                        <span>🎳 Max / Bowler</span>
                        <strong>
                          {match.maxOversPerBowler ??
                            "∞"}
                        </strong>
                      </div>

                      <div>
                        <span>
                          🧤 {match.teamAName} WK
                        </span>
                        <strong>
                          {match.teamAWicketKeeperName ||
                            "Not selected"}
                        </strong>
                      </div>

                      <div>
                        <span>
                          🧤 {match.teamBName} WK
                        </span>
                        <strong>
                          {match.teamBWicketKeeperName ||
                            "Not selected"}
                        </strong>
                      </div>

                      <div>
                        <span>
                          👑 {match.teamAName} Captain
                        </span>
                        <strong>
                          {match.teamACaptainName ||
                            "Not selected"}
                        </strong>
                      </div>

                      <div>
                        <span>
                          👑 {match.teamBName} Captain
                        </span>
                        <strong>
                          {match.teamBCaptainName ||
                            "Not selected"}
                        </strong>
                      </div>
                    </div>
                  </details>
                </article>
              );
            })}
          </div>
        </div>

        {/* =====================================================
            MOBILE VIEW
            New compact scheduled card
        ====================================================== */}
        <div className="matches-mobile-only">
<div className="mobile-wow-match-list">
  {filteredScheduledMatches.map((match) => {
    const shareCode =
      match?.shareCode ||
      match?.sharecode ||
      match?.publicShareCode;

    return (
      <article
        key={`mobile-scheduled-${match.id}`}
        className="mobile-wow-card mobile-wow-scheduled"
      >
        <div className="mobile-wow-top">
          <span className="mobile-wow-status scheduled">
            📅 Scheduled
          </span>

          <button
            type="button"
            className="mobile-wow-icon-btn"
            title="Share spectator link"
            aria-label={`Share ${match.teamAName} versus ${match.teamBName}`}
            onClick={() => handleShareScheduledMatch(match)}
            disabled={!shareCode}
          >
            📤
          </button>
        </div>

        {/* Teams */}
        <div className="mobile-wow-teams">
          <strong>{match.teamAName}</strong>
          <span>VS</span>
          <strong>{match.teamBName}</strong>
        </div>

        {/* Schedule presented as one strong readable line */}
        <div className="mobile-wow-schedule-line">
          <span>Match time</span>

          <strong>
            {match.scheduledAt
              ? formatDate(match.scheduledAt)
              : "Schedule not decided"}
          </strong>
        </div>

        {/* Actions */}
        <div className="mobile-wow-actions scheduled-actions">
          {canScoreCurrentLeague && (
            <button
              type="button"
              className="mobile-wow-primary"
              onClick={() => handleStartMatch(match)}
            >
              ▶ Start Match
            </button>
          )}

          {normalizeStatus(match.status) === "SCHEDULED" && (
            <button
              type="button"
              className="mobile-wow-secondary"
              onClick={() => openEditMatchModal(match)}
            >
              ✏️ Edit
            </button>
          )}
          {permissions?.canDeleteMatch && (
            <button
              type="button"
              className="mobile-wow-delete"
              title="Delete match"
              aria-label={`Delete ${match.teamAName} versus ${match.teamBName}`}
              onClick={() => handleDeleteMatch(match.id)}
            >
              🗑️
            </button>
          )}
        </div>

        {/* One expandable area */}
        <details className="mobile-wow-details">
          <summary>
            <div>
              <span>⚙️</span>

              <strong>Match Setup & Team Roles</strong>
            </div>

            <i>⌄</i>
          </summary>

          <div className="mobile-wow-details-body">
            <div className="mobile-wow-rule-list">
              <div>
                <span>Batting first</span>
                <strong>
                  {match.battingFirstTeamName || "Not decided"}
                </strong>
              </div>

              <div>
                <span>Overs</span>
                <strong>{match.oversPerInnings}</strong>
              </div>

              <div>
                <span>Wickets</span>
                <strong>
                  {match.maxWicketsPerInnings ?? "Unlimited"}
                </strong>
              </div>

              <div>
                <span>Powerplay</span>
                <strong>
                  {match.powerplayOversInnings ?? 0}
                </strong>
              </div>

              <div>
                <span>Max overs / bowler</span>
                <strong>
                  {match.maxOversPerBowler ?? "Unlimited"}
                </strong>
              </div>
            </div>

            <div className="mobile-wow-role-section">
              <h4>Team Roles</h4>

              <div>
                <span>🧤 {match.teamAName} wicketkeeper</span>
                <strong>
                  {match.teamAWicketKeeperName ||
                    "Not selected"}
                </strong>
              </div>

              <div>
                <span>👑 {match.teamAName} captain</span>
                <strong>
                  {match.teamACaptainName ||
                    "Not selected"}
                </strong>
              </div>

              <div>
                <span>🧤 {match.teamBName} wicketkeeper</span>
                <strong>
                  {match.teamBWicketKeeperName ||
                    "Not selected"}
                </strong>
              </div>

              <div>
                <span>👑 {match.teamBName} captain</span>
                <strong>
                  {match.teamBCaptainName ||
                    "Not selected"}
                </strong>
              </div>
            </div>
          </div>
        </details>
      </article>
    );
  })}
</div>
        </div>
      </>
    )}
  </Card>
)}

{activeLeagueId && matchesSubTab === "COMPLETED" && (
  <Card title="✅ Match History">
    {completedMatches.length === 0 ? (
      <div className="empty-state">
        No completed matches found.
      </div>
    ) : (
      <div className="completed-match-list pro-completed-list">
        {visibleCompletedMatches.map((match, index) => {
          const battingFirstTeamName =
            match.battingFirstTeamName ||
            match.teamAName;

          const matchNumber =
            filteredCompletedMatches.length - index;

          const bowlingSecondTeamName =
            battingFirstTeamName === match.teamAName
              ? match.teamBName
              : match.teamAName;

          const normalizedStatus = String(
            match.status || ""
          )
            .trim()
            .replace(/[\s-]+/g, "_")
            .toUpperCase();

          const isDlsMatch =
            Boolean(match.isDlsResult) ||
            String(
              match.statusText || ""
            )
              .toUpperCase()
              .includes("DLS") ||
            String(
              match.statusText || ""
            )
              .toUpperCase()
              .includes("D/L STANDARD") ||
            String(
              match.statusText || ""
            )
              .toUpperCase()
              .includes("DUCKWORTH");

          const hasSuperOver =
            Boolean(
              match?.superOver?.exists
            );

          const canOpenSuperOver =
            Boolean(
              match?.mainMatchTied ||
              hasSuperOver
            );

          const firstTeamName =
            match.battingFirstTeamName ||
            match.firstInningsTeamName ||
            match.teamAName;

          const secondTeamName =
            firstTeamName === match.teamAName
              ? match.teamBName
              : match.teamAName;

          const firstTeamScore =
            match.firstInningsScore;

          const secondTeamScore =
            match.secondInningsScore;

          const cleanScore = (score) =>
            String(score || "")
              .replace(`${match.teamAName}:`, "")
              .replace(`${match.teamBName}:`, "")
              .trim();

          const playedDate =
            match.endedAt ||
            match.startedAt ||
            match.createdAt;

          const playedDateLabel = playedDate
            ? new Date(playedDate)
                .toLocaleString("en-US", {
                  month: "short",
                  day: "numeric",
                  year: "numeric",
                  hour: "numeric",
                  minute: "2-digit",
                })
                .replace(" at ", ", ")
            : "Date unavailable";

          const canShowAi =
            normalizedStatus === "COMPLETED" ||
            normalizedStatus ===
              "COMPLETED_CORRECTED" ||
            normalizedStatus ===
              "COMPLETED_LOCKED";

          const publicShareCode =
            match?.shareCode ||
            match?.sharecode ||
            match?.publicShareCode;

          const openCompletedMatch = () => {
            if (!publicShareCode) {
              alert(
                "Spectator link is not available for this match."
              );
              return;
            }

            void openCric4AllLink(
              `${window.location.origin}/live/${publicShareCode}`
            );
          };

          const renderDesktopActions = () => (
            <div className="completed-actions-bar">
              {permissions?.canScoreMatch &&
                canOpenSuperOver && (
                  <button
                    type="button"
                    className="completed-action-btn completed-super-over-btn"
                    disabled={superOverBusy}
                    onClick={() =>
                      openSuperOver(match)
                    }
                  >
                    <span>⚡</span>
                    <b>
                      {hasSuperOver
                        ? "Super Over"
                        : "Start Super Over"}
                    </b>
                  </button>
                )}

              <button
                type="button"
                className="completed-action-btn"
                onClick={() =>
                  handleMatchSelect(
                    match.id
                  )
                }
              >
                <span>📊</span>
                <b>Scorecard</b>
              </button>


              <button
                type="button"
                className="completed-action-btn"
                onClick={() =>
                  shareCompletedMatch(match)
                }
              >
                <span>📤</span>
                <b>Share Result</b>
              </button>

              {canShowAi && (
                <button
                  type="button"
                  className="completed-action-btn"
                  disabled={aiAnalysisLoading}
                  onClick={() =>
                    loadAiAnalysis(match.id)
                  }
                >
                  <span>🤖</span>

                  <b>
                    {aiAnalysisLoading
                      ? "Working..."
                      : "AI Review"}
                  </b>
                </button>
              )}
              {canScoreCurrentLeague && (
                <button
                  type="button"
                  className="completed-action-btn"
                  onClick={() =>
                    openCorrectionCenter(match.id)
                  }
                >
                  <span>✏️</span>
                  <b>Corrections</b>
                </button>
              )}

              {(
                isSuperAdmin ||
                permissions?.canEditMatch ||
                permissions?.canManagePermissions ||
                ["OWNER", "ADMIN"].includes(activeLeagueRole)
              ) && (
                <button
                  type="button"
                  className="completed-action-btn"
                  onClick={() =>
                    openVenueModalForMatch(match)
                  }
                >
                  <span>📍</span>
                  <b>Venue</b>
                </button>
              )}

              {(
                canScoreCurrentLeague ||
                permissions?.canEditMatch ||
                permissions?.canManagePermissions
              ) && (
                <button
                  type="button"
                  className="completed-action-btn completed-repair-btn"
                  onClick={() =>
                    router.push(
                      `/matches/${match.id}/repair`
                    )
                  }
                >
                  <span>🛠</span>
                  <b>Repair</b>
                </button>
              )}

              {permissions?.canDeleteMatch && (
                <button
                  type="button"
                  className="completed-action-btn completed-danger-btn"
                  onClick={() =>
                    handleDeleteMatch(match.id)
                  }
                >
                  <span>🗑️</span>
                  <b>Delete</b>
                </button>
              )}
            </div>
          );

          const renderDesktopSetup = () => (
            <details className="match-facts-wow completed-setup-row">
              <summary className="match-facts-wow-summary">
                <div className="match-facts-wow-left">
                  <span className="match-facts-wow-icon">
                    📌
                  </span>

                  <div>
                    <strong>
                      Match Setup & Timeline
                    </strong>

                    <small>
                      Overs, wickets, powerplay and
                      match times
                    </small>
                  </div>
                </div>

                <span className="match-facts-wow-caret">
                  ⌄
                </span>
              </summary>

              <div className="match-facts-wow-content">
                <div className="match-facts-grid">
                  <div>
                    <span>🏏 Bat 1st</span>

                    <strong>
                      {match.battingFirstTeamName ||
                        "Not decided"}
                    </strong>
                  </div>

                  <div>
                    <span>📍 Venue</span>

                    <strong>
                      {match.venueName ||
                        match.venueAddress ||
                        "Not set"}
                    </strong>
                  </div>

                  <div>
                    <span>🎯 Overs</span>
                    <strong>
                      {match.oversPerInnings}
                    </strong>
                  </div>

                  <div>
                    <span>⚾ Wickets</span>

                    <strong>
                      {match.maxWicketsPerInnings ??
                        "∞"}
                    </strong>
                  </div>

                  <div>
                    <span>⚡ Powerplay</span>

                    <strong>
                      {match.powerplayOversInnings ??
                        0}
                    </strong>
                  </div>

                  <div>
                    <span>🎳 Max / Bowler</span>

                    <strong>
                      {match.maxOversPerBowler ??
                        "∞"}
                    </strong>
                  </div>
                </div>

                {(match?.startedAt ||
                  match?.endedAt ||
                  match?.lockedAt) && (
                  <div className="match-timeline-wow">
                    {match?.startedAt && (
                      <div>
                        <span>Started</span>

                        <strong>
                          {formatMatchDateTime(
                            match.startedAt
                          )}
                        </strong>
                      </div>
                    )}

                    {match?.endedAt && (
                      <div>
                        <span>Ended</span>

                        <strong>
                          {formatMatchDateTime(
                            match.endedAt
                          )}
                        </strong>
                      </div>
                    )}

                    {match?.lockedAt && (
                      <div>
                        <span>Locked</span>

                        <strong>
                          {formatMatchDateTime(
                            match.lockedAt
                          )}
                        </strong>
                      </div>
                    )}
                  </div>
                )}
              </div>
            </details>
          );

          return (
            <article
              key={match.id}
              className="completed-scorecard-card"
              style={{
                /*
                 * Let Chromium skip layout/paint work for off-screen completed
                 * cards. Existing responsive CSS and mobile alignment remain
                 * untouched.
                 */
                contentVisibility:
                  "auto",

                containIntrinsicSize:
                  "1px 560px",
              }}
            >
              {/* =========
                  DESKTOP / LAPTOP
                  Existing layout retained
              ============= */}
              <div className="matches-desktop-only">
                <div className="completed-desktop-card">
                  <div className="completed-scorecard-top">
                    <div className="completed-top-left">
                      <span className="completed-match-chip">
                        Match #{matchNumber}
                      </span>

                      <span
                        className={
                          `completed-status-chip ${
                            isDlsMatch
                              ? "completed-status-chip-dls"
                              : ""
                          }`
                        }
                      >
                        {isDlsMatch
                          ? "COMPLETED · DLS"
                          : match.status}
                      </span>
                    </div>

                    <div className="completed-top-right">
                      {publicShareCode && (
                        <button
                          type="button"
                          className="completed-view-match-btn"
                          onClick={
                            openCompletedMatch
                          }
                        >
                          🏏 Open Match
                        </button>
                      )}

                      <span className="completed-date-chip">
                        📅 {playedDateLabel}
                      </span>
                    </div>
                  </div>

                  <div className="completed-scorecard-hero compact-teams-line">
                    <strong>
                      {battingFirstTeamName}
                    </strong>

                    <span>vs</span>

                    <strong>
                      {bowlingSecondTeamName}
                    </strong>
                  </div>

                  <div className="completed-winner-banner">
                    🏆{" "}
                    {match.resultText ||
                      "Result unavailable"}
                  </div>

                  <div className="completed-innings-row">
                    <div className="completed-innings-box">
                      <span>1st Innings</span>

                      <strong>
                        {match.firstInningsScore}
                      </strong>
                    </div>

                    <div className="completed-innings-box">
                      <span>2nd Innings</span>

                      <strong>
                        {match.secondInningsScore}
                      </strong>
                    </div>
                  </div>

                  {match?.superOver?.exists && (
                    <details className="completed-super-over-summary">
                      <summary>
                        <span>
                          ⚡ Super Over
                        </span>

                        <strong>
                          {match.superOver.completed
                            ? match.superOver.resultText ||
                              "Completed"
                            : match.superOver.tied
                              ? `Round ${match.superOver.round} tied`
                              : `Round ${match.superOver.round} in progress`}
                        </strong>
                      </summary>

                      <div className="completed-super-over-rounds">
                        {(match.superOver.history || []).map(
                          (round) => {
                            const roundFirstTeam =
                              Number(round.firstBattingTeamId) ===
                              Number(match.teamAId)
                                ? match.teamAName
                                : match.teamBName;

                            const roundSecondTeam =
                              Number(round.secondBattingTeamId) ===
                              Number(match.teamAId)
                                ? match.teamAName
                                : match.teamBName;

                            return (
                              <div
                                key={`so-${match.id}-${round.round}`}
                                className="completed-super-over-round"
                              >
                                <b>
                                  Super Over {round.round}
                                </b>

                                <span>
                                  {roundFirstTeam}:{" "}
                                  {round.firstRuns}/
                                  {round.firstWickets} (
                                  {round.firstOvers})
                                </span>

                                <span>
                                  {roundSecondTeam}:{" "}
                                  {round.secondRuns}/
                                  {round.secondWickets} (
                                  {round.secondOvers})
                                </span>

                                {round.resultText && (
                                  <small>
                                    {round.resultText}
                                  </small>
                                )}
                              </div>
                            );
                          }
                        )}
                      </div>
                    </details>
                  )}

                  {renderDesktopActions()}
                  {renderDesktopSetup()}
                </div>
              </div>

              {/* ============================================
                  MOBILE
                  New readable compact design
              ============================================= */}
              <div className="matches-mobile-only">
                <article className="mobile-completed-wow-card">
                  <div className="mobile-completed-wow-top">
                    <div className="mobile-completed-wow-meta">
                      <span className="mobile-completed-match-number">
                        Match #{matchNumber}
                      </span>

                      <span
                        className={
                          `mobile-completed-status ${
                            isDlsMatch
                              ? "is-dls"
                              : ""
                          }`
                        }
                      >
                        {isDlsMatch
                          ? "🌧 COMPLETED · DLS"
                          : (
                              <>
                                ✓{" "}
                                {String(match.status || "")
                                  .replaceAll("_", " ")
                                  .trim()}
                              </>
                            )}
                      </span>
                    </div>

                    {publicShareCode && (
                      <button
                        type="button"
                        className="mobile-completed-open-btn"
                        title="Open spectator scorecard"
                        aria-label={`Open ${match.teamAName} versus ${match.teamBName}`}
                        onClick={openCompletedMatch}
                      >
                        ↗
                      </button>
                    )}
                  </div>

                  <div className="mobile-completed-date">
                    📅 {playedDateLabel}
                  </div>

                  <div className="mobile-completed-score">
                    <div className="mobile-completed-team">
                      <span>{firstTeamName}</span>

                      <strong>
                        {cleanScore(firstTeamScore) ||
                          "—"}
                      </strong>

                      <small>1st innings</small>
                    </div>

                    <div className="mobile-completed-versus">
                      VS
                    </div>

                    <div className="mobile-completed-team right">
                      <span>{secondTeamName}</span>

                      <strong>
                        {cleanScore(secondTeamScore) ||
                          "—"}
                      </strong>

                      <small>2nd innings</small>
                    </div>
                  </div>

                  <div className="mobile-completed-result">
                    <span>🏆</span>

                    <strong>
                      {match.resultText ||
                        "Result unavailable"}
                    </strong>
                  </div>

                  {permissions?.canScoreMatch &&
                    canOpenSuperOver && (
                      <button
                        type="button"
                        className="mobile-completed-super-over-btn"
                        disabled={superOverBusy}
                        onClick={() =>
                          openSuperOver(match)
                        }
                      >
                        ⚡{" "}
                        {hasSuperOver
                          ? "Super Over"
                          : "Start Super Over"}
                      </button>
                    )}

                  {match?.superOver?.exists && (
                    <div className="mobile-super-over-result">
                      <span>
                        ⚡ Super Over
                      </span>

                      <strong>
                        {match.superOver.completed
                          ? match.superOver.resultText ||
                            "Completed"
                          : match.superOver.tied
                            ? `Round ${match.superOver.round} tied`
                            : `Round ${match.superOver.round} in progress`}
                      </strong>
                    </div>
                  )}

                  <div className="mobile-completed-primary-actions">
                    <button
                      type="button"
                      className="mobile-completed-scorecard-btn"
                      onClick={() =>
                        handleMatchSelect(
                          match.id
                        )
                      }
                    >
                      <span>📊</span>
                      View Scorecard
                    </button>


                    <button
                      type="button"
                      className="mobile-completed-scorecard-btn"
                      onClick={() =>
                        shareCompletedMatch(match)
                      }
                    >
                      <span>📤</span>
                      Share Result
                    </button>

                    {canShowAi && (
                      <button
                        type="button"
                        className="mobile-completed-ai-btn"
                        disabled={aiAnalysisLoading}
                        onClick={() =>
                          loadAiAnalysis(match.id)
                        }
                      >
                        <span>🤖</span>

                        {aiAnalysisLoading
                          ? "Working..."
                          : "AI Review"}
                      </button>
                    )}
                  </div>
                  {(canScoreCurrentLeague ||
                    permissions?.canDeleteMatch) && (
                    <div className="mobile-completed-secondary-actions">
                      {canScoreCurrentLeague && (
                        <button
                          type="button"
                          onClick={() =>
                            openCorrectionCenter(
                              match.id
                            )
                          }
                        >
                          ✏️ Corrections
                        </button>
                      )}

                      {(
                        isSuperAdmin ||
                        permissions?.canEditMatch ||
                        permissions?.canManagePermissions ||
                        ["OWNER", "ADMIN"].includes(activeLeagueRole)
                      ) && (
                        <button
                          type="button"
                          onClick={() =>
                            openVenueModalForMatch(match)
                          }
                        >
                          📍 Venue
                        </button>
                      )}

                      {(
                        canScoreCurrentLeague ||
                        permissions?.canEditMatch ||
                        permissions?.canManagePermissions
                      ) && (
                        <button
                          type="button"
                          onClick={() =>
                            router.push(
                              `/matches/${match.id}/repair`
                            )
                          }
                        >
                          🛠 Repair
                        </button>
                      )}

                      {permissions?.canDeleteMatch && (
                        <button
                          type="button"
                          className="danger"
                          onClick={() =>
                            handleDeleteMatch(match.id)
                          }
                        >
                          🗑️ Delete
                        </button>
                      )}
                    </div>
                  )}

                  <details className="mobile-completed-details">
                    <summary>
                      <div>
                        <span>⚙️</span>

                        <strong>
                          Match Setup & Timeline
                        </strong>
                      </div>

                      <i>⌄</i>
                    </summary>

                    <div className="mobile-completed-details-body">
                      <div className="mobile-completed-rule-list">
                        <div>
                          <span>Batting first</span>

                          <strong>
                            {match.battingFirstTeamName ||
                              "Not decided"}
                          </strong>
                        </div>

                        <div>
                          <span>Venue</span>

                          <strong>
                            {match.venueName ||
                              match.venueAddress ||
                              "Not set"}
                          </strong>
                        </div>

                        <div>
                          <span>Overs</span>

                          <strong>
                            {match.oversPerInnings}
                          </strong>
                        </div>

                        <div>
                          <span>Wickets</span>

                          <strong>
                            {match.maxWicketsPerInnings ??
                              "Unlimited"}
                          </strong>
                        </div>

                        <div>
                          <span>Powerplay</span>

                          <strong>
                            {match.powerplayOversInnings ??
                              0}
                          </strong>
                        </div>

                        <div>
                          <span>
                            Max overs / bowler
                          </span>

                          <strong>
                            {match.maxOversPerBowler ??
                              "Unlimited"}
                          </strong>
                        </div>
                      </div>

                      {(match?.startedAt ||
                        match?.endedAt ||
                        match?.lockedAt) && (
                        <div className="mobile-completed-timeline">
                          <h4>Match Timeline</h4>

                          {match?.startedAt && (
                            <div>
                              <span>Started</span>

                              <strong>
                                {formatMatchDateTime(
                                  match.startedAt
                                )}
                              </strong>
                            </div>
                          )}

                          {match?.endedAt && (
                            <div>
                              <span>Ended</span>

                              <strong>
                                {formatMatchDateTime(
                                  match.endedAt
                                )}
                              </strong>
                            </div>
                          )}

                          {match?.lockedAt && (
                            <div>
                              <span>Locked</span>

                              <strong>
                                {formatMatchDateTime(
                                  match.lockedAt
                                )}
                              </strong>
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  </details>
                </article>
              </div>
            </article>
          );
        })}

        {hasMoreCompletedMatches && (
          <div
            style={{
              display: "flex",
              justifyContent: "center",
              padding: "14px 0 4px",
            }}
          >
            <button
              type="button"
              className="btn btn-outline"
              onClick={() =>
                setCompletedMatchRenderLimit(
                  (current) =>
                    current +
                    COMPLETED_MATCH_RENDER_PAGE_SIZE
                )
              }
            >
              Show More Completed Matches
              {" · "}
              {filteredCompletedMatches.length -
                visibleCompletedMatches.length}
              {" remaining"}
            </button>
          </div>
        )}
      </div>
    )}
  </Card>
)}
</Card>
  </div> 
)}
{activeTab === "management" && canShowManagementTab && (
  <div className="management-page">
    {activeLeagueId ? (
      <PersonalDashboardSnapshot
        data={myCricket}
        loading={myCricketLoading}
        leagueName={
          leagues.find(
            (league) => Number(league.id) === Number(activeLeagueId)
          )?.name || ""
        }
        onOpenYourCricket={() => {
          setStatsSubTab("MY_CRICKET");
          setActiveTab("stats");
          loadMyCricket(activeLeagueId);
          loadLeagueStats(activeLeagueId);
        }}
      />
    ) : null}

    <Card title="🏏 League Management">
      <div className="mgmt-clean-shell">

        <nav
          className="mgmt-command-nav"
          aria-label="League management sections"
        >
          <a
            href="#management-league"
            className="mgmt-command-nav-item is-primary"
          >
            <span className="mgmt-command-nav-icon" aria-hidden="true">
              🏆
            </span>

            <span className="mgmt-command-nav-copy">
              <small>1 · League</small>
              <strong>
                {activeLeague?.name || "Choose league"}
              </strong>
            </span>

            <b aria-hidden="true">→</b>
          </a>

          <a
            href="#management-teams"
            className={
              `mgmt-command-nav-item ${
                minimumTeamsReady
                  ? "is-complete"
                  : "needs-action"
              }`
            }
          >
            <span className="mgmt-command-nav-icon" aria-hidden="true">
              👥
            </span>

            <span className="mgmt-command-nav-copy">
              <small>2 · Teams</small>
              <strong>
                {selectedLeague
                  ? `${selectedLeague.teams?.length || 0} ready`
                  : "Choose league"}
              </strong>
            </span>

            <b aria-hidden="true">→</b>
          </a>

          <a
            href="#players-section"
            className={
              `mgmt-command-nav-item ${
                leagueReadyForMatches
                  ? "is-complete"
                  : "needs-action"
              }`
            }
          >
            <span className="mgmt-command-nav-icon" aria-hidden="true">
              🏏
            </span>

            <span className="mgmt-command-nav-copy">
              <small>3 · Players</small>
              <strong>
                {selectedTeam
                  ? `${selectedTeam.players?.length || 0} in ${selectedTeam.name}`
                  : "Choose team"}
              </strong>
            </span>

            <b aria-hidden="true">→</b>
          </a>

          <a
            href="#management-series"
            className="mgmt-command-nav-item is-optional"
          >
            <span className="mgmt-command-nav-icon" aria-hidden="true">
              📅
            </span>

            <span className="mgmt-command-nav-copy">
              <small>Optional · Series</small>
              <strong>
                {selectedSeries?.name || "No series required"}
              </strong>
            </span>

            <b aria-hidden="true">→</b>
          </a>
        </nav>

{/* LEAGUE */}
{/* =========================================================
    MOBILE-ONLY LEAGUE COMMAND CENTER
    Replace the complete League section with this block.
========================================================= */}

<section
  id="management-league"
  className="mgmt-clean-card league-mobile-wow-card management-league-card"
>
  {/* Existing desktop experience remains unchanged */}
  <div className="league-desktop-experience">
    <div className="mgmt-clean-head">
      <div>
        <h3>🏆 League</h3>
        <p>Select your active league and share invite/public links.</p>
      </div>
    </div>

    <label className="compact-league-picker">
      <span className="league-label">🏆 Active League</span>

      <div className="league-select-wrapper compact">
        <div className="league-current-info">
          <div className="league-current-name">
            {activeLeague?.name || "Select League"}
          </div>

          <span
            className={`league-visibility ${
              activeLeague?.visibility?.toLowerCase() || "private"
            }`}
          >
            {activeLeague?.visibility === "PUBLIC"
              ? "🌍 Public"
              : activeLeague?.visibility === "UNLISTED"
                ? "🔗 Unlisted"
                : "🔒 Private"}
          </span>
        </div>

        <select
          value={activeLeagueId || ""}
          onChange={(event) => {
            setActiveLeagueId(event.target.value);
            setSelectedTeamId("");
            setSelectedSeriesId("");
          }}
        >
          <option value="">Select League</option>

          {(leagues || []).map((league) => (
            <option key={league.id} value={league.id}>
              {league.name} • {league.visibility || "PRIVATE"}
            </option>
          ))}
        </select>

        <div className="league-dropdown-icon" aria-hidden="true">
          ⌄
        </div>
      </div>
    </label>

    <div className="mobile-league-next-step">
      <div>
        <strong>
          {leagueReadyForMatches
            ? "🏏 Ready to play!"
            : "⚙️ Complete Setup"}
        </strong>

        <span>
          {leagueReadyForMatches
            ? "Your league is ready. Create or manage matches."
            : !minimumTeamsReady
              ? "Create at least 2 teams."
              : "Each team needs at least 2 players."}
        </span>
      </div>

      <button
        type="button"
        disabled={!leagueReadyForMatches}
        onClick={() => {
          setActiveTab("matches");
          setMatchesSubTab("CREATE MATCH");
        }}
      >
        {leagueReadyForMatches
          ? "Go to Matches →"
          : "Complete Setup"}
      </button>
    </div>

    <div className="league-action-bar league-actions-desktop">
      <button
        type="button"
        className="league-action-primary"
        onClick={() => setShowLeagueModal(true)}
      >
        <span aria-hidden="true">＋</span>
        <strong>Create League</strong>
      </button>

      {activeLeague && (isSuperAdmin || permissions?.canEditLeague) && (
        <button
          type="button"
          className="league-action-secondary"
          onClick={() => openEditLeagueModal(activeLeague)}
        >
          <span aria-hidden="true">✏️</span>
          <strong>Edit League</strong>
        </button>
      )}

      {activeLeague && allowedInviteRolesForCurrentUser.length > 0 && (
        <button
          type="button"
          className="league-action-secondary"
          onClick={openInviteRoleComposer}
        >
          <span aria-hidden="true">🔗</span>
          <strong>Invite</strong>
        </button>
      )}

      {activeLeague &&
        activeLeague.visibility !== "PRIVATE" &&
        activeLeague.slug && (
          <button
            type="button"
            className="league-action-secondary"
            onClick={() => {
              const url =
                `${window.location.origin}/leagues/${activeLeague.slug}`;

              navigator.clipboard.writeText(url);
              setMessage("Public league link copied.");
              showToast(
                "success",
                "✅ Public league link copied."
              );
            }}
          >
            <span aria-hidden="true">🌐</span>
            <strong>Public Link</strong>
          </button>
        )}

      <details className="league-action-more">
        <summary>
          <span aria-hidden="true">⋯</span>
          <strong>More</strong>
          <b aria-hidden="true">⌄</b>
        </summary>

        <div className="league-action-menu">
          <button
            type="button"
            onClick={() => setShowFollowedLeaguesDrawer(true)}
          >
            <span aria-hidden="true">⭐</span>
            <span>
              <strong>Followed Leagues</strong>
              <small>Open leagues you follow</small>
            </span>
          </button>

          <button
            type="button"
            onClick={() => setShowPublicLeagueDrawer(true)}
          >
            <span aria-hidden="true">🧭</span>
            <span>
              <strong>Discover Leagues</strong>
              <small>Browse public leagues</small>
            </span>
          </button>

          {selectedLeague && permissions?.canDeleteLeague && (
            <button
              type="button"
              className="is-danger"
              onClick={() =>
                handleDeleteLeague(
                  selectedLeague.id,
                  selectedLeague.name
                )
              }
            >
              <span aria-hidden="true">🗑️</span>
              <span>
                <strong>Delete League</strong>
                <small>Permanently delete this league</small>
              </span>
            </button>
          )}
        </div>
      </details>
    </div>
<div className="league-tools-shell">
  {canManagePlayerInactivityAlerts && activeLeagueId && (
    <div className="league-tool-panel player-inactivity-tool">
      <button
        type="button"
        className="league-tool-summary player-inactivity-summary-button"
        aria-expanded={showPlayerInactivitySettings}
        onClick={() =>
          setShowPlayerInactivitySettings(
            (current) => !current
          )
        }
      >
        <div className="league-tool-summary-main">
          <span className="league-tool-icon">
            📵
          </span>

          <div>
            <strong className="league-tool-single-line-title">
              Player Activity
            </strong>

            <small className="league-tool-single-line-subtitle">
              60-day SMS review
            </small>
          </div>
        </div>

        <span
          className="league-tool-action league-tool-disclosure-action"
          aria-hidden="true"
          title={
            showPlayerInactivitySettings
              ? "Close Player Inactivity Alerts"
              : "Open Player Inactivity Alerts"
          }
        >
          <span className="league-tool-disclosure-label">
            {showPlayerInactivitySettings
              ? "−"
              : "+"}
          </span>

          <span className="league-tool-chevron">
            {showPlayerInactivitySettings
              ? "⌃"
              : "⌄"}
          </span>
        </span>
      </button>
    </div>
  )}

  {canViewBirthdayTools && (
    <div className="league-tool-panel birthday-tool league-tool-compact-card">
      <button
        type="button"
        className="league-tool-summary league-tool-summary-button"
        aria-expanded={showBirthdayLeagueToolSettings}
        onClick={() =>
          setShowBirthdayLeagueToolSettings(
            (current) => !current
          )
        }
      >
        <div className="league-tool-summary-main">
          <span className="league-tool-icon">
            🎂
          </span>

          <div>
            <strong className="league-tool-single-line-title">
              Birthdays
            </strong>
          </div>
        </div>

        <span
          className="league-tool-action league-tool-disclosure-action"
          aria-hidden="true"
          title={
            showBirthdayLeagueToolSettings
              ? "Close Birthday tools"
              : "Open Birthday tools"
          }
        >
          <span className="league-tool-disclosure-label">
            {showBirthdayLeagueToolSettings
              ? "−"
              : "+"}
          </span>

          <span className="league-tool-chevron">
            {showBirthdayLeagueToolSettings
              ? "⌃"
              : "⌄"}
          </span>
        </span>
      </button>
    </div>
  )}

  {canViewLeagueKitShortcut && (
    <div className="dashboard-tool-card-shell dashboard-tool-kit-shell">
      <LeagueKitShortcut
        leagueName={
          activeLeague?.name ||
          "Active league"
        }
        sharedKit={
          String(
            activeLeague
              ?.kitRotationMode ||
            ""
          )
            .trim()
            .toUpperCase() ===
          "LEAGUE_PLAYER"
        }
        onOpenKit={() => {
          setActiveTab(
            "matches"
          );
          setMatchesSubTab(
            "KIT"
          );
        }}
      />

      <div
        className="dashboard-tool-card-overlay"
        aria-hidden="true"
      >
        <span className="dashboard-tool-card-overlay-icon">
          🏏
        </span>

        <strong className="league-tool-single-line-title league-tool-overlay-title">
          Kit Tracking
        </strong>

        <span className="dashboard-tool-card-overlay-action league-tool-disclosure-action">
          <span className="league-tool-disclosure-label">
            +
          </span>

          <span className="league-tool-chevron">
            ⌄
          </span>
        </span>
      </div>
    </div>
  )}

  <div className="league-resource-tool-slot dashboard-tool-card-shell dashboard-tool-resource-shell">
    <Link
      href={
        activeLeagueId
          ? `/leagues/${activeLeagueId}/resources`
          : "#"
      }
      className="league-resource-single-link"
      aria-label="Open Resources"
      aria-disabled={!activeLeagueId}
      onClick={(event) => {
        if (!activeLeagueId) {
          event.preventDefault();
        }
      }}
    >
      <span
        className="league-resource-single-icon"
        aria-hidden="true"
      >
        📚
      </span>

      <strong className="league-resource-single-title">
        Resources
      </strong>

      <span
        className="league-resource-single-action"
        aria-hidden="true"
      >
        <span>+</span>
        <span>⌄</span>
      </span>
    </Link>
  </div>

</div>

  {canManagePlayerInactivityAlerts &&
    activeLeagueId &&
    showPlayerInactivitySettings && (
      <section
        className="league-tool-expanded-panel player-inactivity-expanded-panel"
        aria-label="Player inactivity alert settings"
      >
        <div className="league-tool-expanded-panel-heading">
          <div>
            <strong>
              📵 Player Inactivity Alerts
            </strong>
            <small>
              60-day SMS review notice
            </small>
          </div>

          <button
            type="button"
            onClick={() =>
              setShowPlayerInactivitySettings(false)
            }
          >
            Close
          </button>
        </div>

        <PlayerInactivityAlertSettings
          leagueId={
            activeLeagueId
          }
          leagueName={
            activeLeague?.name ||
            selectedLeague?.name ||
            "Active league"
          }
        />
      </section>
    )}

  {canViewBirthdayTools &&
    activeLeagueId &&
    showBirthdayLeagueToolSettings && (
      <section
        className="league-tool-expanded-panel birthday-expanded-panel"
        aria-label="Birthday settings"
      >
        <div className="league-tool-expanded-panel-heading">
          <div>
            <strong>
              🎂 Birthdays
            </strong>
            <small>
              {canManageBirthdayTools
                ? "Dates & reminders"
                : "Events & celebrations"}
            </small>
          </div>

          <button
            type="button"
            onClick={() =>
              setShowBirthdayLeagueToolSettings(false)
            }
          >
            Close
          </button>
        </div>

        {canManageBirthdayTools ? (
          <BirthdayPushSettings
            leagueId={
              activeLeagueId
            }
          />
        ) : (
          <div className="birthday-readonly-shortcut">
            <span aria-hidden="true">
              👁️
            </span>

            <div>
              <strong>
                Birthday events — view only
              </strong>

              <small>
                You can view the Birthday Center and today’s birthdays. Add, edit, delete, notification, and sharing controls remain disabled.
              </small>
            </div>

            <Link
              href={`/leagues/${activeLeagueId}/birthdays`}
              className="birthday-readonly-shortcut-link"
            >
              Open Birthday Center →
            </Link>
          </div>
        )}
      </section>
    )}

  </div>

  {/* Mobile-only state-aware experience */}
  <section
    className="mobile-league-command-center"
    aria-label="League command center"
  >
    {!(leagues || []).length ? (
      <div className="mlcc-first-league">
        <div className="mlcc-first-top">
          <span className="mlcc-trophy" aria-hidden="true">
            🏆
          </span>

          <span className="mlcc-start-badge">
            Start here
          </span>
        </div>

        <div className="mlcc-first-copy">
          <h3>Create your first cricket league</h3>

          <p>
            Your league becomes the home for teams, players,
            matches, standings, scoring, and spectator links.
          </p>
        </div>

        <button
          type="button"
          className="mlcc-primary-create"
          onClick={() => setShowLeagueModal(true)}
        >
          <span className="mlcc-primary-icon" aria-hidden="true">
            +
          </span>

          <span className="mlcc-primary-copy">
            <strong>Create Your First League</strong>
            <small>Set it up in about a minute</small>
          </span>

          <span className="mlcc-primary-arrow" aria-hidden="true">
            →
          </span>
        </button>

        <div className="mlcc-journey">
          <div><b>1</b><span>Create league</span></div>
          <i aria-hidden="true">→</i>
          <div><b>2</b><span>Add teams</span></div>
          <i aria-hidden="true">→</i>
          <div><b>3</b><span>Start scoring</span></div>
        </div>

        <button
          type="button"
          className="mlcc-discover-link"
          onClick={() => setShowPublicLeagueDrawer(true)}
        >
          🧭 Not ready to create? Discover public leagues
        </button>
      </div>
    ) : !activeLeague ? (
      <div className="mlcc-select-state">
        <div className="mlcc-state-heading">
          <span className="mlcc-state-icon" aria-hidden="true">
            🏆
          </span>

          <div>
            <span>League workspace</span>
            <h3>Choose a league to continue</h3>
            <p>
              Select the league you want to manage, or create
              another one.
            </p>
          </div>
        </div>

        <label className="mlcc-league-picker">
          <span>Active league</span>

          <div>
            <select
              value={activeLeagueId || ""}
              onChange={(event) => {
                setActiveLeagueId(event.target.value);
                setSelectedTeamId("");
                setSelectedSeriesId("");
              }}
            >
              <option value="">Choose a league...</option>

              {(leagues || []).map((league) => (
                <option key={league.id} value={league.id}>
                  {league.name} • {league.visibility || "PRIVATE"}
                </option>
              ))}
            </select>

            <span aria-hidden="true">⌄</span>
          </div>
        </label>

        <button
          type="button"
          className="mlcc-secondary-create"
          onClick={() => setShowLeagueModal(true)}
        >
          <span aria-hidden="true">＋</span>
          Create Another League
        </button>
      </div>
    ) : (
      <div className="mlcc-workspace">
        <div className="mlcc-workspace-top">
          <div className="mlcc-active-identity">
            <span className="mlcc-active-mark" aria-hidden="true">
              🏆
            </span>

            <div>
              <span>Active league</span>
              <strong>{activeLeague.name}</strong>
            </div>
          </div>

          <button
            type="button"
            className="mlcc-new-league"
            onClick={() => setShowLeagueModal(true)}
          >
            <span aria-hidden="true">＋</span>
            New
          </button>
        </div>

        <label className="mlcc-switcher">
          <span>Switch league</span>

          <div>
            <select
              value={activeLeagueId || ""}
              onChange={(event) => {
                setActiveLeagueId(event.target.value);
                setSelectedTeamId("");
                setSelectedSeriesId("");
              }}
            >
              {(leagues || []).map((league) => (
                <option key={league.id} value={league.id}>
                  {league.name} • {league.visibility || "PRIVATE"}
                </option>
              ))}
            </select>

            <span aria-hidden="true">⌄</span>
          </div>
        </label>

        <div
          className={`mlcc-readiness ${
            leagueReadyForMatches ? "is-ready" : "needs-setup"
          }`}
        >
          <div className="mlcc-readiness-head">
            <div>
              <span>
                {leagueReadyForMatches
                  ? "Match ready"
                  : "Setup progress"}
              </span>

              <strong>
                {leagueReadyForMatches
                  ? "Your league is ready to play"
                  : !minimumTeamsReady
                    ? "Add at least two teams"
                    : "Add at least two players per team"}
              </strong>
            </div>

            <span
              className="mlcc-readiness-status"
              aria-hidden="true"
            >
              {leagueReadyForMatches ? "✓" : "!"}
            </span>
          </div>

          <div className="mlcc-setup-steps">
            <div className="is-complete">
              <span>1</span>
              <small>League</small>
            </div>

            <i aria-hidden="true" />

            <div className={minimumTeamsReady ? "is-complete" : ""}>
              <span>2</span>
              <small>Teams</small>
            </div>

            <i
              className={minimumTeamsReady ? "is-complete" : ""}
              aria-hidden="true"
            />

            <div className={leagueReadyForMatches ? "is-complete" : ""}>
              <span>3</span>
              <small>Players</small>
            </div>
          </div>

          {leagueReadyForMatches ? (
            <button
              type="button"
              className="mlcc-go-matches"
              onClick={() => {
                setActiveTab("matches");
                setMatchesSubTab("CREATE MATCH");
              }}
            >
              <span>
                <strong>Go to Matches</strong>
                <small>Create or manage a match</small>
              </span>

              <b aria-hidden="true">→</b>
            </button>
          ) : (
            <div className="mlcc-setup-guidance">
              <span aria-hidden="true">💡</span>

              <p>
                {!minimumTeamsReady
                  ? "Use Team Management below to create your first two teams."
                  : "Open each team and add at least two players before creating a match."}
              </p>
            </div>
          )}
        </div>

        <div className="mlcc-quick-actions">
          {(isSuperAdmin || permissions?.canEditLeague) && (
            <button
              type="button"
              onClick={() => openEditLeagueModal(activeLeague)}
            >
              <span className="mlcc-action-icon" aria-hidden="true">
                ✏️
              </span>

              <span>
                <strong>Edit League</strong>
                <small>Name & visibility</small>
              </span>
            </button>
          )}

          {allowedInviteRolesForCurrentUser.length > 0 && (
            <button
              type="button"
              onClick={openInviteRoleComposer}
            >
              <span className="mlcc-action-icon" aria-hidden="true">
                🔗
              </span>

              <span>
                <strong>Invite</strong>
                <small>Choose role & copy link</small>
              </span>
            </button>
          )}

          {activeLeague.visibility !== "PRIVATE" &&
            activeLeague.slug && (
              <button
                type="button"
                onClick={() => {
                  const url =
                    `${window.location.origin}/leagues/${activeLeague.slug}`;

                  navigator.clipboard.writeText(url);
                  setMessage("Public league link copied.");
                  showToast(
                    "success",
                    "✅ Public league link copied."
                  );
                }}
              >
                <span className="mlcc-action-icon" aria-hidden="true">
                  🌐
                </span>

                <span>
                  <strong>Public Link</strong>
                  <small>Copy spectator page</small>
                </span>
              </button>
            )}
        </div>
      </div>
    )}

    <details className="mlcc-more-actions">
      <summary>
        <span className="mlcc-more-copy">
          <span className="mlcc-more-icon" aria-hidden="true">
            ⋯
          </span>

          <span>
            <strong>League tools</strong>
            <small>
              Inactivity · resources · birthdays · kit · discovery
            </small>
          </span>
        </span>

        <span className="mlcc-more-toggle" aria-hidden="true">
          +
        </span>
      </summary>

      <div className="mlcc-more-grid">
        <button
          type="button"
          onClick={() => setShowFollowedLeaguesDrawer(true)}
        >
          <span aria-hidden="true">⭐</span>

          <span>
            <strong>Followed Leagues</strong>
            <small>Open leagues you follow</small>
          </span>
        </button>

        <button
          type="button"
          onClick={() => setShowPublicLeagueDrawer(true)}
        >
          <span aria-hidden="true">🧭</span>

          <span>
            <strong>Discover Leagues</strong>
            <small>Browse public cricket leagues</small>
          </span>
        </button>

        <div className="mobile-dashboard-tool-shell mobile-dashboard-resource-shell">
          <LeagueResourcesShortcut
            leagueId={activeLeagueId}
            leagueName={
              activeLeague?.name ||
              "Active league"
            }
            compact
          />

          <div
            className="mobile-dashboard-tool-overlay"
            aria-hidden="true"
          >
            <span className="mobile-dashboard-tool-icon">
              📚
            </span>

            <strong>
              Resources
            </strong>

            <span className="mobile-dashboard-tool-action">
              Open
            </span>
          </div>
        </div>

        {(
          canManagePlayerInactivityAlerts ||
          canViewBirthdayTools ||
          canViewLeagueKitShortcut
        ) && (
          <div
            className={
              mobileKitStyles.mobileLeagueTools
            }
          >
            {canManagePlayerInactivityAlerts &&
              activeLeagueId && (
                <details
                  className={`${mobileKitStyles.mobileBirthdaySection} mobile-player-inactivity-section`}
                >
                  <summary>
                    <span
                      className={
                        mobileKitStyles.mobileToolSummaryMain
                      }
                    >
                      <span
                        className={
                          mobileKitStyles.mobileToolIcon
                        }
                        aria-hidden="true"
                      >
                        📵
                      </span>

                      <span
                        className={
                          mobileKitStyles.mobileToolCopy
                        }
                      >
                        <strong>
                          Player Inactivity Alerts
                        </strong>

                        <small>
                          60-day SMS review notice
                        </small>
                      </span>
                    </span>

                    <span
                      className={`${mobileKitStyles.mobileToolToggle} mobile-tool-chevron-only`}
                      aria-hidden="true"
                    >
                      <b>⌄</b>
                    </span>
                  </summary>

                  <div
                    className={
                      mobileKitStyles.mobileBirthdayContent
                    }
                  >
                    <PlayerInactivityAlertSettings
                      leagueId={
                        activeLeagueId
                      }
                      leagueName={
                        activeLeague?.name ||
                        selectedLeague?.name ||
                        "Active league"
                      }
                    />
                  </div>
                </details>
              )}

            {canViewBirthdayTools && (
              <details
                className={
                  mobileKitStyles.mobileBirthdaySection
                }
              >
                <summary>
                  <span
                    className={
                      mobileKitStyles.mobileToolSummaryMain
                    }
                  >
                    <span
                      className={
                        mobileKitStyles.mobileToolIcon
                      }
                      aria-hidden="true"
                    >
                      🎂
                    </span>

                    <span
                      className={
                        mobileKitStyles.mobileToolCopy
                      }
                    >
                      <strong>
                        Birthday Management
                      </strong>

                      <small>
                        {canManageBirthdayTools
                          ? "Manage birthday alerts and player records."
                          : "View birthdays and today’s celebrations."}
                      </small>
                    </span>
                  </span>

                  <span
                    className={
                      mobileKitStyles.mobileToolToggle
                    }
                    aria-hidden="true"
                  >
                    <span
                      className={
                        mobileKitStyles.mobileToolOpenText
                      }
                    >
                      Open
                    </span>

                    <span
                      className={
                        mobileKitStyles.mobileToolCloseText
                      }
                    >
                      Close
                    </span>

                    <b>⌄</b>
                  </span>
                </summary>

                <div
                  className={
                    mobileKitStyles.mobileBirthdayContent
                  }
                >
                  {canManageBirthdayTools ? (
                    <BirthdayPushSettings
                      leagueId={
                        activeLeagueId
                      }
                    />
                  ) : (
                    <div className="birthday-readonly-shortcut mobile">
                      <span aria-hidden="true">
                        👁️
                      </span>

                      <div>
                        <strong>
                          View-only birthday access
                        </strong>

                        <small>
                          Birthday records and today’s events are visible. All modifying actions are disabled.
                        </small>
                      </div>

                      <Link
                        href={`/leagues/${activeLeagueId}/birthdays`}
                        className="birthday-readonly-shortcut-link"
                      >
                        Open Birthday Center →
                      </Link>
                    </div>
                  )}
                </div>
              </details>
            )}

            {canViewLeagueKitShortcut && (
              <div
                className={
                  mobileKitStyles.mobileLeagueKitBelowBirthday
                }
              >
                <div className="mobile-dashboard-tool-shell mobile-dashboard-kit-shell">
                  <LeagueKitShortcut
                    leagueName={
                      activeLeague?.name ||
                      "Active league"
                    }
                    sharedKit={
                      String(
                        activeLeague
                          ?.kitRotationMode ||
                        ""
                      )
                        .trim()
                        .toUpperCase() ===
                      "LEAGUE_PLAYER"
                    }
                    onOpenKit={() => {
                      setActiveTab(
                        "matches"
                      );
                      setMatchesSubTab(
                        "KIT"
                      );
                    }}
                  />

                  <div
                    className="mobile-dashboard-tool-overlay"
                    aria-hidden="true"
                  >
                    <span className="mobile-dashboard-tool-icon">
                      🏏
                    </span>

                    <strong>
                      Kit Tracking
                    </strong>

                    <span className="mobile-dashboard-tool-action">
                      Open
                    </span>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}
      </div>

      {selectedLeague && permissions?.canDeleteLeague && (
        <div className="mlcc-danger-zone">
          <div>
            <strong>Danger zone</strong>
            <small>
              Permanently delete {selectedLeague.name}.
            </small>
          </div>

          <button
            type="button"
            onClick={() =>
              handleDeleteLeague(
                selectedLeague.id,
                selectedLeague.name
              )
            }
          >
            🗑️ Delete League
          </button>
        </div>
      )}
    </details>
  </section>
</section>

        {/* SERIES */}
        <details
          id="management-series"
          className="mgmt-clean-card mgmt-series-collapsible"
        >
          <summary className="mgmt-section-summary">
            <span className="mgmt-section-summary-icon" aria-hidden="true">
              📅
            </span>

            <span className="mgmt-section-summary-copy">
              <small>Optional organization</small>

              <strong>
                Series / Season
              </strong>

              <span>
                {selectedSeries
                  ? `${selectedSeries.name} • ${selectedSeries.year}`
                  : "No series selected — matches can still be created normally."}
              </span>
            </span>

            <span
              className={
                `mgmt-section-status ${
                  selectedSeries
                    ? "has-value"
                    : "optional"
                }`
              }
            >
              {selectedSeries
                ? "Selected"
                : "Optional"}
            </span>

            <span className="mgmt-section-chevron" aria-hidden="true">
              ⌄
            </span>
          </summary>

          <div className="mgmt-series-body">
<label className="mgmt-field mgmt-select-field">
            <span>👇 Choose a series or leave optional</span>
            <div className="select-action-hint">
  <span>Tap to choose</span>
  <b>⌄</b>
</div>
            <select
              value={selectedSeriesId || ""}
              disabled={!activeLeagueId}
              onChange={(e) => {
                const seriesId = e.target.value;
                setSelectedSeriesId(seriesId);

                const selected = seriesList.find(
                  (s) => Number(s.id) === Number(seriesId)
                );

                setContextFilters((prev) => ({
                  ...prev,
                  seriesIds: seriesId ? [Number(seriesId)] : [],
                  years: selected ? [Number(selected.year)] : [],
                }));
              }}
            >
              <option value="">No Series Selected (Optional)</option>

              {seriesList.map((series) => (
                <option key={series.id} value={series.id}>
                  {series.name} • {series.year} • {series.status || "ACTIVE"}
                </option>
              ))}
            </select>

            <small className="mgmt-clean-help">
              <strong>Series are optional.</strong>
              <span>
                Create a series only if you want to group matches into a tournament,
                cup, season, or year. You can still create matches without a series.
              </span>
            </small>
          </label>

<div className="mgmt-clean-actions series-actions-row">
  <button
    type="button"
    className="mgmt-clean-btn"
    disabled={!activeLeagueId}
    onClick={() => {
      setEditingSeries(null);
      setSeriesForm({
        name: "",
        year: new Date().getFullYear(),
        status: "ACTIVE",
      });
      setShowSeriesModal(true);
    }}
  >
    ➕ Create Series
  </button>

  {selectedSeries && (
    <>
      <button
        type="button"
        className="mgmt-clean-btn secondary"
          onClick={() => {
            setEditingSeries(selectedSeries);
            setSeriesForm({
              name: selectedSeries.name || "",
              year: selectedSeries.year || new Date().getFullYear(),
              status: selectedSeries.status || "ACTIVE",
            });
            setShowSeriesModal(true);
          }}
      >
        ✏️ Edit Series
      </button>

      <button
        type="button"
        className="mgmt-clean-danger"
        title={`Delete ${selectedSeries.name}`}
        onClick={() =>
          handleDeleteSeries(selectedSeries.id, selectedSeries.name)
        }
      >
        🗑️
      </button>
    </>
  )}
</div>
          </div>
        </details>

        {/* TEAMS */}
        <section
          id="management-teams"
          className="mgmt-clean-card management-teams-card"
        >
          <div className="mgmt-clean-head">
            <div>
              <h3>👥 Teams</h3>
              <p>
                Choose a team here. Its player roster appears immediately beside
                or below this section.
              </p>
            </div>
          </div>

<label className="mgmt-field mgmt-select-field">
            <span>👇 Choose a team to manage players</span>
            <div className="select-action-hint">
  <span>Tap to choose</span>
  <b>⌄</b>
</div>
            <select
              value={selectedTeamId || ""}
              disabled={!selectedLeague}
              onChange={(e) => setSelectedTeamId(e.target.value)}
            >
              <option value="">
                {selectedLeague ? "Select Team" : "Select league first"}
              </option>

              {teamsForSelectedLeague.map((team) => (
                <option key={team.id} value={String(team.id)}>
                  {team.name}
                </option>
              ))}
            </select>
          </label>

          <div className="mgmt-clean-actions">
            <button
              type="button"
              className="mgmt-clean-btn"
              disabled={!selectedLeague}
              onClick={() => {
                setTeamForm({
                  name: "",
                  leagueId: selectedLeague.id,
                });

                setShowAddTeam(true);
              }}
            >
              ➕ Add Team
            </button>

            <button
              type="button"
              className="mgmt-clean-btn"
              disabled={
                !selectedLeague ||
                !canImportLeagueRoster
              }
              title={
                canImportLeagueRoster
                  ? "Move teams and players into Cric4All from CSV"
                  : "Owner/Admin or team+player create permission required"
              }
              onClick={() => {
                if (
                  !selectedLeague ||
                  !canImportLeagueRoster
                ) {
                  return;
                }

                setLeagueImportText("");
                setLeagueImportRows([]);
                setLeagueImportErrors([]);
                setLeagueImportResult(null);
                setShowLeagueImportModal(true);
              }}
            >
              🚚 Move Your League
            </button>
{canEditSelectedTeam && (
  <button
    type="button"
    className="mgmt-clean-btn"
    onClick={() => {
      setEditingTeam(selectedTeam);
      setTeamEditName(selectedTeam.name || "");
      setTeamRoleForm({
        defaultCaptainId: selectedTeam.defaultCaptainId ? String(selectedTeam.defaultCaptainId) : "",
        defaultViceCaptainId: selectedTeam.defaultViceCaptainId ? String(selectedTeam.defaultViceCaptainId) : "",
        defaultWicketKeeperId: selectedTeam.defaultWicketKeeperId ? String(selectedTeam.defaultWicketKeeperId) : "",
      });
      setShowEditTeamModal(true);
    }}
  >
    ✏️ Edit Team
  </button>
)}
            {canDeleteSelectedTeam && (
              <button
                type="button"
                className="mgmt-clean-danger"
                onClick={() =>
                  handleDeleteTeam(selectedTeam.id, selectedTeam.name)
                }
              >
                🗑️
              </button>
            )}
          </div>  
{activeLeagueId && canUseAvailabilityBuilder && (
<button
  type="button"
  className="league-team-builder-btn"
onClick={() => {
  window.location.href = `/ai-team-splitter?leagueId=${activeLeagueId}`;
}}
>
  <span aria-hidden="true">⚖️</span>

  <div>
    <strong>Availability &amp; Team Builder</strong>
    <small>
      Poll · Split teams · Captains
    </small>
  </div>

  <div className="team-builder-arrow" aria-hidden="true">
    →
  </div>
</button>
)}
        </section>
 {/* PLAYERS */}
<section
  id="players-section"
  className="mgmt-clean-card player-manager-card management-players-card"
>
  <div className="player-manager-head">
    <div>
      <h3>🏏 Players</h3>
      <p>
        {selectedTeam
          ? `${selectedTeam.players?.length || 0} players ready for ${selectedTeam.name}`
          : "Select a team to view, add, or manage players."}
      </p>
    </div>

    {selectedTeam && (
      <div className="player-count-pill">
        👥 {selectedTeam.players?.length || 0}
      </div>
    )}
  </div>

  {!selectedTeam ? (
    <div className="player-empty-state">
      <div className="player-empty-icon">👥</div>
      <strong>No team selected yet</strong>
      <span>Choose a team above to view and add players.</span>
    </div>
  ) : (
    <>
      <div className="player-team-banner">
        <div>
          <strong>{selectedTeam.name}</strong>
          <span>Team roster</span>
        </div>

        <button
          type="button"
          className="player-add-btn"
          disabled={!canAddPlayers}
          aria-disabled={!canAddPlayers}
          title={
            canAddPlayers
              ? "Add players to this team"
              : "Only an owner, admin, captain, or permission manager can add players"
          }
          onClick={() => {
            if (!canAddPlayers) {
              setError(
                "Only the league owner, an admin, a captain, or a permission manager can add players."
              );
              return;
            }

            setPlayerLeagueId(Number(activeLeagueId));
            setSelectedPlayerTeamId(Number(selectedTeamId));

            setPlayerForm({
              names: "",
              leagueId: Number(activeLeagueId),
              teamId: Number(selectedTeamId),
            });

            setShowPlayerModal(true);
          }}
        >
          {canAddPlayers ? "➕ Add Players" : "🔒 Add Players"}
        </button>
      </div>

      {!selectedTeam.players?.length ? (
        <div className="player-empty-state compact">
          <div className="player-empty-icon">🏏</div>
          <strong>No players yet</strong>
          <span>Add players in bulk by pasting one name per line.</span>
        </div>
      ) : (
<div className="pretty-player-list">
{[...(selectedTeam.players || [])]
  .sort((a, b) =>
    String(a.name || "").localeCompare(String(b.name || ""), undefined, {
      sensitivity: "base",
      numeric: true,
    })
  )
  .map((player, index) => (
    <div key={player.id} className="pretty-player-row">
      <div className="player-avatar">
        {String(player.name || "?").trim().charAt(0).toUpperCase()}
      </div>

      <div className="player-info">
        {getPlayerCardHref(player.id) ? (
          <Link
            href={getPlayerCardHref(player.id)}
            className={playerCardStyles.playerNameLink}
            title={`Open ${player.name}'s Cric4All player card`}
            aria-label={`Open ${player.name}'s player card`}
          >
            <strong>{player.name}</strong>
            <span className={playerCardStyles.playerCardArrow} aria-hidden="true">
              ↗
            </span>
          </Link>
        ) : (
          <strong>{player.name}</strong>
        )}
        <span>Player #{index + 1}</span>
      </div>

      <div className="player-row-actions desktop-player-actions">
        {getPlayerCardHref(player.id) && (
          <Link
            href={getPlayerCardHref(player.id)}
            className={`${playerCardStyles.playerCardAction} mini-action-btn`}
            title={`View ${player.name}'s Player Card`}
            aria-label={`View ${player.name}'s Player Card`}
          >
            👤
          </Link>
        )}

        {canEditPlayers && (
          <button
            type="button"
            className="mini-action-btn"
            title="Edit Player"
            onClick={() => openEditPlayer(player)}
          >
            ✏️
          </button>
        )}

        {canEditPlayers && (
          <button
            type="button"
            className="mini-action-btn"
            title="Move Player"
            onClick={() => {
              setTransferPlayer(player);
              setTransferTeamId("");
              setShowTransferPlayerModal(true);
            }}
          >
            🔁
          </button>
        )}

        {canDeletePlayers && (
          <button
            type="button"
            className="player-delete-btn"
            title={`Delete ${player.name}`}
            onClick={() => handleDeletePlayer(player.id, player.name)}
          >
            🗑️
          </button>
        )}
      </div>

<details
  className="mobile-player-actions"
  open={openPlayerActionId === player.id}
  onToggle={(e) => {
    setOpenPlayerActionId(e.currentTarget.open ? player.id : null);
  }}
>
  <summary>⚙️</summary>

        <div className="mobile-player-actions-menu">
          {getPlayerCardHref(player.id) && (
            <Link
              href={getPlayerCardHref(player.id)}
              className={playerCardStyles.mobilePlayerCardAction}
              onClick={() => setOpenPlayerActionId(null)}
            >
              <span>👤</span>
              <span>View Player Card</span>
            </Link>
          )}

          {canEditPlayers && (
            <button type="button"   onClick={() => {
    setOpenPlayerActionId(null);
    openEditPlayer(player);
  }}>
             <span>✏️</span>
            <span>Edit Player</span>
            </button>
          )}

          {canEditPlayers && (
            <button
              type="button"
              onClick={() => {
                setOpenPlayerActionId(null);
                setTransferPlayer(player);
                setTransferTeamId("");
                setShowTransferPlayerModal(true);
              }}
            >
              <span>🔁</span>
              <span>Move Player</span>
            </button>
          )}

          {canDeletePlayers && (
            <button
              type="button"
              className="danger"
              onClick={() => {
                setOpenPlayerActionId(null);
                handleDeletePlayer(player.id, player.name);
              }}
            >
              <span>🗑️</span>
              <span>Delete Player</span>
            </button>
          )}
        </div>
      </details>
    </div>
  ))}
</div>
      )}
    </>
  )}
</section>

        {/* NEXT STEP */}
        {canCreateMatch && (
          <section className="mgmt-clean-ready management-bottom-match-cta">
            <div>
              <strong>✅ League setup complete</strong>
              <p>You can now schedule matches from the Matches tab.</p>
            </div>

            <button
              type="button"
              className="mgmt-clean-btn"
onClick={() => {
  setPendingMatchesSubTab("CREATE MATCH");
  setActiveTab("matches");
}}
            >
              🏏 Create Match
            </button>
          </section>
        )}
      </div>
    </Card>

    {(message || error) && (
      <Card title="ℹ️ Notifications" defaultCollapsed={false}>
        {message ? <p className="success">{message}</p> : null}
        {error ? <p className="error">{error}</p> : null}
      </Card>
    )}
  </div>
)}
{activeTab === "Points" && (
  
  <Card title="🏆 Points" defaultCollapsed={false}>
  <div className="active-league-mini">
      <span>League</span>
      <strong>
        {leagues.find((l) => Number(l.id) === Number(activeLeagueId))?.name ||
          "No league selected"}
      </strong>
    </div> 
  {pointsTable.length === 0 ? (
    <p className="muted">No points table available yet.</p>
  ) : (
    <div className="score-table-scroll">
            <ContextLens />
      <table className="score-table sticky-first-col">
        <thead>
          <tr>
            <th>Team</th>
            <th>P</th>
            <th>W</th>
            <th>L</th>
            <th>T</th>
            <th>NR</th>
            <th>Pts</th>
            <th>NRR</th>
          </tr>
        </thead>

        <tbody>
          {filteredPointsTable.map((row) => (
            <tr key={row.teamId}>
              <td>{row.teamName}</td>
              <td>{row.played}</td>
              <td>{row.won}</td>
              <td>{row.lost}</td>
              <td>{row.tied}</td>
              <td>{row.noResult}</td>
              <td><strong>{row.points}</strong></td>
              <td>{row.nrr}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )}
</Card>
)}
{activeTab === "stats" && (
  <div className="stats-page">
    {leagueStatsLoading && (
  <div className="live-feed-banner">
    📊 Refreshing latest stats...
  </div>
)}
    <Card title="📊 League Statistics" defaultCollapsed={false}>
  <div className="active-league-mini">
      <span>League</span>
      <strong>
        {leagues.find((l) => Number(l.id) === Number(activeLeagueId))?.name ||
          "No league selected"}
      </strong>
    </div>
    <ContextLens />
      <div className="stats-subtabs">
        <button
          type="button"
          className={statsSubTab === "MY_CRICKET" ? "active" : ""}
          onClick={() => {
            setStatsSubTab("MY_CRICKET");
            loadMyCricket(activeLeagueId);
          }}
        >
          🎯 Your Cricket
        </button>

        <button
          type="button"
          className={statsSubTab === "BATTING" ? "active" : ""}
          onClick={() => setStatsSubTab("BATTING")}
        >
          🏏 Batting
        </button>

        <button
          type="button"
          className={statsSubTab === "BOWLING" ? "active" : ""}
          onClick={() => setStatsSubTab("BOWLING")}
        >
          🎯 Bowling
        </button>

        <button
          type="button"
          className={statsSubTab === "FIELDING" ? "active" : ""}
          onClick={() => setStatsSubTab("FIELDING")}
        >
          🧤 Fielding
        </button>
        <button
          type="button"
          className={statsSubTab === "CAPTAINCY" ? "active" : ""}
          onClick={() => setStatsSubTab("CAPTAINCY")}
        >
          🧢 Captaincy
        </button>
        <button
          type="button"
          className={statsSubTab === "WICKETKEEPING" ? "active" : ""}
          onClick={() => setStatsSubTab("WICKETKEEPING")}
        >
          🧤 Wicketkeeping
        </button>

        <button
          type="button"
          className={statsSubTab === "LEADERS" ? "active" : ""}
          onClick={() => setStatsSubTab("LEADERS")}
        >
          🌟 Leaders
        </button>

        <button
          type="button"
          className={statsSubTab === "RANKINGS" ? "active" : ""}
          onClick={() => setStatsSubTab("RANKINGS")}
        >
          🏆 Rankings
        </button>

        <button
          type="button"
          className={statsSubTab === "AWARDS" ? "active" : ""}
          onClick={() => setStatsSubTab("AWARDS")}
        >
          ✨ Awards
        </button>
      </div>
    </Card>
    {!activeLeagueId ? (
      <Card title="Select League">
        <p className="muted">Please select an active league first.</p>
      </Card>
    ) : !leagueStats ? (
      <Card title="Loading Stats">
        <p className="muted">Loading league statistics...</p>
      </Card>
    ) : (
      <>
{statsSubTab === "MY_CRICKET" && (
        <PersonalCricketDashboard
          data={myCricket}
          loading={myCricketLoading}
          leagueName={
            leagues.find(
              (league) =>
                Number(league.id) === Number(activeLeagueId)
            )?.name || ""
          }
          leagueId={activeLeagueId}
          onLinkChanged={() =>
            loadMyCricket(activeLeagueId)
          }
        />
      )}

{statsSubTab === "BATTING" && (
  <Card title="🏏 Batting Records">
    {!leagueStats?.batting?.length ? (
      <p className="muted">No batting stats yet.</p>
    ) : (
      <div className="compact-stats-list">
        {filteredBatting.map((row, idx) => (
          <details
            key={`league-bat-${row.playerId ?? row.playerName}-${idx}`}
            className="compact-stat-card"
          >
            <summary className="compact-stat-summary">
              <span className="compact-rank">#{row.actualRank}</span>

              <span className="compact-player">
                <strong>{row.playerName}</strong>
                <small>{row.teamName}</small>
              </span>

              <span className="compact-highlight">
                <strong>{row.runs}</strong>
                <small>Runs</small>
              </span>

              <span className="compact-toggle">⌄</span>
            </summary>

            <div className="compact-stat-grid">
              <span>M {row.matches}</span>
              <span>Inn {row.battingInnings}</span>
              <span>B {row.balls}</span>
              <span>Avg {row.average}</span>
              <span>SR {row.strikeRate}</span>
              <span>4s {row.fours}</span>
              <span>6s {row.sixes}</span>
              <span>HS {row.highestScore}</span>
            </div>
          </details>
        ))}
      </div>
    )}
  </Card>
)}

{statsSubTab === "BOWLING" && (
  <Card title="🎯 Bowling Records">
    {!leagueStats?.bowling?.length ? (
      <p className="muted">No bowling stats yet.</p>
    ) : (
      <div className="compact-stats-list">
        {filteredBowling.map((row, idx) => (
          <details
            key={`league-bowl-${row.playerId ?? row.playerName}-${idx}`}
            className="compact-stat-card"
          >
            <summary className="compact-stat-summary">
              <span className="compact-rank">#{row.actualRank}</span>

              <span className="compact-player">
                <strong>{row.playerName}</strong>
                <small>{row.teamName}</small>
              </span>

              <span className="compact-highlight">
                <strong>{row.wickets}</strong>
                <small>Wkts</small>
              </span>

              <span className="compact-toggle">⌄</span>
            </summary>

            <div className="compact-stat-grid">
              <span>M {row.matches}</span>
              <span>O {row.bowlingOvers}</span>
              <span>R {row.bowlingRuns}</span>
              <span>Eco {row.economy}</span>
              <span>Avg {row.bowlingAverage}</span>
              <span>SR {row.bowlingStrikeRate}</span>
              <span>Dots {row.dots}</span>
              <span>Best {row.bestBowling}</span>
            </div>
          </details>
        ))}
      </div>
    )}
  </Card>
)}

{statsSubTab === "FIELDING" && (
  <Card title="🧤 Fielding Records">
    {!leagueStats?.fielding?.length ? (
      <p className="muted">No fielding stats yet.</p>
    ) : (
      <div className="compact-stats-list">
        {filteredFielding.map((row, idx) => (
          <details
            key={`league-field-${row.playerId ?? row.playerName}-${idx}`}
            className="compact-stat-card"
          >
            <summary className="compact-stat-summary">
              <span className="compact-rank">#{row.actualRank}</span>

              <span className="compact-player">
                <strong>{row.playerName}</strong>
                <small>{row.teamName}</small>
              </span>

              <span className="compact-highlight">
                <strong>{row.fieldingTotal}</strong>
                <small>Total</small>
              </span>

              <span className="compact-toggle">⌄</span>
            </summary>

            <div className="compact-stat-grid">
              <span>Catches {row.catches}</span>
              <span>Run Outs {row.runOuts}</span>
              <span>Stumpings {row.stumpings}</span>
              <span>Assists {row.assists}</span>
            </div>
          </details>
        ))}
      </div>
    )}
  </Card>
)}
<style jsx global>{`
  .dashboard-leaders-intro {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 14px;
    margin-bottom: 14px;
    padding: 12px 14px;
    border: 1px solid rgba(96, 165, 250, 0.18);
    border-radius: 14px;
    background: rgba(8, 22, 42, 0.62);
  }

  .dashboard-leaders-intro > div {
    min-width: 0;
    display: grid;
    gap: 3px;
  }

  .dashboard-leaders-intro strong {
    color: #f8fbff;
    font-size: 14px;
  }

  .dashboard-leaders-intro span {
    color: #9fb2ca;
    font-size: 12px;
    line-height: 1.4;
  }

  .dashboard-leaders-live-badge {
    flex: 0 0 auto;
    padding: 6px 9px;
    border: 1px solid rgba(52, 211, 153, 0.32);
    border-radius: 999px;
    color: #9ff5d3 !important;
    background: rgba(16, 185, 129, 0.1);
    font-size: 10px !important;
    font-weight: 800;
    text-transform: uppercase;
    letter-spacing: 0.04em;
  }

  .dashboard-leaders-tabs {
    display: grid;
    grid-template-columns: repeat(4, minmax(0, 1fr));
    gap: 8px;
    margin-bottom: 14px;
  }

  .dashboard-leaders-tabs button {
    min-width: 0;
    min-height: 42px;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 7px;
    padding: 9px 10px;
    border: 1px solid rgba(113, 146, 184, 0.34);
    border-radius: 11px;
    color: #aebed1;
    background: rgba(8, 22, 42, 0.68);
    font: inherit;
    font-size: 12px;
    font-weight: 800;
    cursor: pointer;
    white-space: nowrap;
  }

  .dashboard-leaders-tabs button:hover {
    border-color: rgba(96, 165, 250, 0.58);
    color: #fff;
  }

  .dashboard-leaders-tabs button.active {
    border-color: rgba(56, 189, 248, 0.72);
    color: #fff;
    background: linear-gradient(
      135deg,
      rgba(37, 99, 235, 0.82),
      rgba(14, 116, 144, 0.74)
    );
    box-shadow: 0 8px 24px rgba(14, 116, 144, 0.14);
  }

  .dashboard-leader-showcase {
    display: grid;
    gap: 12px;
  }

  .dashboard-leader-hero {
    min-width: 0;
    display: flex;
    align-items: stretch;
    justify-content: space-between;
    gap: 18px;
    padding: 18px;
    border: 1px solid rgba(96, 165, 250, 0.24);
    border-radius: 16px;
    overflow: hidden;
    background:
      radial-gradient(circle at 88% 14%, rgba(249, 115, 22, 0.15), transparent 34%),
      linear-gradient(135deg, rgba(34, 30, 30, 0.94), rgba(7, 20, 35, 0.96));
  }

  .dashboard-leader-showcase--bowling .dashboard-leader-hero {
    background:
      radial-gradient(circle at 88% 14%, rgba(139, 92, 246, 0.18), transparent 34%),
      linear-gradient(135deg, rgba(35, 26, 52, 0.94), rgba(7, 20, 35, 0.96));
  }

  .dashboard-leader-showcase--fielding .dashboard-leader-hero {
    background:
      radial-gradient(circle at 88% 14%, rgba(16, 185, 129, 0.17), transparent 34%),
      linear-gradient(135deg, rgba(13, 48, 50, 0.94), rgba(7, 20, 35, 0.96));
  }

  .dashboard-leader-showcase--allround .dashboard-leader-hero {
    background:
      radial-gradient(circle at 88% 14%, rgba(245, 158, 11, 0.18), transparent 34%),
      linear-gradient(135deg, rgba(54, 39, 22, 0.94), rgba(7, 20, 35, 0.96));
  }

  .dashboard-leader-hero-copy {
    min-width: 0;
    display: grid;
    align-content: center;
    gap: 5px;
  }

  .dashboard-leader-eyebrow {
    color: #7dd3fc;
    font-size: 10px;
    font-weight: 900;
    text-transform: uppercase;
    letter-spacing: 0.08em;
  }

  .dashboard-leader-hero-copy > strong {
    color: #dbeafe;
    font-size: 12px;
    text-transform: uppercase;
    letter-spacing: 0.04em;
  }

  .dashboard-leader-player {
    max-width: 100%;
    overflow: hidden;
    color: #fff;
    font-size: clamp(20px, 2.4vw, 30px);
    font-weight: 900;
    line-height: 1.08;
    text-overflow: ellipsis;
    white-space: nowrap;
  }

  .dashboard-leader-hero-copy small {
    overflow: hidden;
    color: #9fb2ca;
    font-size: 11px;
    text-overflow: ellipsis;
    white-space: nowrap;
  }

  .dashboard-leader-hero-value {
    flex: 0 0 auto;
    min-width: 145px;
    display: grid;
    align-content: center;
    justify-items: end;
    gap: 2px;
    text-align: right;
  }

  .dashboard-leader-hero-value > strong {
    color: #fff;
    font-size: clamp(28px, 3.4vw, 42px);
    line-height: 1;
  }

  .dashboard-leader-hero-value > span {
    color: #7dd3fc;
    font-size: 11px;
    font-weight: 900;
    text-transform: uppercase;
  }

  .dashboard-leader-hero-value small {
    max-width: 230px;
    margin-top: 4px;
    color: #9fb2ca;
    font-size: 10px;
    line-height: 1.35;
  }

  .dashboard-leader-grid {
    display: grid;
    grid-template-columns: repeat(4, minmax(0, 1fr));
    gap: 10px;
  }

  .dashboard-leader-card {
    min-width: 0;
    display: grid;
    align-content: space-between;
    gap: 13px;
    min-height: 150px;
    padding: 14px;
    border: 1px solid rgba(113, 146, 184, 0.26);
    border-radius: 14px;
    background: linear-gradient(
      180deg,
      rgba(17, 40, 68, 0.9),
      rgba(8, 23, 41, 0.94)
    );
  }

  .dashboard-leader-card-top {
    min-width: 0;
    display: flex;
    align-items: flex-start;
    gap: 9px;
  }

  .dashboard-leader-card-icon {
    flex: 0 0 auto;
    font-size: 18px;
  }

  .dashboard-leader-card-top > span:last-child {
    min-width: 0;
    display: grid;
    gap: 2px;
  }

  .dashboard-leader-card-top strong {
    color: #f8fbff;
    font-size: 12px;
    line-height: 1.2;
  }

  .dashboard-leader-card-top small {
    color: #7890aa;
    font-size: 9px;
    line-height: 1.25;
  }

  .dashboard-leader-card-player {
    min-width: 0;
    display: grid;
    gap: 2px;
  }

  .dashboard-leader-card-player strong,
  .dashboard-leader-card-player small {
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }

  .dashboard-leader-card-player strong {
    color: #dcecff;
    font-size: 13px;
  }

  .dashboard-leader-card-player small {
    color: #7890aa;
    font-size: 9px;
  }

  .dashboard-leader-card-value {
    display: flex;
    align-items: baseline;
    gap: 5px;
  }

  .dashboard-leader-card-value strong {
    color: #fff;
    font-size: 20px;
  }

  .dashboard-leader-card-value span {
    color: #7dd3fc;
    font-size: 9px;
    font-weight: 800;
    text-transform: uppercase;
  }

  .dashboard-leader-card-empty,
  .dashboard-leaders-empty {
    color: #7890aa;
    font-size: 12px;
  }

  .dashboard-leaders-empty {
    padding: 24px 14px;
    border: 1px dashed rgba(113, 146, 184, 0.28);
    border-radius: 14px;
    text-align: center;
    background: rgba(8, 22, 42, 0.45);
  }

  .dashboard-leaders-footnote {
    margin: 13px 2px 0;
    color: #7188a2;
    font-size: 10px;
    line-height: 1.45;
  }

  @media (max-width: 900px) {
    .dashboard-leader-grid {
      grid-template-columns: repeat(2, minmax(0, 1fr));
    }
  }

  @media (max-width: 640px) {
    .dashboard-leaders-intro {
      align-items: flex-start;
    }

    .dashboard-leaders-live-badge {
      display: none;
    }

    .dashboard-leaders-tabs {
      grid-template-columns: repeat(2, minmax(0, 1fr));
    }

    .dashboard-leader-hero {
      display: grid;
      gap: 14px;
      padding: 15px;
    }

    .dashboard-leader-hero-value {
      min-width: 0;
      justify-items: start;
      text-align: left;
    }

    .dashboard-leader-hero-value small {
      max-width: none;
    }

    .dashboard-leader-player,
    .dashboard-leader-hero-copy small {
      white-space: normal;
      overflow-wrap: anywhere;
    }

    .dashboard-leader-grid {
      grid-template-columns: repeat(2, minmax(0, 1fr));
      gap: 8px;
    }

    .dashboard-leader-card {
      min-height: 142px;
      padding: 12px;
    }
  }

  @media (max-width: 390px) {
    .dashboard-leader-grid {
      grid-template-columns: 1fr;
    }
  }
`}</style>

{statsSubTab === "LEADERS" && (
  <Card title="🌟 League Leaders">
    <div className="dashboard-leaders-intro">
      <div>
        <strong>Standout performers</strong>
        <span>
          Quick league bragging rights from the same records shown in Stats.
        </span>
      </div>
      <span className="dashboard-leaders-live-badge">Stats-powered</span>
    </div>

    <div
      className="dashboard-leaders-tabs"
      role="tablist"
      aria-label="League leader category"
    >
      {[
        ["BATTING", "🏏", "Batting"],
        ["BOWLING", "🎯", "Bowling"],
        ["FIELDING", "🧤", "Fielding"],
        ["ALLROUND", "🌟", "All-Round"],
      ].map(([key, icon, label]) => (
        <button
          key={key}
          type="button"
          role="tab"
          aria-selected={dashboardLeadersTab === key}
          className={dashboardLeadersTab === key ? "active" : ""}
          onClick={() => setDashboardLeadersTab(key)}
        >
          <span>{icon}</span>
          {label}
        </button>
      ))}
    </div>

    {dashboardLeadersTab === "BATTING" ? (
      dashboardTopRunScorer ? (
        <DashboardLeaderShowcase
          accent="batting"
          hero={{
            eyebrow: "Orange cap",
            icon: "🏏",
            label: "Run machine",
            row: dashboardTopRunScorer,
            value: dashboardTopRunScorer.runs,
            unit: "runs",
            detail: `${dashboardTopRunScorer.matches || 0} matches · ${dashboardTopRunScorer.balls || 0} balls`,
          }}
          cards={[
            {
              icon: "🚀",
              label: "Power hitter",
              hint: "Most sixes",
              row: dashboardTopSixHitter,
              value: dashboardTopSixHitter?.sixes || 0,
              unit: "sixes",
            },
            {
              icon: "⚡",
              label: "Boundary boss",
              hint: "Most fours",
              row: dashboardTopFourHitter,
              value: dashboardTopFourHitter?.fours || 0,
              unit: "fours",
            },
            {
              icon: "🔥",
              label: "Accelerator",
              hint: "Best SR · min 5 balls",
              row: dashboardBestStrikeRate,
              value: dashboardBestStrikeRate?.strikeRate || "0.00",
              unit: "SR",
            },
            {
              icon: "📈",
              label: "Match impact",
              hint: "Best runs per match",
              row: dashboardBestRunsPerMatch,
              value: dashboardBestRunsPerMatch?.runsPerMatch?.toFixed(1) || "0.0",
              unit: "runs/match",
            },
          ]}
        />
      ) : (
        <div className="dashboard-leaders-empty">
          No qualifying batting leaders yet.
        </div>
      )
    ) : dashboardLeadersTab === "BOWLING" ? (
      dashboardTopWicketTaker ? (
        <DashboardLeaderShowcase
          accent="bowling"
          hero={{
            eyebrow: "Purple cap",
            icon: "🎯",
            label: "Wicket hunter",
            row: dashboardTopWicketTaker,
            value: dashboardTopWicketTaker.wickets,
            unit: "wickets",
            detail: `${dashboardTopWicketTaker.bowlingOvers || "0.0"} overs · ${dashboardTopWicketTaker.economy || "0.00"} economy`,
          }}
          cards={[
            {
              icon: "🔒",
              label: "Run stopper",
              hint: "Best economy · min 1 over",
              row: dashboardBestEconomy,
              value: dashboardBestEconomy?.economy || "0.00",
              unit: "economy",
            },
            {
              icon: "⚪",
              label: "Dot-ball king",
              hint: "Most dot balls",
              row: dashboardTopDotBowler,
              value: dashboardTopDotBowler?.dots || 0,
              unit: "dots",
            },
            {
              icon: "💥",
              label: "Strike threat",
              hint: "Fewest balls per wicket",
              row: dashboardBestBowlingStrikeRate,
              value: dashboardBestBowlingStrikeRate?.bowlingStrikeRate || "0.0",
              unit: "balls/wkt",
            },
            {
              icon: "💪",
              label: "Workhorse",
              hint: "Most legal deliveries",
              row: dashboardBowlingWorkhorse,
              value: dashboardBowlingWorkhorse?.bowlingOvers || "0.0",
              unit: "overs",
            },
          ]}
        />
      ) : (
        <div className="dashboard-leaders-empty">
          No qualifying bowling leaders yet.
        </div>
      )
    ) : dashboardLeadersTab === "FIELDING" ? (
      dashboardTopFielder ? (
        <DashboardLeaderShowcase
          accent="fielding"
          hero={{
            eyebrow: "Fielding crown",
            icon: "🧤",
            label: "Fielding MVP",
            row: dashboardTopFielder,
            value: dashboardTopFielder.fieldingTotal,
            unit: "contributions",
            detail: `${dashboardTopFielder.catches || 0} catches · ${dashboardTopFielder.runOuts || 0} run-outs · ${dashboardTopFielder.stumpings || 0} stumpings · ${dashboardTopFielder.assists || 0} assists`,
          }}
          cards={[
            {
              icon: "🤲",
              label: "Safe hands",
              hint: "Most catches",
              row: dashboardSafestHands,
              value: dashboardSafestHands?.catches || 0,
              unit: "catches",
            },
            {
              icon: "🎯",
              label: "Run-out specialist",
              hint: "Most direct run-outs",
              row: dashboardRunOutSpecialist,
              value: dashboardRunOutSpecialist?.runOuts || 0,
              unit: "run-outs",
            },
            {
              icon: "🤝",
              label: "Assist king",
              hint: "Most run-out assists",
              row: dashboardAssistLeader,
              value: dashboardAssistLeader?.assists || 0,
              unit: "assists",
            },
            {
              icon: "⚡",
              label: "Glove work",
              hint: "Most stumpings",
              row: dashboardStumpingLeader,
              value: dashboardStumpingLeader?.stumpings || 0,
              unit: "stumpings",
            },
          ]}
        />
      ) : (
        <div className="dashboard-leaders-empty">
          No qualifying fielding leaders yet.
        </div>
      )
    ) : dashboardTopImpactPlayer ? (
      <DashboardLeaderShowcase
        accent="allround"
        hero={{
          eyebrow: "Impact crown",
          icon: "🌟",
          label: "Impact player",
          row: dashboardTopImpactPlayer,
          value: dashboardTopImpactPlayer.allRounderPoints,
          unit: "impact pts",
          detail: `${dashboardTopImpactPlayer.runs || 0} runs · ${dashboardTopImpactPlayer.wickets || 0} wickets · ${dashboardTopImpactPlayer.fieldingTotal || 0} fielding`,
        }}
        cards={[
          {
            icon: "⚔️",
            label: "Balanced force",
            hint: "Runs + wickets impact",
            row: dashboardBalancedForce,
            value: dashboardBalancedForce
              ? `${dashboardBalancedForce.runs}R · ${dashboardBalancedForce.wickets}W`
              : "—",
            unit: "two-way",
          },
          {
            icon: "🧩",
            label: "Three-dimensional",
            hint: "Batting + bowling + fielding",
            row: dashboardThreeDimensionalPlayer,
            value: dashboardThreeDimensionalPlayer?.allRounderPoints || 0,
            unit: "impact pts",
          },
          {
            icon: "📊",
            label: "Impact rate",
            hint: "Best impact per match · min 2",
            row: dashboardBestImpactPerMatch,
            value: dashboardBestImpactPerMatch?.impactPerMatch?.toFixed(1) || "0.0",
            unit: "pts/match",
          },
          {
            icon: "💎",
            label: "Complete package",
            hint: "Contributing disciplines",
            row: dashboardCompletePackage,
            value: dashboardCompletePackage?.disciplines || 0,
            unit: "disciplines",
          },
        ]}
      />
    ) : (
      <div className="dashboard-leaders-empty">
        No qualifying all-round leaders yet.
      </div>
    )}

    <p className="dashboard-leaders-footnote">
      Leaders use the same league Stats data and Smart Filters shown on this
      dashboard. All-Round impact follows Cric4All&apos;s existing weighting:
      runs + 25 per wicket + 10 per catch/run-out/stumping + 5 per assist.
    </p>
  </Card>
)}

{statsSubTab === "RANKINGS" && (
  <Card title="🏆 Rankings Hub">
    <div className="ranking-category-tabs">
      {Object.entries(rankingConfig).map(([key, config]) => (
        <button
          key={key}
          type="button"
          className={rankingType === key ? "active" : ""}
          onClick={() => setRankingType(key)}
        >
          <span>{config.icon}</span>
          {config.label}
        </button>
      ))}
    </div>

    {!filteredSelectedRanking.length ? (
      <p className="muted">No ranking data yet.</p>
    ) : (
      <>
        <div className="ranking-hero">
          {filteredSelectedRanking.slice(0, 3).map((row, index) => (
            <div
              key={`ranking-podium-${rankingType}-${row.playerId ?? row.playerName}-${index}`}
              className={`ranking-podium podium-${index + 1}`}
            >
              <div className="podium-rank">#{row.actualRank}</div>
              <div className="podium-avatar">{currentRankingConfig.icon}</div>
              <strong>{row.playerName}</strong>
              <small>{row.teamName}</small>
              <div className="podium-value">
                {currentRankingConfig.value(row)}
              </div>
            </div>
          ))}
        </div>

        <div className="ranking-table-header">
          <h4>
            {currentRankingConfig.icon} {currentRankingConfig.title}
          </h4>
          <span>{filteredSelectedRanking.length} players</span>
        </div>

        <div className="score-table-scroll">
          <table className="score-table sticky-first-col ranking-table">
            <thead>
              <tr>
                <th>Rank</th>
                <th>Player</th>
                <th>Team</th>
                <th>Matches</th>
                <th>Value</th>
              </tr>
            </thead>

            <tbody>
              {filteredSelectedRanking.map((row, index) => (
                <tr
                  key={`ranking-row-${rankingType}-${row.playerId ?? row.playerName}-${index}`}
                >
                  <td>
                    <strong>#{row.actualRank}</strong>
                  </td>
                  <td>{row.playerName}</td>
                  <td>{row.teamName}</td>
                  <td>{row.matches}</td>
                  <td>
                    <strong>{currentRankingConfig.value(row)}</strong>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </>
    )}
  </Card>
)}
{statsSubTab === "AWARDS" && (
  <div className="awards-engine">
    <Card title="✨ League Awards Engine">
      <div className="awards-filter-bar">
        <div
          className="awards-period-type"
          role="group"
          aria-label="Awards period"
        >
          <button
            type="button"
            disabled={
              awardsSeriesMode
            }
            title={
              awardsSeriesMode
                ? "Week and Month filters are disabled when a Series is selected."
                : "Show weekly awards"
            }
            className={
              awardsPeriodType ===
              "WEEK"
                ? "active"
                : ""
            }
            onClick={() => {
              setAwardsPeriodType(
                "WEEK"
              );
              setAwardsWeekOffset(
                0
              );
            }}
          >
            Week
          </button>

          <button
            type="button"
            disabled={
              awardsSeriesMode
            }
            title={
              awardsSeriesMode
                ? "Week and Month filters are disabled when a Series is selected."
                : "Show monthly awards"
            }
            className={
              awardsPeriodType ===
              "MONTH"
                ? "active"
                : ""
            }
            onClick={() => {
              setAwardsPeriodType(
                "MONTH"
              );
              setAwardsMonthOffset(
                0
              );
            }}
          >
            Month
          </button>
        </div>

        <label className="awards-series-filter">
          <span>
            Series
          </span>

          <select
            value={
              awardsSeriesId
            }
            onChange={(event) => {
              const nextValue =
                event.target
                  .value;

              setAwardsSeriesId(
                nextValue
              );

              /*
               * Date selectors are irrelevant in Series mode.
               */
              setAwardsWeekOffset(
                0
              );
              setAwardsMonthOffset(
                0
              );
            }}
          >
            <option value="ALL">
              All series
            </option>

            {(awardsData
              ?.availableSeries ||
              []).map(
              (series) => (
                <option
                  key={
                    series.id
                  }
                  value={
                    series.id
                  }
                >
                  {series.name}
                  {series.year
                    ? ` (${series.year})`
                    : ""}
                </option>
              )
            )}
          </select>
        </label>
      </div>

      {awardsSeriesMode && (
        <div className="awards-series-mode-note">
          <span aria-hidden="true">
            🏆
          </span>

          <p>
            <strong>
              Series mode active
            </strong>

            <small>
              Awards use every completed match in the selected Series. Week and Month filters are disabled.
            </small>
          </p>
        </div>
      )}

      <div
        className={`awards-toolbar ${
          awardsSeriesMode
            ? "series-mode"
            : ""
        }`}
      >
        <div className="awards-period">
          <button
            type="button"
            aria-label="Previous award period"
            disabled={
              awardsSeriesMode
            }
            title={
              awardsSeriesMode
                ? "Date navigation is disabled for Series awards."
                : "Previous award period"
            }
            onClick={() => {
              if (
                awardsPeriodType ===
                "MONTH"
              ) {
                setAwardsMonthOffset(
                  (current) =>
                    current - 1
                );
              } else {
                setAwardsWeekOffset(
                  (current) =>
                    current - 1
                );
              }
            }}
          >
            ←
          </button>

          <div>
            <small>
              {awardsSeriesMode
                ? "Series awards"
                : awardsPeriodType ===
                    "MONTH"
                  ? "Awards month"
                  : "Awards week"}
            </small>

            <strong>
              {awardsSeriesMode
                ? awardsData
                    ?.selectedSeries
                    ?.name ||
                  "Selected series"
                : formatAwardsPeriod(
                    awardsData
                      ?.period
                      ?.start ||
                      awardsData
                        ?.period
                        ?.weekStart,
                    awardsData
                      ?.period
                      ?.end ||
                      awardsData
                        ?.period
                        ?.weekEnd
                  )}
            </strong>
          </div>

          <button
            type="button"
            aria-label="Next week"
            disabled={
              awardsSeriesMode ||
              (
                awardsPeriodType ===
                "MONTH"
                  ? awardsMonthOffset >=
                    0
                  : awardsWeekOffset >=
                    0
              )
            }
            onClick={() => {
              if (
                awardsPeriodType ===
                "MONTH"
              ) {
                setAwardsMonthOffset(
                  (current) =>
                    Math.min(
                      0,
                      current + 1
                    )
                );
              } else {
                setAwardsWeekOffset(
                  (current) =>
                    Math.min(
                      0,
                      current + 1
                    )
                );
              }
            }}
          >
            →
          </button>
        </div>

        <div className="awards-toolbar-actions">
          {!awardsSeriesMode &&
          (
            awardsPeriodType ===
              "MONTH"
              ? awardsMonthOffset !==
                0
              : awardsWeekOffset !==
                0
          ) && (
            <button
              type="button"
              className="awards-current-week"
              onClick={() => {
                if (
                  awardsPeriodType ===
                  "MONTH"
                ) {
                  setAwardsMonthOffset(
                    0
                  );
                } else {
                  setAwardsWeekOffset(
                    0
                  );
                }
              }}
            >
              {awardsPeriodType ===
                "MONTH"
                ? "Current month"
                : "Current week"}
            </button>
          )}

          <button
            type="button"
            className="awards-refresh"
            disabled={
              awardsLoading
            }
            onClick={() =>
              loadAwards(
                activeLeagueId,
                {
                  period:
                    awardsPeriodType,

                  weekOffset:
                    awardsWeekOffset,

                  monthOffset:
                    awardsMonthOffset,

                  seriesId:
                    awardsSeriesId,
                }
              )
            }
          >
            {awardsLoading
              ? "Refreshing…"
              : "↻ Refresh"}
          </button>
        </div>
      </div>

      <div className="awards-view-tabs">
        <button
          type="button"
          className={
            awardsView ===
              "AWARDS"
              ? "active"
              : ""
          }
          onClick={() =>
            setAwardsView(
              "AWARDS"
            )
          }
        >
          🏅 Awards
        </button>

        <button
          type="button"
          className={
            awardsView ===
              "TEAM"
              ? "active"
              : ""
          }
          onClick={() =>
            setAwardsView(
              "TEAM"
            )
          }
        >
          👥 {awardsSeriesMode
            ? "Team of Series"
            : awardsPeriodType ===
                "MONTH"
              ? "Team of Month"
              : "Team of Week"}
        </button>

        <button
          type="button"
          className={
            awardsView ===
              "LEADERS"
              ? "active"
              : ""
          }
          onClick={() =>
            setAwardsView(
              "LEADERS"
            )
          }
        >
          📊 Leaders
        </button>
      </div>

      {awardsLoading &&
      !awardsData ? (
        <div className="awards-loading">
          <span>✨</span>
          Calculating league awards…
        </div>
      ) : !awardsData ? (
        <div className="awards-empty">
          Awards are not available yet.
        </div>
      ) : (
        <>
          <div className="awards-summary-strip">
            <div>
              <strong>
                {
                  awardsData
                    .counts
                    .weeklyMatches
                }
              </strong>

              <span>
                {awardsSeriesMode
                  ? "Series matches"
                  : awardsPeriodType ===
                      "MONTH"
                    ? "Matches this month"
                    : "Matches this week"}
              </span>
            </div>

            <div>
              <strong>
                {
                  awardsData
                    .counts
                    .seasonMatches
                }
              </strong>

              <span>
                Season matches
              </span>
            </div>

            <div>
              <strong>
                {
                  awardsData
                    .period
                    .seasonYear
                }
              </strong>

              <span>
                Cap season
              </span>
            </div>
          </div>

          {awardsView ===
            "AWARDS" && (
            <>
              {!awardsData
                .counts
                .weeklyMatches && (
                <div className="awards-no-week">
                  No completed matches were found for the {awardsSeriesMode ? "selected series" : awardsPeriodType === "MONTH" ? "selected month" : "selected week"}.
                </div>
              )}

              <div className="awards-grid">
                {awardsData.awards.map(
                  (
                    award,
                    index
                  ) => (
                    <article
                      key={
                        award.key
                      }
                      className={`award-card award-card-${index + 1} ${
                        award.key ===
                        "FASTEST_FIFTY"
                          ? "award-card-fastest-fifty"
                          : ""
                      } ${
                        award.available
                          ? ""
                          : "unavailable"
                      }`}
                    >
                      <div className="award-card-top">
                        <span className="award-icon">
                          {
                            award.icon
                          }
                        </span>

                        <div>
                          {award.key ===
                            "FASTEST_FIFTY" && (
                            <span className="fastest-fifty-kicker">
                              SEASON SPEED RECORD
                            </span>
                          )}
                          <small>
                            {
                              award.title
                            }
                          </small>

                          <strong>
                            {award.playerName ||
                              "Awaiting data"}
                          </strong>

                          <p>
                            {award.teamName ||
                              award.subtitle}
                          </p>
                        </div>
                      </div>

                      <div className="award-value">
                        {
                          award.value
                        }
                      </div>

                      {award.playerName &&
                        award.subtitle && (
                        <div className="award-statline">
                          {
                            award.subtitle
                          }
                        </div>
                      )}

                      <details className="award-method">
                        <summary>
                          How calculated
                        </summary>

                        <p>
                          {
                            award.explanation
                          }
                        </p>

                        {award.methodology && (
                          <p>
                            {
                              award.methodology
                            }
                          </p>
                        )}
                      </details>
                    </article>
                  )
                )}
              </div>
            </>
          )}

          {awardsView ===
            "TEAM" && (
            <div className="team-of-week-panel">
              <div className="team-of-week-heading">
                <div>
                  <span>
                    ⭐ DATA-DRIVEN XI
                  </span>

                  <h3>
                    {awardsSeriesMode
                      ? "Team of the Series"
                      : awardsPeriodType ===
                          "MONTH"
                        ? "Team of the Month"
                        : "Team of the Week"}
                  </h3>

                  <p>
                    A balanced {awardsSeriesMode ? "series" : awardsPeriodType === "MONTH" ? "monthly" : "weekly"} XI from recorded batting, bowling and fielding performances.
                  </p>
                </div>

                <strong>
                  {
                    awardsData
                      .teamOfWeek
                      .length
                  }
                  /11
                </strong>
              </div>

              {!awardsData
                .teamOfWeek
                .length ? (
                <div className="awards-empty">
                  Complete matches in the {awardsSeriesMode ? "selected series" : awardsPeriodType === "MONTH" ? "selected month" : "selected week"} to build the team award.
                </div>
              ) : (
                <div className="team-of-week-list">
                  {awardsData.teamOfWeek.map(
                    (
                      player,
                      index
                    ) => (
                      <article
                        key={`${player.playerId || player.playerName}-${index}`}
                      >
                        <span className="team-week-number">
                          {index +
                            1}
                        </span>

                        <div className="team-week-player">
                          <strong>
                            {
                              player.playerName
                            }
                          </strong>

                          <small>
                            {
                              player.teamName
                            }
                          </small>
                        </div>

                        <span className="team-week-role">
                          {
                            player.role
                          }
                        </span>

                        <div className="team-week-stats">
                          <span>
                            {
                              player.runs
                            }{" "}
                            R
                          </span>

                          <span>
                            {
                              player.wickets
                            }{" "}
                            W
                          </span>

                          <span>
                            {
                              player.fieldingTotal
                            }{" "}
                            F
                          </span>
                        </div>
                      </article>
                    )
                  )}
                </div>
              )}
            </div>
          )}

          {awardsView ===
            "LEADERS" && (
            <div className="awards-leaders-grid">
              <section>
                <header>
                  <span>
                    🏏
                  </span>

                  <div>
                    <strong>
                      {awardsSeriesMode
                        ? "Series batting"
                        : awardsPeriodType ===
                            "MONTH"
                          ? "Monthly batting"
                          : "Weekly batting"}
                    </strong>

                    <small>
                      Top five
                    </small>
                  </div>
                </header>

                {awardsData
                  .weeklyLeaders
                  .batting
                  .length ? (
                  <div className="awards-leader-list">
                    {awardsData.weeklyLeaders.batting.map(
                      (
                        player,
                        index
                      ) => (
                        <div
                          key={`award-bat-${player.playerId || player.playerName}`}
                        >
                          <b>
                            #
                            {index +
                              1}
                          </b>

                          <span>
                            <strong>
                              {
                                player.playerName
                              }
                            </strong>

                            <small>
                              {
                                player.teamName
                              }
                            </small>
                          </span>

                          <em>
                            {
                              player.runs
                            }{" "}
                            runs
                          </em>
                        </div>
                      )
                    )}
                  </div>
                ) : (
                  <p className="muted">
                    No weekly batting data.
                  </p>
                )}
              </section>

              <section>
                <header>
                  <span>
                    🎯
                  </span>

                  <div>
                    <strong>
                      {awardsSeriesMode
                        ? "Series bowling"
                        : awardsPeriodType ===
                            "MONTH"
                          ? "Monthly bowling"
                          : "Weekly bowling"}
                    </strong>

                    <small>
                      Top five
                    </small>
                  </div>
                </header>

                {awardsData
                  .weeklyLeaders
                  .bowling
                  .length ? (
                  <div className="awards-leader-list">
                    {awardsData.weeklyLeaders.bowling.map(
                      (
                        player,
                        index
                      ) => (
                        <div
                          key={`award-bowl-${player.playerId || player.playerName}`}
                        >
                          <b>
                            #
                            {index +
                              1}
                          </b>

                          <span>
                            <strong>
                              {
                                player.playerName
                              }
                            </strong>

                            <small>
                              {
                                player.teamName
                              }
                            </small>
                          </span>

                          <em>
                            {
                              player.wickets
                            }{" "}
                            wkts
                          </em>
                        </div>
                      )
                    )}
                  </div>
                ) : (
                  <p className="muted">
                    No weekly bowling data.
                  </p>
                )}
              </section>

              <section>
                <header>
                  <span>
                    🧤
                  </span>

                  <div>
                    <strong>
                      {awardsSeriesMode
                        ? "Series fielding"
                        : awardsPeriodType ===
                            "MONTH"
                          ? "Monthly fielding"
                          : "Weekly fielding"}
                    </strong>

                    <small>
                      Top five
                    </small>
                  </div>
                </header>

                {awardsData
                  .weeklyLeaders
                  .fielding
                  .length ? (
                  <div className="awards-leader-list">
                    {awardsData.weeklyLeaders.fielding.map(
                      (
                        player,
                        index
                      ) => (
                        <div
                          key={`award-field-${player.playerId || player.playerName}`}
                        >
                          <b>
                            #
                            {index +
                              1}
                          </b>

                          <span>
                            <strong>
                              {
                                player.playerName
                              }
                            </strong>

                            <small>
                              {
                                player.teamName
                              }
                            </small>
                          </span>

                          <em>
                            {
                              player.fieldingTotal
                            }{" "}
                            total
                          </em>
                        </div>
                      )
                    )}
                  </div>
                ) : (
                  <p className="muted">
                    No weekly fielding data.
                  </p>
                )}
              </section>

              <section className="season-cap-leaders">
                <header>
                  <span>
                    👑
                  </span>

                  <div>
                    <strong>
                      Season cap race
                    </strong>

                    <small>
                      Top ten
                    </small>
                  </div>
                </header>

                <div className="season-cap-columns">
                  <div>
                    <h4>
                      🟠 Orange
                    </h4>

                    {awardsData.seasonLeaders.batting.map(
                      (
                        player,
                        index
                      ) => (
                        <p
                          key={`orange-${player.playerId || player.playerName}`}
                        >
                          <b>
                            {index +
                              1}
                          </b>

                          <span>
                            {
                              player.playerName
                            }
                          </span>

                          <strong>
                            {
                              player.runs
                            }
                          </strong>
                        </p>
                      )
                    )}
                  </div>

                  <div>
                    <h4>
                      🟣 Purple
                    </h4>

                    {awardsData.seasonLeaders.bowling.map(
                      (
                        player,
                        index
                      ) => (
                        <p
                          key={`purple-${player.playerId || player.playerName}`}
                        >
                          <b>
                            {index +
                              1}
                          </b>

                          <span>
                            {
                              player.playerName
                            }
                          </span>

                          <strong>
                            {
                              player.wickets
                            }
                          </strong>
                        </p>
                      )
                    )}
                  </div>
                </div>
              </section>
            </div>
          )}
        </>
      )}
    </Card>
  </div>
)}

{statsSubTab === "CAPTAINCY" && (
  <Card title="🧢 Captaincy Records">
    {!filteredCaptaincy.length ? (
      <div className="mgmt-clean-empty">No captaincy stats yet.</div>
    ) : (
      <div className="compact-stats-list">
        {[...filteredCaptaincy]
          .sort((a, b) => {
            const aWinPct = a.winPct
              ? Number(a.winPct)
              : a.played
              ? (a.won / a.played) * 100
              : 0;

            const bWinPct = b.winPct
              ? Number(b.winPct)
              : b.played
              ? (b.won / b.played) * 100
              : 0;

            return (
              bWinPct - aWinPct ||
              (b.won || 0) - (a.won || 0) ||
              (b.played || 0) - (a.played || 0)
            );
          })
          .map((row, idx) => {
            const winPct =
              row.winPct ||
              (row.played
                ? ((row.won / row.played) * 100).toFixed(1)
                : "0.0");

            return (
              <details
                key={`league-captain-${row.playerId ?? row.playerName}-${idx}`}
                className="compact-stat-card"
              >
                <summary className="compact-stat-summary">
                  <span className="compact-rank">#{idx + 1}</span>

                  <span className="compact-player">
                    <strong>{row.playerName}</strong>
                    <small>{row.teamName}</small>
                  </span>

                  <span className="compact-highlight">
                    <strong>{winPct}%</strong>
                    <small>Win</small>
                  </span>

                  <span className="compact-toggle">⌄</span>
                </summary>

                <div className="compact-stat-grid">
                  <span>M {row.played}</span>
                  <span>Won {row.won}</span>
                  <span>Lost {row.lost}</span>
                  <span>Win % {winPct}</span>
                </div>
              </details>
            );
          })}
      </div>
    )}
  </Card>
)}
{statsSubTab === "WICKETKEEPING" && (
  <Card title="🧤 Wicketkeeping Records">
    {!filteredWicketkeeping.length ? (
      <div className="mgmt-clean-empty">No wicketkeeping stats yet.</div>
    ) : (
      <div className="compact-stats-list">
        {[...filteredWicketkeeping]
          .sort(
            (a, b) =>
              (b.dismissals || 0) - (a.dismissals || 0) ||
              (b.catches || 0) - (a.catches || 0) ||
              (b.stumpings || 0) - (a.stumpings || 0) ||
              (b.runOuts || 0) - (a.runOuts || 0)
          )
          .map((row, idx) => (
            <details
              key={`league-keeper-${row.playerId ?? row.playerName}-${idx}`}
              className="compact-stat-card"
            >
              <summary className="compact-stat-summary">
                <span className="compact-rank">#{idx + 1}</span>

                <span className="compact-player">
                  <strong>{row.playerName}</strong>
                  <small>{row.teamName}</small>
                </span>

                <span className="compact-highlight">
                  <strong>{row.dismissals}</strong>
                  <small>Total</small>
                </span>

                <span className="compact-toggle">⌄</span>
              </summary>

              <div className="compact-stat-grid">
                <span>Catches {row.catches}</span>
                <span>Stumpings {row.stumpings}</span>
                <span>Run Outs {row.runOuts}</span>
                <span>Total {row.dismissals}</span>
              </div>
            </details>
          ))}
      </div>
    )}
  </Card>
)}
      </>
    )}
  </div>
)}
{activeTab === "permissions" && (
 <div className="scoring-layout">
      {/* MEMBER LIST */}
<Card title="👥 League Permissions">

  {!activeLeague && (
    <p>Select a league first.</p>
  )}

  {activeLeague && (
    <>
<div
  style={{
    padding: "16px",
    borderRadius: 12,
    border: "1px solid #93c5fd",
    marginBottom: 15,
  }}
>
  <h3
    style={{
      margin: 0,
      fontWeight: 700,
      fontSize: "1.1rem",
    }}
  >
    🔗 Invite Members to{" "}
    <span
      style={{
      }}
    >
      {activeLeague.name}
    </span>
  </h3>

  <div
    style={{
      marginTop: 8,
      fontSize: 14,
      lineHeight: 1.5,
    }}
  >
    Generate a registration link and share it
    with players, captains, scorers, and
    league administrators.
  </div>

  <div style={{ marginTop: 12 }}>
    {allowedInviteRolesForCurrentUser.length > 0 ? (
      <button
        type="button"
        className="btn"
        disabled={!activeLeague}
        onClick={openInviteRoleComposer}
      >
        🔗 Create Role Invite
      </button>
    ) : (
      <div className="permission-warning" style={{ margin: 0 }}>
        🔒 Your current league role cannot create member invitation links.
      </div>
    )}
  </div>
</div>
      <label>
        <strong>Member</strong>
      </label>
 <select
  value={selectedMember?.id || ""}
  onChange={(e) => {
    const member =
      activeLeague.members.find(
        (m) =>
          m.id === Number(e.target.value)
      );

    setSelectedMember(member);
    setShowPermissionModal(false);
  }}
>
        <option value="">
          Select Member
        </option>

        {activeLeague.members?.map(
          (member) => (
            <option
              key={member.id}
              value={member.id}
            >
              {member.user?.name} (
              {member.role})
            </option>
          )
        )}
      </select>
{!activeLeague?.members?.length && (
  <div
    style={{
      padding: 12,
      border: "1px solid #ddd",
      borderRadius: 8
    }}
  >
    No members found for this league.
  </div>
)}
{selectedMember && (
        <>
          <div
            style={{
              padding: 16,
              border: "1px solid #ddd",
              borderRadius: 8,
              marginBottom: 20,
            }}
          >
            <h3>
              {selectedMember.user?.name}
            </h3>

            <div
              style={{
                color: "#666",
                marginBottom: 15,
              }}
            >
              {selectedMember.user?.email}
            </div>

            <label>
              <strong>Role</strong>
            </label>

            <select
              value={memberPermissions?.role || selectedMember.role || "VIEWER"}
              onChange={(e) =>
                updatePermission("role", e.target.value)
              }
              style={{
                width: "100%",
                marginTop: 8,
                marginBottom: 15,
              }}
            >
              <option value="OWNER">
                Owner
              </option>
              <option value="ADMIN">
                Admin
              </option>
              <option value="CAPTAIN">
                Captain
              </option>
              <option value="SCORER">
                Scorer
              </option>
              <option value="VIEWER">
                Viewer
              </option>
            </select>

            <div className="member-management-actions">
              <button
                className="btn"
                onClick={() =>
                  loadPermissions(
                    selectedMember
                  )
                }
              >
                🔐 Edit Permissions
              </button>

              {canUnregisterLeagueMembers &&
                String(
                  selectedMember.userId ||
                    ""
                ) !==
                  String(
                    activeLeague.ownerId ||
                      ""
                  ) && (
                  <button
                    type="button"
                    className="member-unregister-btn"
                    disabled={
                      Number(
                        unregisteringMemberId
                      ) ===
                      Number(
                        selectedMember.id
                      )
                    }
                    onClick={() =>
                      handleUnregisterLeagueMember(
                        selectedMember
                      )
                    }
                  >
                    {Number(
                      unregisteringMemberId
                    ) ===
                    Number(
                      selectedMember.id
                    )
                      ? "Unregistering…"
                      : "🚪 Unregister from League"}
                  </button>
                )}
            </div>
          </div>
        </>
      )}
    </>
  )}

</Card>

 {/* MEMBER PERMISSIONS */}
{showPermissionModal && selectedMember && (
  <Card
    title={`🔐 Permissions - ${
      selectedMember.user?.name ||
      selectedMember.user?.email
    }`}
  >
    <div className="permissions-grid">

      <label className="permission-item">
        <input
          type="checkbox"
          checked={memberPermissions?.canViewManagement ?? false}
          onChange={(e) =>
            updatePermission(
              "canViewManagement",
              e.target.checked
            )
          }
        />
        <span>View Management</span>
      </label>
      
      <label className="permission-item">
        <input
          type="checkbox"
          checked={memberPermissions?.canViewDashboard ?? false}
          onChange={(e) =>
            updatePermission(
              "canViewDashboard",
              e.target.checked
            )
          }
        />
        <span>View Dashboard</span>
      </label>

      <label className="permission-item">
        <input
          type="checkbox"
          checked={memberPermissions?.canViewMatches ?? false}
          onChange={(e) =>
            updatePermission(
              "canViewMatches",
              e.target.checked
            )
          }
        />
        <span>View Matches</span>
      </label>

      <label className="permission-item">
        <input
          type="checkbox"
          checked={memberPermissions?.canViewScoring ?? false}
          onChange={(e) =>
            updatePermission(
              "canViewScoring",
              e.target.checked
            )
          }
        />
        <span>View Scoring</span>
      </label>

      <label className="permission-item">
        <input
          type="checkbox"
          checked={memberPermissions?.canViewStats ?? false}
          onChange={(e) =>
            updatePermission(
              "canViewStats",
              e.target.checked
            )
          }
        />
        <span>View Stats</span>
      </label>


      <label className="permission-item">
        <input
          type="checkbox"
          checked={memberPermissions?.canCreateMatch ?? false}
          onChange={(e) =>
            updatePermission(
              "canCreateMatch",
              e.target.checked
            )
          }
        />
        <span>Create Match</span>
      </label>
      
      <label className="permission-item">
        <input
          type="checkbox"
          checked={memberPermissions?.canEditMatch ?? false}
          onChange={(e) =>
            updatePermission(
              "canEditMatch",
              e.target.checked
            )
          }
        />
        <span>Edit Match</span>
      </label>

      <label className="permission-item">
        <input
          type="checkbox"
          checked={memberPermissions?.canDeleteMatch ?? false}
          onChange={(e) =>
            updatePermission(
              "canDeleteMatch",
              e.target.checked
            )
          }
        />
        <span>Delete Match</span>
      </label>

      <label className="permission-item">
        <input
          type="checkbox"
          checked={memberPermissions?.canScoreMatch ?? false}
          onChange={(e) =>
            updatePermission(
              "canScoreMatch",
              e.target.checked
            )
          }
        />
        <span>Score Match</span>
      </label>

      <label className="permission-item">
        <input
          type="checkbox"
          checked={memberPermissions?.canEditScore ?? false}
          onChange={(e) =>
            updatePermission(
              "canEditScore",
              e.target.checked
            )
          }
        />
        <span>Edit Score</span>
      </label>

      <label className="permission-item">
        <input
          type="checkbox"
          checked={memberPermissions?.canUndoBall ?? false}
          onChange={(e) =>
            updatePermission(
              "canUndoBall",
              e.target.checked
            )
          }
        />
        <span>Undo Ball</span>
      </label>

      <label className="permission-item">
        <input
          type="checkbox"
          checked={memberPermissions?.canSwapStrike ?? false}
          onChange={(e) =>
            updatePermission(
              "canSwapStrike",
              e.target.checked
            )
          }
        />
        <span>Swap Strike</span>
      </label>

      <label className="permission-item">
        <input
          type="checkbox"
          checked={memberPermissions?.canRetirePlayer ?? false}
          onChange={(e) =>
            updatePermission(
              "canRetirePlayer",
              e.target.checked
            )
          }
        />
        <span>Retire Player</span>
      </label>

        <label className="permission-item">
        <input
          type="checkbox"
          checked={memberPermissions?.canCreateTeam ?? false}
          onChange={(e) =>
            updatePermission(
              "canCreateTeam",
              e.target.checked
            )
          }
        />
        <span>Create Team</span>
      </label>

        <label className="permission-item">
        <input
          type="checkbox"
          checked={memberPermissions?.canEditTeam ?? false}
          onChange={(e) =>
            updatePermission(
              "canEditTeam",
              e.target.checked
            )
          }
        />
        <span>Edit Team</span>
      </label>

        <label className="permission-item">
        <input
          type="checkbox"
          checked={memberPermissions?.canDeleteTeam ?? false}
          onChange={(e) =>
            updatePermission(
              "canDeleteTeam",
              e.target.checked
            )
          }
        />
        <span>Delete Team</span>
      </label>

        <label className="permission-item">
        <input
          type="checkbox"
          checked={memberPermissions?.canCreatePlayer ?? false}
          onChange={(e) =>
            updatePermission(
              "canCreatePlayer",
              e.target.checked
            )
          }
        />
        <span>Create Player</span>
      </label>

        <label className="permission-item">
        <input
          type="checkbox"
          checked={memberPermissions?.canDeletePlayer ?? false}
          onChange={(e) =>
            updatePermission(
              "canDeletePlayer",
              e.target.checked
            )
          }
        />
        <span>Delete Player</span>
      </label>

        <label className="permission-item">
        <input
          type="checkbox"
          checked={memberPermissions?.canEditPlayer ?? false}
          onChange={(e) =>
            updatePermission(
              "canEditPlayer",
              e.target.checked
            )
          }
        />
        <span>Edit Player</span>
      </label>    

        <label className="permission-item">
        <input
          type="checkbox"
          checked={memberPermissions?.canCreateLeague ?? false}
          onChange={(e) =>
            updatePermission(
              "canCreateLeague",
              e.target.checked
            )
          }
        />
        <span>Create League</span>
      </label>  

        <label className="permission-item">
        <input
          type="checkbox"
          checked={memberPermissions?.canEditLeague ?? false}
          onChange={(e) =>
            updatePermission(
              "canEditLeague",
              e.target.checked
            )
          }
        />
        <span>Edit League</span>
      </label>  

        <label className="permission-item">
        <input
          type="checkbox"
          checked={memberPermissions?.canDeleteLeague ?? false}
          onChange={(e) =>
            updatePermission(
              "canDeleteLeague",
              e.target.checked
            )
          }
        />
        <span>Delete League</span>
      </label>  

        <label className="permission-item">
        <input
          type="checkbox"
          checked={memberPermissions?.canEndMatch ?? false}
          onChange={(e) =>
            updatePermission(
              "canEndMatch",
              e.target.checked
            )
          }
        />
        <span>End Match</span>
      </label>  

        <label className="permission-item">
        <input
          type="checkbox"
          checked={memberPermissions?.canAbandonMatch ?? false}
          onChange={(e) =>
            updatePermission(
              "canAbandonMatch",
              e.target.checked
            )
          }
        />
        <span>Abandon Match</span>
      </label>  

        <label className="permission-item">
        <input
          type="checkbox"
          checked={memberPermissions?.canLockMatch ?? false}
          onChange={(e) =>
            updatePermission(
              "canLockMatch",
              e.target.checked
            )
          }
        />
        <span>Lock Match</span>
      </label>  

        <label className="permission-item">
        <input
          type="checkbox"
          checked={memberPermissions?.canManageMembers ?? false}
          onChange={(e) =>
            updatePermission(
              "canManageMembers",
              e.target.checked
            )
          }
        />
        <span>Manage Members</span>
      </label>  

        <label className="permission-item">
        <input
          type="checkbox"
          checked={memberPermissions?.canManagePermissions ?? false}
          onChange={(e) =>
            updatePermission(
              "canManagePermissions",
              e.target.checked
            )
          }
        />
        <span>Manage Permissions</span>
      </label>  


    </div>

    <div className="permission-actions">
      <button
        className="btn"
        onClick={() => savePermissions(selectedMember)}
      >
        💾 Save Permissions
      </button>
    </div>

  </Card>
)}
    </div>
)}
{activeTab === "help" && (
  <Card title="❓ Cric4All Help Center">
    <div className="help-page">
      <div className="help-hero">
        <div>
          <h2>🏏 Welcome to Cric4All</h2>

          <p>
            Find practical guidance for league setup, live and offline scoring,
            DLS/rain workflows, AI tools, public sharing, permissions,
            birthdays, and team-kit custody.
          </p>
        </div>
      </div>

      {/* ============================================================
          EXPLORE HELP NAVIGATION
          - clear navigation title
          - responsive grid, NOT horizontal scrolling
          - readable on phone and laptop
          ============================================================ */}
      <div
        style={{
          marginBottom: 18,
          padding: 14,
          borderRadius: 16,
          border: "1px solid rgba(148, 163, 184, 0.18)",
          background: "rgba(15, 23, 42, 0.68)",
        }}
      >
        <div
          style={{
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
            gap: 10,
            marginBottom: 10,
            flexWrap: "wrap",
          }}
        >
          <div>
            <strong
              style={{
                display: "block",
                fontSize: 15,
                lineHeight: 1.2,
              }}
            >
              🧭 Explore Help
            </strong>

            <span
              style={{
                display: "block",
                marginTop: 3,
                fontSize: 12,
                opacity: 0.72,
                lineHeight: 1.35,
              }}
            >
              Choose a topic to jump directly to that section.
            </span>
          </div>
        </div>

        <div
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(auto-fit, minmax(132px, 1fr))",
            gap: 8,
          }}
        >
          {[
            ["help-new", "✨ What’s New"],
            ["help-start", "🚀 Quick Start"],
            ["help-scoring", "⚡ Scoring"],
            ["help-offline", "📴 Offline"],
            ["help-dls", "🌧 DLS & Par"],
            ["help-kit", "🎒 Team Kit"],
            ["help-ai", "🤖 AI"],
            ["help-tabs", "🧭 Main Tabs"],
            ["help-public", "🌐 Public"],
            ["help-admin", "🛡 Admin"],
            ["help-faq", "❓ FAQ"],
          ].map(([id, label]) => (
            <a
              key={id}
              href={`#${id}`}
              style={{
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                minHeight: 42,
                padding: "9px 10px",
                borderRadius: 11,
                border: "1px solid rgba(96, 165, 250, 0.24)",
                background: "rgba(30, 41, 59, 0.72)",
                textDecoration: "none",
                color: "inherit",
                fontSize: 13,
                fontWeight: 800,
                lineHeight: 1.2,
                textAlign: "center",
                whiteSpace: "normal",
                overflowWrap: "anywhere",
              }}
            >
              {label}
            </a>
          ))}
        </div>
      </div>

      <section id="help-new">
        <h3 className="help-section-title">✨ What&apos;s New in Cric4All</h3>

        <div className="help-grid">
          <div className="help-card">
            <h3>📴 Offline Scoring + Auto Sync</h3>
            <p>
              Keep scoring when connectivity drops. Supported scoring actions
              are stored locally and synchronize when the connection returns.
            </p>
          </div>

          <div className="help-card">
            <h3>🔄 Sync Conflict Protection</h3>
            <p>
              If server state changes while a device is offline, Cric4All
              pauses synchronization instead of discarding local scoring.
              Use <strong>Retry Sync</strong> after reviewing the match state.
            </p>
          </div>

          <div className="help-card">
            <h3>↩️ Offline Undo</h3>
            <p>
              Unsynced local deliveries can be undone safely, with snapshot
              support for compatible reconnect-undo scenarios.
            </p>
          </div>

          <div className="help-card">
            <h3>🌧 Cric4All Standard DLS</h3>
            <p>
              Standard rain adjustments can be applied at legal-delivery
              boundaries such as 3.1 through 3.5 using interpolation between
              adjacent Standard resource-table rows.
            </p>
          </div>

          <div className="help-card">
            <h3>📐 Official DLS Workflow</h3>
            <p>
              Official DLS separates <strong>Revise &amp; Resume</strong> from{" "}
              <strong>End Match Now</strong>, so target and par are entered only
              when they are actually needed.
            </p>
          </div>

          <div className="help-card">
            <h3>📊 Cric4All Chase Par</h3>
            <p>
              During innings 2, Cric4All can show a tactical par such as{" "}
              <strong>Par: 18 runs · ▲ +4 ahead</strong>. It is not Official DLS.
            </p>
          </div>

          <div className="help-card">
            <h3>🤖 Faster, DLS-Aware AI Review</h3>
            <p>
              AI Review opens immediately with an in-modal loading state and
              respects Cric4All&apos;s authoritative DLS-aware final result.
            </p>
          </div>

          <div className="help-card">
            <h3>🎒 Post-Match Kit Follow-Up</h3>
            <p>
              The final-kit-holder prompt can appear over Scorer Mode when the
              match finishes, with Lock Match acting as a safe fallback if the
              prompt was missed.
            </p>
          </div>
        </div>
      </section>

      <details id="help-start" open style={{ marginTop: 18 }}>
        <summary
          className="help-section-title"
          style={{
            cursor: "pointer",
            listStyle: "none",
            userSelect: "none",
          }}
        >
          🚀 Quick Start Guide
        </summary>

        <div className="help-grid" style={{ marginTop: 12 }}>
          <div className="help-card">
            <h3>🏆 Step 1</h3>
            <h4>Create or Select League</h4>
            <p>
              Open <strong>Leagues</strong> and choose the active league.
              Teams, players, matches, permissions, stats, AI tools, birthdays,
              and kit workflows are league-scoped.
            </p>
          </div>

          <div className="help-card">
            <h3>✅ Step 2</h3>
            <h4>Complete Minimum Setup</h4>
            <p>
              Create at least two teams and add enough players for the intended
              match format before starting a game.
            </p>
          </div>

          <div className="help-card">
            <h3>🌐 Step 3</h3>
            <h4>Choose Visibility</h4>
            <p>
              Use <strong>Private</strong>, <strong>Unlisted</strong>, or{" "}
              <strong>Public</strong> depending on who should be able to view the league.
            </p>
          </div>

          <div className="help-card">
            <h3>📅 Step 4</h3>
            <h4>Create Series / Season</h4>
            <p>
              Series are optional. Use them for tournaments, cups, seasons,
              divisions, or years.
            </p>
          </div>

          <div className="help-card">
            <h3>👥 Step 5</h3>
            <h4>Add Teams &amp; Players</h4>
            <p>
              Add teams first, then add players manually, in bulk, or through
              supported import tools.
            </p>
          </div>

          <div className="help-card">
            <h3>📋 Step 6</h3>
            <h4>Create / Schedule Match</h4>
            <p>
              Configure overs, powerplay, wickets, bowler limits, captains,
              wicketkeepers, date/time, and optional series.
            </p>
          </div>

          <div className="help-card">
            <h3>▶ Step 7</h3>
            <h4>Start Match</h4>
            <p>
              From Scheduled, select Start Match, confirm batting first,
              complete delivery setup, and begin scoring.
            </p>
          </div>

          <div className="help-card">
            <h3>📤 Step 8</h3>
            <h4>Share With Spectators</h4>
            <p>
              Use Share - Spectator View to send a live score link with Cric4All branding.
            </p>
          </div>
        </div>
      </details>

      <details id="help-scoring" style={{ marginTop: 18 }}>
        <summary className="help-section-title" style={{ cursor: "pointer", listStyle: "none", userSelect: "none" }}>
          ⚡ Scorer Mode &amp; Live Scoring
        </summary>

        <div className="help-grid" style={{ marginTop: 12 }}>
          <div className="help-card">
            <h3>🎯 Quick Buttons</h3>
            <p>
              Record runs, extras, wickets, retired hurt, striker swaps, and
              undo from the focused match-day workspace.
            </p>
          </div>

          <div className="help-card">
            <h3>🏏 Delivery Setup</h3>
            <p>
              Select striker, non-striker, and bowler before scoring starts and
              again when required by innings/over transitions.
            </p>
          </div>

          <div className="help-card">
            <h3>🎯 Bowler Change</h3>
            <p>
              Choose the next bowler at over completion while Cric4All protects
              against invalid consecutive-over choices.
            </p>
          </div>

          <div className="help-card">
            <h3>🧤 Wicketkeeper Change</h3>
            <p>
              Authorized scorers can change the wicketkeeper without reopening
              the same picker after the change is saved.
            </p>
          </div>

          <div className="help-card">
            <h3>🔄 SWAP / RTD / WKT</h3>
            <p>
              Striker and non-striker state stays synchronized for wickets,
              retired-hurt flows, and manual strike swaps.
            </p>
          </div>

          <div className="help-card">
            <h3>📊 Live Match Center</h3>
            <p>
              View score, overs, CRR, target, need, balls remaining, current
              batters, bowler, partnership, recent balls, and chase indicators.
            </p>
          </div>
        </div>
      </details>

      <details id="help-offline" style={{ marginTop: 18 }}>
        <summary className="help-section-title" style={{ cursor: "pointer", listStyle: "none", userSelect: "none" }}>
          📴 Offline Scoring &amp; Automatic Sync
        </summary>

        <div className="help-grid" style={{ marginTop: 12 }}>
          <div className="help-card">
            <h3>📴 Continue Offline</h3>
            <p>
              Supported scoring actions are saved locally on the active device
              when connectivity is unavailable.
            </p>
          </div>

          <div className="help-card">
            <h3>🔵 Automatic Sync</h3>
            <p>
              Pending events synchronize when connectivity returns using
              sequence and client-event safeguards.
            </p>
          </div>

          <div className="help-card">
            <h3>🔴 Sync Conflict</h3>
            <p>
              A conflict means the server changed while this device was offline.
              Cric4All pauses sync instead of silently overwriting newer state.
            </p>
          </div>

          <div className="help-card">
            <h3>🔄 Retry Sync</h3>
            <p>
              Retry synchronization after connectivity and server state are stable.
            </p>
          </div>

          <div className="help-card">
            <h3>↩️ Offline Undo</h3>
            <p>
              Remove pending local deliveries safely before they are synchronized.
            </p>
          </div>

          <div className="help-card">
            <h3>🔒 Lock Requires Sync</h3>
            <p>
              Match Lock stays unavailable while offline changes remain pending,
              sync is running, the browser is offline, or a conflict remains.
            </p>
          </div>
        </div>
      </details>

      <details id="help-dls" style={{ marginTop: 18 }}>
        <summary className="help-section-title" style={{ cursor: "pointer", listStyle: "none", userSelect: "none" }}>
          🌧 Rain, DLS &amp; Cric4All Par
        </summary>

        <div className="help-grid" style={{ marginTop: 12 }}>
          <div className="help-card">
            <h3>🌧 Cric4All Standard</h3>
            <p>
              Built-in rain adjustment based on the published Standard resource
              table. It remains separate from Official DLS.
            </p>
          </div>

          <div className="help-card">
            <h3>🏏 Mid-Over Interruptions</h3>
            <p>
              Standard mode supports legal-delivery points such as 3.1–3.5
              through interpolation.
            </p>
          </div>

          <div className="help-card">
            <h3>📉 Revised Overs</h3>
            <p>
              Enter the new <strong>total innings allocation</strong>, not overs remaining.
            </p>
          </div>

          <div className="help-card">
            <h3>🎯 Par vs Target</h3>
            <p>
              Par is the tie/equivalent score; target is the score required to win.
            </p>
          </div>

          <div className="help-card">
            <h3>📊 Cric4All Chase Par</h3>
            <p>
              Tactical innings-planning indicator. It is not an Official DLS Par.
            </p>
          </div>

          <div className="help-card">
            <h3>▶ Official DLS — Revise &amp; Resume</h3>
            <p>
              Use when play will continue. Enter revised allocation and revised
              target supplied by the authorized DLS source.
            </p>
          </div>

          <div className="help-card">
            <h3>🏁 Official DLS — End Match Now</h3>
            <p>
              Use when play cannot resume. Enter official target and official par
              at the exact suspension point.
            </p>
          </div>

          <div className="help-card">
            <h3>🏆 DLS Result Labels</h3>
            <p>
              Final rain-adjusted results retain a D/L Standard or DLS label.
            </p>
          </div>
        </div>
      </details>

      <details id="help-kit" style={{ marginTop: 18 }}>
        <summary className="help-section-title" style={{ cursor: "pointer", listStyle: "none", userSelect: "none" }}>
          🎂 Birthdays &amp; 🎒 Team Kit Custody
        </summary>

        <div className="help-grid" style={{ marginTop: 12 }}>
          <div className="help-card">
            <h3>🎂 Birthday Setup</h3>
            <p>
              Keep birthday, phone, league, and consent information current.
            </p>
          </div>

          <div className="help-card">
            <h3>🎒 Current Kit Holder</h3>
            <p>
              The confirmed current holder remains separate from any suggested future carrier.
            </p>
          </div>

          <div className="help-card">
            <h3>✨ Fair Next Carrier</h3>
            <p>
              Suggestions favor eligible players with the lowest completed rotation count.
            </p>
          </div>

          <div className="help-card">
            <h3>✅ Record Actual Holder</h3>
            <p>
              After the match, confirm who actually took the kit. Only the recorded
              holder receives completed rotation credit.
            </p>
          </div>

          <div className="help-card">
            <h3>🏁 Post-Match Popup</h3>
            <p>
              Final-holder confirmation can appear over Scorer Mode when the match finishes.
            </p>
          </div>

          <div className="help-card">
            <h3>🔒 Lock Fallback</h3>
            <p>
              If the prompt was missed, Lock Match can safely surface the custody workflow.
            </p>
          </div>

          <div className="help-card">
            <h3>⏰ Kit Reminders</h3>
            <p>
              Configured pre-match reminders are sent to the confirmed current holder,
              not merely to a suggested future carrier.
            </p>
          </div>

          <div className="help-card">
            <h3>🕘 Custody History</h3>
            <p>
              Actual holder changes, corrections, and reminder activity are retained separately
              from live suggestions.
            </p>
          </div>
        </div>
      </details>

      <details id="help-ai" style={{ marginTop: 18 }}>
        <summary className="help-section-title" style={{ cursor: "pointer", listStyle: "none", userSelect: "none" }}>
          🤖 AI Team Builder, Strategy &amp; Match Review
        </summary>

        <div className="help-grid" style={{ marginTop: 12 }}>
          <div className="help-card">
            <h3>🧠 AI Team Builder</h3>
            <p>Build balanced sides from selected players using available player statistics.</p>
          </div>

          <div className="help-card">
            <h3>✅ Availability Polls</h3>
            <p>Confirm player availability before generating the match-day pool.</p>
          </div>

          <div className="help-card">
            <h3>📷 Player Import</h3>
            <p>Import player names from supported screenshots, files, and spreadsheets.</p>
          </div>

          <div className="help-card">
            <h3>🎯 Single Team Strategy</h3>
            <p>Generate batting order, bowling plan, roles, scenarios, and confidence guidance.</p>
          </div>

          <div className="help-card">
            <h3>✨ AI Match Review</h3>
            <p>Review summary, MVP, turning points, momentum, partnerships, and team takeaways.</p>
          </div>

          <div className="help-card">
            <h3>🌧 AI Review + DLS</h3>
            <p>
              AI Review uses Cric4All&apos;s authoritative DLS-aware result rather than
              comparing raw innings totals.
            </p>
          </div>
        </div>
      </details>

      <details id="help-tabs" style={{ marginTop: 18 }}>
        <summary className="help-section-title" style={{ cursor: "pointer", listStyle: "none", userSelect: "none" }}>
          🧭 Main Tabs &amp; Match History
        </summary>

        <div className="help-grid" style={{ marginTop: 12 }}>
          <div className="help-card"><h3>🏆 Leagues</h3><p>Manage leagues, series, teams, players, visibility, links, roles, and permissions.</p></div>
          <div className="help-card"><h3>📋 Matches</h3><p>Use Create, Active, Scheduled, Completed, and authorized Kit workflows.</p></div>
          <div className="help-card"><h3>⚡ Completed History</h3><p>Completed history renders progressively for better performance.</p></div>
          <div className="help-card"><h3>📊 Faster Scorecards</h3><p>Completed scorecards open with fewer duplicate or unnecessary requests.</p></div>
          <div className="help-card"><h3>🥇 Points</h3><p>Track played, wins, losses, ties, points, and standings.</p></div>
          <div className="help-card"><h3>📊 Stats</h3><p>View batting, bowling, fielding, rankings, leaders, strike rate, and economy.</p></div>
          <div className="help-card"><h3>🔐 Access</h3><p>Configure league roles, permissions, and team scope.</p></div>
          <div className="help-card"><h3>🛡 Admin</h3><p>Authorized owners can review user activity, login history, and audit logs.</p></div>
        </div>
      </details>

      <details id="help-public" style={{ marginTop: 18 }}>
        <summary className="help-section-title" style={{ cursor: "pointer", listStyle: "none", userSelect: "none" }}>
          🌐 Public Leagues &amp; Spectator Experience
        </summary>

        <div className="help-grid" style={{ marginTop: 12 }}>
          <div className="help-card"><h3>🔒 Private</h3><p>Visible only to authorized members.</p></div>
          <div className="help-card"><h3>🔗 Unlisted</h3><p>Public by direct link without Explore discovery.</p></div>
          <div className="help-card"><h3>🌐 Public</h3><p>Can appear in Explore.</p></div>
          <div className="help-card"><h3>🧭 Explore</h3><p>Discover supported public leagues.</p></div>
          <div className="help-card"><h3>⭐ Followed Leagues</h3><p>Return quickly to leagues a user follows.</p></div>
          <div className="help-card"><h3>📤 Spectator View</h3><p>Share a live match link with score and Cric4All branding.</p></div>
        </div>
      </details>

      <details id="help-admin" style={{ marginTop: 18 }}>
        <summary className="help-section-title" style={{ cursor: "pointer", listStyle: "none", userSelect: "none" }}>
          🛡 Admin, Roles &amp; Data Integrity
        </summary>

        <div className="help-grid" style={{ marginTop: 12 }}>
          <div className="help-card"><h3>🟢 Online Users</h3><p>Review current user activity where authorized.</p></div>
          <div className="help-card"><h3>🕒 Recent Logins</h3><p>Review recent access history.</p></div>
          <div className="help-card"><h3>📜 Audit Logs</h3><p>Trace important league, match, access, and correction actions.</p></div>
          <div className="help-card"><h3>🔐 Data Integrity</h3><p>Offline guards, event IDs, locks, and audit history help protect score integrity.</p></div>
        </div>
      </details>

      <div className="help-tip-box" style={{ marginTop: 20 }}>
        <h3>💡 Match-Day Pro Tips</h3>
        <ul>
          <li>Use Scorer Mode during live play to minimize scrolling.</li>
          <li>Keep scoring on the same active device while offline.</li>
          <li>Sync before handing scoring control to another device.</li>
          <li>Cric4All Chase Par is tactical guidance, not Official DLS.</li>
          <li>Use authorized Official DLS values rather than guessing.</li>
          <li>Resolve final kit custody before finalizing match administration.</li>
          <li>Use Smart Filters when match history or statistics grow large.</li>
        </ul>
      </div>

      <section id="help-faq" style={{ marginTop: 20 }}>
        <h3 className="help-section-title">❓ Frequently Asked Questions</h3>

        <div className="help-faq" style={{ display: "grid", gap: 8 }}>
          {[
            ["Can I score without internet?", <>Yes. Supported scoring actions can continue locally and synchronize later.</>],
            ["What does Sync Conflict mean?", <>The server changed while your device was offline. Sync pauses to protect both versions of the match state.</>],
            ["Can I undo while offline?", <>Yes for pending local deliveries and supported snapshot-backed cases.</>],
            ["Why can’t I Lock Match?", <>All offline changes must be synchronized and no sync conflict can remain.</>],
            ["What does Cric4All Par mean?", <>It is the current tactical chase par in runs. “+4 ahead” means the batting side is four runs above that tactical par.</>],
            ["Is Cric4All Par Official DLS?", <>No. Cric4All Chase Par is a strategy indicator, not an Official DLS par.</>],
            ["Why are DLS Par and Target different?", <>Par represents the tie/equivalent score; target is the score required to win.</>],
            ["Can Cric4All Standard work at 3.3 overs?", <>Yes. Standard mode supports legal-delivery positions such as 3.1–3.5 using interpolation.</>],
            ["Where do Official DLS values come from?", <>From the competition&apos;s authorized DLS source/calculator and match officials.</>],
            ["Why does AI Review take longer the first time?", <>A new review may require analysis/generation. The modal opens while it is being prepared, and current reviews can be cached.</>],
            ["Does AI Review understand DLS?", <>Yes. It respects Cric4All&apos;s authoritative DLS-aware match result.</>],
            ["Where do I record the final kit holder?", <>Use the post-match prompt or open <strong>Matches → Kit</strong>.</>],
          ].map(([question, answer]) => (
            <details
              key={question}
              style={{
                border: "1px solid rgba(148, 163, 184, 0.16)",
                borderRadius: 12,
                padding: "10px 12px",
              }}
            >
              <summary
                style={{
                  cursor: "pointer",
                  fontWeight: 800,
                  lineHeight: 1.35,
                }}
              >
                {question}
              </summary>

              <div
                style={{
                  marginTop: 8,
                  lineHeight: 1.55,
                  overflowWrap: "anywhere",
                }}
              >
                {answer}
              </div>
            </details>
          ))}
        </div>
      </section>
    </div>
  </Card>
)}
{activeTab === "about" && (
  <Card title="ℹ️ About Cric4All">
    <div className="about-page">
      <div className="about-hero">
        <div>
          <div className="about-kicker">🏏 Built for real cricket communities</div>

          <h2>🏏 Cric4All</h2>

          <p>
            A connected cricket platform for organizing leagues, scoring matches,
            handling match-day interruptions, sharing live cricket, understanding
            performance, and keeping community operations in one place.
          </p>

          <div className="release-badge-row">
            <span className="release-badge">Live + Offline Scoring</span>
            <span className="release-badge">Rain / DLS</span>
            <span className="release-badge">AI-Powered</span>
            <span className="release-badge">Public Spectator View</span>
            <span className="release-badge">League Operations</span>
            <span className="release-badge">Android Ready</span>
          </div>
        </div>
      </div>

      {/* ============================================================
          EXPLORE CRIC4ALL NAVIGATION
          - not a tiny pill strip
          - grid is self-evident on mobile
          ============================================================ */}
      <div
        style={{
          marginBottom: 18,
          padding: 14,
          borderRadius: 16,
          border: "1px solid rgba(148, 163, 184, 0.18)",
          background: "rgba(15, 23, 42, 0.68)",
        }}
      >
        <div style={{ marginBottom: 10 }}>
          <strong style={{ display: "block", fontSize: 15, lineHeight: 1.2 }}>
            🧭 Explore Cric4All
          </strong>

          <span
            style={{
              display: "block",
              marginTop: 3,
              fontSize: 12,
              opacity: 0.72,
              lineHeight: 1.35,
            }}
          >
            A quick look at the platform and what makes it different.
          </span>
        </div>

        <div
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(auto-fit, minmax(145px, 1fr))",
            gap: 8,
          }}
        >
          {[
            ["about-mission", "🎯 Mission"],
            ["about-journey", "🏏 Match Journey"],
            ["about-different", "✨ Why Cric4All"],
            ["about-people", "👥 Who It’s For"],
            ["about-platform", "📱 Platform"],
            ["about-tech", "⚙️ Technology"],
            ["about-roadmap", "🛣 Roadmap"],
          ].map(([id, label]) => (
            <a
              key={id}
              href={`#${id}`}
              style={{
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                minHeight: 44,
                padding: "9px 10px",
                borderRadius: 11,
                border: "1px solid rgba(96, 165, 250, 0.24)",
                background: "rgba(30, 41, 59, 0.72)",
                textDecoration: "none",
                color: "inherit",
                fontSize: 13,
                fontWeight: 800,
                lineHeight: 1.2,
                textAlign: "center",
                whiteSpace: "normal",
                overflowWrap: "anywhere",
              }}
            >
              {label}
            </a>
          ))}
        </div>
      </div>

      <section id="about-mission">
        <div className="about-card about-mission">
          <h3>🎯 Our Mission</h3>

          <p>
            Cric4All makes community cricket easier to organize, score, follow,
            review, and share. The goal is simple: keep the people running the
            game focused on cricket instead of juggling disconnected tools.
          </p>

          <p>
            From a weekend friendly to a full league or tournament, Cric4All is
            designed around practical workflows before, during, and after the match.
          </p>
        </div>
      </section>

      <section id="about-journey" style={{ marginTop: 20 }}>
        <h3 className="about-section-title">🏏 One Platform for the Match Journey</h3>

        <div className="about-workflow-grid">
          <div>
            <strong>1. Plan</strong>
            <p>
              Organize leagues, series, teams, players, availability, and match strategy.
            </p>
          </div>

          <div>
            <strong>2. Schedule</strong>
            <p>
              Create fixtures with configurable overs, wickets, roles, and match settings.
            </p>
          </div>

          <div>
            <strong>3. Score</strong>
            <p>
              Score live or offline with a focused match-day workspace and automatic synchronization.
            </p>
          </div>

          <div>
            <strong>4. Adapt</strong>
            <p>
              Handle interruptions with rain/DLS workflows and tactical chase context.
            </p>
          </div>

          <div>
            <strong>5. Share</strong>
            <p>
              Give spectators live scorecards, commentary, public league pages, standings, and leaders.
            </p>
          </div>

          <div>
            <strong>6. Review</strong>
            <p>
              Use scorecards, statistics, rankings, and AI Match Review to understand the game.
            </p>
          </div>

          <div>
            <strong>7. Close the Loop</strong>
            <p>
              Finalize the match, confirm kit custody, review activity, and keep the league ready for the next game.
            </p>
          </div>
        </div>
      </section>

      <section id="about-different" style={{ marginTop: 20 }}>
        <h3 className="about-section-title">✨ What Makes Cric4All Different</h3>

        <div className="about-workflow-grid">
          <div>
            <strong>⚡ Match-Day First</strong>
            <p>
              Cric4All is built around the scorer&apos;s real workflow, with quick scoring,
              live context, scorecards, commentary, and match controls in one place.
            </p>
          </div>

          <div>
            <strong>📴 Offline Ready</strong>
            <p>
              Scoring can continue when the connection drops, with synchronization and
              conflict protection when connectivity returns.
            </p>
          </div>

          <div>
            <strong>🌧 Rain-Aware Cricket</strong>
            <p>
              Built-in rain adjustment, Official DLS entry workflows, revised-target handling,
              and chase context support interrupted matches.
            </p>
          </div>

          <div>
            <strong>🤖 Practical AI</strong>
            <p>
              AI helps with team balancing, match strategy, and completed-match review without
              replacing Cric4All&apos;s authoritative match result.
            </p>
          </div>

          <div>
            <strong>🎒 Community Operations</strong>
            <p>
              Birthday workflows, fair kit rotation, reminders, and post-match custody help
              manage the responsibilities around the game—not just the score.
            </p>
          </div>

          <div>
            <strong>🌐 Public Cricket</strong>
            <p>
              Public and unlisted league pages, live spectator sharing, standings, and leaders
              make it easier for families, players, and fans to follow the competition.
            </p>
          </div>
        </div>
      </section>

      <section id="about-people" style={{ marginTop: 20 }}>
        <h3 className="about-section-title">👥 Built for Cricket Communities</h3>

        <div className="about-workflow-grid">
          <div>
            <strong>For Organizers</strong>
            <p>
              Manage leagues, scheduling, permissions, public visibility, administration,
              community workflows, and AI planning.
            </p>
          </div>

          <div>
            <strong>For Scorers</strong>
            <p>
              Score live or offline, manage innings/player state, handle rain revisions,
              synchronize safely, and finalize matches.
            </p>
          </div>

          <div>
            <strong>For Captains</strong>
            <p>
              Review availability, AI strategy, live chase context, scorecards, statistics,
              and post-match analysis.
            </p>
          </div>

          <div>
            <strong>For Players</strong>
            <p>
              Follow personal performance, match history, rankings, availability,
              and team/community information.
            </p>
          </div>

          <div>
            <strong>For Spectators</strong>
            <p>
              Follow public leagues, live scores, commentary, scorecards, results,
              standings, and leaders.
            </p>
          </div>
        </div>
      </section>

      <details id="about-platform" open style={{ marginTop: 20 }}>
        <summary
          className="about-section-title"
          style={{ cursor: "pointer", listStyle: "none", userSelect: "none" }}
        >
          📱 Platform
        </summary>

        <div className="about-card" style={{ marginTop: 12 }}>
          <p>
            Cric4All is designed as a responsive cricket application for phones and laptops,
            with match-day layouts optimized for smaller screens and richer management views
            available on larger displays.
          </p>

          <div className="about-highlight-row">
            <span>🌐 Web</span>
            <span>📱 Mobile Friendly</span>
            <span>🤖 AI Assisted</span>
            <span>☁️ Cloud Connected</span>
            <span>📴 Offline Capable</span>
            <span>🤖 Android Ready</span>
          </div>
        </div>
      </details>

      <details id="about-tech" style={{ marginTop: 20 }}>
        <summary
          className="about-section-title"
          style={{ cursor: "pointer", listStyle: "none", userSelect: "none" }}
        >
          ⚙️ Technology
        </summary>

        <div className="about-card" style={{ marginTop: 12 }}>
          <p>
            Cric4All combines modern web, cloud database, AI, messaging, and mobile-packaging
            technologies to support reliable cricket workflows.
          </p>

          <div className="about-tech-row">
            <span className="badge">Next.js</span>
            <span className="badge">React</span>
            <span className="badge">PostgreSQL</span>
            <span className="badge">Prisma</span>
            <span className="badge">Neon</span>
            <span className="badge">OpenAI</span>
            <span className="badge">Twilio</span>
            <span className="badge">Vercel</span>
            <span className="badge">Capacitor</span>
          </div>
        </div>
      </details>

      <details id="about-roadmap" style={{ marginTop: 20 }}>
        <summary
          className="about-section-title"
          style={{ cursor: "pointer", listStyle: "none", userSelect: "none" }}
        >
          🛣 Roadmap
        </summary>

        <div className="about-card" style={{ marginTop: 12 }}>
          <p>
            The roadmap focuses on expanding public cricket experiences, richer competition
            formats, deeper analytics, stronger mobile experiences, and additional league tools.
          </p>

          <div className="about-list-grid">
            <span>🏆 Tournament brackets and richer formats</span>
            <span>🎥 Match highlights and media workflows</span>
            <span>📺 Public scoreboard upgrades</span>
            <span>👥 Public team pages</span>
            <span>🏏 Public player profiles</span>
            <span>📊 Advanced analytics dashboards</span>
            <span>🔍 Continued public-page SEO improvements</span>
            <span>🎤 Enhanced voice scoring</span>
            <span>📲 Android native UX improvements</span>
            <span>🍎 iOS packaging and App Store readiness</span>
            <span>💳 Premium competition tools</span>
            <span>📤 Scorecard / statistics export options</span>
          </div>
        </div>
      </details>

      <div className="about-footer" style={{ marginTop: 24 }}>
        <h3>🏏 Cric4All</h3>

        <p>
          Organize Cricket. Score Anywhere. Adapt to the Match. Share the Game. Review Smarter.
        </p>

        <p className="about-copy">© 2026 Cric4All</p>
      </div>
    </div>
  </Card>
)}
{activeTab === "admin" && (
  <Card title="🛡️ Admin Center">
    <section style={{ marginBottom: 18, padding: 16, border: "1px solid rgba(96,165,250,.22)", borderRadius: 18, background: "rgba(15,23,42,.55)" }}>
      <div style={{ display: "flex", gap: 12, alignItems: "center", justifyContent: "space-between", flexWrap: "wrap", marginBottom: 14 }}>
        <div>
          <h3 style={{ margin: 0 }}>📈 Cric4All Growth Center</h3>
          <p className="muted" style={{ margin: "5px 0 0" }}>Measure discovery, activation and repeat league usage before spending on acquisition.</p>
        </div>
        <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
          {[7, 30, 90].map((days) => (
            <button key={days} type="button" className={`btn ${growthDays === days ? "" : "btn-outline"}`} onClick={() => { setGrowthDays(days); loadGrowthData(days); }}>
              {days} days
            </button>
          ))}
        </div>
      </div>

      {growthLoading && !growthData ? (
        <p className="muted">Loading growth analytics...</p>
      ) : growthData ? (
        <>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(125px, 1fr))", gap: 10 }}>
            {[
              ["Visitors", growthData.all?.visitors ?? 0, "Unique landing visitors"],
              ["Signups", growthData.all?.signups ?? 0, `${growthData.all?.conversion?.visitorToSignup ?? 0}% of visitors`],
              ["Leagues", growthData.all?.leagues ?? 0, "New leagues"],
              ["Matches", growthData.all?.matches ?? 0, `${growthData.all?.conversion?.leagueToMatch ?? 0}% league → match`],
              ["Started", growthData.all?.startedMatches ?? 0, `${growthData.all?.conversion?.matchToStart ?? 0}% match → start`],
              ["Completed", growthData.all?.completedMatches ?? 0, `${growthData.all?.conversion?.startToComplete ?? 0}% start → complete`],
              ["Repeat Leagues", growthData.all?.repeatLeagues ?? 0, "2+ completed matches"],
            ].map(([label, value, note]) => (
              <div key={label} style={{ padding: 12, minWidth: 0, borderRadius: 14, border: "1px solid rgba(148,163,184,.16)", background: "rgba(2,6,23,.38)" }}>
                <span className="muted" style={{ display: "block", fontSize: 12 }}>{label}</span>
                <strong style={{ display: "block", fontSize: 24, lineHeight: 1.15, marginTop: 5 }}>{value}</strong>
                <small className="muted" style={{ display: "block", marginTop: 5, overflowWrap: "anywhere" }}>{note}</small>
              </div>
            ))}
          </div>

          <div style={{ marginTop: 12, display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(210px, 1fr))", gap: 10 }}>
            <div style={{ padding: 13, borderRadius: 14, border: "1px solid rgba(52,211,153,.2)", background: "rgba(6,78,59,.12)" }}>
              <strong>🌍 External adoption</strong>
              <p className="muted" style={{ margin: "7px 0 0", lineHeight: 1.5 }}>
                {growthData.external?.leagues ?? 0} leagues · {growthData.external?.startedMatches ?? 0} matches started · {growthData.external?.completedMatches ?? 0} completed · {growthData.external?.repeatLeagues ?? 0} repeat leagues
              </p>
            </div>
            <div style={{ padding: 13, borderRadius: 14, border: "1px solid rgba(56,189,248,.2)", background: "rgba(7,89,133,.12)" }}>
              <strong>👀 Spectator acquisition</strong>
              <p className="muted" style={{ margin: "7px 0 0", lineHeight: 1.5 }}>
                {growthData.all?.spectatorViews ?? 0} tracked views · {growthData.all?.spectatorCtaClicks ?? 0} CTA clicks · {growthData.all?.conversion?.spectatorToCta ?? 0}% conversion
              </p>
            </div>

            <div style={{ padding: 13, borderRadius: 14, border: "1px solid rgba(167,139,250,.22)", background: "rgba(76,29,149,.12)" }}>
              <strong>🏏 Quick Match onboarding</strong>
              <p className="muted" style={{ margin: "7px 0 0", lineHeight: 1.5 }}>
                {growthData.all?.quickMatchViews ?? 0} views · {growthData.all?.quickMatchStarts ?? 0} setup attempts · {growthData.all?.quickMatchCreated ?? 0} matches created
              </p>
              <p className="muted" style={{ margin: "4px 0 0", lineHeight: 1.45, fontSize: 12 }}>
                {growthData.all?.conversion?.quickViewToStart ?? 0}% view → setup · {growthData.all?.conversion?.quickStartToCreated ?? 0}% setup → match · {growthData.all?.quickMatchAuthClicks ?? 0} auth clicks
              </p>
            </div>
          </div>

          {Array.isArray(growthData.internalLeagueIds) && growthData.internalLeagueIds.length > 0 ? (
            <p className="muted" style={{ margin: "10px 0 0", fontSize: 12 }}>Internal/test league IDs excluded from External adoption: {growthData.internalLeagueIds.join(", ")}</p>
          ) : (
            <p className="muted" style={{ margin: "10px 0 0", fontSize: 12 }}>Set GROWTH_INTERNAL_LEAGUE_IDS in your environment to keep your own community/test leagues out of External adoption.</p>
          )}
        </>
      ) : (
        <p className="muted">Growth analytics are not available yet.</p>
      )}
    </section>

    <div className="admin-center-grid">
      <div className="admin-activity-card">
        <h3>🟢 Online Now</h3>

        {userActivityLoading ? (
          <p className="muted">Loading activity...</p>
        ) : !userActivity?.onlineUsers?.length ? (
          <p className="muted">No users online right now.</p>
        ) : (
          <div className="admin-user-list">
            {userActivity.onlineUsers.map((user) => (
              <div key={user.id} className="admin-user-row">
                <div>
                  <strong>{user.name || "Unknown User"}</strong>
                  <span>{user.email}</span>
                </div>
                <small>Active now</small>
              </div>
            ))}
          </div>
        )}
      </div>

<div className="admin-activity-card">
  <h3>🕒 Recent Logins</h3>
  {!groupedRecentLogins.length ? (
    <p className="muted">No logins in the last 24 hours.</p>
  ) : (
    <div className="admin-login-group-list">
      {groupedRecentLogins.map((group) => (
        <details key={group.key} className="admin-login-group">
          <summary className="admin-login-group-summary">
            <div>
              <strong>{group.name}</strong>
              <span>{group.email}</span>
            </div>

            <div className="admin-login-count">
              <b>{group.logins.length}</b>
              <small>logins</small>
              <i>⌄</i>
            </div>
          </summary>

          <div className="admin-login-events">
            {group.logins.map((login) => (
              <div key={login.id} className="admin-login-event">
                <span>🔐 Login</span>
                <strong>{formatDate(login.loginAt)}</strong>
              </div>
            ))}
          </div>
        </details>
      ))}
    </div>
  )}
</div>

      <div className="admin-activity-card admin-stat-card">
        <h3>📈 Activity Summary</h3>

        <div className="admin-stat-grid">
          <div>
            <span>Online</span>
            <strong>{userActivity?.onlineUsers?.length || 0}</strong>
          </div>

          <div>
            <span>24h Logins</span>
            <strong>{userActivity?.loginCount24h || 0}</strong>
          </div>
        </div>
      </div>
    </div>
<div className="admin-activity-card admin-audit-card">
  <div className="admin-card-title-row">
    <h3>📜 Audit Logs</h3>
  </div>

  {auditLogsLoading ? (
    <p className="muted">Loading audit logs...</p>
  ) : !auditLogs.length ? (
    <p className="muted">No audit logs found.</p>
  ) : (
    <>
<div className="audit-league-tabs">
  <button
    type="button"
    className={selectedAuditLeagueKey === "ALL" ? "active" : ""}
    onClick={() => setSelectedAuditLeagueKey("ALL")}
  >
    🌐 All <span>{auditLogs.length}</span>
  </button>

  {auditLeagueGroups.map((group) => (
    <button
      type="button"
      key={group.key}
      className={
        String(selectedAuditLeagueKey) === String(group.key) ? "active" : ""
      }
      onClick={() => setSelectedAuditLeagueKey(String(group.key))}
    >
      🏆 {group.label} <span>{group.logs.length}</span>
    </button>
  ))}
</div>

      <div className="admin-audit-list">
        {visibleAuditLogs.map((log) => (
          <div key={log.id} className="admin-audit-row">
            <div className="admin-audit-main">
              <strong>{log.action?.replaceAll("_", " ")}</strong>
              <span>{log.description || "No description available."}</span>

              <small>
                🏆 {log.leagueName || "System / No League"} • 👤{" "}
                {log.actorName || log.actorEmail || "Unknown user"}
                {log.actorEmail ? ` • ${log.actorEmail}` : ""}
              </small>
            </div>

            <div className="admin-audit-meta">
              <span>{log.entityType || "SYSTEM"}</span>
              <small>{formatDate(log.createdAt)}</small>
            </div>
          </div>
        ))}
      </div>
    </>
  )}
</div>
        <button
          type="button"
          className="btn"
          onClick={() => {
            loadUserActivity();
            loadAuditLogs();
            loadGrowthData(growthDays);
          }}
        >
          🔄 Refresh Activity
        </button>
  </Card>
)}
{showEditLeagueModal && activeLeague && (
  <div className="league-modal-backdrop">
    <div
      className="modal-card app-modal-card"
      role="dialog"
      aria-modal="true"
      aria-labelledby="edit-league-title"
    >
      <div className="league-modal-header">
        <div>
          <h3 id="edit-league-title">✏️ Edit League</h3>
          <p>
            Update the league name or control who can view the league.
          </p>
        </div>

        <button
          type="button"
          className="icon-btn"
          disabled={editLeagueSaving}
          onClick={() => setShowEditLeagueModal(false)}
        >
          ✕
        </button>
      </div>

      <div className="league-modal-body">
        <label className="league-label" htmlFor="edit-league-name">
          League Name
        </label>

        <input
          id="edit-league-name"
          className="league-input"
          type="text"
          value={editLeagueForm.name}
          onChange={(event) =>
            setEditLeagueForm((previous) => ({
              ...previous,
              name: event.target.value,
            }))
          }
          disabled={editLeagueSaving}
          autoFocus
        />
      </div>

      <div className="league-modal-body">
        <label htmlFor="edit-league-visibility">
          <span>League Visibility</span>

          <select
            id="edit-league-visibility"
            value={editLeagueForm.visibility}
            onChange={(event) =>
              setEditLeagueForm((previous) => ({
                ...previous,
                visibility: event.target.value,
              }))
            }
            disabled={editLeagueSaving}
          >
            <option value="PRIVATE">🔒 Private - Members only</option>
            <option value="UNLISTED">🔗 Unlisted - Anyone with link can view</option>
            <option value="PUBLIC">🌐 Public - Everyone can view</option>
          </select>

          <small className="field-help">
            Public leagues can be discovered by everyone. Unlisted leagues are
            viewable by anyone with the link. Private leagues remain members-only.
          </small>
        </label>
      </div>

      <div className="league-modal-actions">
        <button
          type="button"
          className="btn btn-outline"
          disabled={editLeagueSaving}
          onClick={() => setShowEditLeagueModal(false)}
        >
          Cancel
        </button>

        <button
          type="button"
          className="btn"
          disabled={editLeagueSaving || !editLeagueForm.name.trim()}
          onClick={handleUpdateLeague}
        >
          {editLeagueSaving ? "Saving…" : "💾 Save League"}
        </button>
      </div>
    </div>
  </div>
)}
{showLeagueModal && (
  <div className="league-modal-backdrop">
    <div className="modal-card app-modal-card">

      <div className="league-modal-header">
        <div>
          <h3>🏆 Create League</h3>
          <p>
            Organize teams, fixtures and standings
            under a new league.
          </p>
        </div>

        <button
          className="icon-btn"
          onClick={() =>
            setShowLeagueModal(false)
          }
        >
          ✕
        </button>
      </div>

      <div className="league-modal-body">
        <label className="league-label">
          League Name
        </label>

        <input
          className="league-input"
          type="text"
          value={leagueName}
          onChange={(e) =>
            setLeagueName(e.target.value)
          }
          placeholder="e.g. Summer Premier League 2026"
          autoFocus
        />
      </div>
      <div className="league-modal-body">
<label>
  <span>League Visibility</span>

  <select
    value={leagueForm.visibility || "PRIVATE"}
    onChange={(e) =>
      setLeagueForm((prev) => ({
        ...prev,
        visibility: e.target.value,
      }))
    }
  >
    <option value="PRIVATE">🔒 Private - Members only</option>
    <option value="UNLISTED">🔗 Unlisted - Anyone with link can view</option>
    <option value="PUBLIC">🌐 Public - Everyone can view</option>
  </select>

  <small className="field-help">
    You can keep the league private or allow view-only public access.
  </small>
</label>
</div>
      <div className="league-modal-actions">
        <button
          type="button"
          className="btn btn-outline"
          onClick={() =>
            setShowLeagueModal(false)
          }
        >
          Cancel
        </button>

        <button
          type="button"
          className="btn"
          disabled={!leagueName.trim()}
          onClick={handleCreateLeague}
        >
          ➕ Create League
        </button>
      </div>

    </div>
  </div>
)}
{showBowlerModal &&   typeof document !== "undefined" && createPortal(
  <div
    className="bowler-modal-backdrop"
    role="presentation"
    onMouseDown={(event) => {
      if (
        event.target === event.currentTarget &&
        !mustChangeBowler
      ) {
        handleCloseBowlerModal();
      }
    }}
  >
    <div
      className="bowler-modal bowler-modal-mobile-fit"
      role="dialog"
      aria-modal="true"
      aria-labelledby="change-bowler-title"
    >
      {/* Fixed modal header */}
      <div className="bowler-modal-header">
        <div>
          <h3 id="change-bowler-title">
            🏏 Change Bowler
          </h3>

          <p>Select a different bowler for the next over</p>
        </div>

        {!mustChangeBowler && (
          <button
            type="button"
            className="icon-btn"
            onClick={handleCloseBowlerModal}
            aria-label="Close change bowler modal"
          >
            ✕
          </button>
        )}
      </div>

      {/* Compact live match snapshot */}
        <div className="live-popup-snapshot">
          <div className="live-popup-topline">
            <span className="live-dot">
              ● LIVE
            </span>

            <span className="live-popup-over">
              Over {bowlerChangeScore.overs}
            </span>
          </div>

          <div className="live-popup-main">
            <div>
              <span>Current Score</span>

              <strong>
                {bowlerChangeScore.score}
              </strong>
            </div>

            <div>
              <span>CRR</span>

              <strong>
                {bowlerChangeScore.crr}
              </strong>
            </div>
          </div>

          <div className="live-popup-recent">
            <div className="live-popup-recent-head">
              <span>Current Over</span>

              <b>
                Over {extrasModalCurrentOver.overNo}
              </b>
            </div>

            <div className="live-popup-recent-direction">
              ← Latest delivery
            </div>

            <div className="live-popup-balls">
              {extrasModalCurrentOver.balls.length ? (
                extrasModalCurrentOver.balls.map(
                  (ball, index) => {
                    const label =
                      ball.shortText ||
                      ball.displayText ||
                      ball.resultText ||
                      ball.label ||
                      "";

                    const result = String(label)
                      .replace(
                        /^\s*\d+\.\d+\s*/,
                        ""
                      )
                      .replace(/[()]/g, "")
                      .trim();

                    const normalized =
                      result.toUpperCase();

                    const ballClass =
                      normalized === "W" ||
                      normalized === "WKT"
                        ? "wicket"
                        : normalized === "4"
                          ? "four"
                          : normalized === "6"
                            ? "six"
                            : normalized.startsWith(
                                  "WD"
                                ) ||
                                normalized.includes(
                                  "WIDE"
                                )
                              ? "wide"
                              : normalized.startsWith(
                                    "NB"
                                  ) ||
                                  normalized.includes(
                                    "NO BALL"
                                  ) ||
                                  normalized.includes(
                                    "NOBALL"
                                  )
                                ? "noball"
                                : "";

                    return (
                      <b
                        key={
                          ball.id ||
                          ball.sequence ||
                          `extra-recent-${index}`
                        }
                        className={`${ballClass} ${
                          index === 0
                            ? "latest"
                            : ""
                        }`}
                      >
                        {result || "-"}
                      </b>
                    );
                  }
                )
              ) : (
                <small>
                  No deliveries in the current
                  over yet
                </small>
              )}
            </div>
          </div>
        </div>

      <div className="bowler-warning">
        Same bowler cannot bowl consecutive overs.
      </div>

      {/* Only this area scrolls */}
      <div className="bowler-modal-player-area">
  <div className="bowler-search-box">
    <span>🔎</span>

    <input
      type="search"
      value={bowlerSearchText}
      onChange={(event) =>
        setBowlerSearchText(event.target.value)
      }
      placeholder="Search bowler name"
      autoComplete="off"
    />

    {bowlerSearchText && (
      <button
        type="button"
        onClick={() =>
          setBowlerSearchText("")
        }
        aria-label="Clear bowler search"
      >
        ✕
      </button>
    )}
  </div>

  <div className="bowler-list bowler-list-scroll-area">
    {availableBowlerOptions.length ? (
      availableBowlerOptions.map((player) => {
        const isSelected =
          String(ballForm.bowlerId) ===
          String(player.id);

        return (
          <button
            key={player.id}
            type="button"
            className={`bowler-option ${
              isSelected ? "selected" : ""
            }`}
            aria-pressed={isSelected}
            onClick={() =>
              setBallForm((previous) => ({
                ...previous,
                bowlerId: player.id,
              }))
            }
          >
            <span className="bowler-avatar">
              🎳
            </span>

            <span className="bowler-option-copy">
              <strong className="bowler-name">
                {player.name}
              </strong>

              <small>
                {isSelected
                  ? "Selected for next over"
                  : "Tap to select"}
              </small>
            </span>

            <span
              className={`bowler-selection-indicator ${
                isSelected ? "selected" : ""
              }`}
            >
              {isSelected ? "✓" : "›"}
            </span>
          </button>
        );
      })
    ) : (
      <div className="bowler-search-empty">
        No matching bowlers found.
      </div>
    )}
  </div>
</div>

      {/* Always visible at the bottom */}
      <div className="bowler-modal-actions bowler-modal-sticky-actions">
        <button
          type="button"
          className="btn btn-outline"
          disabled={mustChangeBowler}
          onClick={handleCloseBowlerModal}
        >
          {mustChangeBowler
            ? "Bowler Required"
            : "Cancel"}
        </button>

        <button
          type="button"
          className="btn bowler-continue-btn"
          disabled={!ballForm.bowlerId}
          onClick={confirmBowlerChange}
        >
          Continue →
        </button>
      </div>
    </div>
  </div>,
  document.body
)}
{showLeagueImportModal && (
  <div
    className="modal-backdrop"
    onMouseDown={(event) => {
      if (
        event.target ===
          event.currentTarget &&
        !leagueImportSaving
      ) {
        setShowLeagueImportModal(false);
      }
    }}
    style={{
      padding:
        "clamp(8px, 1.5vw, 18px)",
      alignItems:
        "center",
      justifyContent:
        "center",
      overflow:
        "hidden",
    }}
  >
    <div
      className="modal-card phase5-import-modal"
      style={{
        width:
          "min(1100px, calc(100vw - 20px))",
        height:
          "min(800px, calc(100dvh - 20px))",
        maxHeight:
          "calc(100dvh - 20px)",
        padding:
          0,
        overflow:
          "hidden",
        display:
          "grid",
        gridTemplateRows:
          "auto minmax(0, 1fr) auto",
        borderRadius:
          18,
      }}
    >
      {/* Fixed header */}
      <div
        style={{
          display:
            "flex",
          justifyContent:
            "space-between",
          gap:
            12,
          alignItems:
            "flex-start",
          flexWrap:
            "wrap",
          padding:
            "14px clamp(14px, 2vw, 20px) 12px",
          borderBottom:
            "1px solid rgba(148,163,184,.14)",
          background:
            "rgba(15,23,42,.96)",
          position:
            "relative",
          zIndex:
            2,
        }}
      >
        <div
          style={{
            minWidth:
              0,
            flex:
              "1 1 560px",
          }}
        >
          <div
            style={{
              display:
                "inline-flex",
              padding:
                "4px 8px",
              borderRadius:
                999,
              border:
                "1px solid rgba(56,189,248,.25)",
              fontSize:
                10,
              fontWeight:
                900,
              marginBottom:
                6,
            }}
          >
            🚚 GROWTH PHASE 5
          </div>

          <h3
            style={{
              margin:
                0,
              fontSize:
                "clamp(18px, 2vw, 22px)",
              lineHeight:
                1.2,
              overflowWrap:
                "anywhere",
            }}
          >
            Move Your League to Cric4All
          </h3>

          <p
            className="muted"
            style={{
              margin:
                "5px 0 0",
              lineHeight:
                1.4,
              maxWidth:
                780,
              fontSize:
                "clamp(12px, 1.4vw, 13px)",
              overflowWrap:
                "anywhere",
            }}
          >
            Paste your roster directly or upload a CSV. One player per row;
            repeat the team name for each player.
          </p>
        </div>

        <button
          type="button"
          className="btn btn-outline"
          disabled={
            leagueImportSaving
          }
          onClick={() =>
            setShowLeagueImportModal(
              false
            )
          }
          style={{
            flex:
              "0 0 auto",
            minWidth:
              42,
            minHeight:
              38,
            padding:
              "7px 11px",
          }}
          aria-label="Close league import"
        >
          ✕
        </button>
      </div>

      {/* Scrollable content */}
      <div
        style={{
          minHeight:
            0,
          overflowY:
            "auto",
          overflowX:
            "hidden",
          padding:
            "12px clamp(12px, 2vw, 20px)",
          WebkitOverflowScrolling:
            "touch",
        }}
      >
        {/* Primary action: full-width paste area */}
        <section
          style={{
            padding:
              12,
            borderRadius:
              14,
            border:
              "1px solid rgba(56,189,248,.20)",
            background:
              "rgba(7,89,133,.08)",
            minWidth:
              0,
          }}
        >
          <div
            style={{
              display:
                "flex",
              alignItems:
                "flex-start",
              justifyContent:
                "space-between",
              gap:
                10,
              flexWrap:
                "wrap",
              marginBottom:
                8,
            }}
          >
            <div
              style={{
                minWidth:
                  0,
                flex:
                  "1 1 520px",
              }}
            >
              <strong
                style={{
                  display:
                    "block",
                  fontSize:
                    14,
                }}
              >
                📋 Paste CSV rows
              </strong>

              <span
                className="muted"
                style={{
                  display:
                    "block",
                  marginTop:
                    4,
                  lineHeight:
                    1.4,
                  fontSize:
                    12,
                  overflowWrap:
                    "anywhere",
                }}
              >
                This is the fastest option. Paste directly from your prepared
                CSV text using Team, Player, WhatsApp.
              </span>
            </div>

            <div
              style={{
                display:
                  "flex",
                gap:
                  8,
                flexWrap:
                  "wrap",
                flex:
                  "0 1 auto",
              }}
            >
              <button
                type="button"
                className="btn btn-outline"
                onClick={
                  downloadLeagueImportTemplate
                }
                style={{
                  whiteSpace:
                    "nowrap",
                }}
              >
                ⬇️ Template
              </button>

              <label
                className="btn btn-outline"
                style={{
                  cursor:
                    "pointer",
                  whiteSpace:
                    "nowrap",
                  display:
                    "inline-flex",
                  alignItems:
                    "center",
                  justifyContent:
                    "center",
                }}
              >
                📤 Upload CSV

                <input
                  type="file"
                  accept=".csv,text/csv"
                  disabled={
                    leagueImportSaving
                  }
                  onChange={
                    handleLeagueImportFile
                  }
                  style={{
                    position:
                      "absolute",
                    width:
                      1,
                    height:
                      1,
                    opacity:
                      0,
                    pointerEvents:
                      "none",
                  }}
                />
              </label>
            </div>
          </div>

          <textarea
            rows={10}
            value={
              leagueImportText
            }
            disabled={
              leagueImportSaving
            }
            onChange={(event) =>
              updateLeagueImportPreview(
                event.target.value
              )
            }
            placeholder={`Team,Player,WhatsApp
Eagles,John Smith,+16105550101
Eagles,David Patel,
Eagles,Mike Jones,+16105550103
Tigers,Raj Kumar,+12155550104
New Team,,`}
            style={{
              width:
                "100%",
              boxSizing:
                "border-box",
              resize:
                "vertical",
              borderRadius:
                12,
              padding:
                "12px 13px",
              lineHeight:
                1.45,
              minHeight:
                220,
              maxHeight:
                380,
              fontSize:
                "clamp(12px, 1.4vw, 14px)",
              fontFamily:
                "ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace",
              overflowWrap:
                "normal",
              whiteSpace:
                "pre",
            }}
          />

          <div
            className="phase5-import-helper-grid"
            style={{
              display:
                "grid",
              gridTemplateColumns:
                "repeat(2, minmax(0, 1fr))",
              gap:
                10,
              marginTop:
                10,
            }}
          >
            <div
              style={{
                padding:
                  10,
                borderRadius:
                  11,
                border:
                  "1px solid rgba(56,189,248,.16)",
                background:
                  "rgba(15,23,42,.28)",
                fontSize:
                  12,
                lineHeight:
                  1.45,
                minWidth:
                  0,
              }}
            >
              <strong>
                📌 How rows work
              </strong>

              <div
                className="muted"
                style={{
                  marginTop:
                    4,
                  overflowWrap:
                    "anywhere",
                }}
              >
                Each player gets one row. If Eagles has 15 players, Eagles is
                repeated on 15 rows. <b>New Team,,</b> creates only the team.
              </div>
            </div>

            <div
              style={{
                padding:
                  10,
                borderRadius:
                  11,
                border:
                  "1px solid rgba(250,204,21,.16)",
                background:
                  "rgba(113,63,18,.08)",
                fontSize:
                  12,
                lineHeight:
                  1.45,
                minWidth:
                  0,
              }}
            >
              <strong>
                🔐 Consent protection
              </strong>

              <div
                className="muted"
                style={{
                  marginTop:
                    4,
                  overflowWrap:
                    "anywhere",
                }}
              >
                Imported phone numbers remain contact data only. SMS/WhatsApp
                consent is never enabled by roster import.
              </div>
            </div>
          </div>
        </section>

        {/* Compact counts */}
        <div
          className="phase5-import-stats-grid"
          style={{
            display:
              "grid",
            gridTemplateColumns:
              "repeat(4, minmax(0, 1fr))",
            gap:
              8,
            marginTop:
              10,
          }}
        >
          {[
            [
              "Rows",
              leagueImportRows.length,
            ],
            [
              "Teams",
              new Set(
                leagueImportRows.map(
                  (row) =>
                    String(
                      row.teamName ||
                      ""
                    ).toLowerCase()
                )
              ).size,
            ],
            [
              "Players",
              leagueImportRows.filter(
                (row) =>
                  row.playerName
              ).length,
            ],
            [
              "Errors",
              leagueImportErrors.length,
            ],
          ].map(
            ([
              label,
              value,
            ]) => (
              <div
                key={
                  label
                }
                style={{
                  padding:
                    "8px 10px",
                  borderRadius:
                    10,
                  border:
                    "1px solid rgba(148,163,184,.15)",
                  background:
                    "rgba(15,23,42,.34)",
                  minWidth:
                    0,
                }}
              >
                <span
                  className="muted"
                  style={{
                    display:
                      "block",
                    fontSize:
                      10,
                  }}
                >
                  {label}
                </span>

                <strong
                  style={{
                    display:
                      "block",
                    marginTop:
                      2,
                    fontSize:
                      17,
                  }}
                >
                  {value}
                </strong>
              </div>
            )
          )}
        </div>

        {leagueImportErrors.length >
        0 ? (
          <div
            role="alert"
            style={{
              marginTop:
                10,
              padding:
                11,
              borderRadius:
                11,
              border:
                "1px solid rgba(248,113,113,.28)",
              background:
                "rgba(127,29,29,.12)",
              minWidth:
                0,
            }}
          >
            <strong>
              ⚠️ Fix these rows first
            </strong>

            <ul
              style={{
                margin:
                  "6px 0 0",
                paddingLeft:
                  18,
                lineHeight:
                  1.4,
                fontSize:
                  12,
                overflowWrap:
                  "anywhere",
              }}
            >
              {leagueImportErrors.map(
                (
                  error
                ) => (
                  <li
                    key={
                      error
                    }
                  >
                    {error}
                  </li>
                )
              )}
            </ul>
          </div>
        ) : null}

        {leagueImportRows.length >
        0 ? (
          <section
            style={{
              marginTop:
                10,
              minWidth:
                0,
            }}
          >
            <div
              style={{
                display:
                  "flex",
                alignItems:
                  "center",
                justifyContent:
                  "space-between",
                gap:
                  8,
                flexWrap:
                  "wrap",
                marginBottom:
                  6,
              }}
            >
              <strong>
                👀 Preview
              </strong>

              {leagueImportRows.length >
              10 ? (
                <small
                  className="muted"
                >
                  Showing first 10 of {leagueImportRows.length}
                </small>
              ) : null}
            </div>

            <div
              style={{
                overflowX:
                  "auto",
                borderRadius:
                  11,
                border:
                  "1px solid rgba(148,163,184,.15)",
                WebkitOverflowScrolling:
                  "touch",
                maxWidth:
                  "100%",
              }}
            >
              <table
                style={{
                  width:
                    "100%",
                  borderCollapse:
                    "collapse",
                  minWidth:
                    500,
                  fontSize:
                    11,
                }}
              >
                <thead>
                  <tr>
                    <th
                      style={{
                        padding:
                          8,
                        textAlign:
                          "left",
                      }}
                    >
                      Team
                    </th>

                    <th
                      style={{
                        padding:
                          8,
                        textAlign:
                          "left",
                      }}
                    >
                      Player
                    </th>

                    <th
                      style={{
                        padding:
                          8,
                        textAlign:
                          "left",
                      }}
                    >
                      WhatsApp
                    </th>
                  </tr>
                </thead>

                <tbody>
                  {leagueImportRows
                    .slice(
                      0,
                      10
                    )
                    .map(
                      (
                        row,
                        index
                      ) => (
                        <tr
                          key={`${row.teamName}-${row.playerName}-${index}`}
                        >
                          <td
                            style={{
                              padding:
                                8,
                              overflowWrap:
                                "anywhere",
                            }}
                          >
                            {row.teamName}
                          </td>

                          <td
                            style={{
                              padding:
                                8,
                              overflowWrap:
                                "anywhere",
                            }}
                          >
                            {row.playerName ||
                              "— team only —"}
                          </td>

                          <td
                            style={{
                              padding:
                                8,
                              overflowWrap:
                                "anywhere",
                            }}
                          >
                            {row.whatsappNumber ||
                              "—"}
                          </td>
                        </tr>
                      )
                    )}
                </tbody>
              </table>
            </div>
          </section>
        ) : null}

        {leagueImportResult ? (
          <div
            style={{
              marginTop:
                10,
              padding:
                11,
              borderRadius:
                11,
              border:
                "1px solid rgba(52,211,153,.24)",
              background:
                "rgba(6,78,59,.11)",
              minWidth:
                0,
            }}
          >
            <strong>
              ✅ Import completed
            </strong>

            <p
              className="muted"
              style={{
                margin:
                  "5px 0 0",
                lineHeight:
                  1.4,
                fontSize:
                  12,
                overflowWrap:
                  "anywhere",
              }}
            >
              {leagueImportResult.createdTeams || 0} new team(s) ·{" "}
              {leagueImportResult.createdPlayers || 0} new player(s) ·{" "}
              {leagueImportResult.existingTeams || 0} existing team(s) reused ·{" "}
              {leagueImportResult.skippedPlayers?.length || 0} duplicate player(s) skipped
            </p>
          </div>
        ) : null}
      </div>

      {/* Fixed footer */}
      <div
        className="phase5-import-footer"
        style={{
          display:
            "grid",
          gridTemplateColumns:
            "minmax(0, 140px) minmax(180px, 280px)",
          justifyContent:
            "end",
          gap:
            9,
          padding:
            "10px clamp(12px, 2vw, 20px)",
          borderTop:
            "1px solid rgba(148,163,184,.14)",
          background:
            "rgba(15,23,42,.96)",
          position:
            "relative",
          zIndex:
            2,
        }}
      >
        <button
          type="button"
          className="btn btn-outline"
          disabled={
            leagueImportSaving
          }
          onClick={() =>
            setShowLeagueImportModal(
              false
            )
          }
          style={{
            minWidth:
              0,
          }}
        >
          Close
        </button>

        <button
          type="button"
          className="btn"
          disabled={
            leagueImportSaving ||
            leagueImportRows.length ===
              0 ||
            leagueImportErrors.length >
              0
          }
          onClick={
            submitLeagueImport
          }
          style={{
            minWidth:
              0,
            overflowWrap:
              "anywhere",
          }}
        >
          {leagueImportSaving
            ? "Importing…"
            : "🚚 Import to Cric4All"}
        </button>
      </div>
    </div>

    <style jsx>{`
      @media (max-width: 760px) {
        :global(.phase5-import-modal) {
          width: calc(100vw - 12px) !important;
          height: calc(100dvh - 12px) !important;
          max-height: calc(100dvh - 12px) !important;
          border-radius: 15px !important;
        }

        :global(.phase5-import-helper-grid) {
          grid-template-columns: minmax(0, 1fr) !important;
        }

        :global(.phase5-import-stats-grid) {
          grid-template-columns: repeat(2, minmax(0, 1fr)) !important;
        }

        :global(.phase5-import-footer) {
          grid-template-columns: repeat(2, minmax(0, 1fr)) !important;
        }
      }

      @media (max-width: 420px) {
        :global(.phase5-import-footer) {
          grid-template-columns: minmax(0, 1fr) !important;
        }
      }
    `}</style>
  </div>
)}

{showAddTeam && (
  <div className="modal-backdrop">
    <div className="modal-card app-modal-card">

      <h3>🏏 Add Team</h3>

        <p
          style={{
            opacity: 0.75,
            marginBottom: 20
          }}
        >
          Create a new team in the selected league.
        </p>

      <form onSubmit={handleAddTeam}>

        <input
          type="text"
          placeholder="Team Name"
          value={teamForm.name}
          onChange={(e) =>
            setTeamForm((prev) => ({
              ...prev,
              name: e.target.value
            }))
          }
          required
        />

<div className="modal-actions">
  <button
    type="button"
    className="btn btn-outline"
    onClick={() =>
      setShowAddTeam(false)
    }
  >
    Cancel
  </button>

  <button
    type="submit"
    className="btn"
  >
    Save Team
  </button>
</div>

      </form>

    </div>
  </div>
)}
{showPlayerModal && canAddPlayers && (
  <div className="modal-backdrop">
    <div className="add-player-pro-modal">
      <div className="add-player-pro-hero">
        <div className="add-player-pro-icon">🏏</div>

        <div>
          <h3>Add Players</h3>
          <p>Build your team roster quickly. Paste one player name per line.</p>
        </div>

        <button
          type="button"
          className="add-player-pro-close"
          onClick={() => setShowPlayerModal(false)}
        >
          ✕
        </button>
      </div>

      <form onSubmit={handleAddPlayers} className="add-player-pro-form">
        <div className="add-player-pro-grid">
          <label>
            <span>🏆 League</span>
            <select
              value={playerLeagueId || ""}
              onChange={(e) => {
                const leagueId = Number(e.target.value);

                setPlayerLeagueId(leagueId);

                setPlayerForm((prev) => ({
                  ...prev,
                  leagueId,
                  teamId: "",
                }));

                setSelectedPlayerTeamId("");
              }}
              required
            >
              <option value="">Choose League</option>

              {leagues.map((league) => (
                <option key={league.id} value={league.id}>
                  {league.name}
                </option>
              ))}
            </select>
          </label>

          <label>
            <span>👥 Team</span>
            <select
              value={selectedPlayerTeamId || ""}
              onChange={(e) => {
                const teamId = Number(e.target.value);

                setSelectedPlayerTeamId(teamId);

                setPlayerForm((prev) => ({
                  ...prev,
                  teamId,
                }));
              }}
              required
              disabled={!playerLeagueId}
            >
              <option value="">Choose Team</option>

              {selectedPlayerLeague?.teams?.map((team) => (
                <option key={team.id} value={team.id}>
                  {team.name}
                </option>
              ))}
            </select>
          </label>
        </div>

        <label className="add-player-pro-textarea-wrap">
          <div className="add-player-pro-label-row">
            <span>✍️ Player Names</span>
            <strong>
              {(playerForm.names || "")
                .split("\n")
                .map((x) => x.trim())
                .filter(Boolean).length}{" "}
              ready
            </strong>
          </div>

          <textarea
            rows={8}
            className="add-player-pro-textarea"
            placeholder={`Virat Kohli
Rohit Sharma
MS Dhoni
KL Rahul`}
            value={playerForm.names || ""}
            onChange={(e) =>
              setPlayerForm((prev) => ({
                ...prev,
                names: e.target.value,
              }))
            }
            required
          />
        </label>

        <div className="add-player-pro-tip">
          💡 Tip: You can paste names from WhatsApp, Excel, Notes, or any list.
        </div>

        <div className="add-player-pro-actions">
          <button
            type="button"
            className="add-player-pro-cancel"
            onClick={() => setShowPlayerModal(false)}
          >
            Cancel
          </button>

          <button
            type="submit"
            className="add-player-pro-save"
            disabled={!canAddPlayers || !playerLeagueId || !selectedPlayerTeamId}
          >
            ✅ Save Players
          </button>
        </div>
      </form>
    </div>
  </div>
)}
{showExtrasModal &&
  typeof document !== "undefined" &&
  createPortal(
    <div className="modal-backdrop">
      <div className="modal-card">
        <div className="live-popup-snapshot">
          <div className="live-popup-topline">
            <span className="live-dot">
              ● LIVE
            </span>

            <span className="live-popup-over">
              Over {bowlerChangeScore.overs}
            </span>
          </div>

          <div className="live-popup-main">
            <div>
              <span>Current Score</span>

              <strong>
                {bowlerChangeScore.score}
              </strong>
            </div>

            <div>
              <span>CRR</span>

              <strong>
                {bowlerChangeScore.crr}
              </strong>
            </div>
          </div>

          <div className="live-popup-recent">
            <div className="live-popup-recent-head">
              <span>Current Over</span>

              <b>
                Over {extrasModalCurrentOver.overNo}
              </b>
            </div>

            <div className="live-popup-recent-direction">
              ← Latest delivery
            </div>

            <div className="live-popup-balls">
              {extrasModalCurrentOver.balls.length ? (
                extrasModalCurrentOver.balls.map(
                  (ball, index) => {
                    const label =
                      ball.shortText ||
                      ball.displayText ||
                      ball.resultText ||
                      ball.label ||
                      "";

                    const result = String(label)
                      .replace(
                        /^\s*\d+\.\d+\s*/,
                        ""
                      )
                      .replace(/[()]/g, "")
                      .trim();

                    const normalized =
                      result.toUpperCase();

                    const ballClass =
                      normalized === "W" ||
                      normalized === "WKT"
                        ? "wicket"
                        : normalized === "4"
                          ? "four"
                          : normalized === "6"
                            ? "six"
                            : normalized.startsWith(
                                  "WD"
                                ) ||
                                normalized.includes(
                                  "WIDE"
                                )
                              ? "wide"
                              : normalized.startsWith(
                                    "NB"
                                  ) ||
                                  normalized.includes(
                                    "NO BALL"
                                  ) ||
                                  normalized.includes(
                                    "NOBALL"
                                  )
                                ? "noball"
                                : "";

                    return (
                      <b
                        key={
                          ball.id ||
                          ball.sequence ||
                          `extra-recent-${index}`
                        }
                        className={`${ballClass} ${
                          index === 0
                            ? "latest"
                            : ""
                        }`}
                      >
                        {result || "-"}
                      </b>
                    );
                  }
                )
              ) : (
                <small>
                  No deliveries in the current
                  over yet
                </small>
              )}
            </div>
          </div>
        </div>

        <h3>
          {selectedExtraType === "WIDE" &&
            "Wide"}

          {selectedExtraType === "NOBALL" &&
            "No Ball"}

          {selectedExtraType === "BYE" &&
            "Bye"}

          {selectedExtraType === "LEGBYE" &&
            "Leg Bye"}
        </h3>

        <p style={{ opacity: 0.75 }}>
          Select total extra runs
        </p>

        <div
          style={{
            display: "grid",
            gridTemplateColumns:
              "repeat(auto-fit, minmax(60px, 1fr))",
            gap: 10,
            marginTop: 16,
          }}
        >
          {(
            selectedExtraType === "WIDE"
              ? [
                  "WD",
                  "WD+1",
                  "WD+2",
                  "WD+3",
                  "WD+4",
                  "WD+5",
                  "WD+6",
                ]
              : selectedExtraType === "NOBALL"
                ? [
                    "NB",
                    "NB+1",
                    "NB+2",
                    "NB+3",
                    "NB+4",
                    "NB+5",
                    "NB+6",
                  ]
                : [1, 2, 3, 4, 5, 6, 7]
          ).map((runs) => (
            <button
              key={runs}
              type="button"
              className="extra-choice-btn"
              onClick={() =>
                confirmExtra(runs)
              }
            >
              {runs}
            </button>
          ))}
        </div>

        <div className="modal-actions">
          <button
            type="button"
            className="btn btn-outline"
            onClick={() =>
              setShowExtrasModal(false)
            }
          >
            Cancel
          </button>
        </div>
      </div>
    </div>,
    document.body
  )}
{showStartMatchModal && (
  <div className="modal-backdrop">
    <div className="modal-card">
      <h3>▶ Start Match</h3>

      <p className="muted">
        Select batting first team before starting the match.
      </p>

      <label>
        <span>Batting First</span>
        <select
          value={startMatchData.battingFirstTeamId || ""}
          onChange={(e) =>
            setStartMatchData((prev) => ({
              ...prev,
              battingFirstTeamId: e.target.value
            }))
          }
          required
        >
          <option value="">Select batting first team</option>

          {teams
            .filter((t) =>
              [
                String(selectedMatch?.teamAId),
                String(selectedMatch?.teamBId)
              ].includes(String(t.id))
            )
            .map((team) => (
              <option key={team.id} value={team.id}>
                {team.name}
              </option>
            ))}
        </select>
      </label>

      <div className="modal-actions">
        <button
          type="button"
          className="btn btn-outline"
          onClick={() => setShowStartMatchModal(false)}
        >
          Cancel
        </button>

        <button
          type="button"
          className="btn"
          onClick={confirmStartMatch}
        >
          Start Match
        </button>
      </div>
    </div>
  </div>
)}
{showAiAnalysisModal && (
  <div
    className="modal-backdrop ai-intelligence-backdrop"
    role="presentation"
    onMouseDown={(event) => {
      if (
        event.target ===
        event.currentTarget
      ) {
        setShowAiAnalysisModal(false);
      }
    }}
  >
    <section
      className="ai-intelligence-modal"
      role="dialog"
      aria-modal="true"
      aria-labelledby="ai-intelligence-title"
    >
      <header className="ai-intelligence-header">
        <div className="ai-intelligence-heading">
          <span
            className="ai-intelligence-icon"
            aria-hidden="true"
          >
            ✨
          </span>

          <div>
            <span className="ai-intelligence-kicker">
              MATCH INTELLIGENCE
            </span>

            <h3 id="ai-intelligence-title">
              {aiReview?.match
                ? `${aiReview.match.teamA} vs ${aiReview.match.teamB}`
                : "AI Match Review"}
            </h3>

            <p>
              {aiReview?.executiveSummary?.result ||
                "Verified post-match insights"}
            </p>

            {aiReviewMeta && (
              <div className="ai-review-cache-status">
                <span
                  className={
                    aiReviewMeta.cached
                      ? "cached"
                      : "generated"
                  }
                >
                  {aiReviewMeta.cached
                    ? "⚡ Loaded from saved review"
                    : "✨ Generated and saved"}
                </span>

                {aiReviewMeta.generatedAt && (
                  <time
                    dateTime={
                      aiReviewMeta.generatedAt
                    }
                    title={
                      new Date(
                        aiReviewMeta.generatedAt
                      ).toLocaleString()
                    }
                  >
                    {new Date(
                      aiReviewMeta.generatedAt
                    ).toLocaleDateString()}
                  </time>
                )}
              </div>
            )}
          </div>
        </div>

        <button
          type="button"
          className="ai-intelligence-close"
          onClick={() =>
            setShowAiAnalysisModal(false)
          }
          aria-label="Close AI Match Intelligence"
        >
          ✕
        </button>
      </header>

      {aiReview ? (
        <>
          <div
            className="ai-intelligence-tabs"
            role="tablist"
            aria-label="AI review sections"
          >
            {[
              ["OVERVIEW", "Overview"],
              ["MOMENTS", "Moments"],
              ["INSIGHTS", "Insights"],
              ["STORY", "Story"],
              ["SHARE", "Share"],
            ].map(([key, label]) => (
              <button
                key={key}
                type="button"
                role="tab"
                aria-selected={
                  aiReviewTab === key
                }
                className={
                  aiReviewTab === key
                    ? "active"
                    : ""
                }
                onClick={() =>
                  setAiReviewTab(key)
                }
              >
                {label}
              </button>
            ))}
          </div>

          <div className="ai-intelligence-body">
            {aiReviewTab === "OVERVIEW" && (
              <div className="ai-review-overview">
                <article className="ai-review-hero-card">
                  <span>EXECUTIVE SUMMARY</span>

                  <h4>
                    {aiReview.executiveSummary
                      ?.headline}
                  </h4>

                  <p>
                    {aiReview.executiveSummary
                      ?.summary}
                  </p>
                </article>

                <div className="ai-review-score-strip">
                  {(aiReview.scoreSummary || []).map(
                    (innings) => (
                      <article
                        key={innings.inningsNo}
                      >
                        <span>
                          {innings.teamName}
                        </span>

                        <strong>
                          {innings.runs}/
                          {innings.wickets}
                        </strong>

                        <small>
                          {innings.overs} ov · RR {innings.runRate}
                        </small>
                      </article>
                    )
                  )}
                </div>

                <article className="ai-review-potm-card">
                  <div className="ai-review-potm-title">
                    <span aria-hidden="true">⭐</span>

                    <div>
                      <small>
                        PLAYER OF THE MATCH
                      </small>

                      <h4>
                        {aiReview.playerOfTheMatch
                          ?.playerName}
                      </h4>

                      {aiReview.playerOfTheMatch
                        ?.teamName && (
                        <p>
                          {aiReview.playerOfTheMatch
                            .teamName}
                        </p>
                      )}
                    </div>

                    <b>
                      {aiReview.playerOfTheMatch
                        ?.confidence || 0}
                      %
                    </b>
                  </div>

                  <div className="ai-review-stat-chips">
                    {(aiReview.playerOfTheMatch
                      ?.statLines || []).map(
                      (line) => (
                        <span key={line}>
                          {line}
                        </span>
                      )
                    )}
                  </div>

                  <p className="ai-review-potm-reason">
                    {aiReview.playerOfTheMatch
                      ?.reason}
                  </p>
                </article>

                <div className="ai-review-takeaways">
                  {(aiReview.teamTakeaways || []).map(
                    (item) => (
                      <article key={item.teamName}>
                        <strong>
                          {item.teamName}
                        </strong>

                        <p>{item.takeaway}</p>
                      </article>
                    )
                  )}
                </div>
              </div>
            )}

            {aiReviewTab === "MOMENTS" && (
              <div className="ai-review-section-stack">
                <div className="ai-review-section-heading">
                  <div>
                    <span>TURNING POINTS</span>
                    <h4>Where momentum moved</h4>
                  </div>

                  <small>
                    Verified from ball-by-ball data
                  </small>
                </div>

                <div className="ai-review-moment-list">
                  {(aiReview.turningPoints || []).length ? (
                    aiReview.turningPoints.map(
                      (item, index) => (
                        <article
                          key={`${item.over}-${index}`}
                        >
                          <span className="ai-review-moment-number">
                            {index + 1}
                          </span>

                          <div>
                            <small>{item.over}</small>
                            <h5>{item.title}</h5>
                            <p>{item.detail}</p>
                          </div>

                          <b>{item.impact}</b>
                        </article>
                      )
                    )
                  ) : (
                    <div className="ai-review-empty">
                      No single over met the turning-point threshold.
                    </div>
                  )}
                </div>

                {!!aiReview.recordsAndMilestones
                  ?.length && (
                  <div className="ai-review-milestones">
                    <span>🏅 MATCH MILESTONES</span>

                    <div>
                      {aiReview.recordsAndMilestones.map(
                        (item) => (
                          <p key={item}>{item}</p>
                        )
                      )}
                    </div>
                  </div>
                )}
              </div>
            )}

            {aiReviewTab === "INSIGHTS" && (
              <div className="ai-review-insight-layout">
                <section>
                  <div className="ai-review-section-heading compact">
                    <div>
                      <span>🏏 BATTING</span>
                      <h4>Impact performances</h4>
                    </div>
                  </div>

                  <div className="ai-review-insight-list">
                    {(aiReview.battingInsights || []).map(
                      (item) => (
                        <article key={`${item.title}-${item.metric}`}>
                          <div>
                            <h5>{item.title}</h5>
                            <p>{item.detail}</p>
                          </div>

                          <b>{item.metric}</b>
                        </article>
                      )
                    )}
                  </div>
                </section>

                <section>
                  <div className="ai-review-section-heading compact">
                    <div>
                      <span>🎯 BOWLING</span>
                      <h4>Pressure creators</h4>
                    </div>
                  </div>

                  <div className="ai-review-insight-list">
                    {(aiReview.bowlingInsights || []).map(
                      (item) => (
                        <article key={`${item.title}-${item.metric}`}>
                          <div>
                            <h5>{item.title}</h5>
                            <p>{item.detail}</p>
                          </div>

                          <b>{item.metric}</b>
                        </article>
                      )
                    )}
                  </div>
                </section>
              </div>
            )}

            {aiReviewTab === "STORY" && (
              <div className="ai-review-story-layout">
                <article className="ai-review-story-card">
                  <span>THE MATCH STORY</span>

                  <p>{aiReview.matchStory}</p>
                </article>

                <div className="ai-review-story-actions">
                  <button
                    type="button"
                    onClick={() =>
                      copyAiReviewText(
                        aiReview.matchStory,
                        "story"
                      )
                    }
                  >
                    {aiShareCopied === "story"
                      ? "✓ Story copied"
                      : "Copy match story"}
                  </button>

                  <button
                    type="button"
                    className="secondary"
                    onClick={() =>
                      setAiReviewTab("SHARE")
                    }
                  >
                    Open share pack
                  </button>
                </div>
              </div>
            )}

            {aiReviewTab === "SHARE" && (
              <div className="ai-review-share-grid">
                <article>
                  <header>
                    <div>
                      <span aria-hidden="true">💬</span>
                      <div>
                        <small>WHATSAPP</small>
                        <h4>Match update</h4>
                      </div>
                    </div>

                    <button
                      type="button"
                      onClick={() =>
                        copyAiReviewText(
                          aiReview.shareContent
                            ?.whatsapp,
                          "whatsapp"
                        )
                      }
                    >
                      {aiShareCopied === "whatsapp"
                        ? "Copied"
                        : "Copy"}
                    </button>
                  </header>

                  <pre>
                    {aiReview.shareContent
                      ?.whatsapp}
                  </pre>
                </article>

                <article>
                  <header>
                    <div>
                      <span aria-hidden="true">📣</span>
                      <div>
                        <small>SOCIAL</small>
                        <h4>Short caption</h4>
                      </div>
                    </div>

                    <button
                      type="button"
                      onClick={() =>
                        copyAiReviewText(
                          aiReview.shareContent
                            ?.social,
                          "social"
                        )
                      }
                    >
                      {aiShareCopied === "social"
                        ? "Copied"
                        : "Copy"}
                    </button>
                  </header>

                  <pre>
                    {aiReview.shareContent
                      ?.social}
                  </pre>
                </article>
              </div>
            )}
          </div>
        </>
      ) : aiAnalysisLoading ? (
        <div
          className="ai-analysis-content pretty-ai-analysis ai-review-legacy"
          role="status"
          aria-live="polite"
          style={{
            minHeight: "180px",
            display: "grid",
            placeItems: "center",
            textAlign: "center",
          }}
        >
          <div>
            <div style={{ fontSize: "1.7rem", marginBottom: "10px" }}>✨</div>
            <strong>Building AI Match Review…</strong>
            <p style={{ marginTop: "8px", opacity: 0.78 }}>
              Verifying the result, scorecard and match moments.
            </p>
          </div>
        </div>
      ) : (
        <div className="ai-analysis-content pretty-ai-analysis ai-review-legacy">
          {aiAnalysis
            .split("\n")
            .filter((line) => line.trim())
            .map((line, index) => (
              <p key={`legacy-ai-${index}`}>
                {line.replace(/^[-*]\s*/, "")}
              </p>
            ))}
        </div>
      )}

      <footer className="ai-intelligence-footer">
        <span>
          AI narrative · Verified Cric4All match data
        </span>

        <button
          type="button"
          onClick={() =>
            setShowAiAnalysisModal(false)
          }
        >
          Done
        </button>
      </footer>
    </section>
  </div>
)}
{showMatchCreatedModal && createdMatchInfo && (
  <div className="modal-backdrop">
    <div className="match-created-modal match-created-modal-pro">
      <button
        type="button"
        className="edit-modal-close"
        onClick={() => {
          setShowMatchCreatedModal(false);
          setCreatedMatchInfo(null);
        }}
      >
        ✕
      </button>

      <div className="match-created-icon">✅</div>

      <h3>Match Created Successfully!</h3>

      <p>
        {createdMatchInfo.teamAName || "Team A"} vs{" "}
        {createdMatchInfo.teamBName || "Team B"} has been added to Scheduled matches.
      </p>

      <div className="post-create-actions">
<button
  type="button"
  className="btn btn-primary"
onClick={async () => {
  setShowMatchCreatedModal(false);
  await handleStartMatch(createdMatchInfo);
}}
>
  🏏 Start Scoring
</button>

        <button
          type="button"
          className="btn btn-outline"
          onClick={() => {
            setShowMatchCreatedModal(false);
            setCreatedMatchInfo(null);
            setMatchesSubTab("SCHEDULED");
            setActiveTab("matches");
          }}
        >
          📅 View Scheduled
        </button>

        <button
          type="button"
          className="btn btn-outline"
          onClick={() => {
            setShowMatchCreatedModal(false);
            setCreatedMatchInfo(null);
            setMessage("");
            setError("");
            setMatchesSubTab("CREATE MATCH");
            setActiveTab("matches");
          }}
        >
          ➕ Add Another Match
        </button>
      </div>
    </div>
  </div>
)}
{openFilter === "filterCenter" && (
  <div className="modal-backdrop">
    <div className="filter-center-modal">
      <div className="filter-center-header">
        <div>
          <h3>🔎 Filter Command Center</h3>
          <p>Search, select, and narrow your cricket data quickly.</p>
        </div>

        <button type="button" className="btn" onClick={() => setOpenFilter(null)}>
          ✕
        </button>
      </div>

      <input
        className="filter-search"
        value={filterSearch}
        onChange={(e) => setFilterSearch(e.target.value)}
        placeholder="Search teams, players, matches..."
      />

      <div className="filter-category-tabs">
        {["teams", "players", "matches", "series", "years", "statuses"].map((cat) => (
          <button
            key={cat}
            type="button"
            className={filterCategory === cat ? "active" : ""}
            onClick={() => setFilterCategory(cat)}
          >
            {cat}
          </button>
        ))}
      </div>

      <div className="filter-results-panel">
        {/* render category results here */}
        {filterCategory === "teams" &&
  teams
    .filter((t) => Number(t.leagueId) === Number(activeLeagueId))
    .filter((t) =>
      t.name.toLowerCase().includes(filterSearch.toLowerCase())
    )
    .map((team) => (
      <button
        key={team.id}
        type="button"
        className={
          contextFilters.teamIds.includes(Number(team.id))
            ? "filter-row active"
            : "filter-row"
        }
onClick={() => {
  toggleFilterValue("teamIds", Number(team.id));

  setContextFilters((prev) => ({
    ...prev,
    playerNames: [],
    matchIds: []
  }));
}}
      >
        <span>🏏 {team.name}</span>
        <small>{team.players?.length || 0} players</small>
      </button>
    ))}
    {filterCategory === "players" &&
  availablePlayersForFilter
    .filter((p) =>
      p.name.toLowerCase().includes(filterSearch.toLowerCase())
    )
    .map((player) => (
      <button
        key={player.normalizedName}
        type="button"
        className={
          contextFilters.playerNames.includes(player.normalizedName)
            ? "filter-row active"
            : "filter-row"
        }
        onClick={() =>
          toggleFilterValue("playerNames", player.normalizedName)
        }
      >
        <span>👤 {player.name}</span>
      </button>
    ))}
{filterCategory === "matches" &&
  filteredMatchesForContextLens
    .filter((m) => {
      const searchText = [
        m.teamAName,
        m.teamBName,
        m.id,
        m.seriesName,
        m.status,
        m.battingFirstTeamName,
        m.scoreSummary,
        m.liveScore,
        m.resultText,
        m.firstInningsScore,
        m.secondInningsScore,
        m.scheduledAt,
        m.startedAt,
      ]
        .filter(Boolean)
        .join(" ")
        .toLowerCase();

      return searchText.includes(filterSearch.toLowerCase());
    })
    .map((match) => {
      const matchDate =
        match.scheduledAt ||
        match.startedAt ||
        match.createdAt;

      const dateText = matchDate
        ? formatMatchDateTime(matchDate)
        : "Date TBD";

      const scoreText =
        match.scoreSummary ||
        match.liveScore ||
        [match.firstInningsScore, match.secondInningsScore]
          .filter(Boolean)
          .join(" vs ");

      return (
        <button
          key={match.id}
          type="button"
          className={
            contextFilters.matchIds.includes(Number(match.id))
              ? "filter-row smart-match-row active"
              : "filter-row smart-match-row"
          }
          onClick={() => toggleFilterValue("matchIds", Number(match.id))}
        >
          <span className="smart-match-title">
            🏏 {match.teamAName} vs {match.teamBName}
          </span>

          <small className="smart-match-extra">
            {scoreText
              ? `📊 ${scoreText}`
              : match.battingFirstTeamName
              ? `🏏 Bat 1st: ${match.battingFirstTeamName}`
              : `Match #${match.id}`}
          </small>
          <small className="smart-match-meta">
            <b>{String(match.status || "").replaceAll("_", " ")}</b>
            {" • "}
            {dateText}
            {match.seriesName ? ` • ${match.seriesName}` : ""}
          </small>
        </button>
      );
    })} 
{filterCategory === "series" &&
  filteredSeriesForContextLens
    .filter((s) =>
      `${s.name} ${s.year}`
        .toLowerCase()
        .includes(filterSearch.toLowerCase())
    )
    .map((series) => (
      <button
        key={series.id}
        type="button"
        className={
          contextFilters.seriesIds.includes(Number(series.id))
            ? "filter-row active"
            : "filter-row"
        }
onClick={() => {
  const seriesId = Number(series.id);

  setContextFilters((prev) => {
    const seriesIds = prev.seriesIds.includes(seriesId)
      ? prev.seriesIds.filter((id) => Number(id) !== seriesId)
      : [...prev.seriesIds, seriesId];

    return {
      ...prev,
      seriesIds,
      matchIds: []
    };
  });

  setFilterCategory("matches");
}}
      >
        <span>🏆 {series.name}</span>
        <small>{series.year}</small>
      </button>
    ))}
    {filterCategory === "years" &&
  [...new Set(seriesList.map((s) => Number(s.year)))]
    .sort((a, b) => b - a)
    .map((year) => (
      <button
        key={year}
        type="button"
        className={
          contextFilters.years.includes(Number(year))
            ? "filter-row active"
            : "filter-row"
        }
onClick={() => {
  const yearNumber = Number(year);

  setContextFilters((prev) => {
    const years = prev.years.includes(yearNumber)
      ? prev.years.filter((y) => Number(y) !== yearNumber)
      : [...prev.years, yearNumber];

    return {
      ...prev,
      years,
      seriesIds: [],
      matchIds: []
    };
  });

  setFilterCategory("series");
}}
      >
        <span>📅 {year}</span>
      </button>
    ))}
    {filterCategory === "statuses" &&
  ["SCHEDULED", "IN_PROGRESS", "COMPLETED", "COMPLETED_LOCKED", "COMPLETED_CORRECTED"].map(
    (status) => (
      <button
        key={status}
        type="button"
        className={
          contextFilters.statuses.includes(status)
            ? "filter-row active"
            : "filter-row"
        }
        onClick={() => toggleFilterValue("statuses", status)}
      >
        <span>📌 {status.replaceAll("_", " ")}</span>
      </button>
    )
  )}
      </div>

      <div className="filter-center-footer">
<button
  type="button"
  className="btn"
  onClick={() => {
    clearContextFilters();
    setFilterSearch("");
    setFilterCategory("teams");
  }}
>
  Clear All
</button>

        <button type="button" className="btn" onClick={() => setOpenFilter(null)}>
          Apply Filters
        </button>
      </div>
    </div>
  </div>
)}
{showSeriesModal && (
  <div className="modal-backdrop">
    <div className="modal-card app-modal-card">
      <h3>{editingSeries ? "✏️ Edit Series" : "📅 Create Series"}</h3>

      <p className="muted">
        {editingSeries
          ? "Update the selected series details."
          : "Create a tournament, season, cup, or yearly series under the selected league."}
      </p>

      <label>
        <span>Series Name</span>
        <input
          value={seriesForm.name}
          onChange={(e) =>
            setSeriesForm((prev) => ({
              ...prev,
              name: e.target.value,
            }))
          }
          placeholder="Summer Cup"
        />
      </label>

      <label>
        <span>Year</span>
        <input
          type="number"
          value={seriesForm.year}
          onChange={(e) =>
            setSeriesForm((prev) => ({
              ...prev,
              year: e.target.value,
            }))
          }
        />
      </label>

      <label>
        <span>Description</span>
        <input
          value={seriesForm.description || ""}
          onChange={(e) =>
            setSeriesForm((prev) => ({
              ...prev,
              description: e.target.value,
            }))
          }
          placeholder="Optional"
        />
      </label>

      <div className="modal-actions">
        <button
          type="button"
          className="btn btn-outline"
          onClick={() => {
            setShowSeriesModal(false);
            setEditingSeries(null);
          }}
        >
          Cancel
        </button>

        <button
          type="button"
          className="btn"
          onClick={async () => {
            const isEditing = Boolean(editingSeries?.id);

            const saved = await api(
              isEditing ? `/api/series/${editingSeries.id}` : "/api/series",
              {
                method: isEditing ? "PATCH" : "POST",
                body: JSON.stringify({
                  ...seriesForm,
                  leagueId: activeLeagueId,
                  year: Number(seriesForm.year),
                }),
              }
            );

            setSeriesForm({
              name: "",
              year: new Date().getFullYear(),
              description: "",
            });

            setEditingSeries(null);
            setShowSeriesModal(false);
            await loadSeries(activeLeagueId);

            setSelectedSeriesId(String(saved.id));
          }}
        >
          {editingSeries ? "Save Changes" : "Create Series"}
        </button>
      </div>
    </div>
  </div>
)}
{showWicketModal && typeof document !== "undefined" && createPortal(
<div className="modal-backdrop wicket-modal-backdrop">
  <div className="modal-card app-modal-card wicket-modal-card">
    <button
  type="button"
  className="wicket-modal-close"
  onClick={() => {
    setShowWicketModal(false);
    setRunOutRuns(null);

    setBallForm((prev) => ({
      ...prev,
      isWicket: false,
      wicketType: "NONE",
      dismissedPlayerId: "",
      newBatterId: "",
      fielderId: "",
      assistantFielderId: "",
      wicketNote: "",
    }));
  }}
>
  ✕
</button>
        <div className="live-popup-snapshot">
          <div className="live-popup-topline">
            <span className="live-dot">
              ● LIVE
            </span>

            <span className="live-popup-over">
              Over {bowlerChangeScore.overs}
            </span>
          </div>

          <div className="live-popup-main">
            <div>
              <span>Current Score</span>

              <strong>
                {bowlerChangeScore.score}
              </strong>
            </div>

            <div>
              <span>CRR</span>

              <strong>
                {bowlerChangeScore.crr}
              </strong>
            </div>
          </div>

          <div className="live-popup-recent">
            <div className="live-popup-recent-head">
              <span>Current Over</span>

              <b>
                Over {extrasModalCurrentOver.overNo}
              </b>
            </div>

            <div className="live-popup-recent-direction">
              ← Latest delivery
            </div>

            <div className="live-popup-balls">
              {extrasModalCurrentOver.balls.length ? (
                extrasModalCurrentOver.balls.map(
                  (ball, index) => {
                    const label =
                      ball.shortText ||
                      ball.displayText ||
                      ball.resultText ||
                      ball.label ||
                      "";

                    const result = String(label)
                      .replace(
                        /^\s*\d+\.\d+\s*/,
                        ""
                      )
                      .replace(/[()]/g, "")
                      .trim();

                    const normalized =
                      result.toUpperCase();

                    const ballClass =
                      normalized === "W" ||
                      normalized === "WKT"
                        ? "wicket"
                        : normalized === "4"
                          ? "four"
                          : normalized === "6"
                            ? "six"
                            : normalized.startsWith(
                                  "WD"
                                ) ||
                                normalized.includes(
                                  "WIDE"
                                )
                              ? "wide"
                              : normalized.startsWith(
                                    "NB"
                                  ) ||
                                  normalized.includes(
                                    "NO BALL"
                                  ) ||
                                  normalized.includes(
                                    "NOBALL"
                                  )
                                ? "noball"
                                : "";

                    return (
                      <b
                        key={
                          ball.id ||
                          ball.sequence ||
                          `extra-recent-${index}`
                        }
                        className={`${ballClass} ${
                          index === 0
                            ? "latest"
                            : ""
                        }`}
                      >
                        {result || "-"}
                      </b>
                    );
                  }
                )
              ) : (
                <small>
                  No deliveries in the current
                  over yet
                </small>
              )}
            </div>
          </div>
        </div>
      <h3>🏏 Wicket Details</h3>

      <p style={{ opacity: 0.75, marginBottom: 16 }}>
        Select dismissal type, runs if run out, player out, fielder details,
        and replacement batter.
      </p>

      <label>
        <span>Wicket Type</span>
        <select
          value={ballForm.wicketType || ""}
          onChange={(e) =>
            setBallForm((prev) => ({
              ...prev,
              wicketType: e.target.value,
              dismissedPlayerId:
                e.target.value === "RUN_OUT"
                  ? prev.dismissedPlayerId || prev.strikerId
                  : prev.strikerId,
            }))
          }
        >
 {WICKET_TYPES
  .filter(
    (x) =>
      x !== "NONE" &&
      x !== "RETIRED_HURT"
  )
  .map((type) => (
            <option key={type} value={type}>
              {type.replaceAll("_", " ")}
            </option>
          ))}
        </select>
      </label>

      {ballForm.wicketType === "RUN_OUT" && (
        <>
          <label style={{ marginTop: 12 }}>
            <span>Runs Completed Before Run Out</span>

            <div className="quick-run-grid">
{[0, 1, 2, 3, 4, 5, 6].map((runs) => (
  <button
    key={runs}
    type="button"
    className={`runout-btn ${
      runOutRuns === runs
        ? "selected"
        : ""
    }`}
    onClick={() => {
      setRunOutRuns(runs);
    }}
  >
    RO + {runs}
  </button>
))}
            </div>
          </label>

          <label style={{ marginTop: 12 }}>
            <span>Who is Out?</span>

            <select
              value={ballForm.dismissedPlayerId || ""}
              onChange={(e) =>
  setBallForm((prev) => ({
    ...prev,
    dismissedPlayerId: e.target.value,
    newBatterId: "",
  }))
}
            >
              <option value="">Select Player Out</option>

              {battingTeam?.players
                ?.filter(
                  (p) =>
                    String(p.id) === String(ballForm.strikerId) ||
                    String(p.id) === String(ballForm.nonStrikerId)
                )
                .map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.name}
                    {String(p.id) === String(ballForm.strikerId)
                      ? " — Striker"
                      : " — Non-striker"}
                  </option>
                ))}
            </select>
          </label>
        </>
      )}

      {["CAUGHT", "STUMPED", "RUN_OUT"].includes(ballForm.wicketType) && (
        <label style={{ marginTop: 12 }}>
          <span>
            {ballForm.wicketType === "CAUGHT"
              ? "Caught By"
              : ballForm.wicketType === "STUMPED"
              ? "Stumped By"
              : "Run Out By"}
          </span>

          <select
            value={ballForm.fielderId || ""}
            onChange={(e) =>
              setBallForm((prev) => ({
                ...prev,
                fielderId: e.target.value,
              }))
            }
          >
            <option value="">Select Fielder</option>

            {bowlingTeam?.players?.map((p) => (
              <option key={p.id} value={p.id}>
                {p.name}
              </option>
            ))}
          </select>
        </label>
      )}

      {ballForm.wicketType === "RUN_OUT" && (
        <label style={{ marginTop: 12 }}>
          <span>Assistant Fielder Optional</span>

          <select
            value={ballForm.assistantFielderId || ""}
            onChange={(e) =>
              setBallForm((prev) => ({
                ...prev,
                assistantFielderId: e.target.value,
              }))
            }
          >
            <option value="">No Assistant Fielder</option>

            {bowlingTeam?.players?.map((p) => (
              <option key={p.id} value={p.id}>
                {p.name}
              </option>
            ))}
          </select>
        </label>
      )}

      <label style={{ marginTop: 12 }}>
        <span>New Batter</span>

        <select
          value={ballForm.newBatterId || ""}
          onChange={(e) =>
            setBallForm((prev) => ({
              ...prev,
              newBatterId: e.target.value,
            }))
          }
          disabled={!ballForm.isWicket || endInningsAfterWicket}
        >
          <option value="">Select New Batter</option>
          {wicketNewBatterOptions.map((p) => (
            <option key={p.id} value={p.id}>
              {p.name}
            </option>
          ))}
        </select>
        <label className="wicket-end-innings-option">
  <input
    type="checkbox"
    checked={endInningsAfterWicket}
    onChange={(e) => {
      const checked = e.target.checked;

      setEndInningsAfterWicket(checked);

      if (checked) {
        setBallForm((prev) => ({
          ...prev,
          newBatterId: "",
        }));
      }
    }}
  />

  <span>
    🛑 No more batters available — end innings after this wicket
  </span>
</label>
        {noNewBatterAvailable && (
  <div className="wicket-final-batter-note">
    🏁 No new batter available. This wicket will end the innings.
  </div>
)}
      </label>

      <label style={{ marginTop: 12 }}>
        <span>Wicket Note Optional</span>

        <input
          type="text"
          value={ballForm.wicketNote || ""}
          placeholder="Example: Direct hit from cover"
          onChange={(e) =>
            setBallForm((prev) => ({
              ...prev,
              wicketNote: e.target.value,
            }))
          }
        />
      </label>

      <div className="modal-actions wicket-modal-actions">
        <button
          type="button"
          className="btn btn-outline"
          onClick={() => {
            setShowWicketModal(false);
            setRunOutRuns(null);

            setBallForm((prev) => ({
              ...prev,
              isWicket: false,
              wicketType: "NONE",
              dismissedPlayerId: "",
              newBatterId: "",
              fielderId: "",
              assistantFielderId: "",
              wicketNote: "",
            }));
          }}
        >
          Cancel
        </button>

        <button type="button" className="btn"  onClick={() => confirmWicket()}>
          Confirm Wicket
        </button>
      </div>
    </div>
  </div>,
  document.body
)}
{showDeliverySetupModal && (
  <div className="modal-backdrop">
    <div className="add-player-pro-modal">
        <div className="live-popup-snapshot">
          <div className="live-popup-topline">
            <span className="live-dot">
              ● LIVE
            </span>

            <span className="live-popup-over">
              Over {bowlerChangeScore.overs}
            </span>
          </div>

          <div className="live-popup-main">
            <div>
              <span>Current Score</span>

              <strong>
                {bowlerChangeScore.score}
              </strong>
            </div>

            <div>
              <span>CRR</span>

              <strong>
                {bowlerChangeScore.crr}
              </strong>
            </div>
          </div>

          <div className="live-popup-recent">
            <div className="live-popup-recent-head">
              <span>Current Over</span>

              <b>
                Over {extrasModalCurrentOver.overNo}
              </b>
            </div>

            <div className="live-popup-recent-direction">
              ← Latest delivery
            </div>

            <div className="live-popup-balls">
              {extrasModalCurrentOver.balls.length ? (
                extrasModalCurrentOver.balls.map(
                  (ball, index) => {
                    const label =
                      ball.shortText ||
                      ball.displayText ||
                      ball.resultText ||
                      ball.label ||
                      "";

                    const result = String(label)
                      .replace(
                        /^\s*\d+\.\d+\s*/,
                        ""
                      )
                      .replace(/[()]/g, "")
                      .trim();

                    const normalized =
                      result.toUpperCase();

                    const ballClass =
                      normalized === "W" ||
                      normalized === "WKT"
                        ? "wicket"
                        : normalized === "4"
                          ? "four"
                          : normalized === "6"
                            ? "six"
                            : normalized.startsWith(
                                  "WD"
                                ) ||
                                normalized.includes(
                                  "WIDE"
                                )
                              ? "wide"
                              : normalized.startsWith(
                                    "NB"
                                  ) ||
                                  normalized.includes(
                                    "NO BALL"
                                  ) ||
                                  normalized.includes(
                                    "NOBALL"
                                  )
                                ? "noball"
                                : "";

                    return (
                      <b
                        key={
                          ball.id ||
                          ball.sequence ||
                          `extra-recent-${index}`
                        }
                        className={`${ballClass} ${
                          index === 0
                            ? "latest"
                            : ""
                        }`}
                      >
                        {result || "-"}
                      </b>
                    );
                  }
                )
              ) : (
                <small>
                  No deliveries in the current
                  over yet
                </small>
              )}
            </div>
          </div>
        </div>
      <div className="add-player-pro-hero">
        <div className="add-player-pro-icon">🎯</div>

        <div>
          <h3>Setup Next Delivery</h3>
          <p>{deliverySetupReason}</p>
        </div>

        <button
          type="button"
          className="add-player-pro-close"
          onClick={() => {
  const safeInningsNo = getSafeScoringInningsNo(scoreboard, ballForm);

  setBallForm((prev) => ({
    ...prev,
    inningsNo: safeInningsNo,
  }));

  setShowDeliverySetupModal(false);
}}
        >
          ✕
        </button>
      </div>

      <div className="add-player-pro-form">
        <label className="player-modal-field">
          <span>🏏 Striker</span>
          <select
            value={ballForm.strikerId || ""}
            onChange={(e) =>
              setBallForm((prev) => ({
                ...prev,
                strikerId: e.target.value,
              }))
            }
          >
            <option value="">Choose striker</option>
            {setupBatters.map((p) => (
              <option key={p.id} value={p.id}>
                {p.name}
              </option>
            ))}
          </select>
        </label>

        <label className="player-modal-field">
          <span>🏏 Non-striker</span>
          <select
            value={ballForm.nonStrikerId || ""}
            onChange={(e) =>
              setBallForm((prev) => ({
                ...prev,
                nonStrikerId: e.target.value,
              }))
            }
          >
            <option value="">Choose non-striker</option>
            {setupBatters.filter((p) => String(p.id) !== String(ballForm.strikerId))
              .map((p) => (
                <option key={p.id} value={p.id}>
                  {p.name}
                </option>
              ))}
          </select>
        </label>

        <label className="player-modal-field">
          <span>🎯 Bowler</span>
          <select
            value={ballForm.bowlerId || ""}
            onChange={(e) =>
              setBallForm((prev) => ({
                ...prev,
                bowlerId: e.target.value,
              }))
            }
          >
            <option value="">Choose bowler</option>
            {setupBowlers.map((p) => (
              <option key={p.id} value={p.id}>
                {p.name}
              </option>
            ))}
          </select>
        </label>

        <div className="player-modal-actions">
          <button
            type="button"
            className="player-modal-save"
            disabled={
              !ballForm.strikerId ||
              !ballForm.nonStrikerId ||
              !ballForm.bowlerId ||
              String(ballForm.strikerId) === String(ballForm.nonStrikerId)
            }
onClick={async () => {
  const setupInningsNo =
    Number(ballForm?.inningsNo || 1);

  const selectedStrikerId =
    String(ballForm.strikerId || "");

  const selectedNonStrikerId =
    String(ballForm.nonStrikerId || "");

  const selectedBowlerId =
    String(ballForm.bowlerId || "");

  const selectedStriker =
    setupBatters.find(
      (player) =>
        String(player.id) ===
        selectedStrikerId
    );

  const selectedNonStriker =
    setupBatters.find(
      (player) =>
        String(player.id) ===
        selectedNonStrikerId
    );

  const selectedBowler =
    setupBowlers.find(
      (player) =>
        String(player.id) ===
        selectedBowlerId
    );

  const nextForm = {
    ...ballForm,
    inningsNo: setupInningsNo,
    strikerId: selectedStrikerId,
    nonStrikerId: selectedNonStrikerId,
    bowlerId: selectedBowlerId,
  };

  const setupInnings =
    scoreboard
      ?.innings
      ?.[setupInningsNo - 1] ||
    null;

  const setupInningsLegalBalls =
    Number(
      setupInnings
        ?.legalBalls ||
      0
    );

  /*
   * A Delivery Setup shown at 0.0 is opening a fresh innings.
   * All three active-player stat cards must therefore start at zero even
   * though currentState may still contain objects from the prior innings.
   */
  const isFreshInningsSetup =
    setupInningsLegalBalls ===
    0;

  const createFreshBatterStats =
    (player) => ({
      playerId:
        Number(
          player?.id ||
          0
        ) ||
        null,

      playerName:
        player?.name ||
        "",

      runs:
        0,

      balls:
        0,

      fours:
        0,

      sixes:
        0,

      strikeRate:
        "0.00",
    });

  const createFreshBowlerStats =
    (player) => ({
      playerId:
        Number(
          player?.id ||
          0
        ) ||
        null,

      playerName:
        player?.name ||
        "",

      wickets:
        0,

      runs:
        0,

      balls:
        0,

      overs:
        "0.0",

      maidens:
        0,

      economy:
        "0.00",
    });

  /*
   * Persist the setup into BOTH local scoring sources:
   * 1. ballForm (used to submit the next delivery)
   * 2. scoreboard.currentState (used by offline previews and cache recovery)
   *
   * Previously only ballForm changed. The cached local scoreboard still had
   * null/old players, so periodic offline snapshot reloads could erase the
   * chosen setup and reopen this modal.
   */
  const localBoard =
    scoreboard
      ? (
          typeof structuredClone === "function"
            ? structuredClone(scoreboard)
            : JSON.parse(
                JSON.stringify(scoreboard)
              )
        )
      : null;

  if (localBoard) {
    localBoard.currentInnings =
      setupInningsNo;

    const previousCurrentState =
      localBoard.currentState ||
      {};

    const keepExistingStrikerStats =
      !isFreshInningsSetup &&
      Number(
        previousCurrentState
          .strikerId
      ) ===
        Number(
          selectedStrikerId
        );

    const keepExistingNonStrikerStats =
      !isFreshInningsSetup &&
      Number(
        previousCurrentState
          .nonStrikerId
      ) ===
        Number(
          selectedNonStrikerId
        );

    const keepExistingBowlerStats =
      !isFreshInningsSetup &&
      Number(
        previousCurrentState
          .bowlerId
      ) ===
        Number(
          selectedBowlerId
        );

    localBoard.currentState = {
      ...previousCurrentState,

      inningsNo:
        setupInningsNo,

      strikerId:
        Number(
          selectedStrikerId
        ),

      strikerName:
        selectedStriker?.name ||
        "",

      strikerStats:
        keepExistingStrikerStats &&
        previousCurrentState
          .strikerStats
          ? {
              ...previousCurrentState
                .strikerStats,

              playerId:
                Number(
                  selectedStrikerId
                ),

              playerName:
                selectedStriker?.name ||
                previousCurrentState
                  .strikerStats
                  ?.playerName ||
                "",
            }
          : createFreshBatterStats(
              selectedStriker
            ),

      nonStrikerId:
        Number(
          selectedNonStrikerId
        ),

      nonStrikerName:
        selectedNonStriker?.name ||
        "",

      nonStrikerStats:
        keepExistingNonStrikerStats &&
        previousCurrentState
          .nonStrikerStats
          ? {
              ...previousCurrentState
                .nonStrikerStats,

              playerId:
                Number(
                  selectedNonStrikerId
                ),

              playerName:
                selectedNonStriker?.name ||
                previousCurrentState
                  .nonStrikerStats
                  ?.playerName ||
                "",
            }
          : createFreshBatterStats(
              selectedNonStriker
            ),

      bowlerId:
        Number(
          selectedBowlerId
        ),

      bowlerName:
        selectedBowler?.name ||
        "",

      bowlerStats:
        keepExistingBowlerStats &&
        previousCurrentState
          .bowlerStats
          ? {
              ...previousCurrentState
                .bowlerStats,

              playerId:
                Number(
                  selectedBowlerId
                ),

              playerName:
                selectedBowler?.name ||
                previousCurrentState
                  .bowlerStats
                  ?.playerName ||
                "",
            }
          : createFreshBowlerStats(
              selectedBowler
            ),
    };

    setScoreboard(localBoard);

    await cacheOfflineMatchSnapshot(
      selectedMatchId,
      {
        scoreboard:
          localBoard,

        matchDetail:
          matchDetail ||
          null,

        ballForm:
          nextForm,

        savedAt:
          new Date()
            .toISOString(),
      }
    ).catch(
      (cacheError) => {
        console.warn(
          "[OFFLINE_DELIVERY_SETUP_CACHE_FAILED]",
          cacheError
        );
      }
    );
  }

  setBallForm(nextForm);
  setPendingSecondInningsSetup(false);
  setShowDeliverySetupModal(false);
  setError("");
}}
          >
            ✅ Ready to Score
          </button>
        </div>
      </div>
    </div>
  </div>
)}
{showVenueModal && venueMatch && (
  <div
    className="modal-backdrop"
    onMouseDown={(event) => {
      if (
        event.target ===
        event.currentTarget
      ) {
        setShowVenueModal(false);
        setVenueMatch(null);
      }
    }}
  >
    <div
      className="modal-card"
      style={{
        width: "min(560px, calc(100vw - 24px))",
        maxHeight: "calc(100vh - 24px)",
        overflowY: "auto",
      }}
    >
      <div
        style={{
          display: "flex",
          alignItems: "flex-start",
          justifyContent: "space-between",
          gap: 12,
          marginBottom: 14,
        }}
      >
        <div style={{ minWidth: 0 }}>
          <strong
            style={{
              display: "block",
              fontSize: 18,
            }}
          >
            📍 Match Venue
          </strong>

          <span
            className="muted"
            style={{
              display: "block",
              marginTop: 4,
              lineHeight: 1.4,
              overflowWrap: "anywhere",
            }}
          >
            {venueMatch.teamAName ||
              venueMatch.teamA?.name ||
              "Team A"}{" "}
            vs{" "}
            {venueMatch.teamBName ||
              venueMatch.teamB?.name ||
              "Team B"}
          </span>
        </div>

        <button
          type="button"
          className="btn btn-outline"
          onClick={() => {
            setShowVenueModal(false);
            setVenueMatch(null);
          }}
        >
          ✕
        </button>
      </div>

      <form
        onSubmit={handleSaveMatchVenue}
        className="form"
      >
        <label>
          <span>Venue / Ground</span>
          <input
            type="text"
            maxLength={160}
            placeholder="e.g. Woodley Cricket Fields"
            value={venueForm.venueName}
            onChange={(event) =>
              setVenueForm((previous) => ({
                ...previous,
                venueName:
                  event.target.value,
              }))
            }
          />
        </label>

        <label>
          <span>Venue Address</span>
          <input
            type="text"
            maxLength={300}
            placeholder="Street, city, state/province, postal code, country"
            value={venueForm.venueAddress}
            onChange={(event) =>
              setVenueForm((previous) => ({
                ...previous,
                venueAddress:
                  event.target.value,
              }))
            }
          />

          <small
            className="muted"
            style={{
              display: "block",
              marginTop: 5,
              lineHeight: 1.4,
            }}
          >
            Enter the real physical address. A real address lets public
            Cric4All match pages use valid Google SportsEvent location data.
          </small>
        </label>

        <div
          style={{
            display: "grid",
            gridTemplateColumns:
              "repeat(2, minmax(0, 1fr))",
            gap: 9,
            marginTop: 10,
          }}
        >
          <button
            type="button"
            className="btn btn-outline"
            disabled={venueSaving}
            onClick={() => {
              setShowVenueModal(false);
              setVenueMatch(null);
            }}
          >
            Cancel
          </button>

          <button
            type="submit"
            className="btn"
            disabled={venueSaving}
          >
            {venueSaving
              ? "Saving…"
              : "Save Venue"}
          </button>
        </div>
      </form>
    </div>
  </div>
)}

{showEditMatchModal && editingMatch && (
  <div className="modal-backdrop edit-match-backdrop-v3">
    <div className="edit-match-modal-v3">
      <div className="edit-match-hero-v3">
        <div className="edit-match-hero-left">
          <span className="edit-match-kicker-v3">📅 Scheduled Match</span>

          <h2>Edit Match Details</h2>

<div className="edit-match-vs-v3">
  <span>
    {editTeamA?.name ||
      editingMatch.teamAName ||
      "Team A"}
  </span>

  <b>VS</b>

  <span>
    {editTeamB?.name ||
      editingMatch.teamBName ||
      "Team B"}
  </span>
</div>
        </div>

        <button
          type="button"
          className="edit-modal-close-v3"
          onClick={() => {
            setShowEditMatchModal(false);
            setEditingMatch(null);
          }}
        >
          ✕
        </button>
      </div>

      <form onSubmit={handleUpdateScheduledMatch} className="edit-match-form-v3">
        <section className="edit-panel-v3 edit-teams-panel-v3">
  <div className="edit-panel-title-v3">
    <strong>🏏 Participating Teams</strong>

    <span>
      Choose two different teams from this league. Player role
      options will refresh automatically.
    </span>
  </div>

  <div className="edit-team-picker-grid-v3">
    <label className="edit-field-v3">
      <span>Team A</span>

      <select
        value={editMatchForm.teamAId}
        onChange={(event) => {
          const nextTeamAId = event.target.value;

          setEditMatchForm((previous) => ({
            ...previous,
            teamAId: nextTeamAId,

            teamACaptainId: editMatchLeagueTeams.find((t) => Number(t.id) === Number(nextTeamAId))?.defaultCaptainId ? String(editMatchLeagueTeams.find((t) => Number(t.id) === Number(nextTeamAId)).defaultCaptainId) : "",
            teamAViceCaptainId: editMatchLeagueTeams.find((t) => Number(t.id) === Number(nextTeamAId))?.defaultViceCaptainId ? String(editMatchLeagueTeams.find((t) => Number(t.id) === Number(nextTeamAId)).defaultViceCaptainId) : "",
            teamAWicketKeeperId: editMatchLeagueTeams.find((t) => Number(t.id) === Number(nextTeamAId))?.defaultWicketKeeperId ? String(editMatchLeagueTeams.find((t) => Number(t.id) === Number(nextTeamAId)).defaultWicketKeeperId) : "",
          }));
        }}
        required
      >
        <option value="">Select Team A</option>

        {editMatchLeagueTeams
          .filter(
            (team) =>
              Number(team.id) !==
              Number(editMatchForm.teamBId)
          )
          .map((team) => (
            <option key={team.id} value={team.id}>
              {team.name}
            </option>
          ))}
      </select>
    </label>

    <div className="edit-team-picker-vs-v3">
      <span>VS</span>
    </div>

    <label className="edit-field-v3">
      <span>Team B</span>

      <select
        value={editMatchForm.teamBId}
        onChange={(event) => {
          const nextTeamBId = event.target.value;

          setEditMatchForm((previous) => ({
            ...previous,
            teamBId: nextTeamBId,

            teamBCaptainId: editMatchLeagueTeams.find((t) => Number(t.id) === Number(nextTeamBId))?.defaultCaptainId ? String(editMatchLeagueTeams.find((t) => Number(t.id) === Number(nextTeamBId)).defaultCaptainId) : "",
            teamBViceCaptainId: editMatchLeagueTeams.find((t) => Number(t.id) === Number(nextTeamBId))?.defaultViceCaptainId ? String(editMatchLeagueTeams.find((t) => Number(t.id) === Number(nextTeamBId)).defaultViceCaptainId) : "",
            teamBWicketKeeperId: editMatchLeagueTeams.find((t) => Number(t.id) === Number(nextTeamBId))?.defaultWicketKeeperId ? String(editMatchLeagueTeams.find((t) => Number(t.id) === Number(nextTeamBId)).defaultWicketKeeperId) : "",
          }));
        }}
        required
      >
        <option value="">Select Team B</option>

        {editMatchLeagueTeams
          .filter(
            (team) =>
              Number(team.id) !==
              Number(editMatchForm.teamAId)
          )
          .map((team) => (
            <option key={team.id} value={team.id}>
              {team.name}
            </option>
          ))}
      </select>
    </label>
  </div>

  <div className="edit-team-change-note-v3">
    <span>ℹ️</span>

    <div>
      <strong>Teams are switched, not renamed</strong>

      <small>
        This changes which existing teams participate in this
        scheduled match. It does not change any team’s saved name.
      </small>
    </div>
  </div>
</section>
        <section className="edit-panel-v3">
          <div className="edit-panel-title-v3">
            <strong>⚙️ Match Settings</strong>
            <span>Update schedule, overs, wickets and bowling limits.</span>
          </div>

          <div className="edit-match-grid-v3">
            <label className="edit-field-v3 wide">
              <span>Scheduled Date/Time</span>
              <input
                type="datetime-local"
                value={editMatchForm.scheduledAt}
                onChange={(e) =>
                  setEditMatchForm((prev) => ({
                    ...prev,
                    scheduledAt: e.target.value,
                  }))
                }
              />
            </label>

            <label className="edit-field-v3 wide">
              <span>📍 Venue / Ground</span>
              <input
                type="text"
                maxLength={160}
                placeholder="e.g. Woodley Cricket Fields"
                value={editMatchForm.venueName || ""}
                onChange={(e) =>
                  setEditMatchForm((prev) => ({
                    ...prev,
                    venueName: e.target.value,
                  }))
                }
              />
            </label>

            <label className="edit-field-v3 wide">
              <span>🗺️ Venue Address</span>
              <input
                type="text"
                maxLength={300}
                placeholder="Street, city, state/province, postal code, country"
                value={editMatchForm.venueAddress || ""}
                onChange={(e) =>
                  setEditMatchForm((prev) => ({
                    ...prev,
                    venueAddress: e.target.value,
                  }))
                }
              />
            </label>

            <label className="edit-field-v3 wide">
              <span>Series</span>
              <select
                value={editMatchForm.seriesId}
                onChange={(e) =>
                  setEditMatchForm((prev) => ({
                    ...prev,
                    seriesId: e.target.value,
                  }))
                }
              >
                <option value="">No Series</option>
                {seriesList.map((series) => (
                  <option key={series.id} value={series.id}>
                    {series.name} {series.year ? `(${series.year})` : ""}
                  </option>
                ))}
              </select>
            </label>

            <label className="edit-field-v3">
              <span>🎯 Overs</span>
              <input
                type="number"
                min="1"
                value={editMatchForm.oversPerInnings}
                onChange={(e) =>
                  setEditMatchForm((prev) => ({
                    ...prev,
                    oversPerInnings: e.target.value,
                  }))
                }
              />
            </label>

            <label className="edit-field-v3">
              <span>⚡ Powerplay</span>
              <input
                type="number"
                min="0"
                value={editMatchForm.powerplayOversInnings}
                onChange={(e) =>
                  setEditMatchForm((prev) => ({
                    ...prev,
                    powerplayOversInnings: e.target.value,
                  }))
                }
              />
            </label>

            <label className="edit-field-v3">
              <span>☝️ Max Wickets</span>
              <input
                type="number"
                min="1"
                placeholder="Unlimited"
                value={editMatchForm.maxWicketsPerInnings}
                onChange={(e) =>
                  setEditMatchForm((prev) => ({
                    ...prev,
                    maxWicketsPerInnings: e.target.value,
                  }))
                }
              />
            </label>

            <label className="edit-field-v3">
              <span>🎳 Max Overs/Bowler</span>
              <input
                type="number"
                min="1"
                placeholder="Unlimited"
                value={editMatchForm.maxOversPerBowler}
                onChange={(e) =>
                  setEditMatchForm((prev) => ({
                    ...prev,
                    maxOversPerBowler: e.target.value,
                  }))
                }
              />
            </label>
          </div>
        </section>

        <section className="edit-panel-v3">
          <div className="edit-panel-title-v3">
            <strong>🧢 Captains, Vice-Captains & Wicketkeepers</strong>
            <span>Permanent team defaults are pre-filled; change them here for this match only.</span>
          </div>

          <div className="edit-role-grid-v3">
<div className="edit-team-role-card-v3 team-a">
  <div className="team-role-card-head-v3">
    <span>A</span>

    <strong>
      {editTeamA?.name || "Select Team A"}
    </strong>
  </div>

  <label className="edit-field-v3">
    <span>🧢 Captain</span>

    <select
      value={editMatchForm.teamACaptainId}
      disabled={!editTeamA}
      onChange={(event) =>
        setEditMatchForm((previous) => ({
          ...previous,
          teamACaptainId: event.target.value,
        }))
      }
    >
      <option value="">
        {editTeamA
          ? "Select Captain"
          : "Select Team A first"}
      </option>

      {(editTeamA?.players || [])
        .slice()
        .sort((first, second) =>
          String(first.name || "").localeCompare(
            String(second.name || ""),
            undefined,
            {
              sensitivity: "base",
              numeric: true,
            }
          )
        )
        .map((player) => (
          <option key={player.id} value={player.id}>
            {player.name}
          </option>
        ))}
    </select>
  </label>

  <label className="edit-field-v3">
    <span>⭐ Vice-Captain</span>
    <select value={editMatchForm.teamAViceCaptainId || ""} disabled={!editTeamA} onChange={(event) => setEditMatchForm((previous) => ({ ...previous, teamAViceCaptainId: event.target.value }))}>
      <option value="">{editTeamA ? "Select Vice-Captain" : "Select Team A first"}</option>
      {(editTeamA?.players || []).map((player) => <option key={player.id} value={player.id} disabled={String(player.id) === String(editMatchForm.teamACaptainId)}>{player.name}</option>)}
    </select>
  </label>

  <label className="edit-field-v3">
    <span>🧤 Wicketkeeper</span>

    <select
      value={editMatchForm.teamAWicketKeeperId}
      disabled={!editTeamA}
      onChange={(event) =>
        setEditMatchForm((previous) => ({
          ...previous,
          teamAWicketKeeperId:
            event.target.value,
        }))
      }
    >
      <option value="">
        {editTeamA
          ? "Select Wicketkeeper"
          : "Select Team A first"}
      </option>

      {(editTeamA?.players || [])
        .slice()
        .sort((first, second) =>
          String(first.name || "").localeCompare(
            String(second.name || ""),
            undefined,
            {
              sensitivity: "base",
              numeric: true,
            }
          )
        )
        .map((player) => (
          <option key={player.id} value={player.id}>
            {player.name}
          </option>
        ))}
    </select>
  </label>
</div>
            <div className="edit-team-role-card-v3 team-b">
  <div className="team-role-card-head-v3">
    <span>B</span>

    <strong>
      {editTeamB?.name || "Select Team B"}
    </strong>
  </div>

  <label className="edit-field-v3">
    <span>🧢 Captain</span>

    <select
      value={editMatchForm.teamBCaptainId}
      disabled={!editTeamB}
      onChange={(event) =>
        setEditMatchForm((previous) => ({
          ...previous,
          teamBCaptainId: event.target.value,
        }))
      }
    >
      <option value="">
        {editTeamB
          ? "Select Captain"
          : "Select Team B first"}
      </option>

      {(editTeamB?.players || [])
        .slice()
        .sort((first, second) =>
          String(first.name || "").localeCompare(
            String(second.name || ""),
            undefined,
            {
              sensitivity: "base",
              numeric: true,
            }
          )
        )
        .map((player) => (
          <option key={player.id} value={player.id}>
            {player.name}
          </option>
        ))}
    </select>
  </label>

  <label className="edit-field-v3">
    <span>⭐ Vice-Captain</span>
    <select value={editMatchForm.teamBViceCaptainId || ""} disabled={!editTeamB} onChange={(event) => setEditMatchForm((previous) => ({ ...previous, teamBViceCaptainId: event.target.value }))}>
      <option value="">{editTeamB ? "Select Vice-Captain" : "Select Team B first"}</option>
      {(editTeamB?.players || []).map((player) => <option key={player.id} value={player.id} disabled={String(player.id) === String(editMatchForm.teamBCaptainId)}>{player.name}</option>)}
    </select>
  </label>

  <label className="edit-field-v3">
    <span>🧤 Wicketkeeper</span>

    <select
      value={editMatchForm.teamBWicketKeeperId}
      disabled={!editTeamB}
      onChange={(event) =>
        setEditMatchForm((previous) => ({
          ...previous,
          teamBWicketKeeperId:
            event.target.value,
        }))
      }
    >
      <option value="">
        {editTeamB
          ? "Select Wicketkeeper"
          : "Select Team B first"}
      </option>

      {(editTeamB?.players || [])
        .slice()
        .sort((first, second) =>
          String(first.name || "").localeCompare(
            String(second.name || ""),
            undefined,
            {
              sensitivity: "base",
              numeric: true,
            }
          )
        )
        .map((player) => (
          <option key={player.id} value={player.id}>
            {player.name}
          </option>
        ))}
    </select>
  </label>
</div>
          </div>
        </section>

        <div className="edit-match-actions-v3">
          <button
            type="button"
            className="edit-cancel-btn-v3"
            onClick={() => {
              setShowEditMatchModal(false);
              setEditingMatch(null);
            }}
          >
            Cancel
          </button>

          <button type="submit" className="edit-save-btn-v3">
            💾 Save Changes
          </button>
        </div>
      </form>
    </div>
  </div>
)}

{showKeeperChangeModal && typeof document !== "undefined" && createPortal(
  <div className="modal-backdrop">
    <div className="correction-modal">
        <div className="live-popup-snapshot">
          <div className="live-popup-topline">
            <span className="live-dot">
              ● LIVE
            </span>

            <span className="live-popup-over">
              Over {bowlerChangeScore.overs}
            </span>
          </div>

          <div className="live-popup-main">
            <div>
              <span>Current Score</span>

              <strong>
                {bowlerChangeScore.score}
              </strong>
            </div>

            <div>
              <span>CRR</span>

              <strong>
                {bowlerChangeScore.crr}
              </strong>
            </div>
          </div>

          <div className="live-popup-recent">
            <div className="live-popup-recent-head">
              <span>Current Over</span>

              <b>
                Over {extrasModalCurrentOver.overNo}
              </b>
            </div>

            <div className="live-popup-recent-direction">
              ← Latest delivery
            </div>

            <div className="live-popup-balls">
              {extrasModalCurrentOver.balls.length ? (
                extrasModalCurrentOver.balls.map(
                  (ball, index) => {
                    const label =
                      ball.shortText ||
                      ball.displayText ||
                      ball.resultText ||
                      ball.label ||
                      "";

                    const result = String(label)
                      .replace(
                        /^\s*\d+\.\d+\s*/,
                        ""
                      )
                      .replace(/[()]/g, "")
                      .trim();

                    const normalized =
                      result.toUpperCase();

                    const ballClass =
                      normalized === "W" ||
                      normalized === "WKT"
                        ? "wicket"
                        : normalized === "4"
                          ? "four"
                          : normalized === "6"
                            ? "six"
                            : normalized.startsWith(
                                  "WD"
                                ) ||
                                normalized.includes(
                                  "WIDE"
                                )
                              ? "wide"
                              : normalized.startsWith(
                                    "NB"
                                  ) ||
                                  normalized.includes(
                                    "NO BALL"
                                  ) ||
                                  normalized.includes(
                                    "NOBALL"
                                  )
                                ? "noball"
                                : "";

                    return (
                      <b
                        key={
                          ball.id ||
                          ball.sequence ||
                          `extra-recent-${index}`
                        }
                        className={`${ballClass} ${
                          index === 0
                            ? "latest"
                            : ""
                        }`}
                      >
                        {result || "-"}
                      </b>
                    );
                  }
                )
              ) : (
                <small>
                  No deliveries in the current
                  over yet
                </small>
              )}
            </div>
          </div>
        </div>
      <div className="correction-header">
        <h2>🧤 Change Wicketkeeper</h2>

        <button
          type="button"
          className="edit-modal-close-v2"
          onClick={() => setShowKeeperChangeModal(false)}
        >
          ✕
        </button>
      </div>

      <div className="current-wicketkeeper-callout">
        <div
          className="current-wicketkeeper-icon"
          aria-hidden="true"
        >
          🧤
        </div>

        <div className="current-wicketkeeper-copy">
          <span>
            Current wicketkeeper
          </span>

          <strong>
            {currentWicketKeeperName}
          </strong>
        </div>
      </div>

      <div className="form-grid">
        <label>
          <span>New Wicketkeeper</span>
          <select
            value={keeperChangeForm.newKeeperId}
            onChange={(e) =>
              setKeeperChangeForm((prev) => ({
                ...prev,
                newKeeperId: e.target.value,
              }))
            }
          >
            <option value="">Select wicketkeeper</option>
            {wicketKeeperReplacementOptions.map((p) => (
              <option key={p.id} value={p.id}>
                {p.name}
              </option>
            ))}
          </select>
        </label>

        <label>
          <span>Note</span>
          <input
            value={keeperChangeForm.note}
            onChange={(e) =>
              setKeeperChangeForm((prev) => ({
                ...prev,
                note: e.target.value,
              }))
            }
            placeholder="Optional"
          />
        </label>
      </div>

      <div className="edit-match-actions-v2">
        <button
          type="button"
          className="btn btn-outline"
          onClick={() => setShowKeeperChangeModal(false)}
        >
          Cancel
        </button>

        <button
          type="button"
          className={`btn btn-primary ${
            keeperChangeSaving
              ? "btn-loading"
              : ""
          }`}
          disabled={
            keeperChangeSaving ||
            !keeperChangeForm.newKeeperId
          }
          onClick={handleLiveWicketKeeperChange}
        >
          {keeperChangeSaving
            ? "Saving..."
            : "Save WK Change"}
        </button>
      </div>
    </div>
  </div>,
  document.body
)}
{showFollowedLeaguesDrawer && (
  <div className="public-league-drawer-backdrop">
    <aside className="public-league-drawer">
      <div className="public-league-drawer-head">
        <div>
          <h3>⭐ Followed Leagues</h3>
          <p>Your followed public leagues will appear here.</p>
        </div>

        <button
          type="button"
          onClick={() => setShowFollowedLeaguesDrawer(false)}
        >
          ✕
        </button>
      </div>

      <FollowedLeaguesDrawerContent />
    </aside>
  </div>
)}
{showPublicLeagueDrawer && (
  <div className="public-league-drawer-backdrop">
    <aside className="public-league-drawer">
      <div className="public-league-drawer-head">
        <div>
          <h3>🌐 Public Leagues</h3>
          <p>Browse public leagues without adding them to your workspace.</p>
        </div>

        <button
          type="button"
          onClick={() => setShowPublicLeagueDrawer(false)}
        >
          ✕
        </button>
      </div>

      <a href="/explore" className="public-league-explore-card">
        <strong>Explore all public leagues</strong>
        <span>View leagues, teams, matches, stats, and live scorecards.</span>
        <b>Open Explore →</b>
      </a>
    </aside>
  </div>
)}
{showEditTeamModal && editingTeam && (
<div className="modal-backdrop">
  <div className="rename-modal">
    <button className="rename-close" onClick={() => { setShowEditTeamModal(false); setEditingTeam(null); }}>✕</button>
    <div className="rename-icon">🏏</div>
    <h2>Edit Team</h2>
    <p>Update the team name and permanent match-role defaults. These defaults pre-populate new matches but can still be changed for an individual match.</p>

    <label>
      <span>TEAM NAME</span>
      <input value={teamEditName} placeholder="Enter team name" onChange={(e) => setTeamEditName(e.target.value)} />
    </label>

    <div style={{ display: "grid", gap: 12, marginTop: 16 }}>
      <label>
        <span>🧢 PERMANENT CAPTAIN</span>
        <select value={teamRoleForm.defaultCaptainId} onChange={(e) => setTeamRoleForm((prev) => ({ ...prev, defaultCaptainId: e.target.value }))}>
          <option value="">No permanent captain</option>
          {(editingTeam.players || []).map((player) => <option key={player.id} value={player.id}>{player.name}</option>)}
        </select>
      </label>

      <label>
        <span>⭐ PERMANENT VICE-CAPTAIN</span>
        <select value={teamRoleForm.defaultViceCaptainId} onChange={(e) => setTeamRoleForm((prev) => ({ ...prev, defaultViceCaptainId: e.target.value }))}>
          <option value="">No permanent vice-captain</option>
          {(editingTeam.players || []).map((player) => (
            <option key={player.id} value={player.id} disabled={String(player.id) === String(teamRoleForm.defaultCaptainId)}>{player.name}</option>
          ))}
        </select>
      </label>

      <label>
        <span>🧤 PERMANENT WICKETKEEPER</span>
        <select value={teamRoleForm.defaultWicketKeeperId} onChange={(e) => setTeamRoleForm((prev) => ({ ...prev, defaultWicketKeeperId: e.target.value }))}>
          <option value="">No permanent wicketkeeper</option>
          {(editingTeam.players || []).map((player) => <option key={player.id} value={player.id}>{player.name}</option>)}
        </select>
      </label>
    </div>

    <div className="rename-note">💡 Wicketkeeper may also be captain or vice-captain. Captain and vice-captain must be different players.</div>

    <div className="rename-actions">
      <button className="btn btn-outline" onClick={() => { setShowEditTeamModal(false); setEditingTeam(null); }}>Cancel</button>
      <button className="btn btn-primary" onClick={async () => {
        try {
          await api(`/api/teams/${editingTeam.id}`, {
            method: "PATCH",
            body: JSON.stringify({
              name: teamEditName.trim(),
              defaultCaptainId: teamRoleForm.defaultCaptainId ? Number(teamRoleForm.defaultCaptainId) : null,
              defaultViceCaptainId: teamRoleForm.defaultViceCaptainId ? Number(teamRoleForm.defaultViceCaptainId) : null,
              defaultWicketKeeperId: teamRoleForm.defaultWicketKeeperId ? Number(teamRoleForm.defaultWicketKeeperId) : null,
            }),
          });
          await loadTeams();
          await loadLeagues();
          setShowEditTeamModal(false);
          setEditingTeam(null);
          showToast("success", "✅ Team and permanent roles updated.");
        } catch (err) {
          setError(err.message);
          showToast("error", err.message);
        }
      }}>💾 Save Changes</button>
    </div>
  </div>
</div>
)}
{showEditPlayerModal && editingPlayer && (

<div className="modal-backdrop">

<div className="rename-modal">

<button
className="rename-close"
onClick={()=>{
setShowEditPlayerModal(false);
setEditingPlayer(null);
}}
>
✕
</button>

<div className="rename-icon">
👤
</div>

<h2>Rename Player</h2>

<p>
Update the player's display name.
Statistics and match history remain unchanged.
</p>

<label>

<span>PLAYER NAME</span>

<input
value={editPlayerName}
placeholder="Enter player name"
onChange={(e)=>setEditPlayerName(e.target.value)}
/>

</label>
<label>
  <span>📱 WhatsApp Number</span>

  <input
    type="tel"
    value={editPlayerWhatsappNumber}
    placeholder="+1 555 123 4567"
    onChange={(e) =>
      setEditPlayerWhatsappNumber(e.target.value)
    }
  />
</label>

<label
  style={{
    display: "flex",
    alignItems: "center",
    gap: 10,
    marginTop: 12,
  }}
>
  <input
    type="checkbox"
    checked={editPlayerWhatsappOptIn}
    disabled={!editPlayerWhatsappNumber.trim()}
    onChange={(e) =>
      setEditPlayerWhatsappOptIn(
        e.target.checked
      )
    }
  />

  Receive SMS/Whatsapp notifications
</label>

<div className="rename-note">
🏏 Player statistics are preserved.
</div>

<div className="rename-actions">

<button
className="btn btn-outline"
onClick={()=>{
setShowEditPlayerModal(false);
setEditingPlayer(null);
}}
>
Cancel
</button>

<button
className="btn btn-primary"
onClick={savePlayerName}
>
💾 Save Changes
</button>

</div>

</div>

</div>

)}
{showTransferPlayerModal && transferPlayer && (
  <div className="modal-backdrop">
    <div className="rename-modal">
      <button
        type="button"
        className="rename-close"
        onClick={() => {
          setShowTransferPlayerModal(false);
          setTransferPlayer(null);
          setTransferTeamId("");
        }}
      >
        ✕
      </button>

      <div className="rename-icon">🔁</div>

      <h2>Move Player</h2>

      <p>
        Move <strong>{transferPlayer.name}</strong> to another team in the same league.
      </p>

      <label>
        <span>NEW TEAM</span>

        <select
          value={transferTeamId}
          onChange={(e) => setTransferTeamId(e.target.value)}
        >
          <option value="">Select Team</option>

          {teams
            .filter((team) => Number(team.leagueId) === Number(activeLeagueId))
            .filter((team) => Number(team.id) !== Number(transferPlayer.teamId))
            .sort((a, b) => a.name.localeCompare(b.name))
            .map((team) => (
              <option key={team.id} value={team.id}>
                {team.name}
              </option>
            ))}
        </select>
      </label>

      <div className="rename-note">
        Player stats and match history will stay attached to this player.
      </div>

      <div className="rename-actions">
        <button
          type="button"
          className="btn btn-outline"
          onClick={() => {
            setShowTransferPlayerModal(false);
            setTransferPlayer(null);
            setTransferTeamId("");
          }}
        >
          Cancel
        </button>

        <button
          type="button"
          className="btn btn-primary"
          disabled={!transferTeamId}
          onClick={async () => {
            await api(`/api/players/${transferPlayer.id}`, {
              method: "PATCH",
              body: JSON.stringify({
                teamId: Number(transferTeamId),
              }),
            });

            await refreshPlayerLists();

            setShowTransferPlayerModal(false);
            setTransferPlayer(null);
            setTransferTeamId("");

            showToast("success", "✅ Player moved.");
          }}
        >
          🔁 Move Player
        </button>
      </div>
    </div>
  </div>
)}
{showCorrectionCenter && matchDetail && (
  <div className="modal-backdrop">
    <div className="correction-center-modal">
      <div className="correction-center-header">
        <div>
          <h3>✏️ Scorecard Correction Center</h3>
          <p>Correct completed match details safely without changing innings totals accidentally.</p>
        </div>
        {correctionError && (
  <div className="correction-error-box">
    ⚠️ {correctionError}
  </div>
)}

        <button
          type="button"
          className="icon-btn"
          onClick={() => setShowCorrectionCenter(false)}
        >
          ✕
        </button>
      </div>

      <div className="correction-type-tabs">
        {[
          ["TRANSFER_BATTER_RUNS", "🏏 Batting"],
          ["REASSIGN_OVER_BOWLER", "🎳 Bowling"],
          ["CHANGE_FIELDER", "🧤 Fielding"],
          ["RETIRED_HURT", "🩹 Retired Hurt"],
        ].map(([key, label]) => (
          <button
            key={key}
            type="button"
            className={correctionType === key ? "active" : ""}
            onClick={() => {
              setCorrectionType(key);
              setCorrectionForm({});
              setCorrectionError("");
            }}
          >
            {label}
          </button>
        ))}
      </div>
<label>
  <span>Innings</span>

<select
  value={correctionInnings}
  onChange={(e) => {
    setCorrectionInnings(Number(e.target.value));
    setCorrectionForm({});
  }}
>
    <option value={1}>
      1st Innings
    </option>

    <option value={2}>
      2nd Innings
    </option>
  </select>
</label>
{correctionType === "RETIRED_HURT" && (
  <div className="retired-hurt-wow-layout">
    <section className="retired-hurt-main-panel">
      <div className="retired-hurt-panel-head">
        <div>
          <h4>🩹 Retired Hurt Correction</h4>
          <p>
            Correct the batter flow after a retired hurt event while preserving
            innings score integrity.
          </p>
        </div>
      </div>

      <div className="retired-hurt-form-grid">
        <label className="retired-hurt-field retired-hurt-wide-field">
          <span>① Retired Hurt Event</span>
          <select
            value={correctionForm.retiredBallId || ""}
onChange={(e) => {
  const retiredBallId = e.target.value;

  const selectedBall = retiredHurtBallsForCorrection.find(
    (ball) => String(ball.id) === String(retiredBallId)
  );

  setCorrectionForm((prev) => ({
    ...prev,
    retiredBallId,
    retiredPlayerId: selectedBall?.dismissedPlayerId || "",
    replacementPlayerId: selectedBall?.newBatterId || "",
  }));

  setCorrectionError("");
}}
          >
            <option value="">Select retired hurt event</option>

            {retiredHurtBallsForCorrection.map((ball) => {
              const retiredPlayer =
                battingPlayersForCorrection.find(
                  (p) => Number(p.id) === Number(ball.dismissedPlayerId)
                )?.name || "Retired batter";

              return (
                <option key={ball.id} value={ball.id}>
                  {ball.overNo}.{ball.ballInOver} • {retiredPlayer}
                </option>
              );
            })}
          </select>
        </label>

        <label className="retired-hurt-field">
          <span>② Retired Batter</span>
          <select
            value={correctionForm.retiredPlayerId || ""}
            onChange={(e) =>
              setCorrectionForm((prev) => ({
                ...prev,
                retiredPlayerId: e.target.value,
              }))
            }
          >
            <option value="">Select retired batter</option>

            {battingPlayersForCorrection.map((player) => (
              <option key={player.id} value={player.id}>
                {player.name} ({battingTeamForCorrection?.name})
              </option>
            ))}
          </select>
        </label>

        <div className="retired-hurt-flow-connector">
          <span>→</span>
        </div>

        <label className="retired-hurt-field">
          <span>③ Replacement Batter</span>
          <select
            value={correctionForm.replacementPlayerId || ""}
            onChange={(e) =>
              setCorrectionForm((prev) => ({
                ...prev,
                replacementPlayerId: e.target.value,
              }))
            }
          >
            <option value="">Select replacement batter</option>

            {battingPlayersForCorrection.map((player) => (
              <option key={player.id} value={player.id}>
                {player.name} ({battingTeamForCorrection?.name})
              </option>
            ))}
          </select>
        </label>
      </div>
    </section>

    <aside className="retired-hurt-preview-panel">
      <h4>✨ What Cric4All will update</h4>

      <div className="retired-hurt-check-list">
        <div>✅ The retired hurt event will be corrected, and future affected balls will be updated only if needed.</div>
        <div>✅ Innings total will not be accidentally changed.</div>
        <div>✅ Retired batter can still return later.</div>
        <div>✅ Scorecard, stats, and commentary refresh from corrected ball data.</div>
        <div>✅ Full rollback is available from Correction History.</div>
      </div>
    </aside>
  </div>
)}
      {correctionType === "TRANSFER_BATTER_RUNS" && (
        <div className="correction-form-grid">
          <label>
            <span>From Batter</span>
            <select
              value={correctionForm.fromPlayerId || ""}
              onChange={(e) =>
                setCorrectionForm((p) => ({ ...p, fromPlayerId: e.target.value }))
              }
            >
<option value="">Select batter</option>
{battingPlayersForCorrection.map((player) => (
  <option key={player.id} value={player.id}>
    {player.name} ({battingTeamForCorrection?.name})
  </option>
))}
            </select>
          </label>

          <label>
            <span>To Batter</span>
            <select
              value={correctionForm.toPlayerId || ""}
              onChange={(e) =>
                setCorrectionForm((p) => ({ ...p, toPlayerId: e.target.value }))
              }
            >
<option value="">Select batter</option>
{battingPlayersForCorrection.map((player) => (
  <option key={player.id} value={player.id}>
    {player.name} ({battingTeamForCorrection?.name})
  </option>
))}
            </select>
          </label>

          <label>
            <span>Runs to Transfer</span>
            <input
              type="number"
              min="1"
              value={correctionForm.runs || ""}
              onChange={(e) =>
                setCorrectionForm((p) => ({ ...p, runs: e.target.value }))
              }
            />
          </label>
        </div>
      )}

      {correctionType === "REASSIGN_OVER_BOWLER" && (
        <div className="correction-form-grid">
<label>
  <span>Over</span>
  <select
    value={correctionForm.overNo || ""}
    onChange={(e) =>
      setCorrectionForm((p) => ({ ...p, overNo: e.target.value }))
    }
  >
    <option value="">Select over</option>
    {oversForCorrection.map((overNo) => (
<option key={overNo} value={overNo}>
    Over {Number(overNo) + 1}
</option>
    ))}
  </select>
</label>

          <label>
            <span>Correct Bowler</span>
            <select
              value={correctionForm.newBowlerId || ""}
              onChange={(e) =>
                setCorrectionForm((p) => ({ ...p, newBowlerId: e.target.value }))
              }
            >
<option value="">Select bowler</option>
{bowlingPlayersForCorrection.map((player) => (
  <option key={player.id} value={player.id}>
    {player.name} ({bowlingTeamForCorrection?.name})
  </option>
))}
            </select>
          </label>
        </div>
      )}

      {correctionType === "CHANGE_FIELDER" && (
        <div className="correction-form-grid">
<label>
  <span>Dismissal</span>

  <select
    value={correctionForm.ballId || ""}
    onChange={(e) =>
      setCorrectionForm((p) => ({
        ...p,
        ballId: e.target.value,
      }))
    }
  >
    <option value="">Select dismissal</option>

    {wicketBallsForCorrection.map((ball) => (
      <option key={ball.id} value={ball.id}>
        {Number(ball.overNo) + 1}.{ball.ballInOver} •{" "}
        {String(ball.wicketType || "WICKET").replaceAll("_", " ")}
        {ball.dismissedPlayer?.name ? ` • ${ball.dismissedPlayer.name}` : ""}
      </option>
    ))}
  </select>
</label>

          <label>
            <span>Correct Fielder</span>
            <select
              value={correctionForm.fielderId || ""}
              onChange={(e) =>
                setCorrectionForm((p) => ({ ...p, fielderId: e.target.value }))
              }
            >
<option value="">Select fielder</option>
{bowlingPlayersForCorrection.map((player) => (
  <option key={player.id} value={player.id}>
    {player.name} ({bowlingTeamForCorrection?.name})
  </option>
))}
            </select>
          </label>

          <label>
            <span>Assistant Fielder Optional</span>
            <select
              value={correctionForm.assistantFielderId || ""}
              onChange={(e) =>
                setCorrectionForm((p) => ({ ...p, assistantFielderId: e.target.value }))
              }
            >
              <option value="">None</option>
              {[...(bowlingTeamForCorrection?.players || []), ...(battingTeamForCorrection?.players || [])].map((p) => (
                <option key={p.id} value={p.id}>{p.name}</option>
              ))}
            </select>
          </label>
        </div>
      )}

<label className="correction-reason">
  <span>Reason for correction</span>
  <textarea
    value={correctionReason}
    onChange={(e) => setCorrectionReason(e.target.value)}
    placeholder="Example: Retired hurt replacement was assigned incorrectly."
  />
</label>

      <div className="correction-actions">
        <button
          type="button"
          className="btn btn-outline"
          onClick={() => setShowCorrectionCenter(false)}
        >
          Cancel
        </button>

        <button
          type="button"
          className="btn"
          disabled={correctionLoading}
          onClick={applyCorrection}
        >
          {correctionLoading ? "Applying..." : "Apply Correction"}
        </button>
      </div>

      <div className="correction-history">
        <h4>📜 Correction History</h4>

        {!correctionHistory.length ? (
          <p className="muted">No corrections yet.</p>
        ) : (
          correctionHistory.map((c) => (
            <div key={c.id} className="correction-history-row">
              <div>
                <strong>{c.correctionLabel || c.correctionType}</strong>
                <span>{c.reason || "No reason provided."}</span>
                <small>
                  {c.correctedByName || c.correctedByEmail || "Unknown"} •{" "}
                  {formatDate(c.createdAt)}
                </small>
              </div>

              {!c.revertedAt && (
                <button
                  type="button"
                  className="btn btn-outline"
                  onClick={() => rollbackCorrection(c.id)}
                >
                  ↩ Rollback
                </button>
              )}

              {c.revertedAt && <small>Reverted</small>}
            </div>
          ))
        )}
      </div>
    </div>
  </div>
)}
{showScoringFormSheet && typeof document !== "undefined" && createPortal(
    <div
      className="scoring-form-sheet-backdrop"
      role="presentation"
      onMouseDown={(event) => {
        if (event.target === event.currentTarget) {
          closeScoringFormSheet();
        }
      }}
    >
      <section
        className="scoring-form-sheet"
        role="dialog"
        aria-modal="true"
        aria-labelledby="scoring-form-sheet-title"
        onMouseDown={(event) =>
          event.stopPropagation()
        }
      >
        <header className="scoring-form-sheet-header">
          <div>
            <span>⚙️ Advanced Delivery</span>

            <strong id="scoring-form-sheet-title">
              Scoring Form
            </strong>
          </div>

          <button
            type="button"
            onClick={closeScoringFormSheet}
            aria-label="Close scoring form"
          >
            ✕
          </button>
        </header>

        <div className="scoring-form-sheet-body">
          {/*
            Put the existing contents of your Scoring Form
            here.

            Use the same:
            ballForm
            setBallForm
            submit handler
            extras handlers
            wicket handlers

            Do not create new state for these inputs.
          */}

<div className="scoring-form-sheet-existing-form">
<form
  id="scorer-mode-ball-form"
  className="form grid-2 scorer-mode-ball-form"
  onSubmit={handleScoringFormSheetSubmit}
>
    {/* Innings */}
    <label>
      <span>Innings</span>

      <select
        value={ballForm.inningsNo || ""}
        onChange={(event) =>
          setBallForm((previous) => ({
            ...previous,
            inningsNo: event.target.value,
          }))
        }
      >
        <option value="1">Innings 1</option>
        <option value="2">Innings 2</option>
      </select>
    </label>

    {/* Bowler */}
    <label>
      <span>Bowler</span>

      <select
        value={ballForm.bowlerId || ""}
        onChange={(event) =>
          setBallForm((previous) => ({
            ...previous,
            bowlerId: event.target.value,
          }))
        }
        required
      >
        <option value="">Select bowler</option>

        {(bowlingTeam?.players || []).map((player) => (
          <option
            key={player.id}
            value={player.id}
          >
            {player.name}
          </option>
        ))}
      </select>
    </label>

    {/* Striker */}
    <label>
      <span>Striker</span>

      <select
        value={ballForm.strikerId || ""}
        onChange={(event) => {
          const strikerId = event.target.value;

          setBallForm((previous) => ({
            ...previous,
            strikerId,

            /*
              Keep the dismissed-player default synchronized
              with the striker unless RUN_OUT is selected.
            */
            dismissedPlayerId:
              previous.wicketType === "RUN_OUT"
                ? previous.dismissedPlayerId
                : strikerId,
          }));
        }}
        required
      >
        <option value="">Select striker</option>

        {(battingTeam?.players || []).map((player) => (
          <option
            key={player.id}
            value={player.id}
          >
            {player.name}
          </option>
        ))}
      </select>
    </label>

    {/* Non-striker */}
    <label>
      <span>Non-striker</span>

      <select
        value={ballForm.nonStrikerId || ""}
        onChange={(event) =>
          setBallForm((previous) => ({
            ...previous,
            nonStrikerId: event.target.value,
          }))
        }
        required
      >
        <option value="">Select non-striker</option>

        {(battingTeam?.players || []).map((player) => (
          <option
            key={player.id}
            value={player.id}
          >
            {player.name}
          </option>
        ))}
      </select>
    </label>

    {/* Runs off bat */}
    <label>
      <span>Runs Off Bat</span>

      <input
        type="number"
        min="0"
        max="7"
        inputMode="numeric"
        value={ballForm.runsOffBat ?? ""}
        onChange={(event) =>
          setBallForm((previous) => ({
            ...previous,
            runsOffBat: event.target.value,
          }))
        }
        required
      />
    </label>

    {/* Extra type */}
    <label>
      <span>Extra Type</span>

      <select
        value={ballForm.extraType || "NONE"}
        onChange={(event) => {
          const extraType = event.target.value;

          setBallForm((previous) => ({
            ...previous,
            extraType,

            /*
              Clear the extra count when switching back
              to a normal delivery.
            */
            extras:
              extraType === "NONE"
                ? 0
                : previous.extras,
          }));
        }}
      >
        {EXTRA_TYPES.map((type) => (
          <option
            key={type}
            value={type}
          >
            {type}
          </option>
        ))}
      </select>
    </label>

    <label>
      <span>Extras</span>

      <input
        type="number"
        min="0"
        max="7"
        inputMode="numeric"
        value={ballForm.extras ?? ""}
        disabled={
          !ballForm.extraType ||
          ballForm.extraType === "NONE"
        }
        onChange={(event) =>
          setBallForm((previous) => ({
            ...previous,
            extras: event.target.value,
          }))
        }
        required={
          Boolean(ballForm.extraType) &&
          ballForm.extraType !== "NONE"
        }
      />
    </label>

    {/* Wicket */}
    <label className="checkbox-row scoring-sheet-wicket-toggle">
      <span>Wicket</span>

      <input
        type="checkbox"
        checked={Boolean(ballForm.isWicket)}
        onChange={(event) => {
          const isWicket = event.target.checked;

          if (!isWicket) {
            setRunOutRuns(null);
          }

          setBallForm((previous) => ({
            ...previous,
            isWicket,

            wicketType: isWicket
              ? previous.wicketType || "BOWLED"
              : "NONE",

            dismissedPlayerId: isWicket
              ? previous.dismissedPlayerId ||
                previous.strikerId
              : "",

            newBatterId: isWicket
              ? previous.newBatterId
              : "",

            fielderId: "",
            assistantFielderId: "",
          }));
        }}
      />
    </label>

    {/* Wicket type */}
    <label>
      <span>Wicket Type</span>

      <select
        value={ballForm.wicketType || "NONE"}
        disabled={!ballForm.isWicket}
        onChange={(event) => {
          const wicketType = event.target.value;

          setRunOutRuns(null);

          setBallForm((previous) => ({
            ...previous,
            wicketType,

            dismissedPlayerId:
              wicketType === "RUN_OUT"
                ? previous.dismissedPlayerId ||
                  previous.strikerId
                : previous.strikerId,

            newBatterId: "",
            fielderId: "",
            assistantFielderId: "",
          }));
        }}
      >
        {WICKET_TYPES
          .filter(
            (type) =>
              type !== "NONE" &&
              type !== "RETIRED_HURT"
          )
          .map((type) => (
            <option
              key={type}
              value={type}
            >
              {type.replaceAll("_", " ")}
            </option>
          ))}
      </select>
    </label>

    {/* Dismissed player */}
    <label>
      <span>Dismissed Player</span>

      <select
        value={ballForm.dismissedPlayerId || ""}
        disabled={!ballForm.isWicket}
        onChange={(event) =>
          setBallForm((previous) => ({
            ...previous,
            dismissedPlayerId:
              event.target.value,
          }))
        }
      >
        <option value="">
          Select dismissed player
        </option>

        {(battingTeam?.players || []).map((player) => (
          <option
            key={player.id}
            value={player.id}
          >
            {player.name}
          </option>
        ))}
      </select>
    </label>

    {/* Run-out runs */}
    {ballForm.isWicket &&
      ballForm.wicketType === "RUN_OUT" && (
        <label>
          <span>Runs Completed</span>

          <input
            type="number"
            min="0"
            max="7"
            inputMode="numeric"
            value={runOutRuns ?? 0}
            onChange={(event) => {
              const nextRuns =
  event.target.value === ""
    ? null
    : Number(event.target.value);

setRunOutRuns(nextRuns);

setBallForm((previous) => ({
  ...previous,
  runsOffBat:
    nextRuns === null
      ? "0"
      : String(nextRuns),
}));
            }}
          />
        </label>
      )}

    {/* Primary fielder */}
    {ballForm.isWicket &&
      ["CAUGHT", "STUMPED", "RUN_OUT"].includes(
        ballForm.wicketType
      ) && (
        <label>
          <span>
            {ballForm.wicketType === "CAUGHT"
              ? "Caught By"
              : ballForm.wicketType === "STUMPED"
                ? "Stumped By / Wicketkeeper"
                : "Run Out By"}
          </span>

          <select
            value={ballForm.fielderId || ""}
            onChange={(event) =>
              setBallForm((previous) => ({
                ...previous,
                fielderId: event.target.value,
              }))
            }
          >
            <option value="">
              Select fielder
            </option>

            {(bowlingTeam?.players || []).map(
              (player) => (
                <option
                  key={player.id}
                  value={player.id}
                >
                  {player.name}
                </option>
              )
            )}
          </select>
        </label>
      )}

    {/* Assisted run-out fielder */}
    {ballForm.isWicket &&
      ballForm.wicketType === "RUN_OUT" && (
        <label>
          <span>
            Assisted By / Stumps Broken By
          </span>

          <select
            value={
              ballForm.assistantFielderId || ""
            }
            onChange={(event) =>
              setBallForm((previous) => ({
                ...previous,
                assistantFielderId:
                  event.target.value,
              }))
            }
          >
            <option value="">Optional</option>

            {(bowlingTeam?.players || []).map(
              (player) => (
                <option
                  key={player.id}
                  value={player.id}
                >
                  {player.name}
                </option>
              )
            )}
          </select>
        </label>
      )}

    {/* New batter */}
    <label>
      <span>New Batter</span>

      <select
        value={ballForm.newBatterId || ""}
        disabled={!ballForm.isWicket}
        onChange={(event) =>
          setBallForm((previous) => ({
            ...previous,
            newBatterId: event.target.value,
          }))
        }
      >
        <option value="">
          Select new batter
        </option>

        {wicketNewBatterOptions.map((player) => (
          <option
            key={player.id}
            value={player.id}
          >
            {player.name}
          </option>
        ))}
      </select>
    </label>

    {/* Optional note */}
    <label className="full-span">
      <span>Note</span>

      <input
        type="text"
        value={ballForm.note || ""}
        onChange={(event) =>
          setBallForm((previous) => ({
            ...previous,
            note: event.target.value,
          }))
        }
        placeholder="Optional delivery note"
      />
    </label>
  </form>

  {/* Sticky form actions */}
  <div className="scoring-form-sheet-actions">
    <button
      type="button"
      className="btn btn-outline"
      onClick={closeScoringFormSheet}
    >
      Cancel
    </button>

<button
  type="submit"
  form="scorer-mode-ball-form"
  className="btn scoring-form-sheet-submit"
  disabled={
    scoringFormSubmitting ||
    isMatchCompleted ||
    isMatchLocked ||
    isMatchAbandoned
  }
>
  {scoringFormSubmitting
    ? "Saving..."
    : "🏏 Submit Delivery"}
</button>

  </div>
</div>
        </div>
      </section>
    </div>,
    document.body
  )}
{showRetiredHurtModal && typeof document !== "undefined" && createPortal(
  <div className="modal-backdrop">
    <div className="modal-card">
        <div className="live-popup-snapshot">
          <div className="live-popup-topline">
            <span className="live-dot">
              ● LIVE
            </span>

            <span className="live-popup-over">
              Over {bowlerChangeScore.overs}
            </span>
          </div>

          <div className="live-popup-main">
            <div>
              <span>Current Score</span>

              <strong>
                {bowlerChangeScore.score}
              </strong>
            </div>

            <div>
              <span>CRR</span>

              <strong>
                {bowlerChangeScore.crr}
              </strong>
            </div>
          </div>

          <div className="live-popup-recent">
            <div className="live-popup-recent-head">
              <span>Current Over</span>

              <b>
                Over {extrasModalCurrentOver.overNo}
              </b>
            </div>

            <div className="live-popup-recent-direction">
              ← Latest delivery
            </div>

            <div className="live-popup-balls">
              {extrasModalCurrentOver.balls.length ? (
                extrasModalCurrentOver.balls.map(
                  (ball, index) => {
                    const label =
                      ball.shortText ||
                      ball.displayText ||
                      ball.resultText ||
                      ball.label ||
                      "";

                    const result = String(label)
                      .replace(
                        /^\s*\d+\.\d+\s*/,
                        ""
                      )
                      .replace(/[()]/g, "")
                      .trim();

                    const normalized =
                      result.toUpperCase();

                    const ballClass =
                      normalized === "W" ||
                      normalized === "WKT"
                        ? "wicket"
                        : normalized === "4"
                          ? "four"
                          : normalized === "6"
                            ? "six"
                            : normalized.startsWith(
                                  "WD"
                                ) ||
                                normalized.includes(
                                  "WIDE"
                                )
                              ? "wide"
                              : normalized.startsWith(
                                    "NB"
                                  ) ||
                                  normalized.includes(
                                    "NO BALL"
                                  ) ||
                                  normalized.includes(
                                    "NOBALL"
                                  )
                                ? "noball"
                                : "";

                    return (
                      <b
                        key={
                          ball.id ||
                          ball.sequence ||
                          `extra-recent-${index}`
                        }
                        className={`${ballClass} ${
                          index === 0
                            ? "latest"
                            : ""
                        }`}
                      >
                        {result || "-"}
                      </b>
                    );
                  }
                )
              ) : (
                <small>
                  No deliveries in the current
                  over yet
                </small>
              )}
            </div>
          </div>
        </div>
<h3>🚑 Retired Hurt</h3>

<p
  style={{
    opacity: 0.75,
    marginBottom: 20
  }}
>
  Choose the retiring batter and select a replacement.
</p>

      <label>
        Who is retiring?
      </label>

<div   style={{
    display: "grid",
    gap: 10,
    marginBottom: 20
  }} className="retired-hurt-options">
<button
  type="button"
  className={`btn ${
    retiredPlayerType === "STRIKER"
      ? "btn-selected"
      : "btn-outline"
  }`}
  onClick={() => {
    setRetiredPlayerType("STRIKER");
    setReplacementPlayerId("");
    setShowRetiredHurtModal(true);
  }}
>
  ✅ Retire Striker (
  {scoreboard?.currentState?.strikerName}
  )
</button>

<button
  type="button"
  className={`btn ${
    retiredPlayerType === "NON_STRIKER"
      ? "btn-selected"
      : "btn-outline"
  }`}
  onClick={() => {
    setRetiredPlayerType("NON_STRIKER");
    setReplacementPlayerId("");
    setShowRetiredHurtModal(true);
  }}
>
  ✅ Retire Non-Striker (
  {scoreboard?.currentState?.nonStrikerName}
  )
</button>
</div>

      <label>
        Replacement Batter
      </label>

      <select
        value={replacementPlayerId}
        onChange={(e) =>
          setReplacementPlayerId(
            e.target.value
          )
        }
      >
        <option value="">
          Select Batter
        </option>

 {availableReplacementBatters.map((player) => (
            <option
              key={player.id}
              value={player.id}
            >
              {player.name}
            </option>
          ))}
      </select>

<div className="modal-actions">
  <button
    className="btn btn-outline"
    onClick={() =>
      setShowRetiredHurtModal(false)
    }
  >
    Cancel
  </button>

  <button
    className="btn"
    onClick={handleRetiredHurtSubmit}
  >
    Confirm Replacement
  </button>
</div>
    </div>
  </div>,
  document.body
)}

{milestoneCelebration &&
  typeof document !==
    "undefined" &&
  createPortal(
    <div
      className="milestone-celebration-overlay"
      role="dialog"
      aria-modal="true"
      aria-label="Milestone unlocked"
    >
      <section className="milestone-celebration-card">
        <button
          type="button"
          className="milestone-celebration-close"
          onClick={() =>
            setMilestoneCelebration(
              null
            )
          }
          aria-label="Close milestone celebration"
        >
          ×
        </button>

        <div
          className="milestone-celebration-icon"
          aria-hidden="true"
        >
          {milestoneCelebration
            .primary
            ?.icon ||
            "🏆"}
        </div>

        <p>
          MILESTONE UNLOCKED
        </p>

        <h2>
          {milestoneCelebration
            .primary
            ?.playerName}
        </h2>

        <h3>
          {milestoneCelebration
            .primary
            ?.title}
        </h3>

        <span>
          {milestoneCelebration
            .primary
            ?.description}
        </span>

        {milestoneCelebration
          .all.length >
          1 && (
          <small>
            +
            {milestoneCelebration
              .all.length -
              1}{" "}
            more milestone
            {milestoneCelebration
              .all.length -
              1 ===
            1
              ? ""
              : "s"}{" "}
            unlocked on this delivery
          </small>
        )}

        <div className="milestone-celebration-actions">
          <button
            type="button"
            className="milestone-continue-button"
            onClick={() =>
              setMilestoneCelebration(
                null
              )
            }
          >
            Continue scoring
          </button>

          <Link
            className="milestone-player-card-link"
            href={`/leagues/${encodeURIComponent(
              String(
                selectedLeague?.slug ||
                activeLeague?.slug ||
                activeLeagueId
              )
            )}/players/${encodeURIComponent(
              String(
                milestoneCelebration
                  .primary
                  .playerId
              )
            )}`}
            onClick={() =>
              setMilestoneCelebration(
                null
              )
            }
          >
            View player card
          </Link>
        </div>
      </section>
    </div>,
    document.body
  )}

{correctionSaving && (
  <div className="correction-overlay">
    <div className="correction-card">
      <div className="spinner" />

      <h3>Recalculating Scorecard</h3>

      <p>
        Replaying deliveries from 7.1 onwards.
      </p>
    </div>
  </div>
)}
{postMatchKitPrompt &&
  typeof document !== "undefined" &&
  createPortal(
    <div
      className="post-match-kit-prompt-top-layer"
      style={{
        position: "fixed",
        inset: 0,
        zIndex: 2147483000,
        pointerEvents: "auto",
      }}
      role="presentation"
    >
      <KitPostMatchPrompt
        open={true}
        matchLabel={
          postMatchKitPrompt?.matchLabel || ""
        }
        taskCount={
          postMatchKitPrompt?.taskCount || 0
        }
        warning={
          postMatchKitPrompt?.warning || ""
        }
        onRecordNow={
          openKitFromPostMatchPrompt
        }
        onLater={() => {
          const handledMatchId =
            Number(
              postMatchKitPrompt
                ?.matchId ||
              selectedMatchId
            );

          if (
            Number.isInteger(handledMatchId) &&
            handledMatchId > 0
          ) {
            postMatchKitAutoPromptedRef
              .current
              .add(handledMatchId);
          }

          setPostMatchKitPrompt(
            null
          );
        }}
      />
    </div>,
    document.body
  )}
{showInviteRoleModal &&
  activeLeague &&
  typeof document !== "undefined" &&
  createPortal(
    <div
      role="presentation"
      onMouseDown={(event) => {
        if (event.target === event.currentTarget && !inviteGenerating) {
          setShowInviteRoleModal(false);
        }
      }}
      style={{
        position: "fixed",
        inset: 0,
        zIndex: 2147482500,
        background: "rgba(2,6,23,.72)",
        display: "grid",
        placeItems: "center",
        padding: 16,
      }}
    >
      <section
        role="dialog"
        aria-modal="true"
        aria-label="Create league invitation"
        style={{
          width: "min(560px, 100%)",
          maxHeight: "88vh",
          overflowY: "auto",
          borderRadius: 16,
          padding: 20,
          background: "#0f172a",
          color: "#f8fafc",
          border: "1px solid rgba(148,163,184,.35)",
          boxShadow: "0 24px 70px rgba(0,0,0,.45)",
        }}
      >
        <div style={{ display: "flex", justifyContent: "space-between", gap: 16 }}>
          <div>
            <small style={{ opacity: 0.75 }}>Invite member to</small>
            <h3 style={{ margin: "4px 0 0" }}>{activeLeague.name}</h3>
          </div>

          <button
            type="button"
            className="btn btn-outline"
            disabled={inviteGenerating}
            onClick={() => setShowInviteRoleModal(false)}
            aria-label="Close invite dialog"
          >
            ✕
          </button>
        </div>

        <p style={{ marginBottom: 16, opacity: 0.86 }}>
          The selected role is securely bound to the invite link. The recipient cannot change it.
        </p>

        <label style={{ display: "block" }}>
          <strong>Role</strong>
          <select
            value={selectedInviteRole}
            onChange={(event) => setSelectedInviteRole(event.target.value)}
            style={{ width: "100%", marginTop: 8 }}
          >
            {allowedInviteRolesForCurrentUser.map((role) => (
              <option key={role} value={role}>
                {ROLE_LABELS[role] || role}
              </option>
            ))}
          </select>
        </label>

        {selectedInviteRole === "OWNER" && (
          <div className="permission-warning" style={{ marginTop: 12 }}>
            ⚠️ Owner is the highest league role. Only share this link with a trusted co-owner.
          </div>
        )}

        <div
          style={{
            marginTop: 16,
            padding: 14,
            borderRadius: 12,
            background: "rgba(148,163,184,.12)",
          }}
        >
          <strong>Default permissions</strong>
          <div style={{ marginTop: 8, display: "grid", gap: 5, fontSize: 13 }}>
            {Object.entries(getRolePermissionDefaults(selectedInviteRole))
              .filter(([, enabled]) => enabled === true)
              .map(([permission]) => (
                <span key={permission}>
                  ✓ {permission.replace(/^can/, "").replace(/([A-Z])/g, " $1").trim()}
                </span>
              ))}
          </div>
        </div>

        <div style={{ display: "flex", gap: 10, marginTop: 18, flexWrap: "wrap" }}>
          <button
            type="button"
            className="btn"
            disabled={inviteGenerating}
            onClick={() => generateInviteLink(activeLeague.id, selectedInviteRole)}
          >
            {inviteGenerating
              ? "Creating…"
              : `📋 Copy ${ROLE_LABELS[selectedInviteRole] || selectedInviteRole} Invite Link`}
          </button>

          <button
            type="button"
            className="btn btn-outline"
            disabled={inviteGenerating}
            onClick={() => setShowInviteRoleModal(false)}
          >
            Cancel
          </button>
        </div>
      </section>
    </div>,
    document.body
  )}
{toast && (
  <div
    className={`toast-popup ${
      toast.type === "error" ? "toast-error" : "toast-success"
    }`}
  >
    {toast.text}
  </div>
)}
  </>
);
}