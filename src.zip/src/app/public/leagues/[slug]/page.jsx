import { permanentRedirect } from "next/navigation";

export default async function OldPublicLeagueRedirect({ params }) {
  const { slug } = await params;

  permanentRedirect(`/leagues/${slug}`);
}