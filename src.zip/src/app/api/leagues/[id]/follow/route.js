import {
  NextResponse,
} from "next/server";
import {
  getServerSession,
} from "next-auth";
import prisma from "@/lib/prisma";
import {
  authOptions,
} from "@/lib/auth";
import {
  resolveFollowableLeague,
  resolveLeagueReference,
} from "@/lib/league-follow-ref";

export const runtime =
  "nodejs";

async function getCurrentUser() {
  const session =
    await getServerSession(
      authOptions
    );

  if (
    !session?.user?.email
  ) {
    return null;
  }

  return prisma.user.findUnique({
    where: {
      email:
        session.user.email,
    },
    select: {
      id: true,
    },
  });
}

export async function POST(
  request,
  {
    params,
  }
) {
  const {
    leagueId:
      leagueRef,
  } =
    await params;

  const user =
    await getCurrentUser();

  if (!user) {
    return NextResponse.json(
      {
        error:
          "Please sign in to follow this league.",
      },
      {
        status:
          401,
      }
    );
  }

  const league =
    await resolveFollowableLeague(
      leagueRef
    );

  if (!league) {
    return NextResponse.json(
      {
        error:
          "Cric4All could not resolve this league. Refresh the page and try again.",
      },
      {
        status:
          404,
      }
    );
  }

  const follower =
    await prisma.leagueFollower.upsert({
      where: {
        userId_leagueId: {
          userId:
            user.id,
          leagueId:
            league.id,
        },
      },
      update: {},
      create: {
        userId:
          user.id,
        leagueId:
          league.id,
      },
      select: {
        id: true,
        alertsEnabled: true,
        alertMatchStart: true,
        alertMatchResult: true,
      },
    });

  return NextResponse.json({
    success:
      true,
    followed:
      true,
    leagueId:
      league.id,
    leagueSlug:
      league.slug,
    follower,
    league,
  });
}

export async function DELETE(
  request,
  {
    params,
  }
) {
  const {
    leagueId:
      leagueRef,
  } =
    await params;

  const user =
    await getCurrentUser();

  if (!user) {
    return NextResponse.json(
      {
        error:
          "Please sign in to update followed leagues.",
      },
      {
        status:
          401,
      }
    );
  }

  /*
   * Do not require PUBLIC/UNLISTED here.
   * If a followed league later becomes private, the user must still be able
   * to unfollow it cleanly.
   */
  const league =
    await resolveLeagueReference(
      leagueRef
    );

  if (!league) {
    return NextResponse.json(
      {
        error:
          "The league could not be resolved.",
      },
      {
        status:
          404,
      }
    );
  }

  await prisma.$transaction([
    prisma.leagueAlertDelivery.deleteMany({
      where: {
        userId:
          user.id,
        leagueId:
          league.id,
      },
    }),

    prisma.leagueFollower.deleteMany({
      where: {
        userId:
          user.id,
        leagueId:
          league.id,
      },
    }),
  ]);

  return NextResponse.json({
    success:
      true,
    followed:
      false,
    leagueId:
      league.id,
    leagueSlug:
      league.slug,
  });
}
