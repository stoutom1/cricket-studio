import {
  NextResponse,
} from "next/server";
import {
  getServerSession,
} from "next-auth";
import prisma from "@/lib/prisma";
import {
  authOptions,
} from "@/lib/auth";
import {
  resolveLeagueReference,
} from "@/lib/league-follow-ref";

export const runtime =
  "nodejs";

async function requireUser() {
  const session =
    await getServerSession(
      authOptions
    );

  if (
    !session?.user?.email
  ) {
    return null;
  }

  return prisma.user.findUnique({
    where: {
      email:
        session.user.email,
    },
    select: {
      id: true,
    },
  });
}

async function getState(
  userId,
  leagueId
) {
  const follower =
    await prisma.leagueFollower.findUnique({
      where: {
        userId_leagueId: {
          userId,
          leagueId,
        },
      },
      select: {
        id: true,
        alertsEnabled: true,
        alertMatchStart: true,
        alertMatchResult: true,
      },
    });

  const activePushDevices =
    await prisma.webPushSubscription.count({
      where: {
        userId,
        isActive:
          true,
      },
    });

  return {
    followed:
      Boolean(
        follower
      ),
    alertsEnabled:
      Boolean(
        follower
          ?.alertsEnabled
      ),
    alertMatchStart:
      follower
        ?.alertMatchStart ??
      true,
    alertMatchResult:
      follower
        ?.alertMatchResult ??
      true,
    pushReady:
      activePushDevices >
      0,
  };
}

async function resolveRequest(
  params
) {
  const {
    leagueId:
      leagueRef,
  } =
    await params;

  const league =
    await resolveLeagueReference(
      leagueRef
    );

  return {
    leagueRef,
    league,
  };
}

export async function GET(
  request,
  {
    params,
  }
) {
  const user =
    await requireUser();

  if (!user) {
    return NextResponse.json(
      {
        error:
          "Sign in to manage match alerts.",
      },
      {
        status:
          401,
      }
    );
  }

  const {
    league,
  } =
    await resolveRequest(
      params
    );

  if (!league) {
    return NextResponse.json(
      {
        error:
          "The league could not be resolved.",
      },
      {
        status:
          404,
      }
    );
  }

  return NextResponse.json({
    leagueId:
      league.id,
    leagueSlug:
      league.slug,
    ...(
      await getState(
        user.id,
        league.id
      )
    ),
  });
}

export async function PATCH(
  request,
  {
    params,
  }
) {
  const user =
    await requireUser();

  if (!user) {
    return NextResponse.json(
      {
        error:
          "Sign in to manage match alerts.",
      },
      {
        status:
          401,
      }
    );
  }

  const {
    league,
  } =
    await resolveRequest(
      params
    );

  if (!league) {
    return NextResponse.json(
      {
        error:
          "The league could not be resolved.",
      },
      {
        status:
          404,
      }
    );
  }

  const follower =
    await prisma.leagueFollower.findUnique({
      where: {
        userId_leagueId: {
          userId:
            user.id,
          leagueId:
            league.id,
        },
      },
      select: {
        id: true,
      },
    });

  if (!follower) {
    return NextResponse.json(
      {
        error:
          "Follow this league before enabling match alerts.",
      },
      {
        status:
          409,
      }
    );
  }

  const body =
    await request.json();

  const data = {};

  if (
    typeof body
      ?.alertsEnabled ===
    "boolean"
  ) {
    data.alertsEnabled =
      body.alertsEnabled;
  }

  if (
    typeof body
      ?.alertMatchStart ===
    "boolean"
  ) {
    data.alertMatchStart =
      body.alertMatchStart;
  }

  if (
    typeof body
      ?.alertMatchResult ===
    "boolean"
  ) {
    data.alertMatchResult =
      body.alertMatchResult;
  }

  await prisma.leagueFollower.update({
    where: {
      id:
        follower.id,
    },
    data,
  });

  return NextResponse.json({
    success:
      true,
    leagueId:
      league.id,
    leagueSlug:
      league.slug,
    ...(
      await getState(
        user.id,
        league.id
      )
    ),
  });
}
