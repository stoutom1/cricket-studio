import { NextResponse } from "next/server";
import prisma from "@/lib/prisma";
import {
  ballShortText,
  getBattingTeamId,
  summarizeInningsDetailed,
  buildMatchStats
} from "@/lib/scoring";
import { buildSuperOverView } from "@/lib/super-over-view";

function normalizeBattingStatsForRetiredHurt(battingStats, balls) {
  const retiredHurtIds = new Set();

  for (const ball of balls || []) {
    const wicketType = String(ball.wicketType || "")
      .trim()
      .toUpperCase();

    if (wicketType === "RETIRED_HURT" && ball.dismissedPlayerId) {
      retiredHurtIds.add(Number(ball.dismissedPlayerId));
    }

    // If the same retired-hurt player bats again later, remove retired hurt status
    if (ball.strikerId) {
      retiredHurtIds.delete(Number(ball.strikerId));
    }

    if (ball.nonStrikerId) {
      retiredHurtIds.delete(Number(ball.nonStrikerId));
    }

    if (ball.newBatterId) {
      retiredHurtIds.delete(Number(ball.newBatterId));
    }
  }

  return (battingStats || []).map((row) => {
    const isRetiredHurt = retiredHurtIds.has(Number(row.playerId));

    return {
      ...row,
      isRetiredHurt,
      dismissal: isRetiredHurt
        ? "Retired hurt"
        : row.dismissal || "not out",
    };
  });
}

export async function GET(request, { params }) {
const { matchId: matchIdParam } = await params;

const numericMatchId = Number(matchIdParam);

  const match = await prisma.match.findFirst({
    where: {
      OR: [
        {
          shareCode: matchIdParam,
        },
        ...(!Number.isNaN(numericMatchId)
          ? [
              {
                id: numericMatchId,
              },
            ]
          : []),
      ],
    },
    include: {
      teamA: {
        include: {
          players: true,
        },
      },
      teamB: {
        include: {
          players: true,
        },
      },
      balls: {
        orderBy: {
          sequence: "asc",
        },
      },
      events: {
        orderBy: {
          id: "asc",
        },
      },
    },
  });

  if (!match) {
    return NextResponse.json(
      { error: "Match not found" },
      { status: 404 }
    );
  }

  const superOver = buildSuperOverView(match);

  const playerMap = new Map();

  [
    ...(match.teamA.players || []),
    ...(match.teamB.players || []),
  ].forEach((player) => {
    playerMap.set(player.id, player);
  });

  const innings1Balls = match.balls.filter(
    (b) => b.inningsNo === 1
  );

  const innings2Balls = match.balls.filter(
    (b) => b.inningsNo === 2
  );

const innings1Summary =
  summarizeInningsDetailed(
    innings1Balls,
    playerMap,
    match.oversPerInnings
  );

const innings2Summary =
  summarizeInningsDetailed(
    innings2Balls,
    playerMap,
    match.oversPerInnings
  );

const innings1MatchStats = buildMatchStats({
  ...match,
  balls: innings1Balls
});

const innings2MatchStats = buildMatchStats({
  ...match,
  balls: innings2Balls
});
const innings1TeamId = getBattingTeamId(match, 1);
const innings2TeamId = getBattingTeamId(match, 2);

const innings1TeamName =
  innings1TeamId === match.teamAId
    ? match.teamA.name
    : match.teamB.name;

const innings2TeamName =
  innings2TeamId === match.teamAId
    ? match.teamA.name
    : match.teamB.name;

const inningsData = [
  {
    number: 1,
    teamName: innings1TeamName,
    ...innings1Summary,
    battingStats: normalizeBattingStatsForRetiredHurt(
      innings1MatchStats.batting,
      innings1Balls
    ),
    bowlingStats: innings1MatchStats.bowling
  },
  {
    number: 2,
    teamName: innings2TeamName,
    ...innings2Summary,
    battingStats: normalizeBattingStatsForRetiredHurt(
      innings2MatchStats.batting,
      innings2Balls
    ),
    bowlingStats: innings2MatchStats.bowling
  }
];
 const currentInningsNo =
  match.innings1EndedManually ||
  innings2Summary.legalBalls > 0 ||
  match.status === "COMPLETED" ||
  match.status === "COMPLETED_CORRECTED" ||
  match.status === "COMPLETED_LOCKED"
    ? 2
    : 1;

const currentInningsBalls = match.balls.filter(
  (b) => b.inningsNo === currentInningsNo
);

  const recentBalls = currentInningsBalls
    .slice(-12)
    .reverse()
    .map((ball) => ({
      id: ball.id,
      label: ballShortText(ball)
  }));

  const maxLegalBalls = match.oversPerInnings * 6;

  const innings1Complete =
    innings1Summary.legalBalls >= maxLegalBalls ||
    innings2Balls.length > 0;

  const target = innings1Complete
    ? innings1Summary.runs + 1
    : null;

  const remainingBalls =
  innings1Complete
    ? Math.max(
        maxLegalBalls - innings2Summary.legalBalls,
        0
      )
    : null;

      const innings2Complete =
        innings2Summary.legalBalls >= maxLegalBalls;

      const chaseCompleted =
        target &&
        innings2Summary.runs >= target;

      const maxWickets =
        match.maxWicketsPerInnings ??
        ((innings2TeamId.battingTeam?.players?.length) -1);


      const allOut =
        innings2Summary.wickets >= maxWickets;

 
      const isCompleted =
        innings1Complete &&
        (
          innings2Complete ||  chaseCompleted || match.status === "COMPLETED_LOCKED" || match.status === "COMPLETED" || match.status === "COMPLETED_CORRECTED"
        );

      let statusText = "Match in progress";

      if(match.status === "ABANDONED"){
        statusText = "Match is Abandoned";
      }

      if (isCompleted) {
        if (innings2Summary.runs >= target) {
          //const wicketsRemaining = maxWicketsPerInnings;
            //10 - innings2Summary.wickets;

          statusText = `${innings2TeamName} won by chasing the target`;
          //by ${wicketsRemaining} wickets`;
        } else if (
          innings2Summary.runs === innings1Summary.runs
        ) {
          statusText = "Match tied";
        } else {
          const margin =
            innings1Summary.runs -
            innings2Summary.runs;

          statusText = `${innings1TeamName} won by ${margin} runs`;
        }

 /*       // UPDATE MATCH STATUS
        await prisma.match.update({
          where: { id: match.id },
          data: {
            status: "COMPLETED",
            statusText
          }
        });
*/
        match.status = "COMPLETED";
      }else {
        match.status = "LIVE";
      }

      if (superOver.completed) {
        statusText = superOver.resultText || match.statusText || "Match completed via Super Over";
      } else if (superOver.active) {
        statusText = `Super Over ${superOver.round} in progress`;
      } else if (superOver.tied) {
        statusText = `Super Over ${superOver.round} tied — another Super Over required`;
      }

return NextResponse.json({
  match: {
    id: match.id,
    shareCode: match.shareCode,
    teamAName: match.teamA.name,
    teamBName: match.teamB.name,
    battingFirstTeamId: match.battingFirstTeamId,
    oversPerInnings: match.oversPerInnings,
    powerplayOversInnings: match.powerplayOversInnings,
    status: match.status,
    statusText: superOver.completed
      ? (superOver.resultText || match.statusText || statusText)
      : statusText,
    resultText: superOver.completed
      ? (superOver.resultText || match.statusText || statusText)
      : null,
  },

  summary: {
    target: superOver.exists ? null : target,
    remainingBalls: superOver.exists ? null : remainingBalls,
    statusText,
    resultText: superOver.completed
      ? (superOver.resultText || match.statusText || statusText)
      : null
  },

  superOver,

  innings: inningsData,

  currentInnings: currentInningsNo,

  currentState:
    innings2Summary.legalBalls > 0
      ? innings2Summary.currentState
      : innings1Summary.currentState,

  recentBalls,

  stats: buildMatchStats(match),
});
}